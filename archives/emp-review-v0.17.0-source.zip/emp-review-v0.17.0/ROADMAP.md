## Completed: app 0.13.0

- Bounded multi-stage synthesis, checkpointed after each AI request.
- Resume/pause UI with counts for all selected claims and approved figure observations.
- Conditional owner-scoped leases and idempotent finalisation.
- Complete original input and intermediate provenance retained in the synthesis snapshot.

## Completed: English-only UX pass
- English UI and Word template; English defaults enforced for new AI requests.
- Unsaved draft/import protection, source return action and consistent export messages.
- Auditable presentation translation of legacy Polish Word passages; original data preserved.

## Suggested next iteration
- Persist a reusable English rendering per assessment revision to avoid repeated translation costs.
- Add a resumable server-side job queue and explicit per-stage cost/usage feedback.
- Run task-based usability sessions covering import, source checking, adjudication and export.

# Next iteration after app 0.11

Implemented: full v0.5 reviewer forms, explicit adjudication selection in project synthesis, field-by-field comparisons, consistently English teaching example, article-linked figures with optional AI interpretation and review history, frozen figures in new rounds, separate method/form/app/assessment version metadata, resumable coordinator adjudication drafts, and explicit selection of approved figure observations in project synthesis and export. EMP remains v0.5.

## 1. Adjudication ergonomics
Give every unmatched submitted claim an explicit disposition. Allow reviewers to carry a chosen source passage or checked visual observation into an adjudication with an exact origin link and rationale. Do not merge sidecar AI observations automatically. Pilot independent and assisted rounds with real authorized accounts.

## 2. Selective figure extraction and synthesis
Extract relevant figures and legends from PDF pages, avoiding duplicate image uploads. Add explicit claim-to-figure provenance and a human decision on whether a visual observation changes coding. The current explicit selection and fingerprint mechanism already supports checked observations in project interpretation; extend it to claim-level coding changes with a separate human rationale. Source images, captions and conceptual models must not become independent studies or numerical evidence by default.

## 3. A defined next manual
Before enabling manual 0.6, publish its normative differences from 0.5, classify changes as wording/form/rule changes, and map stable field IDs. Preview affected assessments, preserve earlier records, and create a separate evaluation rather than relabelling results. A formatting change alone must not invalidate scientific coding.

## 4. Durable analysis jobs
Add a supported queue and worker infrastructure with cancellation, bounded cost, idempotency and checkpoint reuse. Closing the browser should not abandon an accepted job. The current automatic pipeline and figure analysis remain foreground workflows; the hosting bindings currently provide D1/R2, not an autonomous task queue.

## Evaluation before wider rollout
Measure omitted claims, source errors, incorrect acceptance, reviewer time and workload on independently adjudicated cases. Check whether synthesis faithfully reflects selected assessments and uncertainty. Treat improved reliability as an empirical question, not a consequence of agreement between model runs.
