import {getChatGPTUser} from '@/app/chatgpt-auth';
import {AppError,db,failure,jsonBody,sameOrigin} from '@/lib/server';
import {ProfileStore} from '@/lib/profile-store';
export const dynamic='force-dynamic';

async function store() {
  const user = await getChatGPTUser();
  if (!user) throw new AppError('Sign in to manage your account.',401);
  return new ProfileStore(db(),user.id,user);
}
const response = (profile: unknown) => Response.json(profile,{headers:{'Cache-Control':'private, no-store'}});
export async function GET() {
  try {return response(await (await store()).get());} catch(e) {return failure(e);}
}
export async function PATCH(req: Request) {
  try {sameOrigin(req);const profiles=await store();return response(await profiles.save(await jsonBody(req,4000)));} catch(e) {return failure(e);}
}
