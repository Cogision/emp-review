import { parseAiSettings } from "@/lib/ai-settings";
import { requestOpenAi } from "@/lib/ai-client";
import { bindings, owner, sameOrigin, jsonBody, failure, AppError } from "@/lib/server";

export async function POST(req: Request) {
  try {
    sameOrigin(req);
    await owner();
    const {key, model} = parseAiSettings(await jsonBody(req, 10000), {key: bindings().OPENAI_API_KEY, model: bindings().OPENAI_MODEL});
    const raw = await requestOpenAi({key, model, instructions: 'Return only this JSON object: {"ok":true}. This is a connection test.', input: 'Return JSON: {"ok":true}', maxOutputTokens: 1024});
    let valid = false;
    try { valid = JSON.parse(raw)?.ok === true; } catch { /* No source or partial evaluation is saved. */ }
    if (!valid) throw new AppError("Model odpowiedział, ale wynik testu JSON był nieprawidłowy. Analiza wymaga zgodnego formatu odpowiedzi.", 502);
    return Response.json({model, message: "Połączenie działa. Model odpowiedział w formacie wymaganym przez aplikację. Możesz uruchomić analizę dokumentu."});
  } catch (e) { return failure(e); }
}
