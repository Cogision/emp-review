import {newManifest} from '@/lib/versions';
import { parseAiSettings } from "@/lib/ai-settings";
import { analyze } from "@/lib/analyzer";
import { bindings, db, owner, rowFor, sourceFor, sameOrigin, jsonBody, failure, AppError, updateDoc } from "@/lib/server";
export async function POST(req:Request,ctx:{params:Promise<{id:string}>}){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);
 if(await db().prepare("SELECT 1 FROM events WHERE document_id=? AND owner=? AND kind='automatic_checkpoint' LIMIT 1").bind(id,who).first())throw new AppError("Ten przegląd rozpoczęto automatycznie. Użyj „Analiza automatyczna v0.5 / wznów”.",409);
 if(row.analysis)throw new AppError("Analiza jest już zapisana. Aby zachować jej historię, dodaj dokument ponownie dla nowego przebiegu.",409);
 const body=await jsonBody(req,10000);const language="en" as const;
 const {key,model}=parseAiSettings(body,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});
 const analysis=await analyze(await sourceFor(row),row.stage,row.coverage,key,model,language);analysis.sourceHash=row.source_hash;analysis.versions=newManifest("core");
 return Response.json(await updateDoc(row,analysis,JSON.parse(row.review),"analysis",{model,sourceHash:row.source_hash,promptVersion:analysis.promptVersion,claimCount:analysis.claims.length}));
 }catch(e){return failure(e);}}
