import {legacyManifest,codingScope,type VersionManifest} from '@/lib/versions';
import {db,owner,rowFor,fullDoc,sourceFor,bindings,failure,AppError} from "@/lib/server";
import type {AssessmentMeta,AssessmentState} from "@/lib/assessment-comparison";
import type {Analysis,Review} from "@/lib/emp";
export async function GET(req:Request,ctx:{params:Promise<{id:string}>}){try{
 const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),selected=new URL(req.url).searchParams.get("snapshot");
 const current:AssessmentMeta={id:`current:${row.revision}`,document_id:id,revision:row.revision,stage:row.stage,source_hash:row.source_hash,manual_version:codingScope(row.analysis?JSON.parse(row.analysis):null,JSON.parse(row.review))==="full"?"v0.5":"v0.5-core",model:row.analysis?JSON.parse(row.analysis).model||null:null,actor_type:"current",created_at:row.updated_at};
 if(selected===current.id){if(!row.analysis)throw new AppError("This report has no saved analysis.",409);return Response.json({meta:current,document:await fullDoc(row),kind:"current"} satisfies AssessmentState);}
 if(selected){
  const saved=await db().prepare("SELECT * FROM assessment_runs WHERE id=? AND document_id=? AND owner=?").bind(selected,id,who).first<AssessmentMeta&{snapshot_key:string}>();
  if(!saved)throw new AppError("Saved assessment not found. Refresh the list.",404);
  const obj=await bindings().BUCKET.get(saved.snapshot_key);if(!obj)throw new AppError("The saved assessment is temporarily unavailable.",503);
  const snap=await obj.json<{documentId:string;revision:number;sourceHash:string;stage:string;analysis:Analysis;review:Review;kind:string;createdAt:string;versions?:VersionManifest}>();
  if(snap.documentId!==id||snap.revision!==saved.revision||snap.sourceHash!==saved.source_hash||snap.stage!==saved.stage||snap.sourceHash!==row.source_hash||!snap.analysis||!snap.review)throw new AppError("The assessment source could not be verified.",503);
  const {snapshot_key:ignored,...meta}=saved;void ignored;
  return Response.json({meta,document:{id,title:row.title,stage:snap.stage,coverage:row.coverage,sourceHash:snap.sourceHash,revision:snap.revision,analysis:snap.analysis,review:snap.review,versions:snap.versions||legacyManifest(snap.analysis,snap.review),createdAt:row.created_at,updatedAt:snap.createdAt,source:await sourceFor(row)},kind:snap.kind} satisfies AssessmentState);
 }
 const rows=await db().prepare("SELECT id,document_id,revision,stage,source_hash,manual_version,model,actor_type,created_at FROM assessment_runs WHERE document_id=? AND owner=? AND revision<? ORDER BY revision DESC LIMIT 100").bind(id,who,row.revision).all<AssessmentMeta>();
 return Response.json({assessments:row.analysis?[current,...rows.results]:rows.results});
 }catch(e){return failure(e);}}
