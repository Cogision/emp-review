import {newManifest} from '@/lib/versions';
import { z } from "zod";
import { parseAiSettings } from "@/lib/ai-settings";
import { AUTO_VERSION, discover, assessNext, completedAnalysis, type AutomaticState, type Generation } from "@/lib/automatic";
import { bindings, db, owner, rowFor, sourceFor, sameOrigin, jsonBody, failure, AppError, updateDoc, fullDoc, type Row } from "@/lib/server";
type Ctx={params:Promise<{id:string}>};
async function stateFor(row:Row){const last=await db().prepare("SELECT payload FROM events WHERE document_id=? AND owner=? AND kind='automatic_checkpoint' ORDER BY revision DESC LIMIT 1").bind(row.id,row.owner).first<{payload:string}>();if(!last)return null;const {stateKey}=JSON.parse(last.payload);const obj=await bindings().BUCKET.get(stateKey);if(!obj)throw new AppError("Nie można odczytać zapisanego etapu analizy.",503);return obj.json<AutomaticState>();}
export async function GET(req:Request,ctx:Ctx){try{const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),state=await stateFor(row);if(new URL(req.url).searchParams.get("export")==="1"){
 if(!state?.complete||!row.analysis)throw new AppError("Najpierw ukończ analizę automatyczną.",409);
 const audits=[];for(const a of state.audit){const obj=await bindings().BUCKET.get(`${row.source_key.replace(/text.json$/,"")}automatic/${state.runId}/audit/${a.id}.json`);if(!obj)throw new AppError("Brakuje aneksu odtwarzalności; ponów pobieranie.",503);audits.push(await obj.json());}
 return Response.json({document:await fullDoc(row),state,audits});
 }return Response.json({state,document:state?.complete?await fullDoc(row):null});}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);
 if(row.stage!=="B")throw new AppError("Tryb automatyczny v0.5 obsługuje pełny tekst (B) wraz z dostępnymi suplementami. Abstrakt i fragmenty oceń w trybie wspomaganym.");
 let state=await stateFor(row);
 if(state?.complete&&row.analysis)return Response.json({state,document:await fullDoc(row)});
 if(row.analysis)throw new AppError("Ten przegląd ma już analizę wspomaganą. Dodaj pliki jako nowy przegląd automatyczny, aby zachować oryginalne oceny.",409);
 const body=await jsonBody(req,10000);const language="en" as const;
 const {key,model}=parseAiSettings(body,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});
 if(state&&state.model!==model)throw new AppError(`Kontynuuj z modelem ${state.model}, z którym rozpoczęto ten przebieg. Dla innego modelu utwórz nowy przegląd.`,409);
 const source=await sourceFor(row),runId=state?.runId||crypto.randomUUID(),auditId=crypto.randomUUID();
 const prefix=`${row.source_key.replace(/text.json$/,"")}automatic/${runId}/`;
 let result,step;
 const recordAttempt=(kind:string,claimId:string|null)=>async (attempt:Generation,issues:string[])=>{
 const attemptId=crypto.randomUUID(),attemptKey=`${prefix}attempts/${attemptId}.json`;
 await bindings().BUCKET.put(attemptKey,JSON.stringify({...attempt,version:AUTO_VERSION,claimId,validationIssues:issues}),{httpMetadata:{contentType:"application/json"}});
 await db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) SELECT ?,id,owner,revision,?,?,? FROM documents WHERE id=? AND owner=?").bind(attemptId,kind,JSON.stringify({runId,claimId,version:AUTO_VERSION,attemptKey,requestHash:attempt.requestHash,outputHash:attempt.outputHash,issues}),attempt.createdAt,row.id,who).run();
 };
 if(!state){result=await discover(source,row.stage,row.coverage,key,model,language,recordAttempt('inventory_attempt',null));step="inventory";state={versions:newManifest("full"),runId,version:AUTO_VERSION,model,language,startedAt:result.createdAt,inventory:result.inventory,claims:[],audit:[],quality:{},complete:false};}
 else {const advanced=await assessNext(source,row.stage,row.coverage,key,model,state,recordAttempt('assessment_attempt',state.inventory.claims[state.claims.length]?.id||null));result=advanced.result;step=advanced.step;state=advanced.state;}
 // Immutable checkpoint and exact request/output records. API key and HTTP auth headers are never persisted.
 const audit={id:auditId,step,version:AUTO_VERSION,requestHash:result.requestHash,outputHash:result.outputHash,createdAt:result.createdAt};state.audit.push(audit);state.complete=state.claims.length===state.inventory.claims.length;
 const stateKey=`${prefix}state/${auditId}.json`;
 await bindings().BUCKET.put(`${prefix}audit/${auditId}.json`,JSON.stringify({...audit,version:AUTO_VERSION,request:result.request,rawOutput:result.raw,...("attempts" in result?{attempts:result.attempts,corrections:result.corrections}:{})}),{httpMetadata:{contentType:"application/json"}});
 await bindings().BUCKET.put(stateKey,JSON.stringify(state),{httpMetadata:{contentType:"application/json"}});
 const document=await updateDoc(row,state.complete?completedAnalysis(state,row.source_hash):null,JSON.parse(row.review),"automatic_checkpoint",{stateKey,runId,step,completed:state.claims.length,total:state.inventory.claims.length});
 return Response.json({state,document:state.complete?document:null});
 }catch(e){return e instanceof z.ZodError?Response.json({error:"Nieprawidłowe dane etapu analizy."},{status:400}):failure(e);}}
