import {z} from 'zod';
import {bindings,owner,sameOrigin,jsonBody,failure,AppError} from '@/lib/server';
import {FigureStore} from '@/lib/figure-store';
import {analyzeFigure} from '@/lib/figure-analyzer';
import {parseAiSettings} from '@/lib/ai-settings';
import type {Source} from '@/lib/emp';
export async function POST(req:Request,ctx:{params:Promise<{id:string;figureId:string}>}){try{
 sameOrigin(req);const who=await owner(),{id,figureId}=await ctx.params,env=bindings(),store=new FigureStore(env,who),doc=await store.document(id),body=await jsonBody(req,10000),runId=z.string().uuid().parse(body.runId);
 const existing=await store.runs(id,figureId),saved=existing.find(r=>r.id===runId);if(saved)return Response.json({run:saved});if(existing.length>=20)throw new AppError('This figure has reached 20 saved analyses.',409);
 const {figure,object}=await store.content(id,figureId);if(figure.archivedAt)throw new AppError('Restore the figure before analysing it.',409);
 const settings=parseAiSettings(body,{key:env.OPENAI_API_KEY,model:env.OPENAI_MODEL}),source=await env.BUCKET.get(doc.source_key);if(!source)throw new AppError('The article text is temporarily unavailable.',503);
 const run=await analyzeFigure(figure,new Uint8Array(await object.arrayBuffer()),await source.json<Source>(),doc.source_hash,{...settings,runId,language:"en" as const});
 return Response.json({run:await store.saveRun(id,figureId,run)});
 }catch(e){return e instanceof z.ZodError?Response.json({error:'The analysis request is invalid.'},{status:400}):failure(e);}}
