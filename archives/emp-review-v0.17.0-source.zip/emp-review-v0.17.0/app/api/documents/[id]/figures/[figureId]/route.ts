import {z} from 'zod';
import {bindings,owner,sameOrigin,jsonBody,failure} from '@/lib/server';
import {FigureStore} from '@/lib/figure-store';
type Ctx={params:Promise<{id:string;figureId:string}>};
export async function GET(req:Request,ctx:Ctx){try{
 const who=await owner(),{id,figureId}=await ctx.params,store=new FigureStore(bindings(),who);
 if(new URL(req.url).searchParams.has('image')){const {figure,object}=await store.content(id,figureId);return new Response(object.body,{headers:{'Content-Type':figure.mime,'Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(figure.fileName)}`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});}
 return Response.json({runs:await store.runs(id,figureId)});
 }catch(e){return failure(e);}}
export async function PATCH(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id,figureId}=await ctx.params,store=new FigureStore(bindings(),who),body=await jsonBody(req,10000);
 if(body.action==='archive'){const v=z.object({revision:z.number().int().nonnegative(),archived:z.boolean()}).parse(body);return Response.json({figure:await store.archive(id,figureId,v.revision,v.archived)});}
 const runId=z.string().uuid().parse(body.runId);return Response.json({review:await store.review(id,figureId,runId,body.review)});
 }catch(e){return e instanceof z.ZodError?Response.json({error:'The figure review is incomplete.'},{status:400}):failure(e);}}
