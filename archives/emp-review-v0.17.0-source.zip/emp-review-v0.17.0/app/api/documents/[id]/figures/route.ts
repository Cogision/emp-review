import {z} from 'zod';
import {bindings,owner,sameOrigin,failure,AppError} from '@/lib/server';
import {FigureStore} from '@/lib/figure-store';
import {figureInput,FIGURE_BYTES} from '@/lib/figures';
type Ctx={params:Promise<{id:string}>};
export async function GET(req:Request,ctx:Ctx){try{const who=await owner(),{id}=await ctx.params,store=new FigureStore(bindings(),who);return Response.json(new URL(req.url).searchParams.has('export')?await store.export(id):{figures:await store.list(id)});}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,store=new FigureStore(bindings(),who);await store.document(id);
 // Bound the body even when the browser omits Content-Length.
 const reader=req.body?.getReader(),parts:Uint8Array[]=[];let total=0;
 if(!reader)throw new AppError('Choose an image to upload.');
 while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>FIGURE_BYTES+24000){await reader.cancel();throw new AppError('Upload one figure per request, up to 3 MB.',413);}parts.push(value);}
 const body=new Uint8Array(total);let offset=0;for(const p of parts){body.set(p,offset);offset+=p.length;}
 const form=await new Response(body,{headers:{'Content-Type':req.headers.get('content-type')||''}}).formData(),file=form.get('file');
 if(!file||typeof file==='string')throw new AppError('Choose a PNG, JPEG or WebP image.');
 const input=figureInput.parse(Object.fromEntries(['id','label','caption','locator','sourceFileId'].map(k=>[k,form.get(k)||''])));
 return Response.json({figure:await store.upload(id,input,file.name,file.type,new Uint8Array(await file.arrayBuffer()))},{status:201});
 }catch(e){return e instanceof z.ZodError?Response.json({error:'Check the figure label, caption and parent file.'},{status:400}):failure(e);}}
