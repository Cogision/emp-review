import { z } from "zod";
import { originalKey, getOriginal } from "@/lib/source-bundle";
import { claimIssues, currentClaims, deriveBridge, reviewSchema, type Analysis } from "@/lib/emp";
import { db, bindings, owner, failure, sameOrigin, fullDoc, rowFor, sourceFor, updateDoc, jsonBody, AppError } from "@/lib/server";
type Ctx={params:Promise<{id:string}>};
export async function GET(req:Request,ctx:Ctx){try{const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);
 if(new URL(req.url).searchParams.has("original")){const source=await sourceFor(row),selected=getOriginal(source,new URL(req.url).searchParams.get("original"));const obj=await bindings().BUCKET.get(originalKey(row.source_key,selected.fileId));if(!obj)throw new AppError("Oryginał tego pliku jest niedostępny.",404);return new Response(obj.body,{headers:{"Content-Type":obj.httpMetadata?.contentType||"application/octet-stream","Content-Disposition":`attachment; filename*=UTF-8''${encodeURIComponent(selected.fileName)}`,"X-Content-Type-Options":"nosniff"}});}

 const history=await db().prepare("SELECT id,revision,kind,payload,created_at FROM events WHERE document_id=? AND owner=? ORDER BY revision ASC,created_at ASC").bind(id,who).all();return Response.json({...await fullDoc(row),history:history.results});
 }catch(e){return failure(e);}}
export async function PATCH(req:Request,ctx:Ctx){try{sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);const input=z.object({revision:z.number().int(),review:reviewSchema}).parse(await jsonBody(req));
 if(input.revision!==row.revision)throw new AppError("Dokument zmienił się w innej karcie. Otwórz go ponownie przed zapisaniem.",409);
 if(!row.analysis&&await db().prepare("SELECT 1 FROM events WHERE document_id=? AND owner=? AND kind='automatic_checkpoint' LIMIT 1").bind(id,who).first())throw new AppError("Najpierw ukończ rozpoczętą analizę automatyczną.",409);
 const source=await sourceFor(row),analysis:Analysis=row.analysis?JSON.parse(row.analysis):{reportType:input.review.reportType||"CB",typeRationale:"Ocena typu raportu przez recenzenta",summary:"Przegląd rozpoczęty ręcznie.",limitations:[],claims:[],model:"Manual",generatedAt:new Date().toISOString()},type=input.review.reportType||analysis?.reportType||"CB";
 const all=currentClaims({...await fullDoc(row),review:input.review});
 for(const [id,decision]of Object.entries(input.review.decisions)){
  if(id!==decision.claim.id)throw new AppError("Identyfikator twierdzenia jest niespójny.");
  if(decision.status==="accepted"){
   const issues=claimIssues(decision.claim,source);if(issues.length)throw new AppError(issues[0]);
   if(!decision.sourceChecked)throw new AppError("Przed akceptacją sprawdź fragment źródłowy.");
   if(deriveBridge(decision.claim,type)==="BU")throw new AppError("Nierozstrzygnięta ocena wymaga statusu „Nierozstrzygnięte”.");
   if(type==="NC"||type==="NMC")throw new AppError("Ten typ raportu nie otrzymuje ocen merytorycznych twierdzeń.");
  }
  if(["excluded","unresolved"].includes(decision.status)&&!decision.comment.trim())throw new AppError("Dodaj powód wyłączenia lub nierozstrzygnięcia.");
 }
 const active=all.filter(c=>input.review.decisions[c.id]?.status!=="excluded");
 if(["CB","M"].includes(type)&&active.length&&active.filter(c=>c.primary).length!==1)throw new AppError("Wskaż dokładnie jedno twierdzenie główne.");
 const old=JSON.parse(row.review);const changes=Object.fromEntries(Object.entries(input.review.decisions).filter(([k,v])=>JSON.stringify(old.decisions[k])!==JSON.stringify(v)));
 return Response.json(await updateDoc(row,analysis,input.review,"review",{decisions:changes,coverageChecked:input.review.coverageChecked,reportType:input.review.reportType,reportComment:input.review.reportComment}));
 }catch(e){return e instanceof z.ZodError?Response.json({error:"Dane oceny są niekompletne lub nieprawidłowe."},{status:400}):failure(e);}}
export async function DELETE(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);
 // Remove all immutable analysis/audit versions as well as originals, including import retries.
 // Keep the database record until cleanup succeeds so a failed deletion can be retried.
 const prefix=`documents/${who}/${row.id}/`;let cursor:string|undefined;
 do{const page=await bindings().BUCKET.list({prefix,cursor});if(page.objects.length)await bindings().BUCKET.delete(page.objects.map(x=>x.key));cursor=page.truncated?page.cursor:undefined;}while(cursor);
 await db().batch([db().prepare("DELETE FROM assessment_runs WHERE document_id=? AND owner=?").bind(id,who),db().prepare("UPDATE projects SET revision=revision+1,updated_at=? WHERE owner=? AND id IN (SELECT project_id FROM project_documents WHERE document_id=?)").bind(new Date().toISOString(),who,row.id),db().prepare("DELETE FROM project_documents WHERE document_id=?").bind(id),db().prepare("DELETE FROM events WHERE document_id=? AND owner=?").bind(id,who),db().prepare("DELETE FROM documents WHERE id=? AND owner=?").bind(id,who)]);
 return Response.json({ok:true});}catch(e){return failure(e);}}
