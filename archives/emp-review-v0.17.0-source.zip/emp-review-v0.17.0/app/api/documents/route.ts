import {newManifest} from '@/lib/versions';
import { z } from "zod";
import { originalUploads, originalKey } from "@/lib/source-bundle";
import { sourceSchema, emptyReview } from "@/lib/emp";
import { demoSource, demoAnalysis, demoTitle, demoCoverage } from "@/lib/demo";
import { bindings, db, owner, failure, sameOrigin, fullDoc, rowFor, AppError } from "@/lib/server";
export async function GET(){try{const who=await owner();const rows=await db().prepare("SELECT id,title,stage,updated_at,analysis IS NOT NULL AS analyzed FROM documents WHERE owner=? ORDER BY updated_at DESC LIMIT 100").bind(who).all();return Response.json({documents:rows.results,aiConfigured:!!bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL||"gpt-4.1"});}catch(e){return failure(e);}}
export async function POST(req:Request){try{
 sameOrigin(req);const who=await owner();if(Number(req.headers.get("content-length"))>12000000)throw new AppError("Limit wynosi 10 MB plików na jeden przegląd.",413);
 const form=await req.formData(),isDemo=form.get("demo")==="true";
 const parsed=z.object({title:z.string().trim().min(1).max(200),stage:z.enum(["A","B","Excerpt"]),coverage:z.string().max(1500)}).parse({title:isDemo?demoTitle:form.get("title"),stage:isDemo?"B":form.get("stage"),coverage:isDemo?demoCoverage:form.get("coverage")});
 const source=isDemo?demoSource:sourceSchema.parse(JSON.parse(String(form.get("source"))));
 if(source.blocks.reduce((n,b)=>n+b.text.trim().length,0)<80)throw new AppError("Za mało czytelnego tekstu. Wklej treść albo użyj dokumentu z warstwą tekstową.");
 const uploads=isDemo?[]:originalUploads(form,source);
 const suppliedId=form.get("importId");const id=suppliedId?z.string().uuid().parse(suppliedId):crypto.randomUUID(),now=new Date().toISOString(),sourceKey=`documents/${who}/${id}/${crypto.randomUUID()}/text.json`;
 const sourceText=JSON.stringify(source);const hash=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(sourceText)))).map(b=>b.toString(16).padStart(2,"0")).join("");
 const existing=await db().prepare("SELECT id,source_hash,title,stage,coverage FROM documents WHERE id=? AND owner=?").bind(id,who).first<{id:string;source_hash:string;title:string;stage:string;coverage:string}>();
 if(existing){if(existing.source_hash!==hash||existing.title!==parsed.title||existing.stage!==parsed.stage||existing.coverage!==parsed.coverage)throw new AppError("Ten import jest już zapisany z innymi danymi. Rozpocznij nowy przegląd.",409);return Response.json(await fullDoc(await rowFor(id,who)));}
 const keys=[sourceKey,...uploads.map(upload=>originalKey(sourceKey,upload.fileId))];
 const cleanup=async()=>{try{await bindings().BUCKET.delete(keys);}catch{console.error("EMP incomplete import cleanup failed");}};
 try{
  await bindings().BUCKET.put(sourceKey,sourceText,{httpMetadata:{contentType:"application/json"}});
  for(const upload of uploads)await bindings().BUCKET.put(originalKey(sourceKey,upload.fileId),upload.file.stream(),{httpMetadata:{contentType:upload.file.type||"application/octet-stream"}});
 }catch(e){await cleanup();throw e;}

 const analysis=isDemo?JSON.stringify({...demoAnalysis,generatedAt:now,sourceHash:hash}):null;
 try{await db().batch([
 db().prepare("INSERT INTO documents (id,owner,title,stage,coverage,source_key,source_hash,analysis,review,version_manifest,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,0,?,?)").bind(id,who,parsed.title,parsed.stage,parsed.coverage,sourceKey,hash,analysis,JSON.stringify(emptyReview),JSON.stringify(newManifest("core")),now,now),
 db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) VALUES (?,?,?,0,?,?,?)").bind(crypto.randomUUID(),id,who,"import",JSON.stringify({sourceHash:hash,demo:isDemo,stage:parsed.stage,files:source.files||null}),now)
 ]);}catch(e){
  // A concurrent retry uses a different object prefix and cannot overwrite originals.
  // Only remove this attempt if the database confirms it is not referenced.
  let known=false;let persisted:{source_key:string;source_hash:string;title:string;stage:string;coverage:string}|null=null;
  try{persisted=await db().prepare("SELECT source_key,source_hash,title,stage,coverage FROM documents WHERE id=? AND owner=?").bind(id,who).first();known=true;}catch{}
  if(known&&persisted?.source_key!==sourceKey)await cleanup();
  if(persisted&&persisted.source_hash===hash&&persisted.title===parsed.title&&persisted.stage===parsed.stage&&persisted.coverage===parsed.coverage)return Response.json(await fullDoc(await rowFor(id,who)));
  throw e;
 }
 return Response.json(await fullDoc(await rowFor(id,who)),{status:201});
 }catch(e){return e instanceof z.ZodError?Response.json({error:"Sprawdź tytuł, zakres i tekst dokumentu."},{status:400}):failure(e);}}
