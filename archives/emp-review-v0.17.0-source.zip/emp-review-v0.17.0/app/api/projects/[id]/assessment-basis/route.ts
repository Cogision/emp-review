import {z} from 'zod';
import {bindings,owner,sameOrigin,jsonBody,failure} from '@/lib/server';
import {ProjectAssessmentStore} from '@/lib/project-assessment-store';
type Ctx={params:Promise<{id:string}>};
export async function GET(req:Request,ctx:Ctx){try{const documentId=z.string().uuid().parse(new URL(req.url).searchParams.get('documentId'));return Response.json(await new ProjectAssessmentStore(bindings(),await owner()).options((await ctx.params).id,documentId),{headers:{'Cache-Control':'no-store'}});}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{sameOrigin(req);const b=z.object({documentId:z.string().uuid()}).passthrough().parse(await jsonBody(req,10000));return Response.json(await new ProjectAssessmentStore(bindings(),await owner()).select((await ctx.params).id,b.documentId,b));}catch(e){return e instanceof z.ZodError?Response.json({error:'Check the assessment selection / Sprawdź wybór oceny.'},{status:400}):failure(e);}}
