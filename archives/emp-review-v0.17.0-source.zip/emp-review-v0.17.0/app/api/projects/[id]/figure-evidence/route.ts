import {bindings,owner,sameOrigin,jsonBody,failure} from '@/lib/server';
import {ProjectFigureStore} from '@/lib/project-figure-store';
type Ctx={params:Promise<{id:string}>};
export async function GET(req:Request,ctx:Ctx){try{const store=new ProjectFigureStore(bindings(),await owner()),{id}=await ctx.params,documentId=new URL(req.url).searchParams.get('documentId');return Response.json(documentId?await store.options(id,documentId):await store.list(id));}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{sameOrigin(req);const store=new ProjectFigureStore(bindings(),await owner());return Response.json(await store.select((await ctx.params).id,await jsonBody(req,10000)));}catch(e){return failure(e);}}
