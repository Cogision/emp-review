import {z} from "zod";
import {bindings,db,owner,sameOrigin,jsonBody,failure,AppError} from "@/lib/server";
import {projectFor,projectData,attachDocument} from "@/lib/project-server";
type Ctx={params:Promise<{id:string}>};
export async function GET(_req:Request,ctx:Ctx){try{return Response.json(await projectData((await ctx.params).id,await owner()));}catch(e){return failure(e);}}
export async function PATCH(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,p=await projectFor(id,who),v=z.object({revision:z.number().int(),title:z.string().trim().min(1).max(200),question:z.string().max(4000),criteria:z.string().max(4000),language:z.enum(["en","pl"]).transform(()=>"en" as const)}).parse(await jsonBody(req,20000));
 const r=await db().prepare("UPDATE projects SET title=?,question=?,criteria=?,language=?,revision=revision+1,updated_at=? WHERE id=? AND owner=? AND revision=?").bind(v.title,v.question,v.criteria,v.language,new Date().toISOString(),id,who,v.revision).run();if(!r.meta.changes)throw new AppError("The project changed. Reload it before saving.",409);return Response.json(await projectFor(p.id,who));
}catch(e){return e instanceof z.ZodError?Response.json({error:"Check the project details."},{status:400}):failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params;await projectFor(id,who);
 const v=z.object({action:z.enum(["add","remove","group"]),documentId:z.string().uuid(),studyGroup:z.string().trim().max(160).default("")}).parse(await jsonBody(req,10000));
 if(v.action==="add")await attachDocument(id,v.documentId,who);
 else {const sql=v.action==="remove"?"DELETE FROM project_documents WHERE project_id=? AND document_id=?":"UPDATE project_documents SET study_group=? WHERE project_id=? AND document_id=?";const params=v.action==="remove"?[id,v.documentId]:[v.studyGroup,id,v.documentId];const results=await db().batch([db().prepare("UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND owner=? AND EXISTS (SELECT 1 FROM project_documents WHERE project_id=? AND document_id=?)").bind(new Date().toISOString(),id,who,id,v.documentId),db().prepare(sql).bind(...params),...(v.action==="remove"?[db().prepare("DELETE FROM project_figure_selections WHERE project_id=? AND document_id=?").bind(id,v.documentId)]:[])]);if(!results[1].meta.changes)throw new AppError("Report is not in this project.",404);}
 return Response.json({ok:true});
}catch(e){return e instanceof z.ZodError?Response.json({error:"Check the report selection."},{status:400}):failure(e);}}
export async function DELETE(req:Request,ctx:Ctx){try{sameOrigin(req);const who=await owner(),{id}=await ctx.params;await projectFor(id,who);const saved=await db().prepare("SELECT snapshot_key FROM project_syntheses WHERE project_id=? AND owner=?").bind(id,who).all<{snapshot_key:string}>();for(let i=0;i<saved.results.length;i+=1000)await bindings().BUCKET.delete(saved.results.slice(i,i+1000).map(s=>s.snapshot_key));await db().batch([db().prepare("DELETE FROM project_syntheses WHERE project_id=? AND owner=?").bind(id,who),db().prepare("DELETE FROM project_documents WHERE project_id=?").bind(id),db().prepare("DELETE FROM projects WHERE id=? AND owner=?").bind(id,who)]);return Response.json({ok:true});}catch(e){return failure(e);}}
