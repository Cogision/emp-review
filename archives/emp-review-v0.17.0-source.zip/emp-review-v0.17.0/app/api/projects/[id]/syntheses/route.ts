import {z} from "zod";
import {bindings,db,owner,sameOrigin,jsonBody,failure,AppError} from "@/lib/server";
import {projectFor,projectData} from "@/lib/project-server";
import {parseAiSettings} from "@/lib/ai-settings";
import {type SynthesisMeta,type SynthesisSnapshot} from "@/lib/project-interpretation";
import {createSynthesisWork,synthesisProgress,completedSynthesis,type SynthesisWork} from "@/lib/synthesis-work";
import {SynthesisWorkStore} from "@/lib/synthesis-work-store";
type Ctx={params:Promise<{id:string}>};
export async function GET(req:Request,ctx:Ctx){try{
 const who=await owner(),{id}=await ctx.params;await projectFor(id,who);
 const query=new URL(req.url).searchParams;
 const run=query.get("run");
 if(run){const {work}=await new SynthesisWorkStore(bindings().BUCKET,who,id).read(run);return Response.json(await workReply(work,who));}
 const selected=query.get("snapshot");
 if(selected){
  const row=await db().prepare("SELECT * FROM project_syntheses WHERE id=? AND project_id=? AND owner=?").bind(selected,id,who).first<SynthesisMeta&{snapshot_key:string}>();
  if(!row)throw new AppError("Synthesis not found.",404);
  const object=await bindings().BUCKET.get(row.snapshot_key);if(!object)throw new AppError("The saved synthesis is temporarily unavailable.",503);
  const snapshot=await object.json<SynthesisSnapshot>();
  if(snapshot.id!==row.id||snapshot.projectId!==id||snapshot.fingerprint!==row.fingerprint)throw new AppError("The saved synthesis could not be verified.",503);
  return Response.json(snapshot);
 }
 const rows=await db().prepare("SELECT id,project_id,filter,language,model,fingerprint,created_at FROM project_syntheses WHERE project_id=? AND owner=? ORDER BY created_at DESC LIMIT 100").bind(id,who).all<SynthesisMeta>();
 return Response.json({snapshots:rows.results});
 }catch(e){return failure(e);}}
async function workReply(work:SynthesisWork,who:string){
 if(work.tasks.length)return {run:synthesisProgress(work)};
 const snapshot=completedSynthesis(work),id=work.projectId;
 const existing=await db().prepare("SELECT snapshot_key FROM project_syntheses WHERE id=? AND project_id=? AND owner=?").bind(work.id,id,who).first<{snapshot_key:string}>();
 if(existing){const object=await bindings().BUCKET.get(existing.snapshot_key);if(!object)throw new AppError("The saved synthesis is temporarily unavailable.",503);return {run:synthesisProgress(work),snapshot:await object.json<SynthesisSnapshot>()};}
 const snapshotKey=`projects/${who}/${id}/syntheses/${snapshot.id}.json`;
 await bindings().BUCKET.put(snapshotKey,JSON.stringify(snapshot),{httpMetadata:{contentType:"application/json"}});
 // Idempotent completion: retrying after a lost response must not repeat an AI call.
 await db().prepare("INSERT INTO project_syntheses (id,project_id,owner,filter,language,model,fingerprint,snapshot_key,created_at) VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING").bind(snapshot.id,id,who,snapshot.filter,snapshot.language,snapshot.model,snapshot.fingerprint,snapshotKey,snapshot.createdAt).run();
 return {run:synthesisProgress(work),snapshot};
}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params;await projectFor(id,who);
 const body=await jsonBody(req,10000);
 const action=z.enum(["start","step"]).safeParse(body.action);
 if(!action.success)throw new AppError("Reload the application to use resumable project synthesis.",409);
 const store=new SynthesisWorkStore(bindings().BUCKET,who,id);
 if(action.data==="step"){
  const {runId}=z.object({runId:z.string().uuid()}).parse(body);
  const saved=await store.read(runId);
  if(!saved.work.tasks.length)return Response.json(await workReply(saved.work,who));
  const {key}=parseAiSettings({...body,model:saved.work.model},{key:bindings().OPENAI_API_KEY,model:saved.work.model});
  const work=await store.step(runId,key);
  return Response.json(await workReply(work,who));
 }
 const v=z.object({filter:z.enum(["all","accepted"]),revision:z.number().int()}).parse(body);
 const data=await projectData(id,who);if(data.project.revision!==v.revision)throw new AppError("The project changed. Refresh it before generating a synthesis.",409);
 const {model}=parseAiSettings(body,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});
 const work=await createSynthesisWork(data,v.filter,"en",model);
 await store.create(work);
 return Response.json({run:synthesisProgress(work)});
 }catch(e){return e instanceof z.ZodError?Response.json({error:"Check the synthesis settings."},{status:400}):failure(e);}}
