import { sameOrigin,jsonBody } from '@/lib/server';
import { roundStore,roundFailure } from '@/lib/round-server';
export async function GET(_req:Request,{params}:{params:Promise<{id:string}>}){try{return Response.json(await (await roundStore()).detail((await params).id),{headers:{'Cache-Control':'no-store'}});}catch(e){return roundFailure(e);}}
export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){try{sameOrigin(req);return Response.json(await (await roundStore()).action((await params).id,await jsonBody(req,1500000)));}catch(e){return roundFailure(e);}}
