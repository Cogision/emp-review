import { sameOrigin,jsonBody } from '@/lib/server';
import { roundStore,roundFailure } from '@/lib/round-server';
export async function POST(req:Request){try{sameOrigin(req);return Response.json(await (await roundStore()).join(await jsonBody(req)));}catch(e){return roundFailure(e);}}
