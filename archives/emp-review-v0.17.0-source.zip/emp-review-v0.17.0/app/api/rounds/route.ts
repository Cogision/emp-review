import {sameOrigin,jsonBody} from '@/lib/server';
import {roundStore,roundFailure} from '@/lib/round-server';
export async function GET(){try{return Response.json(await (await roundStore()).list(),{headers:{'Cache-Control':'no-store'}});}catch(e){return roundFailure(e);}}
export async function POST(req:Request){try{sameOrigin(req);return Response.json(await (await roundStore()).create(await jsonBody(req)));}catch(e){return roundFailure(e);}}
