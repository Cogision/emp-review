import {getChatGPTUser} from '../chatgpt-auth';
import RoundJoin from '@/components/round-join';
export const dynamic='force-dynamic';
export const metadata={title:'Join a review round · EMP Review',referrer:'no-referrer',robots:{index:false,follow:false}};
export default async function Page(){return <RoundJoin user={await getChatGPTUser()}/>;}
