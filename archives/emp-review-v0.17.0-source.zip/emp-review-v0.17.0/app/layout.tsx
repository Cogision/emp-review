import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EMP Review · Claims and evidence",
  description: "Research projects, evidence profiles and source-linked scientific claim review.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
