import {redirect} from 'next/navigation';
import {getChatGPTUser} from '../chatgpt-auth';
import {chatGPTSignInPath,loginReturnPath} from '@/lib/auth-paths';
import {APP_VERSION,MANUAL_VERSION} from '@/lib/versions';
import {ArrowRight,LockKeyhole} from 'lucide-react';
import {Button} from '@/components/ui/button';

export const dynamic='force-dynamic';
export const metadata={title:'Sign in · EMP Review',robots:{index:false,follow:false}};

export default async function Page({searchParams}:{searchParams:Promise<{returnTo?:string}>}) {
 const params=await searchParams;
 return <Login returnTo={loginReturnPath(typeof params.returnTo==='string'?params.returnTo:'/')}/>;
}
async function Login({returnTo}:{returnTo:string}) {
 if(await getChatGPTUser()) redirect(returnTo);
 return <main className="min-h-dvh bg-[#f5f7f4] px-5 py-12 flex flex-col items-center justify-center">
   <div className="w-full max-w-md">
    <div className="flex items-center gap-3 mb-10"><span className="h-11 w-11 bg-primary text-[#d9edc7] rounded-xl grid place-items-center font-serif text-3xl">E</span><span className="text-2xl font-semibold tracking-tight">EMP<span className="font-normal">Review</span></span></div>
    <section className="rounded-3xl border bg-white p-7 sm:p-9 shadow-sm" aria-labelledby="login-title">
     <h1 id="login-title" className="text-3xl font-semibold tracking-tight">Welcome to EMP Review</h1>
     <p className="mt-3 mb-8 text-muted-foreground leading-relaxed">Sign in to review evidence, manage your projects and take part in review rounds.</p>
     <Button asChild className="w-full h-12 text-base"><a href={chatGPTSignInPath(returnTo)} target="_top">Continue with ChatGPT<ArrowRight size={18}/></a></Button>
     <p className="mt-4 text-sm text-muted-foreground leading-relaxed">Use your own ChatGPT account. If you received a round invitation, use the email address it was sent to.</p>
     <div className="mt-7 border-t pt-5 flex items-start gap-2.5 text-sm text-muted-foreground"><LockKeyhole size={17} className="shrink-0 mt-0.5"/><p>Your projects belong to your account. Round access is managed separately by the coordinator.</p></div>
    </section>
    <p className="mt-6 text-center text-xs text-muted-foreground">EMP {MANUAL_VERSION} · App v{APP_VERSION}</p>
   </div>
 </main>;
}
