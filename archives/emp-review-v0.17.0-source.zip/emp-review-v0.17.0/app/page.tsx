import ReviewWorkspace from "@/components/review-workspace";
import {requireChatGPTUser} from './chatgpt-auth';
import {validRoundId} from '@/lib/reviewer-invitations';
export const dynamic='force-dynamic';
export default async function Page({searchParams}:{searchParams:Promise<{round?:string}>}){
 const params=await searchParams,roundId=typeof params.round==='string'&&validRoundId(params.round)?params.round:'';
 return <AuthenticatedWorkspace roundId={roundId}/>;
}
async function AuthenticatedWorkspace({roundId}:{roundId:string}){
 const user=await requireChatGPTUser(roundId?`/?round=${encodeURIComponent(roundId)}`:'/');
 return <ReviewWorkspace initialRoundId={roundId} user={{displayName:user.displayName,email:user.email}}/>;
}
