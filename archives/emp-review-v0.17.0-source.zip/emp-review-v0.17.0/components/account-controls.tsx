"use client";
import {useEffect,useState,type MouseEvent} from 'react';
import {ChevronDown,Loader2,LogOut,Settings2,UserRound} from 'lucide-react';
import {Button} from './ui/button';
import {Input} from './ui/input';
import {Dialog,DialogContent,DialogDescription,DialogHeader,DialogTitle} from './ui/dialog';
import {Tabs,TabsContent,TabsList,TabsTrigger} from './ui/tabs';
import {DropdownMenu,DropdownMenuContent,DropdownMenuItem,DropdownMenuLabel,DropdownMenuSeparator,DropdownMenuTrigger} from './ui/dropdown-menu';
import {AlertDialog,AlertDialogAction,AlertDialogCancel,AlertDialogContent,AlertDialogDescription,AlertDialogFooter,AlertDialogHeader,AlertDialogTitle} from './ui/alert-dialog';
import AiSettings from './ai-settings';
import {request} from '@/lib/http';
import {chatGPTSignOutPath,loginPath} from '@/lib/auth-paths';
import {defaultProfile,profileInput,type AccountIdentity,type AccountProfile} from '@/lib/account-profile';

type Props = {
 user:AccountIdentity; open:boolean; onOpenChange:(value:boolean)=>void;
 onSignOut:(event:MouseEvent<HTMLAnchorElement>)=>void; onProfile:(profile:AccountProfile)=>void;
 apiKey:string;setApiKey:(value:string)=>void;model:string;setModel:(value:string)=>void;configured:boolean;busy:boolean;
};

export default function AccountControls(props:Props) {
 const {user,open,onOpenChange,onSignOut,onProfile,busy,...ai}=props;
 const [profile,setProfile]=useState(()=>defaultProfile(user));
 const [displayName,setDisplayName]=useState(profile.displayName),[affiliation,setAffiliation]=useState(profile.affiliation);
 const [loaded,setLoaded]=useState(false),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false),[checking,setChecking]=useState(false);
 const [error,setError]=useState(''),[saved,setSaved]=useState(false),[conflict,setConflict]=useState(false),[expired,setExpired]=useState(false),[loadFailed,setLoadFailed]=useState(false);
 const [tab,setTab]=useState('ai'),[discard,setDiscard]=useState<null|'close'|'reload'>(null);
 const dirty=loaded&&(displayName!==profile.displayName||affiliation!==profile.affiliation);
 const locked=saving||checking;

 function adopt(next:AccountProfile) {
  setProfile(next);setDisplayName(next.displayName);setAffiliation(next.affiliation);setLoaded(true);onProfile(next);
 }
 async function load() {
  setLoading(true);setLoadFailed(false);setError('');setConflict(false);setExpired(false);setSaved(false);
  try {adopt(await request<AccountProfile>('/api/account'));}
  catch(e) {setLoadFailed(true);setError((e as Error).message);setExpired((e as {status?:number}).status===401);}
  finally {setLoading(false);}
 }
 useEffect(()=>{void load();},[]);
 useEffect(()=>{
  const warn=(event:BeforeUnloadEvent)=>{if(dirty||saving||checking){event.preventDefault();event.returnValue='';}};
  window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);
 },[dirty,saving,checking]);

 function close() {if(locked)return;if(dirty){setDiscard('close');return;}onOpenChange(false);setTab('ai');setSaved(false);}
 function show(next:string) {setTab(next);onOpenChange(true);}
 async function save() {
  if(!loaded||loading||saving||busy||conflict||loadFailed)return;
  const parsed=profileInput.safeParse({displayName,affiliation,revision:profile.revision});
  setSaved(false);setError('');
  if(!parsed.success){setError(parsed.error.issues[0]?.message||'Check your profile details.');return;}
  setSaving(true);
  try {adopt(await request<AccountProfile>('/api/account',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(parsed.data)}));setSaved(true);setExpired(false);}
  catch(e){setError((e as Error).message);setConflict((e as {status?:number}).status===409);setExpired((e as {status?:number}).status===401);}
  finally{setSaving(false);}
 }
 const initials=profile.displayName.split(/\s+/).filter(Boolean).slice(0,2).map(part=>part[0]).join('').toUpperCase();

 return <>
  <DropdownMenu><DropdownMenuTrigger asChild><Button variant="outline" className="h-10 gap-2" aria-label={`Account menu for ${profile.displayName}`}>
   <span aria-hidden="true" className="size-6 grid place-items-center rounded-full bg-primary/10 text-primary text-xs font-semibold">{initials||<UserRound size={15}/>}</span><span className="hidden sm:block max-w-36 truncate">{profile.displayName}</span><ChevronDown size={14}/>
  </Button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-64">
   <DropdownMenuLabel><span className="block break-words">{profile.displayName}</span><span className="block break-all text-xs text-muted-foreground font-normal mt-1">{user.email}</span></DropdownMenuLabel><DropdownMenuSeparator/>
   <DropdownMenuItem onSelect={()=>show('profile')}><UserRound/>Profile &amp; settings</DropdownMenuItem>
   <DropdownMenuItem onSelect={()=>show('ai')}><Settings2/>AI connection<span className={`ml-auto size-2 rounded-full ${ai.apiKey||ai.configured?'bg-emerald-500':'bg-amber-500'}`} aria-label={ai.apiKey||ai.configured?'API key available':'API key needed'}/></DropdownMenuItem><DropdownMenuSeparator/>
   <DropdownMenuItem asChild disabled={busy}><a href={chatGPTSignOutPath()} target="_top" onClick={onSignOut}><LogOut/>Sign out</a></DropdownMenuItem>
  </DropdownMenuContent></DropdownMenu>
  <Dialog open={open} onOpenChange={value=>{if(!value)close();}}><DialogContent className="sm:max-w-xl max-h-[90dvh] overflow-y-auto">
   <DialogHeader><DialogTitle>Account settings</DialogTitle><DialogDescription>Manage your profile and AI connection.</DialogDescription></DialogHeader>
   <Tabs value={tab} onValueChange={next=>{if(!locked)setTab(next);}}>
    <TabsList className="w-full" aria-label="Settings sections"><TabsTrigger value="profile" disabled={locked}>Profile</TabsTrigger><TabsTrigger value="ai" disabled={locked}>AI connection</TabsTrigger></TabsList>
    <TabsContent value="profile" className="pt-4 space-y-5">
     <form onSubmit={event=>{event.preventDefault();void save();}} className="space-y-5">
      <fieldset disabled={!loaded||loading||saving||busy} className="space-y-4">
       <label className="grid gap-2 text-sm font-medium">Display name<Input name="displayName" autoComplete="name" maxLength={120} readOnly={conflict||loadFailed} value={displayName} onChange={event=>{setDisplayName(event.target.value);setSaved(false);}} required aria-describedby="profile-name-hint"/><span id="profile-name-hint" className="font-normal text-xs text-muted-foreground">Used as your default name when joining a new review round.</span></label>
       <label className="grid gap-2 text-sm font-medium">Affiliation <span className="sr-only">(optional)</span><Input name="affiliation" autoComplete="organization" maxLength={200} readOnly={conflict||loadFailed} placeholder="University, organisation or team (optional)" value={affiliation} onChange={event=>{setAffiliation(event.target.value);setSaved(false);}}/></label>
       <label className="grid gap-2 text-sm font-medium">Email<Input name="email" type="email" value={user.email} readOnly aria-describedby="profile-email-hint"/><span id="profile-email-hint" className="font-normal text-xs text-muted-foreground">Managed by your ChatGPT account. Use this email for round invitations.</span></label>
      </fieldset>
      {loading&&<p role="status" className="flex gap-2 items-center text-sm text-muted-foreground"><Loader2 size={16} className="animate-spin"/>Loading your profile…</p>}
      {error&&<div role="alert" className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm space-y-2"><p>{error}</p>{expired?<a className="underline" href={loginPath()} target="_top">Sign in again</a>:(!loaded||conflict||loadFailed)&&<Button type="button" variant="outline" size="sm" disabled={loading||saving} onClick={()=>dirty?setDiscard('reload'):void load()}>{conflict?'Reload latest profile':'Try again'}</Button>}</div>}
      {saved&&<p role="status" className="text-sm text-emerald-800">Profile saved.</p>}
      <div className="flex justify-end"><Button type="submit" disabled={!loaded||loading||saving||busy||!dirty||conflict||loadFailed||!displayName.trim()}>{saving&&<Loader2 size={16} className="animate-spin"/>}{saving?'Saving…':'Save profile'}</Button></div>
     </form>
     <div className="border-t pt-4 text-sm space-y-3"><div className="flex justify-between gap-4"><span className="text-muted-foreground">Sign-in method</span><span>ChatGPT</span></div><div className="flex justify-between gap-4"><span className="text-muted-foreground">Application &amp; export language</span><span>English</span></div></div>
    </TabsContent>
    <TabsContent value="ai" className="pt-4"><AiSettings apiKey={ai.apiKey} setApiKey={ai.setApiKey} model={ai.model} setModel={ai.setModel} configured={ai.configured} busy={busy} onCheckingChange={setChecking}/></TabsContent>
   </Tabs>
   {busy&&<p role="status" className="text-xs text-muted-foreground">Wait for the current operation to finish before changing settings.</p>}
   <div className="flex justify-between items-center gap-3 border-t pt-4"><span className="text-xs text-muted-foreground">{dirty?'Unsaved profile changes':''}</span><Button variant="outline" disabled={locked} onClick={close}>Close</Button></div>
  </DialogContent></Dialog>
  <AlertDialog open={discard!==null} onOpenChange={value=>{if(!value)setDiscard(null);}}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Discard profile changes?</AlertDialogTitle><AlertDialogDescription>Your edits have not been saved. Copy anything you want to keep before continuing.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Keep editing</AlertDialogCancel><AlertDialogAction onClick={()=>{const action=discard;setDiscard(null);if(action==='reload'){void load();}else{setDisplayName(profile.displayName);setAffiliation(profile.affiliation);onOpenChange(false);setTab('ai');setSaved(false);}}}>Discard changes</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
 </>;
}
