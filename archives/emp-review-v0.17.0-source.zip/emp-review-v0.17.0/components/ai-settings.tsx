"use client";
import {tr} from "@/lib/i18n";
import { useState } from "react";
import { Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { request } from "@/lib/http";

export default function AiSettings({onCheckingChange,apiKey,setApiKey,model,setModel,configured,busy}: {
  onCheckingChange:(v:boolean)=>void;apiKey:string;setApiKey:(v:string)=>void;
  model:string;setModel:(v:string)=>void;configured:boolean;busy:boolean;
}) {
  const [checking,setChecking]=useState(false);
  const [result,setResult]=useState<{ok:boolean;message:string}|null>(null);
  async function check(){
    setChecking(true);onCheckingChange(true);setResult(null);
    try{
      const data=await request<{model:string;message:string}>("/api/ai/check",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key:apiKey,model})});
      setModel(data.model);setResult({ok:true,message:data.message});
    }catch(e){setResult({ok:false,message:(e as Error).message});}finally{setChecking(false);onCheckingChange(false);}
  }
  return <div className="grid gap-4">
    <p className="text-sm text-muted-foreground">{configured?tr("A server API key is available. Your own key is optional."):tr("Enter an OpenAI API key for this browser tab. The training example works without a key.")}</p>
    <fieldset disabled={checking||busy} className="grid gap-4">
      <label className="grid gap-2 text-sm font-medium">{tr("OpenAI API key")}<Input type="password" autoComplete="off" value={apiKey} onChange={e=>{setApiKey(e.target.value);setResult(null);}} placeholder="sk-…"/></label>
      <label className="grid gap-2 text-sm font-medium">{tr("API model identifier")}<Input autoCapitalize="none" spellCheck={false} value={model} onChange={e=>{setModel(e.target.value);setResult(null);}} placeholder="gpt-4.1"/><span className="font-normal text-xs text-muted-foreground">{tr("E.g. gpt-4.1. Use the API identifier, not the name shown in the ChatGPT menu. Leave blank to use the default model.")}</span></label>
      <p className="text-xs text-muted-foreground leading-relaxed">{tr("The key is sent to the server when testing, analysing or translating Word exports. It stays in this tab’s memory and is not saved in history or browser storage. The connection test sends a short request without your document and is billed to your API account.")}</p>
      <Button variant="outline" onClick={()=>void check()} disabled={checking||busy||(!apiKey.trim()&&!configured)}>{checking?<Loader2 size={16} className="animate-spin"/>:<CheckCircle2 size={16}/>}{tr("Test connection")}</Button>
    </fieldset>
    {checking&&<p role="status" className="text-sm">{tr("Waiting for the model’s response…")}</p>}
    {result&&<div role={result.ok?"status":"alert"} className={`rounded-xl border p-4 text-sm leading-relaxed break-words ${result.ok?"bg-emerald-50 border-emerald-200":"bg-amber-50 border-amber-200"}`}>{result.ok?<CheckCircle2 size={18} className="mb-2"/>:<AlertTriangle size={18} className="mb-2"/>}{tr(result.message)}</div>}
    <div className="flex gap-2 justify-end"><Button variant="ghost" disabled={checking||busy} onClick={()=>{setApiKey("");setResult(null);}}>{tr("Clear key")}</Button></div>
  </div>;
}
