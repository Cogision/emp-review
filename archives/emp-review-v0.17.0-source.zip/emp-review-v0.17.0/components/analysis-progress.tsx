"use client";
import {tr} from "@/lib/i18n";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export default function AnalysisProgress({startedAt}:{startedAt:number}) {
  const [seconds,setSeconds]=useState(0);
  useEffect(()=>{
    const update=()=>setSeconds(Math.max(0,Math.floor((Date.now()-startedAt)/1000)));
    update();
    const timer=setInterval(update,1000);
    return()=>clearInterval(timer);
  },[startedAt]);
  const elapsed=`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,"0")}`;
  return <section aria-label="Assisted analysis" className="mb-6 rounded-2xl border border-primary/25 bg-white p-5">
    <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
      <p role="status" className="flex items-center gap-2 text-sm font-semibold"><Loader2 aria-hidden="true" size={17} className="animate-spin motion-reduce:animate-none"/>{tr("Analysis in progress")}</p>
      <span role="timer" aria-live="off" className="text-xs text-muted-foreground tabular-nums">{tr("Elapsed:")} {elapsed}</span>
    </div>
    <Progress value={null} aria-label={tr("Publication analysis in progress")} className="h-2"/>
    <p className="text-sm leading-relaxed mt-3">{seconds<90?tr("Waiting for AI to respond and save the suggested assessments. This may take about 1–2 minutes."):tr("The response has not arrived yet. Wait for a result or an error message.")}</p>
    <p className="text-xs text-muted-foreground leading-relaxed mt-2">{tr("An exact progress percentage is unavailable. Keep this tab open.")}</p>
  </section>;
}
