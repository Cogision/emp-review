"use client";
import {tr} from "@/lib/i18n";
import {Button} from "./ui/button";
import {Progress} from "./ui/progress";
import type {AutoProgress} from "@/lib/automatic-batch";
import {Download,Loader2,CheckCircle2,AlertTriangle,Pause} from "lucide-react";

type Props={items:AutoProgress[];running:boolean;stopping:boolean;exporting?:boolean;disabled?:boolean;exportReady:boolean;onStop:()=>void;onResume:()=>void;onDownload:()=>void;onReview?:()=>void;onDismiss?:()=>void;error:string};
const labels={waiting:'Queued',import:'Saving source',inventory:'Identifying claims',claims:'Assessing claims',complete:'Analysis saved',error:'Needs attention'};

export default function AutomaticProgress({items,running,stopping,exporting=false,disabled=false,exportReady,onStop,onResume,onDownload,onReview,onDismiss,error}:Props){
 if(!items.length)return null;
 const done=items.filter(item=>item.phase==='complete').length;
 const failures=items.filter(item=>item.phase==='error');
 const allDone=done===items.length;
 const current=items.find(item=>['import','inventory','claims'].includes(item.phase));
 const canPause=running&&!exporting&&!allDone;
 const active=running||exporting;
 const heading=exporting?'Preparing Word forms':running?'Automatic analysis':allDone?(error?'Analysis saved':'Analysis complete'):failures.length?'Analysis needs attention':'Analysis paused';
 const Icon=active?Loader2:failures.length||error?AlertTriangle:allDone?CheckCircle2:Pause;
 const knownProgress=current?.phase==='claims'&&current.total>0;
 const stage=exporting?'Creating the English Word download.':stopping&&canPause?'Finishing and saving the current step before pausing.':running&&allDone?'Finalising saved analyses.':current?(running?labels[current.phase]:'Progress saved'):running?'Starting analysis…':allDone?'AI assessments are saved and ready for your review.':'Completed steps are saved. Resume to continue.';
 return <section className="rounded-2xl border border-primary/25 bg-white p-5 mb-6" aria-label="Automatic analysis">
  <div className="flex flex-wrap items-start justify-between gap-4">
   <div className="min-w-0"><h2 className="font-semibold flex items-center gap-2"><Icon aria-hidden="true" size={18} className={active?'animate-spin motion-reduce:animate-none':undefined}/>{heading}</h2>
    {items.length>1&&<p className="mt-1 text-sm text-muted-foreground">{done} of {items.length} publications complete{failures.length?` · ${failures.length} need attention`:''}</p>}
   </div>
   <div className="flex flex-wrap gap-2">
    {canPause&&<Button variant="outline" size="sm" disabled={stopping} onClick={onStop}>{stopping?'Pausing…':'Pause after this step'}</Button>}
    {!active&&<>{!allDone&&<Button variant="outline" size="sm" disabled={disabled} onClick={onResume}>{failures.length?'Retry unfinished analyses':'Resume analysis'}</Button>}{exportReady&&onReview&&<Button size="sm" disabled={disabled} onClick={onReview}>Review claims</Button>}{exportReady&&<Button variant="outline" size="sm" disabled={disabled} onClick={onDownload}><Download size={16}/>{error&&allDone?'Retry Word download':'Download Word forms'}</Button>}{allDone&&onDismiss&&<Button variant="ghost" size="sm" disabled={disabled} onClick={onDismiss}>Dismiss</Button>}</>}
   </div>
  </div>
  {current&&!exporting&&<p className="mt-4 text-sm font-medium break-words">{current.title}</p>}
  <div role="status" aria-live="polite" className="mt-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-sm text-muted-foreground"><p>{stage}</p>{knownProgress&&!exporting&&<span className="tabular-nums">{current.completed} of {current.total} claims assessed</span>}</div>
  {knownProgress&&!exporting&&<Progress value={Math.min(100,Math.max(0,current.completed/current.total*100))} className="h-1.5 mt-3" aria-label={`Assessed claims in ${current.title}`} aria-valuetext={`${current.completed} of ${current.total} claims assessed`}/>}
  {failures.length>0&&<div className="mt-4 space-y-2">{failures.map(item=><p role="alert" key={item.id} className="text-sm text-amber-900 break-words"><span className="font-medium">{item.title}: </span>{tr(item.error||'The analysis did not finish. Retry to continue from its saved progress.')}</p>)}</div>}
  {error&&<p role="alert" className="text-sm text-amber-900 mt-3">{tr(error)}</p>}
  {items.length>1&&<details className="mt-4 border-t pt-3"><summary className="cursor-pointer text-sm font-medium">Publication details</summary><ul className="mt-3 space-y-2">{items.map(item=><li key={item.id} className="flex flex-wrap justify-between gap-x-4 gap-y-1 text-sm"><span className="min-w-0 break-words">{item.title}</span><span className="text-muted-foreground">{labels[item.phase]}{item.total>0?` · ${item.completed}/${item.total} claims`:''}</span></li>)}</ul></details>}
  {active&&!exporting&&<p className="text-xs text-muted-foreground mt-4">Keep this tab open. Progress is saved after each step. AI assessments need your review.</p>}
 </section>;
}
