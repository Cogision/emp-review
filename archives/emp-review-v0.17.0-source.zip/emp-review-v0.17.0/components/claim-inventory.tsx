"use client";
import {currentClaims, type RecordDoc} from '@/lib/emp';
import {Button} from './ui/button';
import {Checkbox} from './ui/checkbox';
import {HelpLink,HelpTerm} from './help-term';

export default function ClaimInventory({document,disabled,onOpen,onAdd,onContinue,onCoverage}:{document:RecordDoc;disabled:boolean;onOpen:(id:string)=>void;onAdd:()=>void;onContinue:()=>void;onCoverage:(checked:boolean)=>void}){
 const claims=currentClaims(document),type=document.review.reportType||document.analysis?.reportType;
 const structural=type==='NC'||type==='NMC';
 return <section className="rounded-2xl border bg-white p-5 sm:p-7 space-y-5">
  <div><h2 className="text-xl font-semibold">Check the claim list<HelpTerm label="Claim list" topicId="claim"/></h2><p className="text-sm text-muted-foreground mt-2">Check the scope, remove duplicates and add missed claims before reviewing individual assessments.</p></div>
  {structural?<p className="text-sm">Report type {type} has no substantive claim assessments. Check the report type and rationale in Summary.</p>:<>
   <p className="text-sm">{claims.length} claims · {claims.filter(c=>c.primary).length} selected as primary. Each row is a claim, not an independent study.</p>
   {document.analysis?.automatic?.inventoryComplete===false&&<p role="status" className="text-sm text-amber-900">AI marked this list as incomplete. Check the source for missed claims.</p>}
   <ol className="divide-y">{claims.map(c=><li key={c.id} className="flex items-start justify-between gap-4 py-4"><div className="min-w-0"><p className="text-xs text-muted-foreground mb-1">{c.id}{c.primary?' · Primary claim':''} · {document.review.decisions[c.id]?.status||'draft'}</p><button className="text-left font-medium text-primary hover:underline" disabled={disabled} onClick={()=>onOpen(c.id)}>{c.statement||'Untitled claim'}</button><details className="mt-2"><summary className="text-sm cursor-pointer text-muted-foreground">Source quotation</summary><blockquote className="mt-2 border-l-2 pl-3 text-sm whitespace-pre-wrap">{c.citation.quote||'No quotation recorded.'}</blockquote></details></div><Button variant="ghost" size="sm" disabled={disabled} onClick={()=>onOpen(c.id)}>Review</Button></li>)}</ol>
   {!claims.length&&<p className="text-sm text-muted-foreground">No claims recorded yet. Add a claim from the source to begin.</p>}
   <Button variant="outline" disabled={disabled} onClick={onAdd}>Add a missed claim</Button>
  </>}
  <label className="flex items-start gap-3 border-t pt-5 text-sm leading-relaxed"><Checkbox checked={document.review.coverageChecked} disabled={disabled} onCheckedChange={v=>onCoverage(v===true)}/><span>I have checked the source for missed claims. This list covers the scope of the review.</span></label>
  <div className="flex flex-wrap gap-4 items-center"><Button disabled={disabled} onClick={onContinue}>{structural?'Check report summary':'Continue to assessments'}</Button><HelpLink topicId="inventory">What should I check here?</HelpLink></div>
 </section>;
}
