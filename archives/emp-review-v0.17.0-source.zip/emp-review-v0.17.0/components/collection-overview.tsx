"use client";
import {ChevronDown,TriangleAlert} from 'lucide-react';
import {assessmentBasis,type ProjectData,type ProjectFilter,synthesise} from '@/lib/projects';
import {selectedFigureObservations} from '@/lib/project-figures';
import {Choice} from './claim-editor';
import {HelpLink,HelpTerm} from './help-term';
import {Button} from './ui/button';

type Props={data:ProjectData;summary:ReturnType<typeof synthesise>;filter:ProjectFilter;onFilter:(filter:ProjectFilter)=>void};
export default function CollectionOverview({data,summary,filter,onFilter}:Props){
 const n=summary.counts;
 const agreed=data.documents.filter(d=>assessmentBasis(d).kind==='adjudicated').length;
 const forms=[...new Set(data.documents.map(d=>assessmentBasis(d).manualVersion))];
 const figures=selectedFigureObservations(data).length;
 const unavailable=(data.figureSelections||[]).filter(s=>!s.eligible).length;
 const alerts=[
  n.pending>0?`${n.pending} ${n.pending===1?'report awaits':'reports await'} analysis.`:null,
  n.incomplete>0?`${n.incomplete} ${n.incomplete===1?'report has':'reports have'} a claim list flagged as incomplete by AI.`:null,
  unavailable>0?`${unavailable} unavailable figure ${unavailable===1?'selection is':'selections are'} omitted from synthesis.`:null,
 ].filter(Boolean);
 const metrics=[
  {label:'Reports',value:n.reports},
  {label:'Claims in view',value:n.claims},
  {label:'Accepted & checked',value:n.accepted},
  {label:'Needs checking in view',value:n.needsCheck},
 ];
 const empty=n.reports===0?'Add reports to start building this collection.':
  filter==='accepted'?'No claim assessments meet this filter yet.':
  n.pending>0?'No active claims yet. Reports awaiting analysis are not included.':
  'No active claims in this view. Structural reports and excluded claims do not contribute claim rows.';
 return <section aria-label="Collection overview" className="border bg-white rounded-2xl p-5 sm:p-6 min-w-0">
  <div className="flex flex-wrap items-start justify-between gap-x-5 gap-y-4">
   <h2 className="text-xl font-semibold pt-1">Collection overview</h2>
   <div className="w-full sm:w-72 min-w-0"><Choice label="Synthesis scope" helpId="filter" value={filter} options={[["accepted","Accepted and source-checked only"],["all","Exploratory · all active assessments"]]} onChange={v=>onFilter(v as ProjectFilter)}/></div>
  </div>
  <dl className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-5 mt-1">
   {metrics.map(m=><div key={m.label} className="flex flex-col-reverse justify-end gap-1">
    <dt className="text-sm text-muted-foreground">{m.label}</dt>
    <dd className={`text-2xl font-semibold tabular-nums ${m.label==='Needs checking in view'&&m.value>0?'text-amber-800':''}`}>{m.value}</dd>
   </div>)}
  </dl>
  <p className="text-sm text-muted-foreground leading-relaxed">
   {filter==='all'?'Exploratory scope includes drafts, unresolved decisions and unverified AI proposals.':`${n.filteredOut} ${n.filteredOut===1?'assessment hidden':'assessments hidden'} by this filter.`}
  </p>
  {n.claims===0&&<div className="mt-3 text-sm leading-relaxed"><p>{empty}</p>{filter==='accepted'&&n.filteredOut>0&&<Button variant="link" className="h-auto p-0 mt-2" onClick={()=>onFilter('all')}>Explore all active assessments</Button>}{figures>0&&<p className="mt-1">{figures} approved figure {figures===1?'observation remains':'observations remain'} selected separately.</p>}</div>}
  {alerts.length>0&&<div role="status" className="flex items-start gap-2.5 mt-4 rounded-lg bg-amber-50 px-3 py-3 text-amber-950">
   <TriangleAlert size={17} className="shrink-0 mt-0.5" aria-hidden="true"/>
   <ul className="space-y-1 text-sm leading-relaxed">{alerts.map(text=><li key={text}>{text}</li>)}</ul>
  </div>}
  <details className="group mt-5 border-t pt-4">
   <summary className="flex items-center justify-between gap-2 cursor-pointer list-none text-sm font-medium rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring [&::-webkit-details-marker]:hidden">Scope & methodology<ChevronDown aria-hidden="true" size={16} className="shrink-0 group-open:rotate-180"/></summary>
   <div className="mt-4 space-y-4 text-sm leading-relaxed">
    <dl className="space-y-3">
     <Detail label="Report coverage">{n.analysed} analysed · {n.pending} awaiting analysis</Detail>
     <Detail label="Assessment basis">{agreed} pinned {agreed===1?'adjudication':'adjudications'} · {n.reports-agreed} document {n.reports-agreed===1?'assessment':'assessments'}<HelpTerm label="Assessment basis" topicId="assessment-basis"/></Detail>
     <Detail label="Form coverage">{forms.map(v=>v==='v0.5-core'?'v0.5 core fields':v==='v0.5'?'v0.5 full form':v).join(' · ')||'No assessments yet'}</Detail>
     <Detail label="Figure evidence">{figures} selected, reviewer-approved {figures===1?'observation':'observations'} · {unavailable} unavailable {unavailable===1?'selection':'selections'}</Detail>
     <Detail label="Study groups">{n.groups} labelled · {n.ungrouped} ungrouped {n.ungrouped===1?'report':'reports'}</Detail>
     <Detail label="Outside the claim counts">{n.structural} structural {n.structural===1?'report':'reports'} · {n.excluded} excluded {n.excluded===1?'claim':'claims'}</Detail>
    </dl>
    <p>Counts describe saved claim assessments, not independent studies. Accepted means the assessment has been reviewed, not that the authors’ claim is supported.</p>
    <p>Each report uses one selected assessment. Study-group labels do not establish dataset independence. Figure observations are selected separately from the claim filter and do not change EMP codes or study counts.</p>
    <p>This collection provides a descriptive synthesis. No meta-analysis or automatic assessment of matching scope across reports is performed.</p>
    <HelpLink topicId="synthesis">How to interpret a project synthesis</HelpLink>
   </div>
  </details>
 </section>;
}
function Detail({label,children}:{label:string;children:React.ReactNode}){return <div className="grid sm:grid-cols-[10rem_1fr] gap-x-4 gap-y-0.5"><dt className="text-muted-foreground">{label}</dt><dd>{children}</dd></div>;}
