"use client";
import {HelpLink,HelpTerm} from "./help-term";
import {helpForFieldPath} from '@/lib/help-content';
import {useState} from 'react';
import {useLanguage} from './language-switch';
import {compareFields,fieldLabel} from '@/lib/field-comparison';
import type {Source} from '@/lib/emp';
import {Checkbox} from './ui/checkbox';
import {Input} from './ui/input';
import {Table,TableHeader,TableHead,TableRow,TableBody,TableCell} from './ui/table';
export default function FieldComparison({left,right,leftLabel='A',rightLabel='B',sources}:{left:unknown;right:unknown;leftLabel?:string;rightLabel?:string;sources?:[Source,Source]}){
 const language=useLanguage(),l=(en:string,pl:string)=>language==='pl'?pl:en;
 const [differencesOnly,setDifferencesOnly]=useState(true),[query,setQuery]=useState('');
 const rows=compareFields(left,right),shown=rows.filter(r=>(!differencesOnly||r.different)&&`${r.path} ${fieldLabel(r.path,language)}`.toLowerCase().includes(query.toLowerCase()));
 return <div className="space-y-3"><HelpLink topicId="compare">How to interpret field differences</HelpLink><div className="flex flex-wrap items-center gap-4"><label className="flex gap-2 items-center text-sm"><Checkbox checked={differencesOnly} onCheckedChange={v=>setDifferencesOnly(v===true)}/>{'Differences only'}</label><span className="text-sm">{rows.filter(r=>r.different).length} / {rows.length} {'fields differ'}</span><Input className="sm:max-w-64" aria-label={'Find a field'} placeholder={'Find a field…'} value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="overflow-x-auto rounded-xl border"><Table className="table-fixed min-w-[600px]"><TableHeader><TableRow><TableHead className="w-1/4 whitespace-normal">{'Field'}</TableHead><TableHead className="whitespace-normal">{leftLabel}</TableHead><TableHead className="whitespace-normal">{rightLabel}</TableHead></TableRow></TableHeader><TableBody>{shown.map(r=><TableRow key={r.path} className={r.different?'bg-amber-50/60':''}><TableCell className="whitespace-normal align-top text-sm font-medium break-words">{fieldLabel(r.path,language)}<HelpTerm label={fieldLabel(r.path,language)} topicId={helpForFieldPath(r.path)}/>{r.different&&<span className="block text-xs text-amber-800 mt-1">{'Different'}</span>}</TableCell>{[r.left,r.right].map((value,i)=><TableCell key={i} className="whitespace-normal align-top text-sm break-words"><FieldValue value={value} source={sources?.[i]} path={r.path}/></TableCell>)}</TableRow>)}</TableBody></Table>{!shown.length&&<p className="p-4 text-sm">{'No fields match this filter.'}</p>}</div></div>;
}
function FieldValue({value,source,path}:{value:unknown;source?:Source;path:string}){
 const lang=useLanguage(),l=(en:string,pl:string)=>lang==='pl'?pl:en;
 if(value===undefined)return <span className="text-muted-foreground">{'Not supplied'}</span>;
 if(value===null)return <span className="text-muted-foreground">{'No entry (null)'}</span>;
 if(typeof value==='boolean')return <span>{value?'Yes':'No'}</span>;
 if(Array.isArray(value))return value.length?<ol className="space-y-3">{value.map((v,i)=><li key={i}><FieldValue value={v} source={source} path={path}/></li>)}</ol>:<span>{'Empty list'}</span>;
 if(value&&typeof value==='object'){
  const v=value as Record<string,unknown>,block=source?.blocks.find(b=>b.id===v.blockId);
  if(typeof v.quote==='string')return <div className="space-y-2"><blockquote className="border-l-2 pl-3 whitespace-pre-wrap">{v.quote}</blockquote><span className="text-xs text-muted-foreground">{String(v.blockId||'')} · {block?.label}</span>{block&&<details><summary className="cursor-pointer">{'Open source passage'}</summary><p className="whitespace-pre-wrap mt-2">{block.text}</p></details>}</div>;
  return <dl>{Object.entries(v).map(([k,x])=><div key={k}><dt className="font-medium">{fieldLabel(k,lang)}</dt><dd><FieldValue value={x} source={source} path={k}/></dd></div>)}</dl>;
 }
 const block=path.endsWith('blockId')?source?.blocks.find(b=>b.id===value):undefined;
 return <div className="whitespace-pre-wrap">{value===''?'Empty text':String(value)}{block&&<details className="mt-2"><summary className="cursor-pointer">{block.label}</summary><p className="mt-2">{block.text}</p></details>}</div>;
}
