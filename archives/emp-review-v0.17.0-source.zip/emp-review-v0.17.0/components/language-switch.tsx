"use client";
import {useEffect} from "react";
import {setLanguage,type Language} from "@/lib/i18n";
/** English is the product language; legacy stored preferences cannot change it. */
export function useLanguage():Language{useEffect(()=>{setLanguage("en");},[]);return "en";}
