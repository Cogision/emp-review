"use client";
import {useEffect,useState} from 'react';
import {Button} from './ui/button';
import {Checkbox} from './ui/checkbox';
import {Choice,TextField} from './claim-editor';
import {useLanguage} from './language-switch';
import {request} from '@/lib/http';
import {tr} from '@/lib/i18n';
import type {ProjectData} from '@/lib/projects';
import type {Figure,FigureRun} from '@/lib/figures';
import type {SelectedFigureObservation} from '@/lib/project-figures';

export function FigureObservation({row,onOpen}:{row:SelectedFigureObservation;onOpen?:()=>void}){
 const locale=useLanguage(),l=(en:string,pl:string)=>locale==='pl'?pl:en;
 return <details className="border rounded-xl p-4 text-sm"><summary className="cursor-pointer text-primary">{row.title} · {row.figure.label} · {row.observation.panel||'Figure'}</summary>
 <p className="my-3 whitespace-pre-wrap">{row.observation.statement}</p><p>{row.kind} · {row.readability} · {row.observation.relation}</p>
 {row.observation.textCitation&&<blockquote className="border-l-2 pl-3 my-3 whitespace-pre-wrap">{row.observation.textCitation.quote}<p className="text-muted-foreground">{row.observation.textCitation.blockId}</p></blockquote>}
 <p className="my-3">{'Project relevance'}: {row.selection.note}</p>
 {row.limitations.map((v,i)=><p key={i} className="my-2 text-muted-foreground">{v}</p>)}
 <p>{'Reviewer comment'}: {row.review.comment||'None'}</p>
 <p className="mt-3 text-xs break-all">{row.model} · {row.generatedAt} · {"Review"} r{row.review.revision} · {row.review.updatedAt}<br/>{'Reviewer'}: {row.reviewerId}<br/>{'Review event'}: {row.reviewEventId}<br/>{'Figure analysis'}: {row.runId}<br/>SHA-256: {row.imageHash}</p>
 {onOpen&&<Button variant="link" size="sm" onClick={onOpen}>{'Open source article'}</Button>}
 </details>;
}

export default function ProjectFigureChoice({data,disabled,onBusy,onDirty,onChanged,onOpen}:{data:ProjectData;disabled:boolean;onBusy:(v:boolean)=>void;onDirty:(v:boolean)=>void;onChanged:()=>Promise<void>;onOpen:(id:string)=>void}){
 const locale=useLanguage(),l=(en:string,pl:string)=>locale==='pl'?pl:en;
 const [documentId,setDocumentId]=useState(''),[options,setOptions]=useState<Array<{figure:Figure;runs:FigureRun[]}>>([]),[loaded,setLoaded]=useState(false),[selected,setSelected]=useState(''),[indices,setIndices]=useState<number[]>([]),[note,setNote]=useState(''),[baseline,setBaseline]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const entries=options.flatMap(i=>i.runs.map(run=>({figure:i.figure,run,key:`${i.figure.id}/${run.id}`}))),entry=entries.find(e=>e.key===selected),dirty=!!selected&&JSON.stringify({selected,indices,note})!==baseline;
 useEffect(()=>{onDirty(dirty);return()=>onDirty(false);},[dirty,onDirty]);
 const mayLeave=()=>!dirty||window.confirm('Discard unsaved figure selection changes?');
 function reset(){setSelected('');setIndices([]);setNote('');setBaseline('');setOptions([]);setLoaded(false);}
 async function loadOptions(){if(!documentId||disabled||!mayLeave())return;onBusy(true);setError('');setNotice('');try{const r=await request<{items:typeof options}>(`/api/projects/${data.project.id}/figure-evidence?documentId=${encodeURIComponent(documentId)}`);reset();setOptions(r.items);setLoaded(true);}catch(e){setError(tr((e as Error).message));}finally{onBusy(false);}}
 function choose(key:string){if(!mayLeave())return;const item=entries.find(e=>e.key===key),saved=data.figureSelections?.find(s=>item&&s.selection.documentId===documentId&&s.selection.figureId===item.figure.id&&s.selection.runId===item.run.id),chosen=saved?.selection.indices||[],reason=saved?.selection.note||'';setSelected(key);setIndices(chosen);setNote(reason);setBaseline(saved?JSON.stringify({selected:key,indices:chosen,note:reason}):'');setNotice('');}
 async function save(){if(!entry||disabled)return;onBusy(true);setError('');try{await request(`/api/projects/${data.project.id}/figure-evidence`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:data.project.revision,documentId,figureId:entry.figure.id,runId:entry.run.id,reviewRevision:entry.run.review.revision,indices,note})});setBaseline(JSON.stringify({selected,indices,note}));await onChanged();setNotice('Selected observations saved for this project.');}catch(e){setError(tr((e as Error).message));}finally{onBusy(false);}}
 async function remove(documentId:string,figureId:string){if(disabled||!mayLeave())return;onBusy(true);setError('');try{await request(`/api/projects/${data.project.id}/figure-evidence`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:data.project.revision,documentId,figureId,runId:null})});reset();await onChanged();}catch(e){setError(tr((e as Error).message));}finally{onBusy(false);}}
 return <section className="rounded-2xl border bg-white p-6 space-y-4"><h2 className="font-semibold text-xl">{'Figure observations in this synthesis'}</h2>
 <p className="text-sm text-muted-foreground">{'Select observations from a reviewed figure analysis and explain their relevance. The saved selection supplements the narrative; EMP codes and counts remain unchanged.'}</p>
 {(data.figureSelections||[]).map(s=><div key={s.selection.figureId} className={`border rounded-xl p-4 ${s.eligible?'':'bg-amber-50'}`}><p className="font-medium">{s.title} · {s.figure?.label||s.selection.figureId}</p><p className="text-sm my-2">{s.eligible?'Included':s.reason} · {s.selection.indices.length} {'observations'}</p><p className="text-sm whitespace-pre-wrap">{s.selection.note}</p><div className="flex flex-wrap gap-2 mt-2"><Button size="sm" variant="link" disabled={disabled} onClick={()=>onOpen(s.selection.documentId)}>{'Open article and review'}</Button><Button size="sm" variant="outline" disabled={disabled} onClick={()=>void remove(s.selection.documentId,s.selection.figureId)}>{'Remove from synthesis'}</Button></div></div>)}
 <fieldset disabled={disabled} className="space-y-4"><Choice label={'Source article'} value={documentId} options={data.documents.map(d=>[d.id,d.title])} onChange={id=>{if(mayLeave()){reset();setDocumentId(id);}}}/><Button variant="outline" disabled={disabled||!documentId} onClick={()=>void loadOptions()}>{'Load reviewed figure analyses'}</Button>
 {loaded&&!entries.length&&<p className="text-sm">{'No eligible figure analysis. Open the article, analyse a figure, and mark its result checked after inspecting the source.'}</p>}
 {entries.length>0&&<Choice label={'Figure and saved analysis'} value={selected} options={entries.map(e=>[e.key,`${e.figure.label} · ${new Date(e.run.createdAt).toLocaleString(locale)} · ${e.run.model} · r${e.run.review.revision}`])} onChange={choose}/>}
 {entry&&<div className="space-y-4"><p className="text-sm">{entry.run.report.summary}</p>{entry.run.report.observations.map((o,i)=><label key={i} className="flex items-start gap-3 border rounded-xl p-4 text-sm"><Checkbox checked={indices.includes(i)} onCheckedChange={yes=>setIndices(yes?[...indices,i].sort((a,b)=>a-b):indices.filter(x=>x!==i))}/><span><b>{o.panel||'Observation'}</b><br/>{o.statement}<br/><span className="text-muted-foreground">{o.relation}</span></span></label>)}<TextField label={'Why include these observations in this project?'} value={note} onChange={setNote} rows={3}/><Button disabled={disabled||!indices.length||!note.trim()} onClick={()=>void save()}>{'Save selection for synthesis'}</Button><p role="status" className="text-sm">{dirty?'Unsaved selection':'Saved selection'}</p></div>}
 </fieldset>{error&&<p role="alert" className="text-sm text-amber-900">{error}</p>}{notice&&<p role="status" className="text-sm">{notice}</p>}
 </section>;
}
