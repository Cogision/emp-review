"use client";
import {HelpLink} from "./help-term";
import type {SynthesisProgress,SynthesisReply} from "@/lib/synthesis-work";
import {FigureObservation} from "./project-figure-choice";
import {selectedFigureObservations} from "@/lib/project-figures";
import {useEffect,useRef,useState} from "react";
import {Sparkles,Loader2} from "lucide-react";
import {Button} from "./ui/button";
import {Choice} from "./claim-editor";
import {useLanguage} from "./language-switch";
import {request} from "@/lib/http";
import {tr,type Language} from "@/lib/i18n";
import {synthesisFingerprint,type SynthesisMeta,type SynthesisSnapshot} from "@/lib/project-interpretation";
import {synthesise,type ProjectData,type ProjectFilter} from "@/lib/projects";

export default function ProjectInterpretation({data,filter,language,apiKey,model,configured,onSettings,onOpen,onSelected,onBusy,onRefresh}:{data:ProjectData;filter:ProjectFilter;language:Language;apiKey:string;model:string;configured:boolean;onSettings:()=>void;onOpen:(documentId:string,claimId?:string)=>void;onSelected:(s:SynthesisSnapshot|null)=>void;onBusy:(busy:boolean)=>void;onRefresh:()=>void}){
 const locale=useLanguage(),l=(en:string,pl:string)=>locale==="pl"?pl:en,alive=useRef(true);
 const [list,setList]=useState<SynthesisMeta[]>([]),[selected,setSelected]=useState<SynthesisSnapshot|null>(null),[fingerprint,setFingerprint]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState(""),[seconds,setSeconds]=useState(0);
 const [pending,setPending]=useState<SynthesisProgress|null>(null),[checkingRun,setCheckingRun]=useState(true);
 const pause=useRef(false),storageKey=`emp-synthesis-run:${data.project.id}`;
 function remember(run:SynthesisProgress|null){setPending(run);try{if(run)localStorage.setItem(storageKey,run.id);else localStorage.removeItem(storageKey);}catch{}}
 useEffect(()=>{let active=true;setCheckingRun(true);let id:string|null=null;try{id=localStorage.getItem(storageKey);}catch{}
  if(!id){setCheckingRun(false);return;}
  void request<SynthesisReply>(`/api/projects/${data.project.id}/syntheses?run=${encodeURIComponent(id)}`).then(reply=>{if(!active)return;if(reply.snapshot){adopt(reply.snapshot);remember(null);}else setPending(reply.run);}).catch(e=>{if(active)setError(tr((e as Error).message));}).finally(()=>{if(active)setCheckingRun(false);});
  return()=>{active=false;};
 },[storageKey]);
 const eligible=synthesise(data,filter).rows.length+selectedFigureObservations(data).length;
 useEffect(()=>{alive.current=true;onSelected(null);void loadList();return()=>{alive.current=false;};},[]);
 useEffect(()=>{let active=true;setFingerprint("");void synthesisFingerprint(data,filter).then(f=>{if(active)setFingerprint(f);}).catch(()=>{if(active)setError("Could not check the source snapshot. Refresh the project.");});return()=>{active=false;};},[data,filter]);
 useEffect(()=>{if(!busy)return;const start=Date.now();setSeconds(0);const t=setInterval(()=>setSeconds(Math.floor((Date.now()-start)/1000)),1000);return()=>clearInterval(t);},[busy]);
 async function loadList(){try{const r=await request<{snapshots:SynthesisMeta[]}>(`/api/projects/${data.project.id}/syntheses`);if(alive.current)setList(r.snapshots);}catch(e){if(alive.current)setError(tr((e as Error).message));}}
 function adopt(s:SynthesisSnapshot){setSelected(s);onSelected(s);}
 async function choose(id:string){setBusy(true);onBusy(true);setError("");try{const s=await request<SynthesisSnapshot>(`/api/projects/${data.project.id}/syntheses?snapshot=${encodeURIComponent(id)}`);if(alive.current)adopt(s);}catch(e){if(alive.current)setError(tr((e as Error).message));}finally{if(alive.current)setBusy(false);onBusy(false);}}
 async function generate(){if(!configured&&!apiKey.trim()){onSettings();return;}setBusy(true);onBusy(true);setError("");pause.current=false;try{
  const endpoint=`/api/projects/${data.project.id}/syntheses`;
  let reply:SynthesisReply;
  if(pending)reply=await request<SynthesisReply>(`${endpoint}?run=${encodeURIComponent(pending.id)}`);
  else reply=await request<SynthesisReply>(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"start",filter,language,revision:data.project.revision,key:apiKey||undefined,model})});
  if(alive.current)remember(reply.run);
  while(!reply.snapshot&&alive.current&&!pause.current){
   reply=await request<SynthesisReply>(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"step",runId:reply.run.id,key:apiKey||undefined})});
   if(alive.current)remember(reply.run);
  }
  if(alive.current&&reply.snapshot){adopt(reply.snapshot);remember(null);await loadList();onRefresh();}
 }catch(e){if(alive.current)setError(`${tr((e as Error).message)} Completed synthesis steps remain saved. Resume to retry the unfinished step.`);}finally{if(alive.current)setBusy(false);onBusy(false);}}
 function download(){if(!selected)return;const url=URL.createObjectURL(new Blob([JSON.stringify(selected,null,2)],{type:"application/json"})),a=document.createElement("a");a.href=url;a.download=`EMP_synthesis_${selected.id.slice(0,8)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}
 const current=!!selected&&fingerprint===selected.fingerprint&&selected.filter===filter&&selected.language===language;
 const groups=selected?[["Overview",selected.result.overview],["Findings, differences and gaps",selected.result.findings],["Limits of interpretation",selected.result.limitations],["Questions to investigate",selected.result.nextQuestions]] as const:[];
 return <section className="rounded-2xl border bg-white p-6 space-y-4"><div className="flex flex-wrap items-center justify-between gap-4"><div><h2 className="text-xl font-semibold">{"Interpret the collection"}</h2><HelpLink topicId="synthesis">How synthesis uses your assessments</HelpLink><p className="text-sm text-muted-foreground mt-2">{"AI synthesises the saved assessments selected above. It preserves their scope and links each paragraph to its sources."}</p></div><Button onClick={()=>void generate()} disabled={busy||checkingRun||(!eligible&&!pending)}>{busy?<Loader2 size={17} className="animate-spin motion-reduce:animate-none"/>:<Sparkles size={17}/>} {checkingRun?"Checking saved progress…":pending?"Resume synthesis":"Generate synthesis"} ({(pending?.language||language).toUpperCase()})</Button></div>
 <p className="text-xs text-muted-foreground">{"This sends saved assessments, approved figure observations and cited passages to your configured AI. Larger collections are processed in batches and then combined; every selected record is included in a batch. More batches take longer and use more AI credits. The final narrative is a qualitative summary, not a restatement of every claim. AI interpretations remain unverified."}</p>
 {pending&&<div className="rounded-xl border p-4 text-sm" role="status"><p><b>{pending.phase==='combine'?'Combining batch syntheses':pending.phase==='complete'?'Finishing the saved synthesis':'Assessment batches'}</b> · {pending.completedBatches}/{pending.batchCount} batches saved · {pending.completedSteps} total steps saved</p><p className="mt-1">{pending.claimCount} claims · {pending.figureCount} selected figure observations · {pending.filter} filter · {pending.model}</p>{pending.fingerprint!==fingerprint&&fingerprint&&<p className="mt-2 text-amber-800">This run uses an earlier project state or a different filter. Resume preserves that snapshot; start a new synthesis to use the current selection.</p>}{!busy&&<Button className="mt-2" variant="outline" onClick={()=>remember(null)}>Start a new synthesis instead</Button>}</div>}
 {busy&&<div role="status" aria-live="polite" className="rounded-xl bg-muted p-4"><p className="text-sm mb-2">{"Processing the synthesis…"} {seconds}s</p><div role="progressbar" aria-label={"Synthesis in progress"} className="h-2 rounded-full bg-primary/15 overflow-hidden"><div className="h-full w-1/3 rounded-full bg-primary animate-pulse motion-reduce:animate-none"/></div><p className="text-xs text-muted-foreground mt-2">{"Each completed step is saved. Keep this tab open to continue automatically, or pause after the current step."}</p><Button variant="outline" className="mt-3" onClick={()=>{pause.current=true;setError("Pausing after the current step is saved. You can resume later.");}}>Pause after this step</Button></div>}
 {error&&<p role="alert" className="text-sm border border-amber-300 bg-amber-50 rounded-xl p-3">{error}</p>}
 {list.length>0&&<fieldset disabled={busy}><Choice label={"Saved syntheses (latest 100)"} value={selected?.id||""} options={list.map(s=>[s.id,`${new Date(s.created_at).toLocaleString(locale)} · ${s.language.toUpperCase()} · ${s.filter} · ${s.model}`])} onChange={id=>void choose(id)}/></fieldset>}
 {selected&&<><div className={`rounded-xl p-4 text-sm ${current?"bg-emerald-50":"bg-amber-50"}`}><b>{current?"Matches this saved project state":!fingerprint?"Checking source state…":"Earlier project state or different filter/language"}</b><p className="mt-1">{current?"Included in the project report export. References confirm provenance, not the correctness of an interpretation.":"Kept as a separate snapshot. Generate a new synthesis to include it in the current project report."}</p><p className="mt-2 text-xs">{new Date(selected.createdAt).toLocaleString(locale)} · {selected.language.toUpperCase()} · {selected.model} · {selected.filter}</p></div>
 {groups.filter(([,items])=>items.length).map(([title,items])=><div key={title}><h3 className="font-semibold mb-3">{title}</h3>{items.map((p,i)=><div key={i} className="mb-4"><p className="text-sm leading-relaxed whitespace-pre-wrap">{p.text}</p><div className="mt-2 space-y-2">{p.claimKeys.map(k=>{const row=selected.input.claims.find(c=>c.key===k)!;return <details key={k} className="text-xs rounded-lg border p-3"><summary className="text-primary cursor-pointer">{row.title} · {row.claim.id} · r{row.revision}</summary>{row.assessmentBasis&&<p className="my-2">{row.assessmentBasis.kind==='adjudicated'?'Adjudicated assessment':'Document assessment'} · {row.assessmentBasis.manualVersion} {row.assessmentBasis.adjudicationId||''}</p>}<p className="font-medium my-2">{row.claim.statement}</p><p>{row.claim.evidenceSummary}</p>{row.locations.map((q,j)=><blockquote key={j} className="border-l-2 pl-3 my-3 whitespace-pre-wrap"><p>{q.quote}</p><p className="text-muted-foreground mt-1">{q.fileName} · {q.label} · {q.exists?"Quote found in source":"Quote not verified"}</p></blockquote>)}<p>{"Saved assessment status"}: {row.status}; {"Source checked"}: {String(row.sourceChecked)}</p><Button variant="link" size="sm" disabled={busy} onClick={()=>onOpen(row.documentId,row.claim.id)}>{"Open current review"}</Button></details>;})}{(p.figureKeys||[]).map(k=>{const row=selected.input.figureObservations?.find(f=>f.key===k);return row?<FigureObservation key={k} row={row} onOpen={()=>onOpen(row.documentId)}/>:null;})}</div></div>)}</div>)}
 <Button variant="outline" disabled={busy} onClick={download}>{"Download this synthesis with its source snapshot"}</Button></>}
 </section>;
}
