"use client";
import {useEffect,useRef,useState} from 'react';
import {Button} from './ui/button';
import {Input} from './ui/input';
import {request} from '@/lib/http';
import type {AccountProfile} from '@/lib/account-profile';
import {validInvitationCode} from '@/lib/reviewer-invitations';

// Temporary, tab-local handoff through sign-in. The server owns invitation validity and access.
const HANDOFF_KEY='emp-pending-round-invitation';
export default function RoundJoin({user}:{user:{email:string;displayName:string}|null}){
 const [code,setCode]=useState(''),[name,setName]=useState(user?.displayName||''),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState(''),[roundId,setRoundId]=useState('');
 const [hasSuppliedCode,setHasSuppliedCode]=useState(false);
 const nameEdited=useRef(false);
 useEffect(()=>{
  let cancelled=false;
  if(user)void request<AccountProfile>('/api/account').then(profile=>{if(!cancelled&&!nameEdited.current)setName(profile.displayName);}).catch(()=>{});
  return()=>{cancelled=true;};
 },[user]);
 useEffect(()=>{
  const fromLink=new URLSearchParams(window.location.hash.slice(1)).get('invite')||'';
  let value=fromLink;
  if(!value){try{const saved=JSON.parse(sessionStorage.getItem(HANDOFF_KEY)||'null');if(saved&&Date.now()-saved.savedAt<30*60*1000)value=saved.code;else sessionStorage.removeItem(HANDOFF_KEY);}catch{/* A manual code remains available when browser storage is disabled. */}}
  if(validInvitationCode(value)){setCode(value);setHasSuppliedCode(true);}
  else if(fromLink)setError('This invitation link is not valid. Ask the coordinator for a new link.');
  setReady(true);
 },[]);
 function remember(){try{sessionStorage.setItem(HANDOFF_KEY,JSON.stringify({code,savedAt:Date.now()}));}catch{setError('Your browser cannot keep the invitation during sign-in. Sign in, then open the original invitation link again.');}}
 async function join(e:React.FormEvent){e.preventDefault();if(busy||!validInvitationCode(code)||!name.trim())return;setBusy(true);setError('');try{
  const result=await request<{id:string}>('/api/rounds/join',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:code,name:name.trim()})});setRoundId(result.id);setCode('');try{sessionStorage.removeItem(HANDOFF_KEY);}catch{}history.replaceState(null,'','/join');
 }catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 return <main className="min-h-screen bg-background px-5 py-12"><div className="max-w-xl mx-auto rounded-2xl border bg-white p-6 sm:p-8 space-y-5">
  <p className="font-semibold text-primary">EMP Review</p><h1 className="text-2xl font-semibold">Join a review round</h1>
  {!ready?<p role="status">Opening invitation…</p>:roundId?<><p role="status">Your request is recorded. The coordinator will check your account and approve access to the round.</p><Button asChild><a href={`/?round=${encodeURIComponent(roundId)}`}>Open round</a></Button></>:!user?<>
   <p>Sign in with the ChatGPT account for the email address receiving this invitation.</p>
   <Button asChild><a href="/signin-with-chatgpt?return_to=%2Fjoin" target="_top" onClick={remember}>Sign in with ChatGPT</a></Button>
   <p className="text-sm text-muted-foreground">If the code is missing after sign-in, open your original invitation link again.</p>
  </>:<form onSubmit={e=>void join(e)} className="space-y-4">
   <p className="text-sm">Signed in as <strong className="break-all">{user.email}</strong></p>
   <p className="text-sm text-muted-foreground">Only this round’s shared source will become available after approval and round start. Other assessments stay hidden until they are released.</p>
   {hasSuppliedCode?<div className="rounded-lg bg-primary/5 p-3 text-sm"><p>Invitation ready. Confirm your reviewer name to request access.</p><Button type="button" variant="link" size="sm" className="px-0" disabled={busy} onClick={()=>setHasSuppliedCode(false)}>Use another invitation code</Button></div>:(<label className="grid gap-2 text-sm font-medium">Invitation code<Input autoComplete="off" value={code} onChange={e=>setCode(e.target.value.trim())} disabled={busy} maxLength={64} required/></label>)}
   <label className="grid gap-2 text-sm font-medium">Your reviewer name<Input autoComplete="name" value={name} onChange={e=>{nameEdited.current=true;setName(e.target.value);}} maxLength={120} disabled={busy} required/></label>
   <Button type="submit" disabled={busy||!validInvitationCode(code)||!name.trim()}>{busy?'Requesting access…':'Request to join'}</Button>
   <div><a className="text-sm underline underline-offset-4" href="/signout-with-chatgpt?return_to=%2Fjoin" target="_top" onClick={remember}>Use a different account</a></div>
  </form>}
  {error&&<p role="alert" className="text-sm text-amber-900 whitespace-pre-wrap">{error}</p>}
 </div></main>;
}
