"use client";
import type {Source,Citation} from "@/lib/emp";
import {useLanguage} from "./language-switch";
export default function SourceContext({source,citation}:{source:Source;citation:Citation}){
 const lang=useLanguage(),index=source.blocks.findIndex(b=>b.id===citation.blockId),block=source.blocks[index];
 if(!block)return null;
 const location=source.files?.find(f=>f.id===block.fileId)?.fileName||source.fileName;
 const start=citation.quote?block.text.indexOf(citation.quote):-1;
 const highlighted=start>=0?<>{block.text.slice(0,start)}<mark className="bg-amber-200/70">{citation.quote}</mark>{block.text.slice(start+citation.quote.length)}</>:block.text;
 return <details className="mt-3 text-sm"><summary className="cursor-pointer text-primary font-medium">{lang==="pl"?"Pokaż otoczenie cytatu":"Show surrounding text"}</summary><p className="text-xs text-muted-foreground mt-2 break-words">{location} · {block.label}</p><div className="max-h-80 overflow-auto space-y-3 mt-3 rounded-lg border p-3 leading-relaxed">{index>0&&source.blocks[index-1].fileId===block.fileId&&<p className="text-muted-foreground">{source.blocks[index-1].text}</p>}<p className="whitespace-pre-wrap">{highlighted}</p>{source.blocks[index+1]&&source.blocks[index+1].fileId===block.fileId&&<p className="text-muted-foreground">{source.blocks[index+1].text}</p>}</div></details>;
}
