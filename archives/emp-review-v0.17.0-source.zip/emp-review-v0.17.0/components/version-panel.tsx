"use client";
import {HelpLink} from "./help-term";
import {useLanguage} from './language-switch';
import {APP_VERSION,MANUAL_RELEASES,legacyManifest} from '@/lib/versions';
import type {RecordDoc} from '@/lib/emp';
import AssessmentComparison from './assessment-comparison';
import {Button} from './ui/button';
import {saveFigureData} from './figures-panel';
export default function VersionPanel({doc}:{doc:RecordDoc}){
 const locale=useLanguage(),l=(en:string,pl:string)=>locale==='pl'?pl:en,v=doc.versions||legacyManifest(doc.analysis,doc.review),ai=doc.analysis?.versions;
 return <details className="rounded-2xl border bg-white p-5 mb-5"><summary className="cursor-pointer font-semibold text-lg">{'Versions and assessment history'} · {v.manualVersion} · r{doc.revision}</summary><div className="space-y-5 mt-5"><HelpLink topicId="versions">Understand versions and saved revisions</HelpLink>
 <dl className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 text-sm">{[['Application now',APP_VERSION],['Coding manual',v.manualVersion],['Form coverage',v.scope==='full'?'Full v0.5':'Core fields of v0.5'],['Saved assessment revision',`r${doc.revision}`],['Application at this save',v.appVersion||'Not recorded'],['Application at AI generation',ai?.appVersion||'Not recorded'],['Full form template',v.formVersion||'Not used for core coding'],['Saved at',new Date(doc.updatedAt).toLocaleString(locale)]].map(([key,val])=><div key={key}><dt className="text-muted-foreground mb-1">{key}</dt><dd className="font-medium">{val}</dd></div>)}</dl>
 <p className="text-sm text-muted-foreground">{'Saving an assessment creates a new record revision. It does not change the coding manual or overwrite earlier saved assessments. Full and core coverage refer to the same v0.5 manual. Older records without application metadata are shown as not recorded.'}</p>
 <details className="rounded-xl bg-muted p-4 text-sm"><summary className="cursor-pointer font-medium">{'Available manuals and changes'}</summary><ul className="list-disc pl-5 mt-3">{MANUAL_RELEASES.map(r=><li key={r.version}>{r.version} · {'Current normative manual'}</li>)}</ul><p className="mt-3">{'Versions 0.6 and later will become selectable when their rules and field mappings are defined. A future update will create a separate assessment with a change comparison; existing v0.5 reports will keep their original labels.'}</p><p className="mt-3">{'Application 0.10.0 adds field comparison, article figures and version metadata. The EMP v0.5 coding rules are unchanged.'}</p></details>
 <Button variant="outline" onClick={()=>saveFigureData({documentId:doc.id,sourceHash:doc.sourceHash,revision:doc.revision,recordedVersions:v,analysisVersions:ai||null,exportedWith:APP_VERSION},`EMP_versions_${doc.id.slice(0,8)}_r${doc.revision}.json`)}>{'Export version record'}</Button>
 {doc.analysis&&<AssessmentComparison data={{documents:[doc],generatedAt:`${doc.id}:${doc.revision}`}}/>}
 </div></details>;
}
