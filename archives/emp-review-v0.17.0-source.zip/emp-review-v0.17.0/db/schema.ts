import { sqliteTable, text, integer, index, primaryKey } from "drizzle-orm/sqlite-core";
export const accountProfiles = sqliteTable('account_profiles', {
 userId:text('user_id').primaryKey(),displayName:text('display_name').notNull(),affiliation:text('affiliation').notNull().default(''),
 revision:integer('revision').notNull().default(1),updatedAt:text('updated_at').notNull(),
});
export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(), owner: text("owner").notNull(), title: text("title").notNull(),
  stage: text("stage").notNull(), coverage: text("coverage").notNull(), sourceKey: text("source_key").notNull(),
  sourceHash: text("source_hash").notNull(), analysis: text("analysis"), review: text("review").notNull(), versionManifest:text('version_manifest'),
  mutation: text("mutation").notNull().default(""), revision: integer("revision").notNull().default(0), createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
}, t => [index("documents_owner").on(t.owner)]);
export const events = sqliteTable("events", {
  id: text("id").primaryKey(), documentId: text("document_id").notNull().references(()=>documents.id),
  owner: text("owner").notNull(), revision: integer("revision").notNull(), kind: text("kind").notNull(),
  payload: text("payload").notNull(), createdAt: text("created_at").notNull(),
}, t => [index("events_document").on(t.documentId)]);

export const projects = sqliteTable("projects", {
 id:text("id").primaryKey(), owner:text("owner").notNull(), title:text("title").notNull(), question:text("question").notNull().default(""),
 criteria:text("criteria").notNull().default(""), language:text("language").notNull().default("en"), revision:integer("revision").notNull().default(0),
 createdAt:text("created_at").notNull(), updatedAt:text("updated_at").notNull(),
},t=>[index("projects_owner").on(t.owner)]);
export const projectDocuments=sqliteTable("project_documents",{
 projectId:text("project_id").notNull().references(()=>projects.id), documentId:text("document_id").notNull().references(()=>documents.id),
 selectedRoundId:text("selected_round_id"), selectedAdjudicationId:text("selected_adjudication_id"),
 studyGroup:text("study_group").notNull().default(""), addedAt:text("added_at").notNull(),
},t=>[primaryKey({columns:[t.projectId,t.documentId]}),index("project_documents_document").on(t.documentId)]);
export const assessmentRuns=sqliteTable("assessment_runs",{
 id:text("id").primaryKey(),documentId:text("document_id").notNull().references(()=>documents.id),owner:text("owner").notNull(),
 actorType:text("actor_type").notNull(),actorId:text("actor_id").notNull(),model:text("model"),manualVersion:text("manual_version").notNull(),
 sourceHash:text("source_hash").notNull(),stage:text("stage").notNull(),revision:integer("revision").notNull(),snapshotKey:text("snapshot_key").notNull(),createdAt:text("created_at").notNull(),
},t=>[index("assessment_runs_document").on(t.documentId)]);
export const projectSyntheses=sqliteTable("project_syntheses",{
 id:text("id").primaryKey(),projectId:text("project_id").notNull().references(()=>projects.id),owner:text("owner").notNull(),
 filter:text("filter").notNull(),language:text("language").notNull(),model:text("model").notNull(),fingerprint:text("fingerprint").notNull(),
 snapshotKey:text("snapshot_key").notNull(),createdAt:text("created_at").notNull(),
},t=>[index("project_syntheses_project").on(t.projectId)]);

export const reviewRounds=sqliteTable('review_rounds',{
 id:text('id').primaryKey(),coordinatorId:text('coordinator_id').notNull(),title:text('title').notNull(),mode:text('mode').notNull(),status:text('status').notNull().default('recruiting'),
 manualVersion:text('manual_version').notNull(),sourceDocumentId:text('source_document_id').notNull(),sourceHash:text('source_hash').notNull(),stage:text('stage').notNull(),sourceKey:text('source_key').notNull(),proposalKey:text('proposal_key'),hadAnalysis:integer('had_analysis').notNull(),
 revision:integer('revision').notNull().default(0),mutation:text('mutation').notNull().default(''),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),
},t=>[index('review_rounds_coordinator').on(t.coordinatorId)]);
export const roundMembers=sqliteTable('round_members',{
 roundId:text('round_id').notNull().references(()=>reviewRounds.id),userId:text('user_id').notNull(),name:text('name').notNull(),email:text('email').notNull(),status:text('status').notNull().default('pending'),
 draftKey:text('draft_key'),revision:integer('revision').notNull().default(0),submissionId:text('submission_id'),submittedAt:text('submitted_at'),createdAt:text('created_at').notNull(),
},t=>[primaryKey({columns:[t.roundId,t.userId]}),index('round_members_user').on(t.userId)]);
export const roundInvites=sqliteTable('round_invites',{
 id:text('id').primaryKey(),roundId:text('round_id').notNull().references(()=>reviewRounds.id),tokenHash:text('token_hash').notNull().unique(),recipientEmail:text('recipient_email'),expiresAt:text('expires_at').notNull(),revokedAt:text('revoked_at'),claimedBy:text('claimed_by'),claimId:text('claim_id'),createdAt:text('created_at').notNull(),
},t=>[index('round_invites_round').on(t.roundId)]);
export const roundEvents=sqliteTable('round_events',{
 id:text('id').primaryKey(),roundId:text('round_id').notNull().references(()=>reviewRounds.id),actor:text('actor').notNull(),kind:text('kind').notNull(),detail:text('detail').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('round_events_round').on(t.roundId)]);
export const roundAdjudications=sqliteTable('round_adjudications',{
 id:text('id').primaryKey(),roundId:text('round_id').notNull().references(()=>reviewRounds.id),snapshotKey:text('snapshot_key').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('round_adjudications_round').on(t.roundId)]);
export const roundAdjudicationDrafts=sqliteTable('round_adjudication_drafts',{
 roundId:text('round_id').primaryKey().references(()=>reviewRounds.id,{onDelete:'cascade'}),snapshotKey:text('snapshot_key'),revision:integer('revision').notNull().default(0),updatedAt:text('updated_at').notNull(),
});

export const projectFigureSelections=sqliteTable('project_figure_selections',{
 projectId:text('project_id').notNull().references(()=>projects.id,{onDelete:'cascade'}),documentId:text('document_id').notNull().references(()=>documents.id,{onDelete:'cascade'}),figureId:text('figure_id').notNull().references(()=>documentFigures.id,{onDelete:'cascade'}),
 selection:text('selection').notNull(),updatedAt:text('updated_at').notNull(),
},t=>[primaryKey({columns:[t.projectId,t.documentId,t.figureId]})]);

export const projectSelectionEvents=sqliteTable('project_selection_events',{
 id:text('id').primaryKey(),projectId:text('project_id').notNull().references(()=>projects.id,{onDelete:'cascade'}),documentId:text('document_id').notNull(),actor:text('actor').notNull(),detail:text('detail').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('project_selection_events_project').on(t.projectId)]);

export const documentFigures=sqliteTable('document_figures',{
 id:text('id').primaryKey(),documentId:text('document_id').notNull().references(()=>documents.id,{onDelete:'cascade'}),owner:text('owner').notNull(),
 objectKey:text('object_key').notNull(),metadata:text('metadata').notNull(),imageHash:text('image_hash').notNull(),createdAt:text('created_at').notNull(),archivedAt:text('archived_at'),revision:integer('revision').notNull().default(0),
},t=>[index('document_figures_document').on(t.documentId)]);
export const figureRuns=sqliteTable('figure_runs',{
 id:text('id').primaryKey(),figureId:text('figure_id').notNull().references(()=>documentFigures.id,{onDelete:'cascade'}),owner:text('owner').notNull(),result:text('result').notNull(),review:text('review').notNull(),revision:integer('revision').notNull().default(0),mutation:text('mutation').notNull().default(''),createdAt:text('created_at').notNull(),
},t=>[index('figure_runs_figure').on(t.figureId)]);
export const figureReviewEvents=sqliteTable('figure_review_events',{
 id:text('id').primaryKey(),runId:text('run_id').notNull().references(()=>figureRuns.id,{onDelete:'cascade'}),owner:text('owner').notNull(),review:text('review').notNull(),createdAt:text('created_at').notNull(),
},t=>[index('figure_review_events_run').on(t.runId)]);
