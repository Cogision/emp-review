CREATE TABLE `assessment_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`document_id` text NOT NULL,
	`owner` text NOT NULL,
	`actor_type` text NOT NULL,
	`actor_id` text NOT NULL,
	`model` text,
	`manual_version` text NOT NULL,
	`source_hash` text NOT NULL,
	`stage` text NOT NULL,
	`revision` integer NOT NULL,
	`snapshot_key` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `assessment_runs_document` ON `assessment_runs` (`document_id`);--> statement-breakpoint
CREATE TABLE `project_documents` (
	`project_id` text NOT NULL,
	`document_id` text NOT NULL,
	`study_group` text DEFAULT '' NOT NULL,
	`added_at` text NOT NULL,
	PRIMARY KEY(`project_id`, `document_id`),
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `project_documents_document` ON `project_documents` (`document_id`);--> statement-breakpoint
CREATE TABLE `projects` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`title` text NOT NULL,
	`question` text DEFAULT '' NOT NULL,
	`criteria` text DEFAULT '' NOT NULL,
	`language` text DEFAULT 'en' NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `projects_owner` ON `projects` (`owner`);