CREATE TABLE `project_syntheses` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`owner` text NOT NULL,
	`filter` text NOT NULL,
	`language` text NOT NULL,
	`model` text NOT NULL,
	`fingerprint` text NOT NULL,
	`snapshot_key` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `project_syntheses_project` ON `project_syntheses` (`project_id`);