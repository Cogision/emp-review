CREATE TABLE `review_rounds` (
	`id` text PRIMARY KEY NOT NULL,
	`coordinator_id` text NOT NULL,
	`title` text NOT NULL,
	`mode` text NOT NULL,
	`status` text DEFAULT 'recruiting' NOT NULL,
	`manual_version` text NOT NULL,
	`source_document_id` text NOT NULL,
	`source_hash` text NOT NULL,
	`stage` text NOT NULL,
	`source_key` text NOT NULL,
	`proposal_key` text,
	`had_analysis` integer NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`mutation` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `review_rounds_coordinator` ON `review_rounds` (`coordinator_id`);--> statement-breakpoint
CREATE TABLE `round_adjudications` (
	`id` text PRIMARY KEY NOT NULL,
	`round_id` text NOT NULL,
	`snapshot_key` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`round_id`) REFERENCES `review_rounds`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `round_adjudications_round` ON `round_adjudications` (`round_id`);--> statement-breakpoint
CREATE TABLE `round_events` (
	`id` text PRIMARY KEY NOT NULL,
	`round_id` text NOT NULL,
	`actor` text NOT NULL,
	`kind` text NOT NULL,
	`detail` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`round_id`) REFERENCES `review_rounds`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `round_events_round` ON `round_events` (`round_id`);--> statement-breakpoint
CREATE TABLE `round_invites` (
	`id` text PRIMARY KEY NOT NULL,
	`round_id` text NOT NULL,
	`token_hash` text NOT NULL,
	`expires_at` text NOT NULL,
	`revoked_at` text,
	`claimed_by` text,
	`claim_id` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`round_id`) REFERENCES `review_rounds`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `round_invites_token_hash_unique` ON `round_invites` (`token_hash`);--> statement-breakpoint
CREATE INDEX `round_invites_round` ON `round_invites` (`round_id`);--> statement-breakpoint
CREATE TABLE `round_members` (
	`round_id` text NOT NULL,
	`user_id` text NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`draft_key` text,
	`revision` integer DEFAULT 0 NOT NULL,
	`submission_id` text,
	`submitted_at` text,
	`created_at` text NOT NULL,
	PRIMARY KEY(`round_id`, `user_id`),
	FOREIGN KEY (`round_id`) REFERENCES `review_rounds`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `round_members_user` ON `round_members` (`user_id`);