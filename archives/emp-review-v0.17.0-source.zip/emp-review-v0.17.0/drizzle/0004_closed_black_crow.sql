CREATE TABLE `project_selection_events` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`document_id` text NOT NULL,
	`actor` text NOT NULL,
	`detail` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `project_selection_events_project` ON `project_selection_events` (`project_id`);--> statement-breakpoint
ALTER TABLE `project_documents` ADD `selected_round_id` text;--> statement-breakpoint
ALTER TABLE `project_documents` ADD `selected_adjudication_id` text;