CREATE TABLE `document_figures` (
	`id` text PRIMARY KEY NOT NULL,
	`document_id` text NOT NULL,
	`owner` text NOT NULL,
	`object_key` text NOT NULL,
	`metadata` text NOT NULL,
	`image_hash` text NOT NULL,
	`created_at` text NOT NULL,
	`archived_at` text,
	`revision` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `document_figures_document` ON `document_figures` (`document_id`);--> statement-breakpoint
CREATE TABLE `figure_review_events` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`owner` text NOT NULL,
	`review` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`run_id`) REFERENCES `figure_runs`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `figure_review_events_run` ON `figure_review_events` (`run_id`);--> statement-breakpoint
CREATE TABLE `figure_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`figure_id` text NOT NULL,
	`owner` text NOT NULL,
	`result` text NOT NULL,
	`review` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`mutation` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`figure_id`) REFERENCES `document_figures`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `figure_runs_figure` ON `figure_runs` (`figure_id`);--> statement-breakpoint
ALTER TABLE `documents` ADD `version_manifest` text;