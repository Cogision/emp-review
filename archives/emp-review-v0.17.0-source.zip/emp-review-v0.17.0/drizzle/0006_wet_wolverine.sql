CREATE TABLE `project_figure_selections` (
	`project_id` text NOT NULL,
	`document_id` text NOT NULL,
	`figure_id` text NOT NULL,
	`selection` text NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`project_id`, `document_id`, `figure_id`),
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`figure_id`) REFERENCES `document_figures`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `round_adjudication_drafts` (
	`round_id` text PRIMARY KEY NOT NULL,
	`snapshot_key` text,
	`revision` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`round_id`) REFERENCES `review_rounds`(`id`) ON UPDATE no action ON DELETE cascade
);
