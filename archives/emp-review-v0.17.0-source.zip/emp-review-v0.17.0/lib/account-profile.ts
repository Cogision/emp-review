import { z } from 'zod';

export type AccountIdentity = { displayName: string; email: string };
export type AccountProfile = AccountIdentity & { affiliation: string; revision: number; updatedAt: string | null };

const singleLine = (limit: number) => z.string().trim().max(limit).refine(value => !/[\u0000-\u001f\u007f]/.test(value), 'Use a single line of text.');
export const profileInput = z.object({
  displayName: singleLine(120).refine(value => value.length > 0, 'Enter your display name.'),
  affiliation: singleLine(200),
  revision: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
}).strict();

export function defaultProfile(identity: AccountIdentity): AccountProfile {
  return { displayName: identity.displayName.trim().slice(0,120) || identity.email.split('@')[0].slice(0,120), email: identity.email, affiliation: '', revision: 0, updatedAt: null };
}
