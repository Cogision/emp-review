import { z } from "zod";
import { AppError } from "./app-error";

export const DEFAULT_MODEL = "gpt-4.1";
const settingsSchema = z.object({
  key: z.string({ invalid_type_error: "Klucz API musi być tekstem." }).trim()
    .max(2048, "Klucz API jest za długi. Wklej sam klucz, bez opisu.")
    .refine(v => !/\s/.test(v), "Klucz API zawiera spacje lub podział wiersza. Wklej sam klucz.").optional(),
  model: z.string({ invalid_type_error: "Identyfikator modelu musi być tekstem." }).trim()
    .max(200, "Identyfikator modelu jest za długi.")
    .refine(v => !v.startsWith("sk-"), "W polu Model znajduje się klucz API. Przenieś go do pola Klucz OpenAI API.")
    .refine(v => !v || /^[a-zA-Z0-9._:-]+$/.test(v), "Wpisz identyfikator modelu API, np. gpt-4.1, bez spacji i adresu strony. Nazwa z menu ChatGPT może być inna.").optional(),
});

export function parseAiSettings(value: unknown, defaults: {key?: string; model?: string} = {}) {
  const parsed = settingsSchema.safeParse(value);
  if (!parsed.success) throw new AppError(parsed.error.issues[0]?.message || "Nieprawidłowe ustawienia AI.");
  const resolved = settingsSchema.safeParse({key: parsed.data.key || defaults.key, model: parsed.data.model || defaults.model || DEFAULT_MODEL});
  if (!resolved.success) throw new AppError(resolved.error.issues[0]?.message || "Nieprawidłowe ustawienia serwerowe AI.");
  if (!resolved.data.key) throw new AppError("Otwórz „Ustawienia AI” i podaj klucz OpenAI API. Dokument jest już zapisany.", 428);
  return {key: resolved.data.key, model: resolved.data.model || DEFAULT_MODEL};
}
