import {currentClaims,deriveBridge,claimIssues,FAMILIES,type Claim,type RecordDoc} from "./emp";
import {compareFields,documentClaimFields} from "./field-comparison";
export type AssessmentMeta={id:string;document_id:string;revision:number;stage:string;source_hash:string;manual_version:string;model:string|null;actor_type:string;created_at:string};
export type AssessmentState={meta:AssessmentMeta;document:RecordDoc;kind:string};
const norm=(s:string)=>s.replace(/\s+/g," ").trim();
function signature(c:Claim){return JSON.stringify([norm(c.statement),c.citation.blockId,norm(c.citation.quote),Object.entries(c.scope).sort(([a],[b])=>a.localeCompare(b))]);}
function fields(c:Claim,d:RecordDoc){return {...documentClaimFields(c,d),bridge:deriveBridge(c,d.review.reportType||d.analysis?.reportType)}}
export function compareAssessments(a:AssessmentState,b:AssessmentState){
 if(a.meta.id===b.meta.id&&a.document.id===b.document.id)throw new Error("Choose two different saved assessments.");
 const sameSource=a.meta.source_hash===b.meta.source_hash,sameStage=a.meta.stage===b.meta.stage,sameManual=a.meta.manual_version===b.meta.manual_version;
 const typeA=a.document.review.reportType||a.document.analysis?.reportType,typeB=b.document.review.reportType||b.document.analysis?.reportType;
 const structural=[typeA,typeB].some(x=>x==="NC"||x==="NMC");
 const left=currentClaims(a.document),right=currentClaims(b.document),used=new Set<string>();
 const pairs=left.map(c=>{
  const candidates=a.document.id===b.document.id?right.filter(x=>x.id===c.id):sameSource?right.filter(x=>signature(x)===signature(c)):[];
  const ambiguous=candidates.length>1||(a.document.id!==b.document.id&&left.filter(x=>signature(x)===signature(c)).length>1);
  const match=!ambiguous&&candidates.length===1&&!used.has(candidates[0].id)?candidates[0]:null;
  if(match)used.add(match.id);
  const changedIdentity=!!match&&signature(c)!==signature(match);
  const excluded=a.document.review.decisions[c.id]?.status==="excluded"||(!!match&&b.document.review.decisions[match.id]?.status==="excluded");
  const leftIssues=claimIssues(c,a.document.source),rightIssues=match?claimIssues(match,b.document.source):[];
  const av=fields(c,a.document),bv=match?fields(match,b.document):null;
  const differences=bv?compareFields(av,bv).filter(r=>r.different).map(r=>r.path):[];
  return {left:c,right:match,ambiguous,changedIdentity,excluded,comparable:!!match&&sameSource&&sameStage&&sameManual&&!structural&&!changedIdentity&&!excluded&&!leftIssues.length&&!rightIssues.length,
   differences,leftValues:av,rightValues:bv,leftIssues,rightIssues};
 });
 const unpairedRight=right.filter(c=>!used.has(c.id));
 const eligible=pairs.filter(p=>p.comparable);
 const families=FAMILIES.map(f=>{
  const bothNE=eligible.filter(p=>p.left.profile[f]==="NE"&&p.right!.profile[f]==="NE").length;
  const scopeDifference=eligible.filter(p=>(p.left.profile[f]==="NE")!==(p.right!.profile[f]==="NE")).length;
  const assessed=eligible.filter(p=>p.left.profile[f]!=="NE"&&p.right!.profile[f]!=="NE");
  return {family:f,assessed:assessed.length,sameCode:assessed.filter(p=>p.left.profile[f]===p.right!.profile[f]).length,bothNE,scopeDifference,bothU:assessed.filter(p=>p.left.profile[f]==="U"&&p.right!.profile[f]==="U").length};
 });
 const origin=(d:RecordDoc)=>d.analysis?.automatic?.runId||`${d.id}:${d.analysis?.model}:${d.analysis?.generatedAt}`;
 return {version:"EMP-assessment-comparison-0.7.0",sameSource,sameStage,sameManual,structural,reportTypes:{a:typeA,b:typeB},sharedOrigin:origin(a.document)===origin(b.document),
  pairs,unpairedRight,families,counts:{matched:pairs.filter(p=>p.right).length,onlyA:pairs.filter(p=>!p.right).length,onlyB:unpairedRight.length,ambiguous:pairs.filter(p=>p.ambiguous).length,excluded:pairs.filter(p=>p.excluded).length,excludedA:left.filter(c=>a.document.review.decisions[c.id]?.status==="excluded").length,excludedB:right.filter(c=>b.document.review.decisions[c.id]?.status==="excluded").length,qcPairs:pairs.filter(p=>p.right&&(p.leftIssues.length||p.rightIssues.length)).length,comparable:eligible.length,changedIdentity:pairs.filter(p=>p.changedIdentity).length}};
}
