import { z } from 'zod';
import { claimSchema, syncV05, claimIssues, type Claim, type Source, type Citation } from './emp';
import { v05Schema } from './v05';
import { recoverCitation } from './citation-recovery';
import { structuredSchema, type OutputSchema } from './structured-schema';

export type FocalCandidate=Pick<Claim,'id'|'primary'|'statement'|'citation'>;
// Identity comes from the frozen inventory. Compatibility fields are derived
// from normative v05 codes, not independently generated or silently defaulted.
export const assessmentSchema=claimSchema.omit({primary:true,statement:true,citation:true,scopeMatch:true,condition:true,coupling:true,conditionMatches:true,commitment:true,polarity:true}).extend({v05:v05Schema});
export type AssessmentCorrection={path:string;method:string;before:unknown;after:unknown};
export type AssessmentValidation={claim?:Claim;issues:string[];quality:string[];corrections:AssessmentCorrection[]};
export function assessmentOutputSchema(focal:FocalCandidate):OutputSchema {
 const schema=structuredSchema(assessmentSchema);
 schema.properties!.id={type:'string',enum:[focal.id]};
 return {name:'emp_v05_assessment',schema};
}
const record=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
const ws=(s:string)=>s.replace(/\s+/gu,' ').trim();
function canonicalEnums(value:unknown,schema:z.ZodTypeAny,path:string,corrections:AssessmentCorrection[]):unknown {
 if(schema instanceof z.ZodEnum&&typeof value==='string'){
  const match=(schema.options as string[]).find(x=>x.toLowerCase()===value.trim().toLowerCase());
  if(match!==undefined&&match!==value){corrections.push({path,method:'enum-format',before:value,after:match});return match;}
 }
 if(schema instanceof z.ZodObject&&record(value))return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,schema.shape[k]?canonicalEnums(v,schema.shape[k],path?`${path}.${k}`:k,corrections):v]));
 if(schema instanceof z.ZodArray&&Array.isArray(value))return value.map((v,i)=>canonicalEnums(v,schema.element,`${path}.${i}`,corrections));
 if(schema instanceof z.ZodNullable&&value!==null)return canonicalEnums(value,schema.unwrap(),path,corrections);
 return value;
}
// No raw provider text/values in diagnostics: they could contain source data or secrets.
function fieldIssue(e:z.ZodIssue):string {
 const path=e.path.join('.')||'form';
 if(e.code==='invalid_type')return `${path}: ${e.received==='undefined'?'missing field / brak pola':`expected / wymagane: ${e.expected}`}`;
 if(e.code==='invalid_enum_value')return `${path}: allowed values / dozwolone wartości: ${e.options.join(', ')}`;
 if(e.code==='too_big')return `${path}: maximum / maksimum ${e.maximum} (${e.type})`;
 return `${path}: invalid field / nieprawidłowe pole (${e.code})`;
}
export function validateAssessment(raw:string,source:Source,focal:FocalCandidate,reportType:string):AssessmentValidation {
 const corrections:AssessmentCorrection[]=[],issues:string[]=[];
 let value:unknown;
 try{value=JSON.parse(raw);}catch{return {issues:['form: invalid JSON / nieprawidłowy JSON'],quality:[],corrections};}
 if(!record(value))return {issues:['form: expected an object / wymagany obiekt'],quality:[],corrections};
 if(value.id!==focal.id)issues.push('id: different inventoried claim / inne twierdzenie niż w zapisanej liście');
 // Older/full-shape responses may echo identity. Never accept a changed claim.
 if('primary' in value&&value.primary!==focal.primary)issues.push('primary: inventoried selection changed / zmieniono wybór twierdzenia');
 if('statement' in value&&(typeof value.statement!=='string'||ws(value.statement)!==ws(focal.statement)))issues.push('statement: inventoried statement changed / zmieniono treść twierdzenia');
 if('citation' in value){
  const c=value.citation;
  if(!record(c)||typeof c.quote!=='string'||typeof c.blockId!=='string')issues.push('citation: invalid echoed quotation / nieprawidłowy powtórzony cytat');
  else{const r=recoverCitation(c as Citation,source);if(!r||r.citation.blockId!==focal.citation.blockId||r.citation.quote!==focal.citation.quote)issues.push('citation: inventoried quotation changed / zmieniono cytat z listy twierdzeń');
   else if(r.method!=='exact')corrections.push({path:'citation',method:r.method,before:c,after:r.citation});}
 }
 const parsed=assessmentSchema.safeParse(canonicalEnums(value,assessmentSchema,'',corrections));
 if(!parsed.success)issues.push(...parsed.error.issues.map(fieldIssue));
 if(issues.length||!parsed.success)return {issues,quality:[],corrections};
 // syncV05 fills every omitted compatibility field from the validated v05 object.
 const claim=claimSchema.extend({v05:v05Schema}).parse(syncV05({...parsed.data,...structuredClone(focal)} as Claim));
 const recover=(c:Citation,path:string):Citation=>{
  const r=recoverCitation(c,source);
  if(!r||r.citation.quote.length>2500){issues.push(`${path}: quotation not found unambiguously in source / cytatu nie odnaleziono jednoznacznie w źródle`);return c;}
  if(r.method!=='exact')corrections.push({path,method:r.method,before:{...c},after:r.citation});return r.citation;
 };
 claim.evidence=claim.evidence.map((c,i)=>recover(c,`evidence.${i}`));
 if(claim.conditionCitation)claim.conditionCitation=recover(claim.conditionCitation,'conditionCitation');
 if(claim.v05!.equivalenceCitation)claim.v05!.equivalenceCitation=recover(claim.v05!.equivalenceCitation,'v05.equivalenceCitation');
 if(issues.length)return {issues,quality:[],corrections};
 const quality=claimIssues(claim,source);
 if(claim.v05!.methodologicalGeneralisation&&reportType!=='M')quality.push('Generalizacja M została wskazana poza raportem M.');
 if(quality.length)claim.bridgeClear=false;
 return {claim,issues,quality,corrections};
}
