const AUTH_PATHS = new Set(['/signin-with-chatgpt', '/signout-with-chatgpt', '/callback']);
function routeName(pathname: string) { return decodeURIComponent(pathname).replace(/\/+$/, '').toLowerCase(); }

export function safeReturnPath(value: string): string {
  if (!value.startsWith('/') || value.startsWith('//') || /[\u0000-\u001f\u007f]/.test(value)) return '/';
  try {
    const url = new URL(value, 'https://app.local');
    if (url.origin !== 'https://app.local' || AUTH_PATHS.has(routeName(url.pathname))) return '/';
    return `${url.pathname}${url.search}${url.hash}`;
  } catch { return '/'; }
}

export function loginReturnPath(value: string): string {
  const safe = safeReturnPath(value);
  return routeName(new URL(safe, 'https://app.local').pathname) === '/login' ? '/' : safe;
}

export function loginPath(returnTo = '/') {
  return `/login?returnTo=${encodeURIComponent(loginReturnPath(returnTo))}`;
}

export function chatGPTSignInPath(returnTo: string) {
  return `/signin-with-chatgpt?return_to=${encodeURIComponent(safeReturnPath(returnTo))}`;
}

export function chatGPTSignOutPath(returnTo = '/login') {
  return `/signout-with-chatgpt?return_to=${encodeURIComponent(safeReturnPath(returnTo))}`;
}
