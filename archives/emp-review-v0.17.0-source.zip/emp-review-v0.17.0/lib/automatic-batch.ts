import type { RecordDoc } from "./emp";
import type { AutomaticState } from "./automatic";
export type AutoTask={id:string;title:string;form?:FormData};
export type AutoProgress={id:string;title:string;phase:"waiting"|"import"|"inventory"|"claims"|"complete"|"error";completed:number;total:number;error?:string};
export type StepResult={state:AutomaticState|null;document:RecordDoc|null};
export async function runAutomaticBatch(tasks:AutoTask[],ops:{import:(task:AutoTask)=>Promise<unknown>;load:(id:string)=>Promise<StepResult>;step:(id:string)=>Promise<StepResult>;progress:(p:AutoProgress)=>void;stop:()=>boolean}){
 const completed:RecordDoc[]=[],failed:Array<{id:string;title:string;error:string}>=[];
 for(const task of tasks){
  if(ops.stop())break;
  let state:AutomaticState|null=null;
  try{
   ops.progress({...task,phase:"import",completed:0,total:0});await ops.import(task);
   let result=await ops.load(task.id);state=result.state;
   for(let steps=0;!state?.complete;steps++){
    if(ops.stop())return {completed,failed,paused:true};
    if(steps>=82)throw new Error("Przekroczono liczbę etapów; zapisany postęp można wznowić.");
    ops.progress({id:task.id,title:task.title,phase:state?"claims":"inventory",completed:state?.claims.length||0,total:state?.inventory.claims.length||0});
    result=await ops.step(task.id);state=result.state;
    // Publish the saved checkpoint before a possible pause at the next loop check.
    if(state&&!state.complete)ops.progress({id:task.id,title:task.title,phase:"claims",completed:state.claims.length,total:state.inventory.claims.length});
   }
   if(!result.document?.analysis?.automatic)throw new Error("Nie otrzymano kompletnego zapisu analizy automatycznej.");
   completed.push(result.document);ops.progress({id:task.id,title:task.title,phase:"complete",completed:state.claims.length,total:state.inventory.claims.length});
  }catch(e){const error=e instanceof Error?e.message:"Nie udało się zakończyć analizy.";failed.push({id:task.id,title:task.title,error});ops.progress({id:task.id,title:task.title,phase:"error",completed:state?.claims.length||0,total:state?.inventory.claims.length||0,error});}
 }
 return {completed,failed,paused:ops.stop()};
}
