import type { Citation, Source } from './emp';
export type CitationRecovery={citation:Citation;method:'exact'|'whitespace'|'unique-location'};
// Only whitespace is normalised. No fuzzy words, punctuation changes, ellipses or cross-block joins.
function mappedWhitespace(text:string){
 let normalized='',starts:number[]=[],ends:number[]=[];
 for(let i=0;i<text.length;){const start=i;if(/\s/u.test(text[i])){while(i<text.length&&/\s/u.test(text[i]))i++;normalized+=' ';}else{normalized+=text[i];i++;}starts.push(start);ends.push(i);}
 return {normalized,starts,ends};
}
function matches(text:string,quote:string):string[]{
 const map=mappedWhitespace(text),needle=quote.replace(/\s+/gu,' ').trim();if(!needle)return [];
 const out:string[]=[];let at=map.normalized.indexOf(needle);while(at!==-1){out.push(text.slice(map.starts[at],map.ends[at+needle.length-1]));if(out.length>1)break;at=map.normalized.indexOf(needle,at+1);}return out;
}
export function recoverCitation(c:Citation,source:Source):CitationRecovery|null{
 const block=source.blocks.find(b=>b.id===c.blockId);
 if(c.quote.trim()&&block?.text.includes(c.quote))return {citation:c,method:'exact'};
 if(block){const found=matches(block.text,c.quote);if(found.length===1)return {citation:{blockId:block.id,quote:found[0]},method:'whitespace'};if(found.length>1)return null;}
 const found=source.blocks.flatMap(b=>matches(b.text,c.quote).map(quote=>({blockId:b.id,quote})));
 if(found.length!==1)return null;return {citation:found[0],method:'unique-location'};
}
