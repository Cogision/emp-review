import JSZip from 'jszip';
import {request} from './http';

export type TranslationEntry={id:string;text:string};
export type EnglishTranslator=(entries:TranslationEntry[])=>Promise<TranslationEntry[]>;
// Includes common unaccented Polish words, so legacy text is not checked by
// diacritics alone. Identifiers, names and original records are never rewritten.
export function needsEnglish(text:string){
 return /[ąćęłńóśźż]/i.test(text)||/\b(?:brak|dowod\w*|twierdz\w*|raport\w*|badani\w*|wniosk\w*|nie|jest|oraz|przez|dla|potwierdz\w*|zakres\w*|wynik\w*|ocen\w*|suplement\w*|populacj\w*|wymaga\w*)\b/i.test(text);
}
const entities:Record<string,string>={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};
const decode=(s:string)=>s.replace(/&#(x[\da-f]+|\d+);|&(amp|lt|gt|quot|apos);/gi,(_,code:string|undefined,name:string|undefined)=>{
 if(code)return String.fromCodePoint(code[0].toLowerCase()==='x'?parseInt(code.slice(1),16):Number(code));
 return entities[name!.toLowerCase()]||_;
});
const escape=(s:string)=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');
const tokens=(s:string)=>s.match(/\b(?:B[0-3]|BU|BNA|SE[0-7U]|SH[0-7]|R[0-4AU]|NC[0-3U]|U[1-9X]|FC|PC|UC|NA|D|I|N0|NMC|CB|NC|NE|EMP_\w+|[\da-f]{64})\b|\d+(?:[.,]\d+)*/g)||[];
export function validateEnglishResult(input:TranslationEntry[],output:TranslationEntry[]){
 if(output.length!==input.length||new Set(output.map(x=>x.id)).size!==input.length)throw new Error('The English translation is incomplete. Saved assessments are unchanged. Retry the export.');
 return input.map(entry=>{const translated=output.find(x=>x.id===entry.id);
  if(!translated?.text.trim()||JSON.stringify(tokens(entry.text))!==JSON.stringify(tokens(translated.text)))throw new Error('The English translation changed a numeric value or coding token. Saved assessments are unchanged. Retry the export.');
  if(/\b(?:brak dowod|brak danych|nie ma|nie jest|jest to|wyniki badania|do oceny|w tym|na podstawie)\b/i.test(translated.text))throw new Error('Some assessment text was not translated into English. Saved assessments are unchanged. Retry the export.');
  return translated;
 });
}
export function englishTranslator(key:string,model:string):EnglishTranslator{return async entries=>{
 const result=await request<{entries:TranslationEntry[]}>('/api/ai/translate-export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:key||undefined,model,entries})});
 return validateEnglishResult(entries,result.entries);
};}

/** A presentation-only conversion: original JSON, CSV, hashes and figures are
 * byte-for-byte untouched. Changed passages carry a visible translation label. */
export async function englishWordPackage(blob:Blob,translate:EnglishTranslator){
 const zip=await JSZip.loadAsync(await blob.arrayBuffer()),texts=new Map<string,string>();
 const docs:Array<{path:string;zip:JSZip;parts:Map<string,string>}>=[];
 for(const file of Object.values(zip.files).filter(f=>!f.dir&&f.name.endsWith('.docx'))){
  const doc=await JSZip.loadAsync(await file.async('uint8array')),parts=new Map<string,string>();
  for(const part of Object.values(doc.files).filter(f=>/^word\/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$/.test(f.name))){
   const xml=await part.async('string');parts.set(part.name,xml);
   for(const match of xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)){const text=decode(match[1]);if(needsEnglish(text)&&!texts.has(text))texts.set(text,`T${texts.size+1}`);}
  }
  docs.push({path:file.name,zip:doc,parts});
 }
 if(!texts.size)return blob;
 const entries=[...texts].map(([text,id])=>({id,text})),results=new Map<string,string>();
 for(let start=0;start<entries.length;){
  const batch:TranslationEntry[]=[];let size=0;
  while(start<entries.length&&batch.length<24&&(size+entries[start].text.length<=18000||!batch.length)){const entry=entries[start++];batch.push(entry);size+=entry.text.length;}
  for(const item of validateEnglishResult(batch,await translate(batch)))results.set(item.id,item.text);
 }
 for(const doc of docs){for(const [path,xml]of doc.parts){doc.zip.file(path,xml.replace(/(<w:t\b[^>]*>)([\s\S]*?)(<\/w:t>)/g,(all,open,text,close)=>{
   const id=texts.get(decode(text));return id?`${open}${escape(`[English translation ${id}] ${results.get(id)!}`)}${close}`:all;
  }));}zip.file(doc.path,await doc.zip.generateAsync({type:'uint8array',compression:'DEFLATE'}));}
 zip.file('english-translations.json',JSON.stringify({language:'en',createdAt:new Date().toISOString(),note:'Presentation translations only, not new assessments. Translated quotations are not verbatim source text. Original evidence and assessments remain in the other JSON files.',entries:entries.map(e=>({...e,english:results.get(e.id)}))},null,2));
 return zip.generateAsync({type:'blob',compression:'DEFLATE'});
}
