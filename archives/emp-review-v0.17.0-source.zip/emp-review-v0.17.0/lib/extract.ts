import { type Source } from "./emp";
export function textSource(text:string,fileName="Wklejony tekst"):Source{
 const paragraphs=text.replace(/\r\n/g,"\n").split(/\n\s*\n/).filter(x=>x.trim());
 const parts=paragraphs.flatMap(p=>p.match(/[\s\S]{1,6000}/g)||[]);
 return {fileName,warnings:[],blocks:parts.map((t,i)=>({id:`b${i+1}`,label:`Fragment ${i+1}`,text:t.trim()}))};
}
export async function extract(file:File):Promise<Source>{
 if(file.size>10000000)throw new Error("Maksymalny rozmiar dokumentu to 10 MB.");
 const ext=file.name.split(".").pop()?.toLowerCase();
 if(ext==="txt"||ext==="md")return textSource(await file.text(),file.name);
 if(ext==="docx"){
  const mammoth=await import("mammoth");const result=await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()});
  const s=textSource(result.value,file.name);s.warnings=["DOCX: analizowany jest tekst. Obrazy i układ tabel wymagają kontroli w oryginale.",...result.messages.slice(0,8).map(x=>String(x.message).slice(0,300))];return s;
 }
 if(ext==="pdf"){
  const pdfjs=await import("pdfjs-dist");pdfjs.GlobalWorkerOptions.workerSrc="/pdf.worker.min.mjs";
  const task=pdfjs.getDocument({data:await file.arrayBuffer()}); const pdf=await task.promise;
  try{if(pdf.numPages>80)throw new Error("MVP obsługuje PDF do 80 stron. Wgraj pojedynczy raport.");
   const blocks:Source["blocks"]=[],warnings=["PDF: analizowana jest warstwa tekstowa. Ryciny, skany i układ tabel wymagają kontroli w oryginale."];
   for(let i=1;i<=pdf.numPages;i++){
    const page=await pdf.getPage(i),content=await page.getTextContent();let text="";
    for(const item of content.items){if("str"in item)text+=item.str+(item.hasEOL?"\n":" ");}
    if(text.trim().length<30)warnings.push(`Strona ${i}: brak wystarczającej warstwy tekstowej; potrzebne OCR lub kontrola oryginału.`);
    const parts=text.trim().match(/[\s\S]{1,6000}/g)||[];parts.forEach((text,j)=>blocks.push({id:`p${i}b${j+1}`,label:`Strona ${i}${parts.length>1?` · część ${j+1}`:""}`,text}));
   }return {fileName:file.name,blocks,warnings};
  }finally{await task.destroy();}
 }
 throw new Error("Obsługiwane formaty: PDF, DOCX, TXT i MD.");
}
