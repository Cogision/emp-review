import {requestOpenAi} from './ai-client';
import {AppError} from './app-error';
import {structuredSchema} from './structured-schema';
import {checkedFigureReport,figurePrompt,figureReportSchema,imageDataUrl,FIGURE_PROMPT_VERSION,type Figure,type FigureRun} from './figures';
import {APP_VERSION} from './versions';
import type {Source} from './emp';
export async function analyzeFigure(figure:Figure,bytes:Uint8Array,source:Source,sourceHash:string,settings:{key:string;model:string;language:'en'|'pl';runId:string},fetcher:typeof fetch=fetch):Promise<FigureRun>{
 const raw=await requestOpenAi({key:settings.key,model:settings.model,instructions:figurePrompt(settings.language),input:JSON.stringify({figure:{label:figure.label,caption:figure.caption,locator:figure.locator,sourceFileId:figure.sourceFileId},source}),imageDataUrl:imageDataUrl(bytes,figure.mime),maxOutputTokens:7000,outputSchema:{name:'emp_figure',schema:structuredSchema(figureReportSchema)}},fetcher);
 let json:unknown;try{json=JSON.parse(raw);}catch{throw new AppError('The figure response was not valid JSON. No result was saved.',502);}
 const report=checkedFigureReport(json,source);
 return {id:settings.runId,figureId:figure.id,sourceHash,imageHash:figure.imageHash,model:settings.model,language:settings.language,createdAt:new Date().toISOString(),appVersion:APP_VERSION,promptVersion:FIGURE_PROMPT_VERSION,report,review:{revision:0,status:'draft',sourceChecked:false,comment:''}};
}
