import {AppError} from './app-error';
import {figureInput,figureMime,figureHash,figureReviewSchema,FIGURES_PER_DOCUMENT,type Figure,type FigureRun,type FigureInput} from './figures';
import type {Source} from './emp';
type Env={DB:D1Database;BUCKET:R2Bucket};
type FigureRow={id:string;document_id:string;owner:string;object_key:string;metadata:string;image_hash:string;archived_at:string|null;revision:number};
type RunRow={id:string;figure_id:string;result:string;review:string;revision:number;created_at:string};
export class FigureStore{
 constructor(readonly env:Env,readonly who:string){}
 private q(sql:string,...args:unknown[]){return this.env.DB.prepare(sql).bind(...args);}
 async document(id:string){const row=await this.q('SELECT id,source_key,source_hash FROM documents WHERE id=? AND owner=?',id,this.who).first<{id:string;source_key:string;source_hash:string}>();if(!row)throw new AppError('Document not found.',404);return row;}
 async row(docId:string,id:string){await this.document(docId);const r=await this.q('SELECT * FROM document_figures WHERE id=? AND document_id=? AND owner=?',id,docId,this.who).first<FigureRow>();if(!r)throw new AppError('Figure not found.',404);return r;}
 private value(r:FigureRow):Figure{return {...JSON.parse(r.metadata),archivedAt:r.archived_at,revision:r.revision};}
 async list(docId:string){await this.document(docId);return (await this.q('SELECT * FROM document_figures WHERE document_id=? AND owner=? ORDER BY created_at,id',docId,this.who).all<FigureRow>()).results.map(r=>this.value(r));}
 async upload(docId:string,input:FigureInput,fileName:string,declared:string,bytes:Uint8Array):Promise<Figure>{
  const doc=await this.document(docId),v=figureInput.parse(input),mime=figureMime(bytes,declared),hash=await figureHash(bytes);
  const source=await this.env.BUCKET.get(doc.source_key);if(!source)throw new AppError('Article text is temporarily unavailable.',503);
  const text=await source.json<Source>();if(v.sourceFileId&&!text.files?.some(f=>f.id===v.sourceFileId))throw new AppError('The parent file does not belong to this article.');
  const existing=await this.q('SELECT * FROM document_figures WHERE id=? AND document_id=? AND owner=?',v.id,docId,this.who).first<FigureRow>();
  if(existing){const f=this.value(existing);if(f.imageHash!==hash||f.label!==v.label||f.caption!==v.caption||f.locator!==v.locator||f.sourceFileId!==v.sourceFileId)throw new AppError('This upload identifier belongs to a different figure. Refresh before uploading.',409);return f;}
  const f:Figure={id:v.id,documentId:docId,fileName:fileName.slice(0,200),mime,bytes:bytes.length,imageHash:hash,label:v.label,caption:v.caption,locator:v.locator,sourceFileId:v.sourceFileId,createdAt:new Date().toISOString(),archivedAt:null,revision:0};
  // Unique object key per attempt. A losing concurrent retry cannot replace stored bytes.
  const objectKey=`${doc.source_key.replace(/text.json$/,'')}figures/${v.id}/${crypto.randomUUID()}`;
  await this.env.BUCKET.put(objectKey,bytes,{httpMetadata:{contentType:mime}});
  const r=await this.q('INSERT OR IGNORE INTO document_figures (id,document_id,owner,object_key,metadata,image_hash,created_at,revision) SELECT ?,?,?,?,?,?,?,0 WHERE (SELECT count(*) FROM document_figures WHERE document_id=? AND archived_at IS NULL)<? AND (SELECT count(*) FROM document_figures WHERE document_id=?)<36',v.id,docId,this.who,objectKey,JSON.stringify(f),hash,f.createdAt,docId,FIGURES_PER_DOCUMENT,docId).run();
  if(r.meta.changes!==1){await this.env.BUCKET.delete(objectKey);const saved=await this.q('SELECT id FROM document_figures WHERE id=? AND document_id=? AND owner=?',v.id,docId,this.who).first();if(saved)return this.upload(docId,input,fileName,declared,bytes);throw new AppError('This article has reached its figure limit (12 active, 36 including archived figures).',409);}
  return f;
 }
 async content(docId:string,id:string){const r=await this.row(docId,id),obj=await this.env.BUCKET.get(r.object_key);if(!obj)throw new AppError('The figure file is temporarily unavailable.',503);return {figure:this.value(r),object:obj};}
 async runs(docId:string,id:string){await this.row(docId,id);const rows=await this.q('SELECT * FROM figure_runs WHERE figure_id=? AND owner=? ORDER BY created_at DESC,id DESC',id,this.who).all<RunRow>();return rows.results.map(r=>({...JSON.parse(r.result),review:{...JSON.parse(r.review),revision:r.revision}} as FigureRun));}
 async saveRun(docId:string,id:string,run:FigureRun){const r=await this.row(docId,id);if(r.archived_at)throw new AppError('Restore the figure before analysing it.',409);
  const result=await this.q('INSERT OR IGNORE INTO figure_runs (id,figure_id,owner,result,review,revision,created_at) SELECT ?,?,?,?,?,0,? WHERE (SELECT count(*) FROM figure_runs WHERE figure_id=?)<20 AND EXISTS (SELECT 1 FROM document_figures WHERE id=? AND archived_at IS NULL)',run.id,id,this.who,JSON.stringify(run),JSON.stringify({status:'draft',sourceChecked:false,comment:''}),run.createdAt,id,id).run();
  if(result.meta.changes!==1){const saved=(await this.runs(docId,id)).find(r=>r.id===run.id);if(saved)return saved;throw new AppError('The figure is archived or has reached 20 saved analyses.',409);}return run;
 }
 async review(docId:string,id:string,runId:string,input:unknown){await this.row(docId,id);const v=figureReviewSchema.parse(input);if(v.status==='checked'&&!v.sourceChecked)throw new AppError('Inspect the figure and article before marking this analysis checked.');if(['unresolved','excluded'].includes(v.status)&&!v.comment.trim())throw new AppError('Explain the unresolved or excluded status.');
  const now=new Date().toISOString(),event=crypto.randomUUID(),review={...v,revision:v.revision+1,updatedAt:now};
  const out=await this.env.DB.batch([
   this.q('UPDATE figure_runs SET review=?,revision=revision+1,mutation=? WHERE id=? AND figure_id=? AND owner=? AND revision=?',JSON.stringify(review),event,runId,id,this.who,v.revision),
   this.q('INSERT INTO figure_review_events (id,run_id,owner,review,created_at) SELECT ?,id,owner,?,? FROM figure_runs WHERE id=? AND figure_id=? AND owner=? AND mutation=?',event,JSON.stringify(review),now,runId,id,this.who,event)
  ]);if(out[0].meta.changes!==1)throw new AppError('The figure review changed in another tab. Refresh before saving.',409);return review;
 }
 async archive(docId:string,id:string,revision:number,archive:boolean){await this.row(docId,id);const r=await this.q('UPDATE document_figures SET archived_at=?,revision=revision+1 WHERE id=? AND document_id=? AND owner=? AND revision=? AND (?=1 OR (SELECT count(*) FROM document_figures WHERE document_id=? AND archived_at IS NULL)<?)',archive?new Date().toISOString():null,id,docId,this.who,revision,archive?1:0,docId,FIGURES_PER_DOCUMENT).run();if(r.meta.changes!==1)throw new AppError('The figure changed or the active figure limit was reached. Refresh the list.',409);return this.value(await this.row(docId,id));}
 async export(docId:string){const figures=await this.list(docId),items=[];for(const figure of figures){const runs=await this.runs(docId,figure.id),events=(await this.q('SELECT e.id,e.run_id,e.review,e.created_at FROM figure_review_events e JOIN figure_runs r ON r.id=e.run_id WHERE r.figure_id=? AND e.owner=? ORDER BY e.created_at,e.id',figure.id,this.who).all<{id:string;run_id:string;review:string;created_at:string}>()).results.map(e=>({...e,review:JSON.parse(e.review)}));items.push({figure,runs,reviewHistory:events});}return {version:'EMP-figure-export-0.10.0',documentId:docId,items};}
}
