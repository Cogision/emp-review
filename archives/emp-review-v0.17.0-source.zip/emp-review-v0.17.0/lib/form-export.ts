import {translate} from "./i18n";
import JSZip from "jszip";
import { currentClaims, deriveBridge, claimIssues, FAMILIES, type RecordDoc, type Claim, type Citation } from "./emp";
import { SCOPE_KEYS } from "./v05";
import type { AutomaticState } from "./automatic";

export type ExportData={document:RecordDoc;state:AutomaticState;audits:Array<{id:string;step:string;requestHash:string;outputHash:string;createdAt:string;request:unknown;rawOutput:string}>};
const classes:Record<string,string>={B0:"Supported",B1:"Open",B2:"Evidential inheritance",B3:"Unbridged assertion",BU:"Unresolved at coding",BNA:"Not applicable"};
const xml=(s:string)=>s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/\r?\n/g,'</w:t><w:br/><w:t xml:space="preserve">');
type FormData={document:RecordDoc;state:Pick<AutomaticState,'language'|'runId'|'audit'|'startedAt'|'version'|'model'>&{inventory:Pick<AutomaticState['inventory'],'reportType'|'typeRationale'|'bibliography'|'complete'>}};
export function formValues(data:FormData,c?:Claim){
 const t=(s:string,values:unknown[]=[])=>translate(s,"en",values);
 const d=data.document,s=data.state,v=c?.v05,values:Record<string,string>={};
 const set=(t:number,r:number,value:unknown,k=1)=>{values[`EMP_${t}_${r}_${k}`]=String(value??"");};
 const cite=(x:Citation|null|undefined)=>x?`${x.quote}\n[${d.source.blocks.find(b=>b.id===x.blockId)?.label||x.blockId}; ${x.blockId}]`:"";
 const type=d.review.reportType||d.analysis?.reportType||s.inventory.reportType;
 const structural=!c||["NC","NMC"].includes(type);
 const quality=c?claimIssues(c,d.source):[];
 if(c?.v05?.methodologicalGeneralisation&&type!=="M")quality.push(t("Generalizacja M została wskazana poza raportem M."));
 const bridge=structural?"BNA":quality.length?"BU":deriveBridge(c!,type);
 const cid=structural?"":c!.id,record=`${d.id}/${cid||"structural"}/${s.runId}/${d.stage}`;
 const decision=c?d.review.decisions[c.id]:null;
 const changed=!!decision;
 const audit=s.audit.find(x=>x.step===cid)||s.audit[0];
 const label=changed?t("Ocena z zapisanymi zmianami recenzenta; status: {0}",[decision!.status]):t("Automatyczna ocena AI — bez weryfikacji człowieka");
 const rawpath=audit?`audyt/${audit.id}.json`:t("Brak");
 set(1,0,`Ref_ID: ${d.id}\nClaim_ID: ${cid}\nPrimary_for_report: ${!structural&&c?.primary?"Yes":"No"}`);
 set(1,1,`Coder_ID: AI-${s.runId}\nType: Model-assisted\nManual: v0.5\n${label}`);
 set(1,2,t("Model_assistance_record_ID: {0}\nAneks: tabela końcowa + katalog audyt/ w tej samej paczce ZIP.",[record]));
 set(1,3,t("{0}\nStage_A_linked_claim_ID: brak\nNo valid A record. Nie wykonano zaślepionego porównania etapów.",[d.stage==="A"?"A - Title and abstract only":"B - Full text and supplements"]));
 set(1,4,t("Source_bundle_ID: {0}\nSource_bundle_version: 1\nSHA-256 tekstu źródłowego (JSON): {1}\nSumy oryginalnych plików binarnych: nie obliczono; zarejestrowano dokładny tekst przekazany modelowi.",[d.id,d.sourceHash]));
 set(1,5,t("Contents: {0}\nSeen: {1}\nDokładny zakres: {2}\n{3} fragmentów; identyfikatory, lokalizacje i pełny odczyt w analiza.json.\n{4}",[(d.source.files||[{fileName:d.source.fileName,role:"primary"}]).map(f=>`${f.fileName} (${f.role})`).join("; "),d.stage==="A"?"Title and abstract only":"Full text and report supplements",d.coverage,d.source.blocks.length,d.source.warnings.join("\n")]));
 set(1,6,t("Blind_independent: No\nConflict_status: Unclear\nTryb automatyczny nie jest niezależnym kodowaniem przez człowieka; konflikt operatora nie był deklarowany."));
 set(1,7,`${d.title}\n${s.inventory.bibliography}`);
 set(1,8,`Report_type: ${type}\n${s.inventory.typeRationale}\nMethodological_generalisation_present: ${!structural&&v?.methodologicalGeneralisation?"Yes":"No"}\nTarget: ${structural?"":v?.generalisationTarget||""}`);
 set(1,9,structural?t("Zastosowano regułę zatrzymania. Zachowano metadane i stany strukturalne; nie utworzono twierdzenia."):t("Raport z ocenianym twierdzeniem. Reguła zatrzymania strukturalnego nie ma zastosowania."));
 set(3,0,structural?"":cite(c?.citation));set(3,1,structural?"":c?.statement);
 set(3,2,structural?"":`Location: ${v?.location}\nBasis: ${v?.selectionBasis}`);
 set(3,3,structural?"":c?.selectionRationale);set(3,4,structural?"":`Commitment: ${v?.commitment}\nPolarity: ${v?.polarity}`);
 set(3,5,structural?"":`${v?.declaredUse}\n${v?.usePredicate}`);set(3,6,structural?"":c?.family);
 set(3,7,structural?"":`Cross-cutting: ${c?.family==="Cross-cutting"?"Yes":"No"}\nRequired_family_set: ${c?.requiredFamilies.join("; ")}`);
 set(5,0,structural?"":c?.readout);set(5,1,structural?"RNA":v?.readoutRelation);set(5,2,structural?"":`${v?.equivalenceEvidence}\n${cite(v?.equivalenceCitation)}`);
 set(5,3,structural?"":`${c?.context}\n${SCOPE_KEYS.map(k=>`${k}: ${c?.scope[k]}`).join("\n")}\nImplied elements: ${v?.impliedElements}`);
 set(5,4,structural?"":c?.evidenceRequired);set(5,5,structural?"":`${c?.evidenceSummary}\n${c?.evidence.map(cite).join("\n\n")}`);
 set(5,6,structural?"Structural NA":c?.kindMatch);set(5,7,structural?"Not applicable":v?.evidenceTiming);set(5,8,structural?"Not applicable":v?.observationMode);set(5,9,structural?"Not applicable":`${v?.evidenceLocation}\n${v?.evidenceLocationDetail}`);
 SCOPE_KEYS.forEach((key,r)=>["E","N","X","U","NA"].forEach((code,k)=>set(7,r+1,(structural?"NA":v?.scopeCodes[key])===code?"X":"",k+1)));
 FAMILIES.forEach((f,r)=>["D","I","N0","U","NE"].forEach((code,k)=>set(8,r+1,(structural?"NE":c?.profile[f])===code?"X":"",k+1)));
 set(9,0,structural?"Warrant_family: Not applicable":`${v?.warrantClaim}\nWarrant_family: ${v?.warrantFamily}`);set(9,1,structural?"Structural NA":c?.focal);set(9,2,structural?"Structural NA":`${c?.adequacy}\n${v?.adequacyRationale}`);
 set(11,0,structural?"Structural NA":v?.condition);set(11,1,structural?"":cite(c?.conditionCitation));set(11,2,structural?"NA":v?.coupling);set(11,3,structural?"Structural NA":v?.conditionMatches);set(11,4,structural?"Not applicable":c?.role);set(11,5,structural?"Structural NA":c?.substitution);set(11,6,structural?"":`${c?.secondarySubstitutions.join("; ")}\n${v?.substitutionDetail}`);
 set(11,7,bridge);set(11,8,structural?"":`From: ${v?.bridgeFrom}\nTo: ${v?.bridgeTo}`);set(11,9,classes[bridge]);
 set(11,10,t("Module: Disabled\nAttempted: {0}\nPrimary: {1}\nSecondary 1: \nSecondary 2: \nConfidence: {2}\nModuł wyłączony przed analizą w tym trybie.",[bridge==="B2"?"No":"Structural NA",bridge==="B2"?"":"Structural NA",bridge==="B2"?"":"Structural NA"]));set(11,11,"");
 set(13,0,structural?"":t("Hedging present: {0}\nConfidence: {1} (ocena modelu; nie prawdopodobieństwo poprawności)",[v?.hedging,v?.confidence]));set(13,1,structural?"":c?.rationale);
 set(13,2,t("{0}\n{1}\n{2}\n{3}\nAdjudication_required: {4}\nKontrola automatyczna: {5}\nKompletność listy zadeklarowana przez AI: {6}; człowiek: {7}",[label,v?.notes||"",c?.questions.join("\n")||"",decision?.comment||"",bridge==="BU"?"Yes":"No",quality.length?quality.join("; "):t("brak wykrytych niespójności strukturalnych; nie potwierdza trafności oceny"),s.inventory.complete?"Yes":"No",d.review.coverageChecked?t("sprawdzono"):t("nie sprawdzono")]));
 set(13,3,t("Zapis wyniku: {0}\nNie wykonano certyfikacji blokady etapu ani podpisu człowieka. Czas zapisu nie potwierdza prospektywnego zaślepienia.",[s.startedAt]));
 set(15,0,t("No valid A record. Brak prawidłowej zablokowanej pary A/B. Porównania nie wykonano."));set(15,1,"Not assessed");
 for(let r=1;r<10;r++){set(16,r,"",1);set(16,r,"",2);}set(17,0,"");set(17,1,t("Nie oceniano zmian A/B — brak prawidłowej pary. Shift_QC: nie obliczano."));
 for(let r=0;r<8;r++)set(19,r,"");set(19,0,t("Adjudykacji nie wykonano. Nie ma pary niezależnych surowych ocen."));
 set(21,0,`Model_assistance_record_ID: ${record}\nRef_ID: ${d.id}\nClaim_ID: ${cid}\nSource_stage: ${d.stage}\nRun ID: ${s.runId}`);
 set(21,1,t("Provider: OpenAI\nModel requested: {0}\nVersion/snapshot: identyfikator migawki odpowiedzi nie został zarejestrowany; nie utożsamiać aliasu z migawką.\nRun date-time and zone: {1} (UTC)",[s.model,s.startedAt]));
 set(21,2,t("{0} → request.input\nPełny nieskrócony prompt oraz source w JSON. SHA-256 całego request JSON: {1}\nPozostałe etapy: pliki w katalogu audyt/.",[rawpath,audit?.requestHash||""]));
 set(21,3,t("{0} → request.instructions\nPełny tekst instrukcji w paczce. Wersja: {1}\nSHA-256 całego request JSON: {2}",[rawpath,s.version,audit?.requestHash||""]));
 set(21,4,t("Temperature / Top_p / Seed / Reasoning-effort: not set explicitly; provider defaults were not recorded.\nmax_output_tokens, text.format and store: exact values are recorded in the request annexes; the format may vary between calls."));
 set(21,5,t("Tools: brak narzędzi modelu.\nBrowsing or retrieval used: No\nAplikacja odczytuje tekst z plików; nie wykonuje OCR ani wyszukiwania poza pakietem."));
 set(21,6,t("Source_bundle_ID/version: {0}/1\nDokładne pliki, fragmenty i lokalizacje: analiza.json oraz request.input w audyt/.\nOther conversation/memory: brak historii rozmowy użytkownika. Etap szczegółowy otrzymuje typ raportu i jednego kandydata z wcześniejszego etapu tego samego przebiegu.",[d.id]));
 set(21,7,t("Workbook prefilled: No\nWorked/training examples visible: Yes — przykłady w normatywnych sekcjach manuala; przykład JSON określa kształt danych.\nOther coder/adjudicated values visible: No — wcześniejsza lista kandydatów pochodzi z tego samego przebiegu."));
 set(21,8,t("Isolated\nOsobne bezstanowe żądania API; bez previous_response_id, pamięci rozmowy, narzędzi zewnętrznych i ocen innych koderów. Każdy etap widzi źródło; etap szczegółowy także własnego kandydata z inwentaryzacji. Nie jest to zaślepiony test dwóch koderów."));
 set(21,9,t("{0} → rawOutput\nSHA-256: {1}\nHuman editing before coding extraction: No\nPóźniejsze zmiany w tej wersji formularza: {2}\nSurowa odpowiedź pozostaje w audycie. Ewentualne błędy kontroli skutkują nierozstrzygniętym pomostem; nie są poprawą dokonaną przez człowieka.",[rawpath,audit?.outputHash||"",changed?t("Yes; zapisane w analiza.json → document.review"):"No"]));
 set(21,10,t("Potwierdzenie operatora: niewykonane.\nOperator: \nDate: \nSignature: "));
 return values;
}
export async function fillForm(template:Uint8Array,values:Record<string,string>,recordNote?:string){
 const zip=await JSZip.loadAsync(template),file=zip.file("word/document.xml");if(!file)throw new Error("The v0.5 form template is unavailable. Retry the export.");
 let content=(await file.async("string")).replace(/\{\{(EMP_\d+_\d+_\d+)\}\}/g,(_m,key)=>{if(!(key in values))throw new Error(`Missing export field: ${key}`);return xml(values[key]);});
 if(recordNote){
  // The original automated template has an AI-only cover note. Human records
  // replace that note without changing the normative field layout.
  content=content.replace(/<w:p\b[^>]*>[\s\S]*?<\/w:p>/g,p=>{
   if(!p.includes('Form populated by AI')&&!p.includes('Formularz wypełniony automatycznie przez AI'))return p;
   const pPr=p.match(/<w:pPr\b[^>]*>[\s\S]*?<\/w:pPr>/)?.[0]||'',rPr=p.match(/<w:rPr\b[^>]*>[\s\S]*?<\/w:rPr>/)?.[0]||'';
   return `<w:p>${pPr}<w:r>${rPr}<w:t xml:space="preserve">${xml(recordNote)}</w:t></w:r></w:p>`;
  });
 }
 // Keep introductory paragraphs with their table and short rows together.
  content=content.replace(/<w:tbl\b[^>]*>[\s\S]*?<\/w:tbl>|<w:p\b[^>]*>[\s\S]*?<\/w:p>/g,part=>{
   if(part.startsWith('<w:tbl'))return part.replace(/<w:tr\b[^>]*>[\s\S]*?<\/w:tr>/g,row=>{
    if(row.replace(/<[^>]*>/g,'').length>1000||row.includes('<w:cantSplit'))return row;
    return row.includes('<w:trPr>')?row.replace('<w:trPr>','<w:trPr><w:cantSplit/>'):row.replace(/(<w:tr\b[^>]*>)/,'$1<w:trPr><w:cantSplit/></w:trPr>');
   });
   if(!part.includes('<w:t')||part.includes('<w:keepNext'))return part;
   return part.includes('<w:pPr>')?part.replace('<w:pPr>','<w:pPr><w:keepNext/>'):part.replace(/(<w:p\b[^>]*>)/,'$1<w:pPr><w:keepNext/></w:pPr>');
  });
 if(content.includes("{{EMP_"))throw new Error("The form contains unfilled fields. Retry the export.");zip.file("word/document.xml",content);return zip.generateAsync({type:"uint8array",compression:"DEFLATE"});
}
export async function createExportPackage(items:ExportData[],template:Uint8Array,failures:Array<{title:string;error:string}>=[]){
 const t=(s:string,values:unknown[]=[])=>translate(s,"en",values);
 const zip=new JSZip();const summary=[t("EMP — automatyczne formularze v0.5"),t("Wygenerowano: {0}",[new Date().toISOString()]),t("Oceny AI nie są automatycznie zatwierdzane przez człowieka. Formularze zawierają zapisane korekty, jeśli istnieją; oryginalne odpowiedzi są w audycie."),t("Pełny tekst i dostępne suplementy są analizowane w zakresie importu. Nie wykonano OCR, oceny samych rycin, zaślepionego porównania A/B ani adjudykacji. Moduł przejść: Disabled."),""];
 for(const data of items){const d=data.document;if(!data.state.complete)throw new Error(t("Nie można eksportować nieukończonej analizy jako pełnego formularza."));
  const folder=zip.folder(`EMP_${d.id}`)!;folder.file("analiza.json",JSON.stringify(data,null,2));
  data.audits.forEach(a=>folder.file(`audyt/${a.id}.json`,JSON.stringify(a,null,2)));
  const type=d.review.reportType||d.analysis?.reportType,structural=type==="NC"||type==="NMC",claims=structural?[]:currentClaims(d).filter(c=>d.review.decisions[c.id]?.status!=="excluded");
  if(claims.some(c=>!c.v05))throw new Error(t("Ta ocena nie ma wszystkich pól v0.5. Uruchom nowy przegląd w trybie automatycznym."));
  if(structural)folder.file("EMP_structural_v0_5.docx",await fillForm(template,formValues(data)));
  else if(!claims.length)summary.push(t("{0}: brak aktywnych twierdzeń po zmianach recenzenta. Zachowano JSON i audyt; nie utworzono formularza twierdzenia ani formularza strukturalnego.",[d.title]));
  for(const c of claims){const name=`${String(claims.indexOf(c)+1).padStart(2,"0")}_${c.id.replace(/[^a-zA-Z0-9_-]/g,"_")}`;folder.file(`EMP_${name}_v0_5.docx`,await fillForm(template,formValues(data,c)));}
  summary.push(t("{0}\nReport_ID: {1}\nTwierdzenia: {2}; typ: {3}; {4}.\n{5}\n{6}\n",[d.title,d.id,claims.length,type,data.state.inventory.complete?t("ukończono listę zgłoszoną przez AI"):t("UWAGA: lista twierdzeń zgłoszona jako niepełna"),d.analysis?.summary||"",d.analysis?.limitations.join("\n")||""]));
 }
 if(failures.length){summary.push(t("NIEUKOŃCZONE PUBLIKACJE — brak pełnych formularzy:"));failures.forEach(x=>summary.push(`${x.title}: ${x.error}`));}
 zip.file("CZYTAJ_TO.txt",summary.join("\n"));return zip.generateAsync({type:"blob",compression:"DEFLATE"});
}
