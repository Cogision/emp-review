import {tr} from "./i18n";
export class HttpError extends Error {
  constructor(message: string, public status: number) { super(message); this.name = 'HttpError'; }
}
/** Read API responses without mistaking a proxy/framework error page for JSON. */
export async function readJsonResponse<T>(response: Response): Promise<T> {
  const body = await response.text();
  let data: unknown;
  let validJson = false;
  try {
    data = JSON.parse(body);
    validJson = true;
  } catch {
    // HTTP status remains authoritative even when the body is plain text/HTML.
  }
  if (!response.ok) {
    const message = data && typeof data === "object" && "error" in data
      && typeof data.error === "string" ? data.error : undefined;
    if (message) throw new HttpError(tr(message),response.status);
    if (response.status === 413) {
      throw new HttpError("The server rejected an oversized request. Files can be up to 10 MB. Your form text has been kept; try a smaller file or paste its text.",response.status);
    }
    if (response.status === 401 || response.status === 403) {
      throw new HttpError("Your session has expired or access is unavailable. Sign in again and retry.",response.status);
    }
    throw new HttpError(`The server could not complete the operation (HTTP ${response.status}). Your input is still on screen. Please try again.`,response.status);
  }
  if (!validJson) {
    throw new Error("The server returned an invalid response. Saving was not confirmed; your form data remains on screen. Try again.");
  }
  return data as T;
}

export async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response:Response;
  try{response=await fetch(path,init);}catch{throw new Error('Connection interrupted. The server may still be processing the request. Reload the saved state before retrying. This message alone does not indicate exhausted AI credits.');}
  return readJsonResponse<T>(response);
}
