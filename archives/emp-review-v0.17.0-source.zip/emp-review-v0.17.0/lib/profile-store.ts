import { AppError } from './app-error';
import { defaultProfile, profileInput, type AccountIdentity, type AccountProfile } from './account-profile';

type ProfileRow = { display_name: string; affiliation: string; revision: number; updated_at: string };

export class ProfileStore {
  constructor(private database: D1Database, private userId: string, private identity: AccountIdentity) {
    if (!userId) throw new AppError('Sign in to manage your account.',401);
  }
  async get(): Promise<AccountProfile> {
    const row = await this.database.prepare('SELECT display_name,affiliation,revision,updated_at FROM account_profiles WHERE user_id=?').bind(this.userId).first<ProfileRow>();
    return row ? {displayName:row.display_name,affiliation:row.affiliation,email:this.identity.email,revision:row.revision,updatedAt:row.updated_at} : defaultProfile(this.identity);
  }
  async save(input: unknown): Promise<AccountProfile> {
    const parsed = profileInput.safeParse(input);
    if (!parsed.success) throw new AppError('Enter a display name (up to 120 characters) and an optional affiliation (up to 200 characters), each on one line.',400);
    const {displayName,affiliation,revision} = parsed.data, now = new Date().toISOString();
    const statement = revision === 0
      ? this.database.prepare('INSERT INTO account_profiles (user_id,display_name,affiliation,revision,updated_at) VALUES (?,?,?,1,?) ON CONFLICT(user_id) DO NOTHING').bind(this.userId,displayName,affiliation,now)
      : this.database.prepare('UPDATE account_profiles SET display_name=?,affiliation=?,revision=revision+1,updated_at=? WHERE user_id=? AND revision=?').bind(displayName,affiliation,now,this.userId,revision);
    const result = await statement.run();
    if (result.meta.changes !== 1) throw new AppError('Your profile changed in another tab. Copy any edits you want to keep, then reload the latest profile.',409);
    return {displayName,affiliation,email:this.identity.email,revision:revision+1,updatedAt:now};
  }
}
