import {legacyManifest} from './versions';
import {z} from 'zod';
import {AppError} from './app-error';
import {RoundStore} from './round-store';
import {parseDraft,assertSubmission,type Adjudication,type RoundSource} from './review-rounds';
import {type ProjectDocument,type AssessmentBasis} from './projects';
import type {Analysis,Review} from './emp';

type Selection={selected_round_id:string|null;selected_adjudication_id:string|null};
type Option={roundId:string;roundTitle:string;manualVersion:string;adjudicationId:string;createdAt:string;summary:string;actorName:string;rationale:string};
const changed=()=>new AppError('The project changed. Reload before selecting an assessment / Projekt zmienił się. Wczytaj go ponownie.',409);
export class ProjectAssessmentStore {
 constructor(private env:{DB:D1Database;BUCKET:R2Bucket},private who:string){}
 private q(sql:string,...args:unknown[]){return this.env.DB.prepare(sql).bind(...args);}
 private async member(projectId:string,documentId:string){
  const row=await this.q('SELECT p.revision,d.source_hash,d.stage,pd.selected_round_id,pd.selected_adjudication_id FROM projects p JOIN project_documents pd ON pd.project_id=p.id JOIN documents d ON d.id=pd.document_id WHERE p.id=? AND pd.document_id=? AND p.owner=? AND d.owner=?',projectId,documentId,this.who,this.who).first<Selection&{revision:number;source_hash:string;stage:string}>();
  if(!row)throw new AppError('Project report not found / Nie znaleziono raportu w projekcie.',404);return row;
 }
 private async resolve(documentId:string,sourceHash:string,stage:string,roundId:string,adjudicationId:string){
  // Only the coordinator who owns this exact source document can select its round.
  const row=await this.q("SELECT r.id,r.title,r.manual_version,r.source_hash,r.source_key,a.snapshot_key FROM review_rounds r JOIN round_adjudications a ON a.round_id=r.id WHERE r.id=? AND r.coordinator_id=? AND r.source_document_id=? AND r.source_hash=? AND r.stage=? AND r.status IN ('revealed','adjudicated') AND a.id=?",roundId,this.who,documentId,sourceHash,stage,adjudicationId).first<{id:string;title:string;manual_version:string;source_hash:string;source_key:string;snapshot_key:string}>();
  if(!row)throw new AppError('Adjudication not available or not found for this source / Rozstrzygnięcie niedostępne dla tego źródła.',409);
  const [object,sourceObject]=await Promise.all([this.env.BUCKET.get(row.snapshot_key),this.env.BUCKET.get(row.source_key)]);
  if(!object||!sourceObject)throw new AppError('Selected assessment temporarily unavailable / Wybrana ocena jest chwilowo niedostępna.',503);
  const adjudication=await object.json<Adjudication>(),source=await sourceObject.json<RoundSource>();
  if(adjudication.id!==adjudicationId||source.sourceHash!==sourceHash)throw new AppError('Selected assessment reference mismatch.',503);
  const draft=parseDraft(adjudication.draft,row.manual_version);assertSubmission(draft,source.source,row.manual_version);
  return {round:{id:row.id,title:row.title,manualVersion:row.manual_version,sourceHash:row.source_hash},adjudication:{...adjudication,draft}};
 }
 async options(projectId:string,documentId:string){
  const m=await this.member(projectId,documentId),rows=await this.q("SELECT r.id,r.title,r.manual_version,a.id AS adjudication_id FROM review_rounds r JOIN round_adjudications a ON a.round_id=r.id WHERE r.coordinator_id=? AND r.source_document_id=? AND r.source_hash=? AND r.stage=? AND r.status IN ('revealed','adjudicated') ORDER BY a.created_at DESC,a.id",this.who,documentId,m.source_hash,m.stage).all<{id:string;title:string;manual_version:string;adjudication_id:string}>();
  const options:Option[]=[];
  // Load each released round once; never access drafts from a collecting round.
  const cache=new Map<string,Awaited<ReturnType<RoundStore['detail']>>>();
  for(const r of rows.results){let d=cache.get(r.id);if(!d){d=await new RoundStore(this.env,this.who).detail(r.id);cache.set(r.id,d);}const a=d.adjudications?.find(a=>a.id===r.adjudication_id);if(a)options.push({roundId:r.id,roundTitle:r.title,manualVersion:r.manual_version,adjudicationId:a.id,createdAt:a.createdAt,summary:a.draft.summary,actorName:a.actorName||a.actorId||'',rationale:a.rationale});}
  return {revision:m.revision,selected:m.selected_adjudication_id,options};
 }
 async select(projectId:string,documentId:string,body:unknown){
  const b=z.object({revision:z.number().int().nonnegative(),roundId:z.string().min(1).max(120).nullable(),adjudicationId:z.string().min(1).max(120).nullable()}).parse(body);
  if(!!b.roundId!==!!b.adjudicationId)throw new AppError('Choose a complete assessment reference / Wybierz pełne odniesienie do oceny.',400);
  const m=await this.member(projectId,documentId);if(m.revision!==b.revision)throw changed();
  if(b.roundId&&b.adjudicationId)await this.resolve(documentId,m.source_hash,m.stage,b.roundId,b.adjudicationId);
  const event=crypto.randomUUID(),now=new Date().toISOString();
  const detail=JSON.stringify({previous:{roundId:m.selected_round_id,adjudicationId:m.selected_adjudication_id},selected:{roundId:b.roundId,adjudicationId:b.adjudicationId},sourceHash:m.source_hash});
  // A unique event is the CAS marker for every write in the atomic batch.
  const results=await this.env.DB.batch([
   this.q('INSERT INTO project_selection_events (id,project_id,document_id,actor,detail,created_at) SELECT ?,p.id,?,?,?,? FROM projects p JOIN project_documents pd ON pd.project_id=p.id JOIN documents d ON d.id=pd.document_id WHERE p.id=? AND p.owner=? AND p.revision=? AND pd.document_id=? AND d.owner=? AND d.source_hash=? AND d.stage=?',event,documentId,this.who,detail,now,projectId,this.who,b.revision,documentId,this.who,m.source_hash,m.stage),
   this.q('UPDATE project_documents SET selected_round_id=?,selected_adjudication_id=? WHERE project_id=? AND document_id=? AND EXISTS(SELECT 1 FROM project_selection_events WHERE id=?)',b.roundId,b.adjudicationId,projectId,documentId,event),
   this.q('UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM project_selection_events WHERE id=?)',now,projectId,event),
  ]);
  if(results[0].meta.changes!==1)throw changed();
  return {ok:true};
 }
 async apply(projectId:string,document:ProjectDocument):Promise<ProjectDocument>{
  const m=await this.member(projectId,document.id);
  if(!m.selected_round_id&&!m.selected_adjudication_id)return document;
  if(!m.selected_round_id||!m.selected_adjudication_id)throw new AppError('The selected assessment reference is incomplete.',503);
  const {round,adjudication:a}=await this.resolve(document.id,document.sourceHash,document.stage,m.selected_round_id,m.selected_adjudication_id);
  return projectAdjudication(document,a,{kind:'adjudicated',manualVersion:round.manualVersion,roundId:round.id,roundTitle:round.title,adjudicationId:a.id,createdAt:a.createdAt,actorId:a.actorId,actorName:a.actorName,basedOn:a.basedOn,sourceHash:round.sourceHash});
 }
 async history(projectId:string){
  const project=await this.q('SELECT 1 FROM projects WHERE id=? AND owner=?',projectId,this.who).first();if(!project)throw new AppError('Project not found.',404);
  return (await this.q('SELECT id,document_id AS documentId,actor,detail,created_at AS createdAt FROM project_selection_events WHERE project_id=? ORDER BY created_at,id',projectId).all<{id:string;documentId:string;actor:string;detail:string;createdAt:string}>()).results;
 }
}

export function projectAdjudication(d:ProjectDocument,a:Adjudication,basis:AssessmentBasis):ProjectDocument{
 const draft=a.draft;
 const analysis:Analysis={reportType:draft.reportType as Analysis['reportType'],typeRationale:draft.typeRationale,summary:draft.summary,limitations:[],claims:draft.claims,language:draft.metadata?.language||'en',model:'Human adjudication',generatedAt:a.createdAt,promptVersion:'not-applicable-human-adjudication',demo:false,sourceHash:d.sourceHash};
 const review:Review={decisions:Object.fromEntries(draft.claims.map(c=>[c.id,{...draft.decisions[c.id],claim:c,updatedAt:a.createdAt}])),coverageChecked:draft.coverageChecked,reportType:draft.reportType as Review['reportType'],reportComment:draft.typeRationale};
 return {...d,analysis,review,versions:legacyManifest(analysis,review),assessmentBasis:basis,originalAssessment:{analysis:d.analysis,review:d.review},adjudication:a};
}
