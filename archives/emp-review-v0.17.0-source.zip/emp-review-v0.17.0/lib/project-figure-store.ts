import {z} from 'zod';
import {AppError} from './app-error';
import {FigureStore} from './figure-store';
import {figureSelectionIssue,type FigureSelection,type ProjectFigureSelection} from './project-figures';
type Env={DB:D1Database;BUCKET:R2Bucket};
export class ProjectFigureStore{
 constructor(private env:Env,private who:string){}
 private q(sql:string,...args:unknown[]){return this.env.DB.prepare(sql).bind(...args);}
 private async project(id:string){const p=await this.q('SELECT revision FROM projects WHERE id=? AND owner=?',id,this.who).first<{revision:number}>();if(!p)throw new AppError('Project not found.',404);return p;}
 private async member(id:string,documentId:string){const d=await this.q('SELECT d.source_hash,d.title FROM project_documents pd JOIN projects p ON p.id=pd.project_id JOIN documents d ON d.id=pd.document_id WHERE p.id=? AND d.id=? AND p.owner=? AND d.owner=?',id,documentId,this.who,this.who).first<{source_hash:string;title:string}>();if(!d)throw new AppError('Project report not found.',404);return d;}
 async options(id:string,documentId:string){
  const p=await this.project(id),d=await this.member(id,documentId),store=new FigureStore(this.env,this.who),items=[];
  for(const figure of await store.list(documentId)){if(figure.archivedAt)continue;const runs=(await store.runs(documentId,figure.id)).filter(r=>r.review.status==='checked'&&r.review.sourceChecked&&r.sourceHash===d.source_hash&&r.imageHash===figure.imageHash&&r.report.readability!=='unreadable'&&r.report.observations.length);if(runs.length)items.push({figure,runs});}
  return {revision:p.revision,items};
 }
 async list(id:string):Promise<ProjectFigureSelection[]>{
  await this.project(id);const rows=(await this.q('SELECT s.selection,d.title,d.source_hash FROM project_figure_selections s JOIN project_documents pd ON pd.project_id=s.project_id AND pd.document_id=s.document_id JOIN documents d ON d.id=pd.document_id WHERE s.project_id=? AND d.owner=? ORDER BY s.document_id,s.figure_id',id,this.who).all<{selection:string;title:string;source_hash:string}>()).results;
  const store=new FigureStore(this.env,this.who),out:ProjectFigureSelection[]=[];
  for(const row of rows){const selection=JSON.parse(row.selection) as FigureSelection,figure=(await store.list(selection.documentId)).find(f=>f.id===selection.figureId)||null,run=figure?(await store.runs(selection.documentId,figure.id)).find(r=>r.id===selection.runId)||null:null;const reason=figureSelectionIssue(selection,figure,run,row.source_hash);out.push({selection,title:row.title,figure,run,eligible:!reason,reason});}
  return out;
 }
 async select(id:string,body:unknown){
  const v=z.object({revision:z.number().int().nonnegative(),documentId:z.string().uuid(),figureId:z.string().uuid(),runId:z.string().uuid().nullable(),reviewRevision:z.number().int().nonnegative().optional(),indices:z.array(z.number().int().min(0).max(11)).max(12).default([]),note:z.string().trim().max(4000).default('')}).parse(body);
  const p=await this.project(id),d=await this.member(id,v.documentId);if(p.revision!==v.revision)throw new AppError('The project changed. Reload before selecting figure observations.',409);
  const previous=await this.q('SELECT selection FROM project_figure_selections WHERE project_id=? AND document_id=? AND figure_id=?',id,v.documentId,v.figureId).first<{selection:string}>();
  let selection:FigureSelection|null=null;
  if(v.runId){
   const store=new FigureStore(this.env,this.who),figure=(await store.content(v.documentId,v.figureId)).figure,run=(await store.runs(v.documentId,v.figureId)).find(r=>r.id===v.runId);
   if(!run)throw new AppError('Figure analysis not found.',404);if(!v.note||!v.indices.length||new Set(v.indices).size!==v.indices.length||v.reviewRevision===undefined)throw new AppError('Choose observations and explain their relevance to this project.');
   const state=await this.q('SELECT mutation,owner FROM figure_runs WHERE id=? AND figure_id=? AND owner=? AND revision=?',run.id,figure.id,this.who,v.reviewRevision).first<{mutation:string;owner:string}>();
   if(!state?.mutation)throw new AppError('The figure review changed. Refresh before selecting.',409);
   selection={documentId:v.documentId,figureId:v.figureId,runId:run.id,reviewRevision:v.reviewRevision,reviewEventId:state.mutation,reviewerId:state.owner,figureRevision:figure.revision,sourceHash:run.sourceHash,imageHash:run.imageHash,indices:[...v.indices].sort((a,b)=>a-b),note:v.note,actorId:this.who,selectedAt:new Date().toISOString()};
   const issue=figureSelectionIssue(selection,figure,run,d.source_hash);if(issue)throw new AppError(issue,409);
  }
  const event=crypto.randomUUID(),now=new Date().toISOString(),check=selection?" AND EXISTS(SELECT 1 FROM document_figures f JOIN figure_runs r ON r.figure_id=f.id WHERE f.id=? AND f.document_id=d.id AND f.owner=? AND f.archived_at IS NULL AND f.revision=? AND r.id=? AND r.owner=? AND r.revision=? AND r.mutation=?)":'',args=selection?[selection.figureId,this.who,selection.figureRevision,selection.runId,this.who,selection.reviewRevision,selection.reviewEventId]:[];
  const results=await this.env.DB.batch([
   this.q('INSERT INTO project_selection_events (id,project_id,document_id,actor,detail,created_at) SELECT ?,p.id,d.id,?,?,? FROM projects p JOIN project_documents pd ON pd.project_id=p.id JOIN documents d ON d.id=pd.document_id WHERE p.id=? AND p.owner=? AND p.revision=? AND d.id=? AND d.owner=? AND d.source_hash=?'+check,event,this.who,JSON.stringify({kind:'figure_selection',previous:previous?JSON.parse(previous.selection):null,selected:selection}),now,id,this.who,v.revision,v.documentId,this.who,d.source_hash,...args),
   selection?this.q('INSERT INTO project_figure_selections (project_id,document_id,figure_id,selection,updated_at) SELECT project_id,document_id,?,?,? FROM project_selection_events WHERE id=? ON CONFLICT(project_id,document_id,figure_id) DO UPDATE SET selection=excluded.selection,updated_at=excluded.updated_at',v.figureId,JSON.stringify(selection),now,event):this.q('DELETE FROM project_figure_selections WHERE project_id=? AND document_id=? AND figure_id=? AND EXISTS(SELECT 1 FROM project_selection_events WHERE id=?)',id,v.documentId,v.figureId,event),
   this.q('UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM project_selection_events WHERE id=?)',now,id,event)
  ]);
  if(results[0].meta.changes!==1)throw new AppError('The project or figure review changed. Reload before selecting.',409);return {ok:true};
 }
}
