import type {Figure,FigureRun,FigureReport} from './figures';
export type FigureSelection={documentId:string;figureId:string;runId:string;reviewRevision:number;reviewEventId:string;reviewerId:string;figureRevision:number;sourceHash:string;imageHash:string;indices:number[];note:string;actorId:string;selectedAt:string};
export type ProjectFigureSelection={selection:FigureSelection;eligible:boolean;reason:string;title:string;figure:Figure|null;run:FigureRun|null};
export type SelectedFigureObservation={key:string;documentId:string;title:string;figure:Figure;runId:string;model:string;appVersion:string;promptVersion:string;generatedAt:string;language:'en'|'pl';sourceHash:string;imageHash:string;review:FigureRun['review'];reviewEventId:string;reviewerId:string;selection:FigureSelection;observationIndex:number;observation:FigureReport['observations'][number];kind:FigureReport['kind'];readability:FigureReport['readability'];limitations:string[]};
export function figureSelectionIssue(selection:FigureSelection,figure:Figure|null,run:FigureRun|null,sourceHash:string):string{
 if(!figure||!run)return 'Selected figure analysis is unavailable / Wybrana analiza ryciny jest niedostępna.';
 if(figure.archivedAt)return 'Figure is archived / Rycina jest zarchiwizowana.';
 if(figure.revision!==selection.figureRevision)return 'Figure status changed; select it again / Status ryciny zmienił się; wybierz ją ponownie.';
 if(run.review.status!=='checked'||!run.review.sourceChecked)return 'Review is no longer approved / Ocena nie jest zatwierdzona.';
 if(run.review.revision!==selection.reviewRevision)return 'Review changed; confirm this selection again / Ocena zmieniła się; ponownie potwierdź wybór.';
 if(run.sourceHash!==sourceHash||selection.sourceHash!==sourceHash||run.imageHash!==figure.imageHash||selection.imageHash!==figure.imageHash)return 'Source changed; analyse and review it again / Źródło zmieniło się; ponów analizę i ocenę.';
 if(run.report.readability==='unreadable'||!selection.indices.length||selection.indices.some(i=>!Number.isInteger(i)||i<0||!run.report.observations[i]))return 'Selected observations are unavailable / Wybrane obserwacje są niedostępne.';
 return '';
}
export function selectedFigureObservations(data:{figureSelections?:ProjectFigureSelection[]}):SelectedFigureObservation[]{
 return (data.figureSelections||[]).filter(s=>s.eligible&&s.figure&&s.run).flatMap(({selection,title,figure,run})=>selection.indices.map(index=>({key:`figure:${figure!.id}:${run!.id}:${index}`,documentId:selection.documentId,title,figure:figure!,runId:run!.id,model:run!.model,appVersion:run!.appVersion,promptVersion:run!.promptVersion,generatedAt:run!.createdAt,language:run!.language,sourceHash:run!.sourceHash,imageHash:run!.imageHash,review:run!.review,reviewEventId:selection.reviewEventId,reviewerId:selection.reviewerId,selection,observationIndex:index,observation:run!.report.observations[index],kind:run!.report.kind,readability:run!.report.readability,limitations:run!.report.limitations}))).sort((a,b)=>a.key.localeCompare(b.key));
}
