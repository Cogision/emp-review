import {selectedFigureObservations} from "./project-figures";
import {codingScope,type VersionManifest} from './versions';
import { FAMILIES, currentClaims, deriveBridge, claimIssues, type Analysis, type Review, type Claim, type Source, type RecordDoc } from "./emp";
export type Project={id:string;title:string;question:string;criteria:string;language:"en"|"pl";revision:number;created_at:string;updated_at:string;document_count?:number};
export type AssessmentBasis={kind:'original'|'adjudicated';manualVersion:string;roundId?:string;roundTitle?:string;adjudicationId?:string;createdAt?:string;actorId?:string;actorName?:string;basedOn?:string[];sourceHash?:string};
export function assessmentBasis(d:ProjectDocument):AssessmentBasis{return d.assessmentBasis||{kind:'original',manualVersion:codingScope(d.analysis,d.review)==='full'?'v0.5':'v0.5-core'};}
export function basisLabel(d:ProjectDocument,language:'en'|'pl'='en'){const b=assessmentBasis(d);return b.kind==='adjudicated'?`${language==='pl'?'Uzgodniona ocena':'Adjudicated assessment'} · ${b.manualVersion} · ${b.roundTitle} · ${b.adjudicationId}`:`${language==='pl'?'Ocena w dokumencie':'Document assessment'} · ${b.manualVersion}`;}
export type ProjectDocument={id:string;title:string;stage:string;coverage:string;sourceHash:string;revision:number;updatedAt:string;createdAt:string;studyGroup:string;versions?:VersionManifest;analysis:Analysis|null;review:Review;source:Source;assessmentBasis?:AssessmentBasis;originalAssessment?:{analysis:Analysis|null;review:Review};adjudication?:import("./review-rounds").Adjudication};
export type ProjectData={project:Project;documents:ProjectDocument[];generatedAt:string;figureSelections?:import("./project-figures").ProjectFigureSelection[];selectionHistory?:{id:string;documentId:string;actor:string;detail:string;createdAt:string}[]};
export type ProjectFilter="all"|"accepted";
export type ProjectClaim={key:string;documentId:string;title:string;stage:string;studyGroup:string;sourceHash:string;revision:number;reportType:string;claim:Claim;status:string;sourceChecked:boolean;bridge:string;issues:string[];sourceLabel:string;model:string;assessmentBasis:AssessmentBasis};
export function synthesise(data:ProjectData,filter:ProjectFilter="all"){
 const rows:ProjectClaim[]=[],codes=["D","I","N0","U","NE"] as const;
 let excluded=0,structural=0,pending=0,filteredOut=0,incomplete=0;
 for(const d of data.documents){if(!d.analysis){pending++;continue;}if(d.analysis.automatic&&!d.analysis.automatic.inventoryComplete)incomplete++;
  const type=d.review.reportType||d.analysis.reportType;if(type==="NC"||type==="NMC"){structural++;continue;}
  for(const c of currentClaims(d)){
   const decision=d.review.decisions[c.id],status=decision?.status||"draft";
   if(status==="excluded"){excluded++;continue;}
   const issues=claimIssues(c,d.source);if(c.v05?.methodologicalGeneralisation&&type!=="M")issues.push("Methodological generalisation requires report type M.");
   const bridge=issues.length||status==="unresolved"?"BU":deriveBridge(c,type);
   if(filter==="accepted"&&(status!=="accepted"||!decision?.sourceChecked||issues.length||bridge==="BU")){filteredOut++;continue;}
   rows.push({key:`${d.id}:${c.id}`,documentId:d.id,title:d.title,stage:d.stage,studyGroup:d.studyGroup,sourceHash:d.sourceHash,revision:d.revision,reportType:type,claim:c,status,sourceChecked:!!decision?.sourceChecked,bridge,issues,sourceLabel:d.source.blocks.find(b=>b.id===c.citation.blockId)?.label||c.citation.blockId,model:d.analysis.model||"Manual",assessmentBasis:assessmentBasis(d)});
  }
 }
 const matrix=FAMILIES.map(family=>({family,counts:Object.fromEntries(codes.map(c=>[c,rows.filter(r=>r.claim.profile[family]===c).length])) as Record<typeof codes[number],number>,assessed:rows.filter(r=>r.claim.profile[family]!=="NE").length}));
 return {filter,rows,matrix,counts:{reports:data.documents.length,analysed:data.documents.length-pending,pending,structural,excluded,filteredOut,incomplete,claims:rows.length,accepted:rows.filter(r=>r.status==="accepted"&&r.sourceChecked&&!r.issues.length&&r.bridge!=="BU").length,needsCheck:rows.filter(r=>r.status!=="accepted"||!r.sourceChecked||r.issues.length||r.bridge==="BU").length,groups:new Set(data.documents.map(d=>d.studyGroup.trim()).filter(Boolean)).size,ungrouped:data.documents.filter(d=>!d.studyGroup.trim()).length},version:"EMP-project-0.11.0",generatedAt:data.generatedAt};
}
export function projectNarrative(data:ProjectData,filter:ProjectFilter,lang:"en"|"pl"){
 const s=synthesise(data,filter),n=s.counts,visual=selectedFigureObservations(data).length,stale=(data.figureSelections||[]).filter(s=>!s.eligible).length,agreed=data.documents.filter(d=>assessmentBasis(d).kind==='adjudicated').length,manuals=[...new Set(data.documents.map(d=>assessmentBasis(d).manualVersion))].join(', ');
 return lang==="pl"?[
  `Raporty w projekcie: ${n.reports}. Zapisane analizy: ${n.analysed}; oczekujące: ${n.pending}. Aktywne twierdzenia w tym widoku: ${n.claims}.`,
  `Filtr: ${filter==="accepted"?"wyłącznie zaakceptowane oceny z kontrolą źródła i poprawną kontrolą pól":"wszystkie aktywne oceny, również niezweryfikowane propozycje AI"}. ${n.needsCheck} ocen wymaga wyjaśnienia lub sprawdzenia.`,
  `Podstawa syntezy: ${agreed} przypisanych rozstrzygnięć i ${n.reports-agreed} ocen z dokumentów. Wersje formularza: ${manuals||"brak"}. Każdy raport uwzględniono raz.`,
  `Wybrane i zatwierdzone obserwacje z rycin: ${visual}. Nieaktualne wybory pominięte w syntezie: ${stale}. Obserwacje są uzupełnieniem interpretacji i nie zmieniają kodów EMP ani liczby badań.`,
  `Oznaczone grupy badań: ${n.groups}; raporty bez grupy: ${n.ungrouped}. Grupy są oznaczeniami użytkownika, nie potwierdzeniem niezależności danych.`,
  `Macierz pokazuje osobno pięć rodzin EMP. Liczby odnoszą się do twierdzeń, nie do niezależnych badań. NE oznacza nieocenianą rodzinę i nie wchodzi do mianownika ocenionych pozycji.`,
  `To opisowa synteza zapisanych ocen w dostarczonym zbiorze. Nie wykonano metaanalizy ani automatycznej oceny zgodności zakresu między publikacjami. ${n.incomplete} analiz ma listę twierdzeń oznaczoną przez AI jako niepełna.`,
 ]:[
  `Reports in the project: ${n.reports}. Saved analyses: ${n.analysed}; awaiting analysis: ${n.pending}. Active claims in this view: ${n.claims}.`,
  `Filter: ${filter==="accepted"?"accepted assessments with source verification and valid field checks only":"all active assessments, including unverified AI proposals"}. ${n.needsCheck} assessments require clarification or checking.`,
  `Synthesis basis: ${agreed} pinned adjudications and ${n.reports-agreed} document assessments. Form versions: ${manuals||"none"}. Each report is counted once.`,
  `Selected and reviewer-approved figure observations: ${visual}. Stale selections omitted from synthesis: ${stale}. These observations supplement interpretation without changing EMP codes or study counts.`,
  `Labelled study groups: ${n.groups}; ungrouped reports: ${n.ungrouped}. Groups are user-assigned labels, not confirmation that datasets are independent.`,
  `The matrix shows five EMP families separately. Counts refer to claims, not independent studies. NE denotes an unassessed family and is excluded from the assessed denominator.`,
  `This is a descriptive synthesis of recorded assessments in the supplied collection. No meta-analysis or automatic cross-report scope-equivalence assessment was performed. ${n.incomplete} analyses have an inventory flagged as incomplete by AI.`,
 ];
}
