import {currentClaims, type Claim, type RecordDoc} from './emp';

/** Use the latest saved record. Unresolved and excluded are decisions, not unfinished drafts. */
export function nextPendingClaim(document:RecordDoc,currentId:string):Claim|null {
 const claims=currentClaims(document),current=claims.findIndex(c=>c.id===currentId);
 for(let offset=1;offset<=claims.length;offset++){
  const claim=claims[(current+offset)%claims.length];
  if((document.review.decisions[claim.id]?.status??'draft')==='draft')return claim;
 }
 return null;
}
