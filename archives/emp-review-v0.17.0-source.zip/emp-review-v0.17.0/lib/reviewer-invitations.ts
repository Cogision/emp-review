import {z} from 'zod';
import type {RoundInvitation} from './review-rounds';

export const normalizeReviewerEmail=(value:string)=>value.trim().toLowerCase();
export const recipientEmailSchema=z.string().trim().max(254).email().transform(normalizeReviewerEmail);
export const validInvitationCode=(value:string)=>/^[a-f0-9]{64}$/.test(value);
export const validRoundId=(value:string)=>/^[a-f0-9-]{36}$/.test(value);

export function invitationStatus(invite:RoundInvitation,now=Date.now()){
 if(invite.claimed)return 'Used';
 if(invite.revoked)return 'Revoked';
 if(new Date(invite.expiresAt).getTime()<=now)return 'Expired';
 return 'Awaiting reviewer';
}
export function invitationUrl(origin:string,token:string){
 if(!validInvitationCode(token))throw new Error('Invalid invitation code.');
 const url=new URL('/join',origin);
 // Fragments stay in the browser and do not enter server request logs.
 url.hash=`invite=${token}`;
 return url.toString();
}
export function invitationMessage(url:string){
 return `You are invited to review a publication in EMP Review.\n\n${url}\n\nSign in with the ChatGPT account for the email address receiving this invitation, then enter your reviewer name and request to join. The coordinator will approve your request. The invitation is single-use and expires after seven days.\n\nYou will see the shared source after the round starts. Your assessment stays private until everyone has submitted and the coordinator reveals the assessments.`;
}
