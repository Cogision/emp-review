import { sourceSchema, type Source } from "./emp";
import { AppError } from "./app-error";
export const MAX_FILES=10;
export const MAX_UPLOAD_BYTES=10000000;

export function combineSources(sources:Source[],primaryIndex=0):Source{
 if(!sources.length||sources.length>MAX_FILES)throw new AppError("Wybierz od 1 do 10 plików.");
 if(!sources[primaryIndex])throw new AppError("Wskaż plik główny.");
 if(sources.some(s=>s.files))throw new AppError("Nie można zagnieżdżać zestawów plików.");
 const files=sources.map((s,i)=>({id:`f${i+1}`,fileName:s.fileName,role:i===primaryIndex?"primary" as const:"supplement" as const}));
 const candidate={fileName:sources.length===1?sources[0].fileName:`Artykuł i materiały uzupełniające (${sources.length} plików)`,files,
  blocks:sources.flatMap((s,i)=>s.blocks.map((b,j)=>({id:`f${i+1}:b${j+1}`,fileId:`f${i+1}`,label:`${s.fileName.slice(0,100)} · ${b.label}`.slice(0,160),text:b.text}))),
  warnings:sources.flatMap((s,i)=>s.warnings.map(w=>`[f${i+1} · ${s.fileName}] ${w}`))};
 const parsed=sourceSchema.safeParse(candidate);
 if(!parsed.success)throw new AppError(candidate.blocks.length>600?"Zestaw przekracza 600 fragmentów. Wybierz mniej plików lub osobne publikacje.":candidate.blocks.reduce((n,b)=>n+b.text.length,0)>120000?"Zestaw przekracza 120 000 znaków. Wybierz mniej plików lub osobne publikacje.":"Zestaw przekracza limity odczytu. Wybierz mniej plików lub osobne publikacje.");
 return parsed.data;
}
export function originalKey(sourceKey:string,fileId?:string){
 if(fileId&&!/^f(?:[1-9]|10)$/.test(fileId))throw new AppError("Nieprawidłowy identyfikator pliku.");
 return sourceKey.replace(/text\.json$/,fileId?`originals/${fileId}`:"original");
}
export function getOriginal(source:Source,requested:string|null){
 if(!source.files)return {fileName:source.fileName,fileId:undefined};
 const file=(!requested||requested==="1")?source.files.find(f=>f.role==="primary"):source.files.find(f=>f.id===requested);
 if(!file)throw new AppError("Nie znaleziono pliku w tym przeglądzie.",404);
 return {fileName:file.fileName,fileId:file.id};
}
export function originalUploads(form:FormData,source:Source):{file:File;fileId?:string}[]{
 const uploads:{file:File;fileId?:string}[]=[];
 const expected=new Set(source.files?source.files.map(f=>`original_${f.id}`):["file"]);
 for(const [field,value]of form.entries())if(value instanceof File&&(!expected.has(field)||form.getAll(field).length!==1))throw new AppError("Lista oryginałów nie odpowiada plikom w przeglądzie.");
 if(source.files){
  for(const entry of source.files){const value=form.get(`original_${entry.id}`);if(!(value instanceof File)||!value.size||value.name!==entry.fileName)throw new AppError(`Brak właściwego oryginału pliku ${entry.id}. Dodaj zestaw ponownie.`);uploads.push({file:value,fileId:entry.id});}
 }else{const file=form.get("file");if(file instanceof File&&file.size)uploads.push({file});}
 if(uploads.reduce((n,x)=>n+x.file.size,0)>MAX_UPLOAD_BYTES)throw new AppError("Wspólny przegląd może zawierać do 10 MB plików łącznie. Dla osobnych publikacji limit wynosi 10 MB na plik.",413);
 return uploads;
}
