import { z } from 'zod';

export type JsonSchema = {type?:string;enum?:string[];properties?:Record<string,JsonSchema>;required?:string[];additionalProperties?:false;items?:JsonSchema;anyOf?:JsonSchema[];description?:string};
export type OutputSchema = {name:string;schema:JsonSchema};

// Deliberately limited to the field types used by EMP. Fail closed for a new type.
// Length limits stay in local validation and in the prompt; the wire schema uses
// the common Structured Outputs subset supported by the selected model.
export function structuredSchema(schema:z.ZodTypeAny):JsonSchema {
 if(schema instanceof z.ZodObject){
  const properties=Object.fromEntries(Object.entries(schema.shape).map(([key,value])=>[key,structuredSchema(value as z.ZodTypeAny)]));
  return {type:'object',properties,required:Object.keys(properties),additionalProperties:false};
 }
 if(schema instanceof z.ZodEnum)return {type:'string',enum:schema.options};
 if(schema instanceof z.ZodString)return {type:'string',...(schema.maxLength!==null?{description:`Maximum ${schema.maxLength} characters.`}:{})};
 if(schema instanceof z.ZodBoolean)return {type:'boolean'};
 if(schema instanceof z.ZodArray)return {type:'array',items:structuredSchema(schema.element)};
 if(schema instanceof z.ZodNullable)return {anyOf:[structuredSchema(schema.unwrap()),{type:'null'}]};
 throw new Error('Unsupported EMP structured-output field');
}
