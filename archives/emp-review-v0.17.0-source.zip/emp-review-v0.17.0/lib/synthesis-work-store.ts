import {AppError} from './app-error';
import {advanceSynthesisWork,type SynthesisWork} from './synthesis-work';

/** Owner-scoped checkpoints with a conditional lease: concurrent tabs cannot run the same step. */
export class SynthesisWorkStore {
 constructor(private bucket:R2Bucket,private ownerId:string,private projectId:string){}
 private key(id:string){if(!/^[0-9a-f-]{36}$/.test(id))throw new AppError('Invalid synthesis run.',400);return `projects/${this.ownerId}/${this.projectId}/synthesis-work/${id}.json`;}
 async create(work:SynthesisWork){
  if(work.projectId!==this.projectId)throw new AppError('The synthesis belongs to another project.',409);
  await this.bucket.put(this.key(work.id),JSON.stringify(work),{httpMetadata:{contentType:'application/json'}});
 }
 async read(id:string){
  const object=await this.bucket.get(this.key(id));if(!object)throw new AppError('The saved synthesis run was not found. Start a new synthesis.',404);
  const work=await object.json<SynthesisWork>();
  if(work.id!==id||work.projectId!==this.projectId)throw new AppError('The saved synthesis run could not be verified.',503);
  return {work,etag:object.etag};
 }
 async step(id:string,key:string,fetcher:typeof fetch=fetch){
  const {work,etag}=await this.read(id);if(!work.tasks.length)return work;
  if((work.lockUntil||0)>Date.now())throw new AppError('This synthesis step is still running. Wait up to three minutes, then resume; completed steps are saved.',409);
  const path=this.key(id),locked={...work,lockUntil:Date.now()+180000};
  const lease=await this.bucket.put(path,JSON.stringify(locked),{onlyIf:{etagMatches:etag},httpMetadata:{contentType:'application/json'}});
  if(!lease)throw new AppError('Another tab started this synthesis step. Wait, then resume.',409);
  try{
   const next=await advanceSynthesisWork(work,key,fetcher);
   const saved=await this.bucket.put(path,JSON.stringify(next),{onlyIf:{etagMatches:lease.etag},httpMetadata:{contentType:'application/json'}});
   if(!saved)throw new AppError('The synthesis checkpoint changed. Resume to load its latest saved state.',409);
   return next;
  }catch(error){
   // A failed/uncertain write cannot overwrite a checkpoint saved by another request.
   await this.bucket.put(path,JSON.stringify({...work,lockUntil:undefined}),{onlyIf:{etagMatches:lease.etag},httpMetadata:{contentType:'application/json'}}).catch(()=>null);
   throw error;
  }
 }
}
