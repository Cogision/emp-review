import {AppError} from './app-error';
import {requestOpenAi,responseBody} from './ai-client';
import {synthesisInput,synthesisFingerprint,synthesisInstructions,validateInterpretation,SYNTHESIS_VERSION,type Interpretation,type SynthesisSnapshot} from './project-interpretation';
import type {ProjectData,ProjectFilter} from './projects';

// Per-call bounds, not collection limits. Every eligible record belongs to a batch.
export const SYNTHESIS_CALL_CHARACTERS=200000;
export const SYNTHESIS_BATCH_CLAIMS=100;
type Input=ReturnType<typeof synthesisInput>;
type Coverage={claimKeys:string[];figureKeys:string[]};
export type SynthesisNode=Coverage&{result:Interpretation};
type Task=({kind:'assessments'}&Coverage)|{kind:'combine';nodes:SynthesisNode[]};
export type SynthesisStep=Coverage&{kind:Task['kind'];request:ReturnType<typeof responseBody>;output:string};
export type SynthesisWork={id:string;projectId:string;createdAt:string;filter:ProjectFilter;language:'en'|'pl';model:string;fingerprint:string;input:Input;tasks:Task[];nodes:SynthesisNode[];steps:SynthesisStep[];batchCount:number;completedBatches:number;lockUntil?:number;completedAt?:string};
export type SynthesisProgress={id:string;filter:ProjectFilter;language:'en'|'pl';model:string;fingerprint:string;claimCount:number;figureCount:number;batchCount:number;completedBatches:number;completedSteps:number;phase:'assessments'|'combine'|'complete';locked:boolean};
export type SynthesisReply={run:SynthesisProgress;snapshot?:SynthesisSnapshot};
const size=(value:unknown)=>JSON.stringify(value).length;
function references(result:Interpretation):Coverage{
 const p=[...result.overview,...result.findings,...result.limitations,...result.nextQuestions];
 return {claimKeys:[...new Set(p.flatMap(p=>p.claimKeys))],figureKeys:[...new Set(p.flatMap(p=>p.figureKeys||[]))]};
}
function coverage(nodes:Coverage[]):Coverage{return {claimKeys:[...new Set(nodes.flatMap(n=>n.claimKeys))],figureKeys:[...new Set(nodes.flatMap(n=>n.figureKeys))]};}
function batchInput(input:Input,task:Coverage):Input{
 const claims=new Set(task.claimKeys),figures=new Set(task.figureKeys);
 return {...input,claims:input.claims.filter(c=>claims.has(c.key)),figureObservations:input.figureObservations.filter(f=>figures.has(f.key))};
}
function combineInput(input:Input,nodes:SynthesisNode[]){
 return {version:SYNTHESIS_VERSION,project:input.project,filter:input.filter,counts:input.counts,documents:input.documents,
  collectionScope:{claims:input.claims.length,figureObservations:input.figureObservations.length},
  summaries:nodes.map((node,index)=>({part:index+1,processedClaims:node.claimKeys.length,processedFigureObservations:node.figureKeys.length,interpretation:node.result}))};
}
function batches(input:Input):Task[]{
 if(size({...input,claims:[],figureObservations:[]})>SYNTHESIS_CALL_CHARACTERS-10000)throw new AppError('The project description and source metadata exceed one synthesis request. Shorten the project description or divide the project. No assessments were omitted.',413);
 const tasks:Task[]=[];let current:Coverage={claimKeys:[],figureKeys:[]};
 const add=(kind:'claimKeys'|'figureKeys',key:string)=>{
  const next={claimKeys:[...current.claimKeys],figureKeys:[...current.figureKeys]};next[kind].push(key);
  if(next.claimKeys.length>SYNTHESIS_BATCH_CLAIMS||size(batchInput(input,next))>SYNTHESIS_CALL_CHARACTERS){
   if(current.claimKeys.length||current.figureKeys.length)tasks.push({kind:'assessments',...current});
   current={claimKeys:[],figureKeys:[]};current[kind].push(key);
   if(size(batchInput(input,current))>SYNTHESIS_CALL_CHARACTERS)throw new AppError(`One assessment or figure observation (${key}) exceeds ${SYNTHESIS_CALL_CHARACTERS.toLocaleString('en')} characters including project metadata. Review that record or divide the project. No text was truncated.`,413);
  }else current=next;
 };
 // Keep each report's claims and approved figures adjacent where possible.
 for(const document of input.documents){for(const c of input.claims.filter(c=>c.documentId===document.id))add('claimKeys',c.key);for(const f of input.figureObservations.filter(f=>f.documentId===document.id))add('figureKeys',f.key);}
 if(current.claimKeys.length||current.figureKeys.length)tasks.push({kind:'assessments',...current});
 const assigned=coverage(tasks as Coverage[]);
 if(assigned.claimKeys.length!==input.claims.length||assigned.figureKeys.length!==input.figureObservations.length)throw new AppError('The synthesis batches could not cover all selected records. Refresh the project. No synthesis was started.',409);
 return tasks;
}
function reductionTasks(input:Input,nodes:SynthesisNode[]):Task[]{
 const groups:SynthesisNode[][]=[];let current:SynthesisNode[]=[];
 for(const node of nodes){
  if(size(combineInput(input,[...current,node]))>SYNTHESIS_CALL_CHARACTERS){if(current.length)groups.push(current);current=[];}
  current.push(node);
  if(size(combineInput(input,current))>SYNTHESIS_CALL_CHARACTERS)throw new AppError('An intermediate synthesis is too large to combine. Completed batches remain saved; retry with a model that follows the concise output format.',413);
 }
 if(current.length)groups.push(current);
 if(groups.length>=nodes.length)throw new AppError('The intermediate syntheses are too large to combine within the request limit. Completed batches remain saved.',413);
 return groups.map(nodes=>({kind:'combine',nodes}));
}
export async function createSynthesisWork(data:ProjectData,filter:ProjectFilter,language:'en'|'pl',model:string):Promise<SynthesisWork>{
 const input=synthesisInput(data,filter);
 if(!input.claims.length&&!input.figureObservations.length)throw new AppError('No eligible assessments or selected figure observations in this view. Analyse a report or select reviewed observations.');
 const tasks=batches(input);
 return {id:crypto.randomUUID(),projectId:data.project.id,createdAt:new Date().toISOString(),filter,language,model,fingerprint:await synthesisFingerprint(data,filter),input,tasks,nodes:[],steps:[],batchCount:tasks.length,completedBatches:0};
}
export function synthesisProgress(work:SynthesisWork):SynthesisProgress{return {id:work.id,filter:work.filter,language:work.language,model:work.model,fingerprint:work.fingerprint,claimCount:work.input.claims.length,figureCount:work.input.figureObservations.length,batchCount:work.batchCount,completedBatches:work.completedBatches,completedSteps:work.steps.length,phase:!work.tasks.length?'complete':work.tasks[0].kind,locked:(work.lockUntil||0)>Date.now()};}
export async function advanceSynthesisWork(work:SynthesisWork,key:string,fetcher:typeof fetch=fetch):Promise<SynthesisWork>{
 if(!work.tasks.length)return work;
 const task=work.tasks[0],isBatch=task.kind==='assessments';
 const covered=isBatch?{claimKeys:task.claimKeys,figureKeys:task.figureKeys}:coverage(task.nodes);
 // A combining step may cite only references actually carried by its child summaries.
 const allowed=isBatch?covered:coverage(task.nodes.map(n=>references(n.result)));
 const validationInput=batchInput(work.input,allowed);
 const payload=isBatch?batchInput(work.input,covered):combineInput(work.input,task.nodes);
 const instructions=synthesisInstructions(work.language)+(work.batchCount>1?`\nThis is a ${isBatch?'batch assessment':'summary-combination'} step in a multi-stage synthesis. Collection totals describe the entire frozen input, not this subset. Consider every record in this step. Preserve disagreements, distinct claim scopes, uncertainty, QC flags, selected/adjudicated assessment basis, and figure limitations. Do not imply that a summary is a new study. ${isBatch?'This batch is only part of the collection; do not infer collection-wide patterns from it.':'Combine all child summaries, comparing evidence boundaries across them; preserve material differences and gaps. Cite only exact claim/figure keys present in the child summaries. A paragraph need not cite every record processed.'} Keep the complete JSON output below 20,000 characters. Every intermediate result and original assessment will remain in the audit snapshot; the final narrative is a selective qualitative summary, not a restatement of every claim.`:'');
 const text=JSON.stringify(payload),maxOutputTokens=9000;
 if(text.length>SYNTHESIS_CALL_CHARACTERS)throw new AppError('This synthesis step exceeds the per-request data limit. Completed steps remain saved.',413);
 const raw=await requestOpenAi({key,model:work.model,instructions,input:text,maxOutputTokens},fetcher);
 const result=validateInterpretation(raw,validationInput);
 if(work.batchCount>1&&raw.length>20000)throw new AppError('The AI returned an intermediate synthesis that is too long. Retry this step; completed steps remain saved.',502);
 const steps=[...work.steps,{kind:task.kind,...covered,request:responseBody(work.model,instructions,text,maxOutputTokens),output:raw}];
 let tasks=work.tasks.slice(1),nodes=[...work.nodes,{...covered,result}];
 if(!tasks.length&&nodes.length>1){tasks=reductionTasks(work.input,nodes);nodes=[];}
 const next={...work,tasks,nodes,steps,completedBatches:work.completedBatches+(isBatch?1:0),lockUntil:undefined,...(!tasks.length?{completedAt:new Date().toISOString()}:{})};
 if(!tasks.length){const all=coverage(nodes);if(all.claimKeys.length!==work.input.claims.length||all.figureKeys.length!==work.input.figureObservations.length)throw new AppError('The synthesis did not process every selected record. No final synthesis was saved.',502);}
 return next;
}
export function completedSynthesis(work:SynthesisWork):SynthesisSnapshot{
 if(work.tasks.length||work.nodes.length!==1||!work.steps.length)throw new AppError('The synthesis is not complete. Resume its remaining steps.',409);
 const last=work.steps[work.steps.length-1];
 return {version:SYNTHESIS_VERSION,id:work.id,projectId:work.projectId,createdAt:work.completedAt||work.createdAt,filter:work.filter,language:work.language,model:work.model,fingerprint:work.fingerprint,input:work.input,result:work.nodes[0].result,audit:{request:last.request,output:last.output,steps:work.steps}};
}
