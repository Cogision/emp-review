import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Vinext also probes ordinary multipart POSTs as progressive form actions
  // before routing them to /api/documents. Keep room for the 10 MB original,
  // extracted text and multipart framing. The route enforces its own limits.
  experimental: {
    serverActions: { bodySizeLimit: "12mb" },
  },
};

export default nextConfig;
