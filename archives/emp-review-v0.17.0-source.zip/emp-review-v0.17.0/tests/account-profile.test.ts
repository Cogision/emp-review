import assert from 'node:assert/strict';
import test from 'node:test';
import {ProfileStore} from '../lib/profile-store';
import {roundFixture} from './helpers/round-fixture';
import {chatGPTSignInPath,chatGPTSignOutPath,loginPath,loginReturnPath,safeReturnPath} from '../lib/auth-paths';

const identity={displayName:'Alice',email:'alice@example.invalid'};
const input={displayName:'Alice Reviewer',affiliation:'Example University',revision:0};
const status=(expected:number)=>(error:unknown)=>{assert.equal((error as {status:number}).status,expected);return true;};

test('profiles persist across store instances and stay scoped to authenticated identity',async()=>{
 const f=roundFixture();
 const alice=new ProfileStore(f.env.DB,'alice',identity), bob=new ProfileStore(f.env.DB,'bob',{displayName:'Bob',email:'bob@example.invalid'});
 const initial=await alice.get();assert.equal(initial.revision,0);assert.equal(initial.displayName,'Alice');
 const saved=await alice.save({...input,displayName:' Alice Reviewer '});assert.equal(saved.displayName,'Alice Reviewer');assert.equal(saved.revision,1);
 assert.deepEqual(await new ProfileStore(f.env.DB,'alice',identity).get(),saved);
 assert.equal((await bob.get()).displayName,'Bob');assert.equal((await bob.get()).revision,0);
 const newEmail=await new ProfileStore(f.env.DB,'alice',{...identity,email:'current@example.invalid'}).get();
 assert.equal(newEmail.email,'current@example.invalid');assert.equal(newEmail.affiliation,input.affiliation);
 f.sql.close();
});

test('profile updates reject lost writes, missing records and forged identity fields',async()=>{
 const f=roundFixture(),profiles=new ProfileStore(f.env.DB,'alice',identity);
 await assert.rejects(()=>profiles.save({...input,revision:3}),status(409));
 assert.equal((await profiles.get()).revision,0);
 await profiles.save(input);
 await assert.rejects(()=>profiles.save({...input,displayName:'Stale create'}),status(409));
 await profiles.save({...input,revision:1,displayName:'New name'});
 await assert.rejects(()=>profiles.save({...input,revision:1,displayName:'Stale update'}),status(409));
 for(const extra of [{userId:'bob'},{email:'forged@example.invalid'},{role:'admin'},{apiKey:'secret'}])await assert.rejects(()=>profiles.save({...input,revision:2,...extra}),status(400));
 assert.equal((await profiles.get()).displayName,'New name');
 assert.throws(()=>new ProfileStore(f.env.DB,'',identity),status(401));
 f.sql.close();
});

test('profile validation rejects blank, oversized and multiline fields; affiliation can be cleared',async()=>{
 const f=roundFixture(),profiles=new ProfileStore(f.env.DB,'alice',identity);
 for(const extra of [{displayName:'  '},{displayName:'x'.repeat(121)},{affiliation:'x'.repeat(201)},{displayName:'Alice\nBob'},{affiliation:'Team\u0000A'},{revision:-1},{revision:1.5}])await assert.rejects(()=>profiles.save({...input,...extra}),status(400));
 await profiles.save(input);const saved=await profiles.save({...input,revision:1,affiliation:''});assert.equal(saved.affiliation,'');
 f.sql.close();
});

test('changing profile does not rewrite existing round membership or immutable submissions',async()=>{
 const f=roundFixture(),round=await f.ready();
 await f.as('alice').action(round.round.id,{action:'submit',assessmentRevision:0,draft:f.assessment('A complete descriptive summary.')});
 const before=f.sql.prepare('SELECT name,draft_key FROM round_members WHERE round_id=? AND user_id=?').get(round.round.id,'alice');
 const snapshots=new Map(f.objects);
 await new ProfileStore(f.env.DB,'alice',identity).save(input);
 assert.deepEqual(f.sql.prepare('SELECT name,draft_key FROM round_members WHERE round_id=? AND user_id=?').get(round.round.id,'alice'),before);
 assert.deepEqual(f.objects,snapshots);
 f.sql.close();
});

test('authentication destinations preserve rounds and reject external or looping returns',()=>{
 const destination='/?round=round_123';
 assert.equal(new URL(loginPath(destination),'https://site.invalid').searchParams.get('returnTo'),destination);
 assert.equal(new URL(chatGPTSignInPath('/join'),'https://site.invalid').searchParams.get('return_to'),'/join');
 assert.equal(new URL(chatGPTSignOutPath(),'https://site.invalid').searchParams.get('return_to'),'/login');
 for(const bad of ['https://evil.invalid','//evil.invalid','/\\evil.invalid','javascript:alert(1)','/signin-with-chatgpt','/signout-with-chatgpt/','/%63allback','/\n/evil.invalid'])assert.equal(safeReturnPath(bad),'/',bad);
 for(const bad of ['/login','/login?returnTo=/login','/login/','/%6cogin'])assert.equal(loginReturnPath(bad),'/',bad);
 assert.equal(loginReturnPath('/join#invite=abc'),'/join#invite=abc');
});
