import {test} from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {roundFixture} from './helpers/round-fixture';
import {fullDraft} from './helpers/full-round-fixture';
import {blankV05Draft,type RoundDetail} from '../lib/review-rounds';
import {FigureStore} from '../lib/figure-store';
import {ProjectFigureStore} from '../lib/project-figure-store';
import {selectedFigureObservations} from '../lib/project-figures';
import type {FigureRun,FigureReport} from '../lib/figures';
import {demoAnalysis,demoSource} from '../lib/demo';
import {emptyReview} from '../lib/emp';
import {synthesise,type ProjectData} from '../lib/projects';
import {synthesisInput,synthesisFingerprint,validateInterpretation,generateInterpretation} from '../lib/project-interpretation';
import {createProjectPackage} from '../lib/project-export';
import {translate} from '../lib/i18n';

async function revealed(){const f=roundFixture(),round=await f.ready();for(const user of ['alice','bob'])await f.as(user).action(round.round.id,{action:'submit',assessmentRevision:0,draft:fullDraft()});return {f,d:await f.owner.action(round.round.id,{action:'reveal',revision:round.round.revision}) as RoundDetail};}
const incomplete=()=>{const d=fullDraft();d.fullFields={C01:blankV05Draft()};d.unanswered={C01:['primary']};return d;};
const saveBody=(d:RoundDetail)=>({action:'saveAdjudicationDraft',revision:d.round.revision,draftRevision:d.adjudicationDraft?.revision??0,draft:incomplete(),rationale:'PRIVATE_DRAFT_NOTE',links:[],claimRationales:{C01:'Unfinished private reasoning'}});
test('incomplete adjudication survives reload without exposing private content or becoming final',async()=>{
 const {f,d}=await revealed();const saved=await f.owner.action(d.round.id,saveBody(d)) as RoundDetail;
 const reloaded=await f.owner.detail(d.round.id);assert.deepEqual(reloaded.adjudicationDraft,saved.adjudicationDraft);assert.equal(reloaded.adjudicationDraft!.revision,1);
 assert.equal(reloaded.adjudicationDraft!.value!.draft.claims[0].v05,undefined);assert.deepEqual(reloaded.adjudicationDraft!.value!.draft.unanswered,{C01:['primary']});assert.equal(reloaded.adjudications!.length,0);
 assert.doesNotMatch(JSON.stringify(await f.as('alice').detail(d.round.id)),/PRIVATE_DRAFT_NOTE|Unfinished private reasoning/);
 assert.doesNotMatch(JSON.stringify(await f.owner.export(d.round.id)),/PRIVATE_DRAFT_NOTE|Unfinished private reasoning/);
 await assert.rejects(f.as('alice').action(d.round.id,saveBody(saved)),/Coordinator/);
});
test('stale saves, discards and finalization cannot replace or resurrect a newer draft',async()=>{
 const {f,d}=await revealed();const saved=await f.owner.action(d.round.id,saveBody(d)) as RoundDetail;
 for(const action of ['saveAdjudicationDraft','discardAdjudicationDraft','adjudicate'])await assert.rejects(f.owner.action(d.round.id,{...saveBody(saved),action,draftRevision:0}),/changed/);
 const cleared=await f.owner.action(d.round.id,{action:'discardAdjudicationDraft',revision:saved.round.revision,draftRevision:1}) as RoundDetail;
 assert.deepEqual(cleared.adjudicationDraft,{revision:2,value:null});await assert.rejects(f.owner.action(d.round.id,{...saveBody(cleared),draftRevision:1}),/changed/);
 assert.equal((await f.owner.detail(d.round.id)).adjudicationDraft!.value,null);
});
test('failed finalization retains partial work; successful finalization preserves original assessments and clears the draft atomically',async()=>{
 const {f,d}=await revealed(),saved=await f.owner.action(d.round.id,saveBody(d)) as RoundDetail;
 await assert.rejects(f.owner.action(d.round.id,{...saveBody(saved),action:'adjudicate'}));assert.deepEqual((await f.owner.detail(d.round.id)).adjudicationDraft,saved.adjudicationDraft);
 const final=await f.owner.action(d.round.id,{...saveBody(saved),action:'adjudicate',draft:fullDraft(),rationale:'Both assessments checked against the original source.',claimRationales:{C01:'Checked scope and supporting evidence.'},links:d.submissions!.map(s=>({claimId:'C01',submissionId:s.id,originalClaimId:'C01'}))}) as RoundDetail;
 assert.deepEqual(final.submissions,d.submissions);assert.equal(final.adjudications!.length,1);assert.equal(final.adjudications![0].finalizedFromDraftRevision,1);assert.deepEqual(final.adjudicationDraft,{revision:2,value:null});
});

const png=new Uint8Array(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZV8AAAAASUVORK5CYII=','base64'));
const report:FigureReport={kind:'conceptual',readability:'clear',summary:'Synthetic figure.',observations:[{panel:'A',statement:'Selected connection shown in panel A.',relation:'consistent',textCitation:{blockId:'b4',quote:'Our findings provide evidence for prognosis during treatment A.'}},{panel:'B',statement:'UNSELECTED_PANEL_B',relation:'not_in_text',textCitation:null}],limitations:['No numerical results are shown.'],questions:[]};
async function visualFixture(){
 const f=roundFixture(),documentId=crypto.randomUUID(),projectId=crypto.randomUUID();f.sql.prepare('UPDATE documents SET id=?').run(documentId);f.sql.prepare("INSERT INTO projects (id,owner,title,created_at,updated_at) VALUES (?,'owner','Synthetic project','now','now')").run(projectId);f.sql.prepare("INSERT INTO project_documents (project_id,document_id,added_at) VALUES (?,?,'now')").run(projectId,documentId);
 const figures=new FigureStore(f.env,'owner'),selections=new ProjectFigureStore(f.env,'owner'),figure=await figures.upload(documentId,{id:crypto.randomUUID(),label:'Figure 1',caption:'Synthetic caption',locator:'p. 2',sourceFileId:''},'figure.png','image/png',png);
 const make=():FigureRun=>({id:crypto.randomUUID(),figureId:figure.id,sourceHash:'hash',imageHash:figure.imageHash,model:'fixture-model',language:'en',createdAt:new Date().toISOString(),appVersion:'0.11.0',promptVersion:'fixture',report,review:{revision:0,status:'draft',sourceChecked:false,comment:''}});
 const run=await figures.saveRun(documentId,figure.id,make());
 const approve=()=>figures.review(documentId,figure.id,run.id,{revision:0,status:'checked',sourceChecked:true,comment:'Manually checked.'});
 const revision=()=>Number(f.sql.prepare('SELECT revision FROM projects WHERE id=?').get(projectId)!.revision);
 const choose=(overrides:Record<string,unknown>={})=>selections.select(projectId,{revision:revision(),documentId,figureId:figure.id,runId:run.id,reviewRevision:1,indices:[0],note:'Relevant to the project question.',...overrides});
 const data=async():Promise<ProjectData>=>({project:{id:projectId,title:'Synthetic project',question:'What is supported?',criteria:'Synthetic only',language:'en',revision:revision(),created_at:'now',updated_at:'now'},documents:[{id:documentId,title:'Synthetic report',stage:'B',coverage:'Full text',sourceHash:String(f.sql.prepare('SELECT source_hash FROM documents WHERE id=?').get(documentId)!.source_hash),revision:0,createdAt:'now',updatedAt:'now',studyGroup:'',analysis:structuredClone(demoAnalysis),review:structuredClone(emptyReview),source:demoSource}],generatedAt:'now',figureSelections:await selections.list(projectId)});
 return {...f,documentId,projectId,figures,selections,figure,run,make,approve,choose,revision,data};
}
test('figure selection requires approval, explicit observations and a rationale; approved unselected runs are absent',async()=>{
 const f=await visualFixture();await assert.rejects(f.choose(),/changed/);assert.equal((await f.selections.options(f.projectId,f.documentId)).items.length,0);
 await f.approve();assert.equal(selectedFigureObservations(await f.data()).length,0);assert.equal((await f.selections.options(f.projectId,f.documentId)).items.length,1);
 for(const v of [{note:''},{indices:[]},{indices:[0,0]},{indices:[2]}])await assert.rejects(f.choose(v));
 await f.choose();const observations=selectedFigureObservations(await f.data());assert.equal(observations.length,1);assert.equal(observations[0].observationIndex,0);assert.equal(observations[0].review.revision,1);assert.equal(observations[0].reviewerId,'owner');assert.ok(observations[0].reviewEventId);
});
test('selected observations change synthesis input without inflating codes, reports, claims or study counts',async()=>{
 const f=await visualFixture();await f.approve();const before=await f.data(),fingerprint=await synthesisFingerprint(before,'all');await f.choose();const after=await f.data();
 assert.deepEqual(synthesise(after).counts,synthesise(before).counts);assert.deepEqual(synthesise(after).matrix,synthesise(before).matrix);assert.notEqual(await synthesisFingerprint(after,'all'),fingerprint);
 assert.doesNotMatch(JSON.stringify(synthesisInput(after,'all')),/UNSELECTED_PANEL_B/);const pinned=await synthesisFingerprint(after,'all');await f.figures.saveRun(f.documentId,f.figure.id,f.make());assert.equal(await synthesisFingerprint(await f.data(),'all'),pinned);
});
test('review changes, source changes and archives invalidate selections without silently promoting another run',async()=>{
 const f=await visualFixture();await f.approve();await f.choose({note:'REVOKED_SELECTION_NOTE'});const hash=await synthesisFingerprint(await f.data(),'all');
 await f.figures.review(f.documentId,f.figure.id,f.run.id,{revision:1,status:'checked',sourceChecked:true,comment:'Changed assessment.'});let data=await f.data();assert.equal(data.figureSelections![0].eligible,false);assert.equal(selectedFigureObservations(data).length,0);assert.notEqual(await synthesisFingerprint(data,'all'),hash);assert.doesNotMatch(JSON.stringify(synthesisInput(data,'all')),/REVOKED_SELECTION_NOTE/);
 await assert.rejects(f.choose(),/changed/);await f.choose({reviewRevision:2});assert.equal(selectedFigureObservations(await f.data()).length,1);
 await f.figures.archive(f.documentId,f.figure.id,0,true);assert.match((await f.data()).figureSelections![0].reason,/archived/);await f.figures.archive(f.documentId,f.figure.id,1,false);assert.equal(selectedFigureObservations(await f.data()).length,0);
 await f.choose({reviewRevision:2});f.sql.prepare("UPDATE documents SET source_hash='replacement' WHERE id=?").run(f.documentId);assert.match((await f.data()).figureSelections![0].reason,/Source changed/);
});
test('project figure selections enforce ownership, report/run identity and stale project revisions',async()=>{
 const f=await visualFixture();await f.approve();await assert.rejects(new ProjectFigureStore(f.env,'intruder').options(f.projectId,f.documentId),/not found/);
 await assert.rejects(f.choose({documentId:crypto.randomUUID()}),/not found/);await assert.rejects(f.choose({runId:crypto.randomUUID()}),/not found/);
 await f.choose();const selected=await f.selections.list(f.projectId);await assert.rejects(f.choose({revision:0,runId:null}),/changed/);assert.deepEqual(await f.selections.list(f.projectId),selected);
 await f.choose({runId:null});assert.deepEqual(await f.selections.list(f.projectId),[]);assert.equal(f.sql.prepare('SELECT count(*) AS n FROM project_selection_events').get()!.n,2);
});
function visualOutput(key:string){return {overview:[{text:'The selected conceptual connection provides context only.',claimKeys:[],figureKeys:[key]}],findings:[],limitations:[{text:'No numerical results are shown.',claimKeys:[],figureKeys:[key]}],nextQuestions:[]};}
test('figure-only synthesis validates exact selected keys and rejects invented, repeated or misplaced references',async()=>{
 const f=await visualFixture();await f.approve();await f.choose();const input=synthesisInput(await f.data(),'accepted'),key=input.figureObservations[0].key;assert.equal(input.claims.length,0);
 assert.doesNotThrow(()=>validateInterpretation(JSON.stringify(visualOutput(key)),input));for(const k of ['invented',key.replace(/:0$/,':1')])assert.throws(()=>validateInterpretation(JSON.stringify(visualOutput(k)),input),/unknown/);
 const repeated=visualOutput(key);repeated.overview[0].figureKeys.push(key);assert.throws(()=>validateInterpretation(JSON.stringify(repeated),input),/repeated/);
 const misplaced=visualOutput(key) as any;misplaced.overview[0].claimKeys=[key];misplaced.overview[0].figureKeys=[];assert.throws(()=>validateInterpretation(JSON.stringify(misplaced),input),/unknown/);
 const empty=visualOutput(key);empty.overview[0].figureKeys=[];assert.throws(()=>validateInterpretation(JSON.stringify(empty),input),/unknown/);
});
test('exports retain figure provenance and omit revoked evidence and outdated synthesis from current reports',async()=>{
 const f=await visualFixture();await f.approve();await f.choose();const data=await f.data(),key=synthesisInput(data,'all').figureObservations[0].key;
 const snapshot=await generateInterpretation(data,'all','en','fixture-key','fixture-model',async()=>Response.json({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(visualOutput(key))}]}]}));
 assert.doesNotMatch(JSON.stringify(snapshot),/fixture-key|UNSELECTED_PANEL_B/);
 const zip=await JSZip.loadAsync(await (await createProjectPackage(data,'all','en',snapshot)).arrayBuffer()),json=JSON.parse(await zip.file('project.json')!.async('string'));
 assert.equal(json.interpretation.includedInReport,true);assert.equal(json.selectedFigureObservations.length,1);assert.match(await zip.file('figure-observations.csv')!.async('string'),/Manually checked/);
 assert.match(await zip.file('report.html')!.async('string'),new RegExp(f.run.id));const docx=await JSZip.loadAsync(await zip.file('report.docx')!.async('uint8array'));assert.match(await docx.file('word/document.xml')!.async('string'),new RegExp(f.run.id));
 await f.figures.review(f.documentId,f.figure.id,f.run.id,{revision:1,status:'excluded',sourceChecked:true,comment:'Approval revoked.'});const current=await f.data(),freshZip=await JSZip.loadAsync(await (await createProjectPackage(current,'all','en',snapshot)).arrayBuffer());
 const updated=JSON.parse(await freshZip.file('project.json')!.async('string'));assert.equal(updated.interpretation.includedInReport,false);assert.equal(updated.selectedFigureObservations.length,0);assert.equal(updated.figureSelections[0].eligible,false);
 assert.doesNotMatch(await freshZip.file('report.html')!.async('string'),/The selected conceptual connection|Selected connection shown/);assert.ok(freshZip.file('synthesis-snapshot.json'));assert.doesNotMatch(await freshZip.file('figure-observations.csv')!.async('string'),/Selected connection shown/);
});
test('stale module errors offer save/reload/export recovery in both languages without assuming missing credits',()=>{
 const error='Failed to fetch dynamically imported module: https://example.invalid/assets/form-export-old.js';
 assert.match(translate(error,'en'),/Save current edits, reload/);assert.match(translate(error,'pl'),/Zapisz bieżące zmiany, odśwież/);assert.doesNotMatch(translate(error,'en'),/credit|example.invalid/);
 assert.match(translate('Importing a module script failed','en'),/without running AI analysis again/);
});
