import { test } from "node:test";
import assert from "node:assert/strict";
import { parseAiSettings } from "../lib/ai-settings";
import { requestOpenAi, providerError, responseBody } from "../lib/ai-client";
import { analyze } from "../lib/analyzer";
import { demoAnalysis, demoSource } from "../lib/demo";

const settings={key:"test-key",model:"gpt-4.1",instructions:"Return JSON",input:"source",maxOutputTokens:12000};
const fetchResponse=(response:Response)=>(async()=>response) as typeof fetch;
const completed=(text:string)=>Response.json({status:"completed",output:[{content:[{type:"output_text",text}]}]});

test("surrounding whitespace is removed and valid fine-tuned IDs reach the provider unchanged",()=>{
  const id="ft:gpt-4.1-nano-2025-04-14:openai::BTz2REMH";
  assert.deepEqual(parseAiSettings({key:"  test-key\n",model:` ${id} `}),{key:"test-key",model:id});
});
test("empty model uses server default; explicit model always takes precedence",()=>{
  assert.equal(parseAiSettings({model:"  "},{key:"server-key",model:"configured-model"}).model,"configured-model");
  assert.equal(parseAiSettings({model:"chosen-model"},{key:"server-key",model:"configured-model"}).model,"chosen-model");
  assert.equal(parseAiSettings({key:"key",model:""}).model,"gpt-4.1");
});
test("model and key input errors are distinct and do not echo secrets",()=>{
  assert.throws(()=>parseAiSettings({key:"key",model:"GPT 4.1"}),/identyfikator modelu API/);
  assert.throws(()=>parseAiSettings({key:"key",model:"sk-sensitive-secret"}),e=>e instanceof Error&&e.message.includes("W polu Model")&&!e.message.includes("sk-sensitive"));
  assert.throws(()=>parseAiSettings({key:"some key",model:"gpt-4.1"}),/Klucz API zawiera/);
  assert.throws(()=>parseAiSettings({model:"gpt-4.1"}),/podaj klucz/);
});
test("JSON requirement is explicit even if paper never mentions JSON",()=>{
  const body=responseBody("chosen-model","rules","a paper without the keyword",12000);
  assert.match(body.input,/JSON/);assert.equal(body.store,false);assert.equal(body.model,"chosen-model");
  assert.deepEqual(body.text,{format:{type:"json_object"}});
});
test("provider errors distinguish billing, rate, access, format and context failures",()=>{
  assert.match(providerError(429,{error:{code:"insufficient_quota"}},null).message,/rozliczeniowego/);
  assert.match(providerError(429,{error:{code:"credit_balance_exhausted"}},null).message,/rozliczeniowego/);
  assert.match(providerError(429,{error:{code:"specific_billing_code",type:"insufficient_quota"}},null).message,/rozliczeniowego/);
  assert.match(providerError(429,{error:{code:"rate_limit_exceeded"}},null).message,/Odczekaj/);
  assert.match(providerError(404,{error:{code:"model_not_found"}},null).message,/nie istnieje lub/);
  assert.match(providerError(403,{},null).message,/uprawnienia/);
  assert.match(providerError(400,{error:{param:"text.format",code:"unsupported_value"}},null).message,/format JSON/);
  assert.match(providerError(400,{error:{code:"context_length_exceeded"}},null).message,/zakres obsługiwany/);
});
test("diagnostics never contain raw provider errors, credentials or document text",()=>{
  const err=providerError(401,{error:{code:"sk-leaked-key",param:"sk-leaked-key",message:"Bad key: sk-leaked-key. SECRET SOURCE TEXT"}},"req_safe123");
  assert.doesNotMatch(JSON.stringify(err)+err.message,/sk-leaked|SECRET SOURCE/);
  assert.match(err.message,/req_safe123/);
});
test("upstream plain text failure preserves HTTP status without a JSON parse error",async()=>{
  await assert.rejects(requestOpenAi(settings,fetchResponse(new Response("Bad Gateway",{status:502}))),/HTTP 502/);
});
test("upstream rejected request is made once, with no silent model switch",async()=>{
  let calls=0;
  await assert.rejects(requestOpenAi(settings,(async(_url,init)=>{
    calls++;assert.equal(JSON.parse(String(init?.body)).model,settings.model);
    return Response.json({error:{code:"model_not_found"}},{status:404,headers:{"x-request-id":"req_test"}});
  }) as typeof fetch),/model_not_found/);
  assert.equal(calls,1);
});
test("complete output succeeds; incomplete, refusal and malformed outputs cannot be mistaken for success",async()=>{
  assert.equal(await requestOpenAi(settings,fetchResponse(completed('{"ok":true}'))),'{"ok":true}');
  await assert.rejects(requestOpenAi(settings,fetchResponse(Response.json({status:"incomplete",incomplete_details:{reason:"max_output_tokens"}}))),/limit długości/);
  await assert.rejects(requestOpenAi(settings,fetchResponse(Response.json({status:"completed",output:[{content:[{type:"refusal"}]}]}))),/odmówił/);
  await assert.rejects(requestOpenAi(settings,fetchResponse(new Response("not JSON"))),/ukończonej/);
});
test("successful provider result passes real analysis schema and preserves provenance",async(t)=>{
  t.mock.method(globalThis,"fetch",async()=>completed(JSON.stringify(demoAnalysis)));
  const result=await analyze(demoSource,"B","synthetic test","test-key","chosen-model");
  assert.equal(result.claims.length,demoAnalysis.claims.length);assert.equal(result.model,"chosen-model");
  assert.equal(result.promptVersion,"emp-assisted-core-0.5.2");
});
test("schema-invalid JSON never becomes a saved analysis",async(t)=>{
  t.mock.method(globalThis,"fetch",async()=>completed('{"ok":true}'));
  await assert.rejects(analyze(demoSource,"B","test","key","gpt-4.1"),/nie spełnia schematu/);
});
