import {test} from 'node:test';
import assert from 'node:assert/strict';
import {demoAnalysis,demoSource} from '../lib/demo';
import {v05Example} from '../lib/v05';
import {syncV05,claimSchema,quoteExists,deriveBridge,type Claim} from '../lib/emp';
import {assessmentSchema,assessmentOutputSchema,validateAssessment} from '../lib/assessment-validation';
import {assess,assessNext,completedAnalysis,type AutomaticState} from '../lib/automatic';
import type {JsonSchema} from '../lib/structured-schema';
const full=():Claim=>syncV05({...structuredClone(demoAnalysis.claims[0]),v05:{...structuredClone(v05Example),declaredUse:'U5',readoutRelation:'R0',scopeCodes:{readout:'E',population:'E',setting:'E',treatment:'E',comparator:'NA',outcome:'E',horizon:'E',inferenceUnit:'E',decisionRule:'NA'},evidenceTiming:'Prospective',observationMode:'Directly observed',evidenceLocation:'Report main text',condition:'NC0',coupling:'NA',conditionMatches:'Structural NA',hedging:'No',adequacyRationale:'Prospective test; limited calibration.'}});
function fixture(){const c=full();return {c,focal:{id:c.id,primary:c.primary,statement:c.statement,citation:c.citation},payload:assessmentSchema.parse(c),inventory:{reportType:'CB' as const,typeRationale:'Clinical prediction',bibliography:'Synthetic test',summary:'Test',limitations:[],complete:true,claims:[{id:c.id,primary:c.primary,statement:c.statement,citation:c.citation}]}};}
const reply=(v:unknown)=>Response.json({status:'completed',output:[{content:[{type:'output_text',text:typeof v==='string'?v:JSON.stringify(v)}]}]});

test('structured response requires normative fields and exact candidate ID without duplicate identity/codes',()=>{
 const {focal}=fixture(),s=assessmentOutputSchema(focal).schema;
 const walk=(s:JsonSchema)=>{if(s.type==='object'){assert.equal(s.additionalProperties,false);assert.deepEqual(s.required,Object.keys(s.properties!));Object.values(s.properties!).forEach(walk);}if(s.items)walk(s.items);s.anyOf?.forEach(walk);};walk(s);
 assert.deepEqual(s.properties!.id.enum,['C01']);assert.equal(s.properties!.statement,undefined);assert.equal(s.properties!.citation,undefined);assert.equal(s.properties!.condition,undefined);
 assert.deepEqual(s.properties!.v05.properties!.condition.enum,['NC0','NC1','NC2','NC3','NCU']);
});
test('new response restores frozen identity and derives compatible codes before full-schema validation',()=>{
 const {payload,focal}=fixture();payload.v05.condition='NC3';payload.v05.coupling='BG';payload.v05.commitment='Mixed';payload.v05.polarity='Mixed';
 const r=validateAssessment(JSON.stringify(payload),demoSource,focal,'CB');assert.deepEqual(r.issues,[]);assert.ok(claimSchema.safeParse(r.claim).success);
 assert.equal(r.claim!.statement,focal.statement);assert.deepEqual(r.claim!.citation,focal.citation);assert.equal(r.claim!.condition,'NC1');assert.equal(r.claim!.coupling,'Not coupled');assert.equal(r.claim!.commitment,'Unclear');assert.equal(r.claim!.v05!.polarity,'Mixed');
});
test('format-only enum recovery is audited; missing or invented scientific categories stay invalid',()=>{
 const {payload,focal}=fixture();const r=validateAssessment(JSON.stringify({...payload,adequacy:' not assessed ',v05:{...payload.v05,confidence:'low'}}),demoSource,focal,'CB');
 assert.equal(r.claim!.adequacy,'Not assessed');assert.equal(r.corrections.length,2);
 for(const v of [undefined,null,'invented category','Structural NA']){const bad=validateAssessment(JSON.stringify({...payload,adequacy:v}),demoSource,focal,'CB');assert.equal(bad.claim,undefined);assert.match(bad.issues.join(' '),/adequacy/);}
});
test('historical compatibility fields cannot invalidate correct normative fields',()=>{
 const {c,focal}=fixture(),r=validateAssessment(JSON.stringify({...c,condition:'NC3',coupling:'BG',polarity:'Mixed',scopeMatch:'E'}),demoSource,focal,'CB');assert.deepEqual(r.issues,[]);assert.equal(r.claim!.condition,'NC0');
});
test('echoed changes to claim identity and changed numbers in evidence are never accepted',()=>{
 const {c,focal,payload}=fixture();for(const edited of [{...c,id:'C02'},{...c,primary:false},{...c,statement:'A different conclusion'},{...c,citation:{...c.citation,quote:'An invented conclusion'}}])assert.equal(validateAssessment(JSON.stringify(edited),demoSource,focal,'CB').claim,undefined);
 const r=validateAssessment(JSON.stringify({...payload,evidence:[{...c.citation,quote:'AUC 0.999'}]}),demoSource,focal,'CB');assert.equal(r.claim,undefined);assert.match(r.issues[0],/evidence.0/);
});
test('source whitespace recovery keeps exact substring and raw model output separately',()=>{
 const {payload,focal}=fixture();const c=payload.evidence[0],source=structuredClone(demoSource);const block=source.blocks.find(b=>b.id===c.blockId)!;block.text=block.text.replace(c.quote,c.quote.replace(/ /g,'\n  '));
 const r=validateAssessment(JSON.stringify(payload),source,focal,'CB');assert.ok(r.claim);assert.ok(quoteExists(r.claim!.evidence[0],source));assert.ok(r.corrections.some(c=>c.path==='evidence.0'));assert.equal(payload.evidence[0].quote,c.quote);
});
test('a valid response uses one call; the exact strict request is retained without its key',async(t)=>{
 const {payload,inventory}=fixture();let calls=0,sent:unknown;t.mock.method(globalThis,'fetch',async(_url:unknown,init?:RequestInit)=>{calls++;sent=JSON.parse(String(init?.body));return reply(payload);});
 const r=await assess(demoSource,'B','test','private-secret-key','gpt-4.1',inventory,0);
 assert.equal(calls,1);assert.deepEqual(sent,r.request);assert.equal(r.request.text.format.type,'json_schema');assert.equal(r.attempts.length,1);assert.deepEqual(r.quality,[]);assert.doesNotMatch(JSON.stringify(r),/private-secret-key/);
});
test('one targeted repair identifies a missing field and keeps both exact attempts',async(t)=>{
 const {payload,inventory}=fixture(),bad={...payload,v05:{...payload.v05,scopeCodes:{...payload.v05.scopeCodes,horizon:undefined}}};let calls=0;const recorded:string[][]=[];
 t.mock.method(globalThis,'fetch',async()=>reply(calls++===0?bad:payload));
 const r=await assess(demoSource,'B','test','key','gpt-4.1',inventory,0,'pl',async(_,issues)=>{recorded.push(issues);});
 assert.equal(calls,2);assert.match(recorded[0][0],/v05.scopeCodes.horizon/);assert.deepEqual(recorded[1],[]);assert.equal(r.attempts.length,2);assert.match(r.request.input,/validationIssues/);assert.equal(r.claim.id,inventory.claims[0].id);
});
test('persistent schema failure names claim and field, is bounded, and never echoes a bad value',async(t)=>{
 const {payload,inventory}=fixture();let calls=0,recorded=0;t.mock.method(globalThis,'fetch',async()=>{calls++;return reply({...payload,v05:{...payload.v05,confidence:'sk-secret SOURCE TEXT'}});});
 await assert.rejects(assess(demoSource,'B','test','key','gpt-4.1',inventory,0,'pl',async()=>{recorded++;}),e=>e instanceof Error&&/C01.*v05.confidence/.test(e.message)&&!/sk-secret|SOURCE TEXT/.test(e.message));assert.equal(calls,2);assert.equal(recorded,2);
});
test('logical uncertainty is retained as QC and cannot become a supported conclusion',()=>{
 const {payload,focal}=fixture();payload.evidence=[];const r=validateAssessment(JSON.stringify(payload),demoSource,focal,'CB');assert.ok(r.claim);assert.ok(r.quality.length);assert.equal(deriveBridge(r.claim!),'BU');
});
test('explicit unsupported schema on same model falls back to JSON mode with exact provenance',async(t)=>{
 const {payload,inventory}=fixture();let calls=0;t.mock.method(globalThis,'fetch',async()=>++calls===1?Response.json({error:{code:'unsupported_value',param:'text.format',message:"json_schema is not supported with this model."}},{status:400}):reply(payload));
 const r=await assess(demoSource,'B','test','key','legacy-model',inventory,0);assert.equal(calls,2);assert.equal(r.request.model,'legacy-model');assert.equal(r.request.text.format.type,'json_object');assert.equal(r.formatFallback!.request.text.format.type,'json_schema');
});
test('schema and access errors do not trigger a bypass or repair loop',async(t)=>{
 const {inventory}=fixture();for(const code of ['invalid_json_schema','model_not_found','insufficient_quota']){let calls=0;const mock=t.mock.method(globalThis,'fetch',async()=>{calls++;return Response.json({error:{code,message:'json_schema is not supported; invalid schema'}},{status:code==='model_not_found'?404:code==='insufficient_quota'?429:400});});await assert.rejects(assess(demoSource,'B','test','key','gpt-4.1',inventory,0));assert.equal(calls,1);mock.mock.restore();}
});
test('resuming after a failed claim preserves old checkpoint and only re-evaluates unfinished claim',async(t)=>{
 const {c,inventory}=fixture(),next={...structuredClone(c),id:'C02',primary:false};inventory.claims.push({id:next.id,primary:next.primary,statement:next.statement,citation:next.citation});
 const saved:AutomaticState={runId:'old-run',version:'emp-automatic-form-0.5.1',language:'en',model:'gpt-4.1',startedAt:'2026-09-01',inventory,claims:[c],audit:[],quality:{C01:[]},complete:false};const before=JSON.stringify(saved);let calls=0;
 const mock=t.mock.method(globalThis,'fetch',async()=>{calls++;return reply({id:'C02',v05:{}});});await assert.rejects(assessNext(demoSource,'B','test','key','gpt-4.1',saved));assert.equal(calls,2);assert.equal(JSON.stringify(saved),before);mock.mock.restore();
 t.mock.method(globalThis,'fetch',async(_url:unknown,init?:RequestInit)=>{calls++;const body=JSON.parse(String(init?.body));assert.match(body.input,/"id":"C02"/);return reply(assessmentSchema.parse(next));});
 const advanced=await assessNext(demoSource,'B','test','key','gpt-4.1',saved);assert.equal(calls,3);assert.equal(JSON.stringify(saved),before);assert.deepEqual(advanced.state.claims[0],c);assert.equal(advanced.step,'C02');assert.equal(advanced.state.runId,'old-run');assert.equal(completedAnalysis({...advanced.state,complete:true},'hash').claims.length,2);
});
