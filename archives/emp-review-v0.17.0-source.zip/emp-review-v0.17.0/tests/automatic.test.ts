import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import JSZip from "jszip";
import { demoAnalysis,demoSource } from "../lib/demo";
import { emptyReview,deriveBridge,claimIssues,syncV05,type Claim } from "../lib/emp";
import { v05Example } from "../lib/v05";
import { inventorySchema,completedAnalysis,assess,discover,type AutomaticState } from "../lib/automatic";
import { formValues,fillForm,createExportPackage,type ExportData } from "../lib/form-export";
import { runAutomaticBatch,type StepResult } from "../lib/automatic-batch";

export {fixture} from './helpers/automatic-fixture';
import {fixture} from './helpers/automatic-fixture';
test("v0.5 current direct claim and motivation-only B3 follow different rules",()=>{
 const c=fixture().state.claims[0];assert.deepEqual(claimIssues(c,demoSource),[]);assert.equal(deriveBridge(c),"B0");
 const b=syncV05({...c,focal:"I",substitution:"SE1",role:"Motivation-background",v05:{...c.v05!,condition:"NC3"}});assert.equal(deriveBridge(b),"B3");assert.equal(b.condition,"NC1");
 assert.equal(deriveBridge({...b,secondarySubstitutions:["SEU"]}),"BU");
});
test("inventory supports more than 12 material claims and rejects unsafe/colliding IDs",()=>{
 const i=fixture().state.inventory;i.claims=Array.from({length:18},(_,n)=>({...i.claims[0],id:`C${String(n+1).padStart(2,"0")}`,primary:n===0}));assert.equal(inventorySchema.parse(i).claims.length,18);
 assert.equal(inventorySchema.safeParse({...i,claims:[{...i.claims[0],id:"C/1"}]}).success,false);
});
test("complete analysis cannot be created from unfinished claim set",()=>{const s=fixture().state;s.claims=[];assert.throws(()=>completedAnalysis(s,"x"),/jeszcze ukończona/);});
test("original DOCX template has every placeholder filled, quotations escaped, no invented certification",async()=>{
 const d=fixture(),values=formValues(d,d.state.claims[0]);values.EMP_3_1_1="A < B & wynik\nDrugi wiersz";
 const bytes=await fillForm(new Uint8Array(await readFile("public/templates/EMP_Coding_Form_v0_5.docx")),values),zip=await JSZip.loadAsync(bytes),xml=await zip.file("word/document.xml")!.async("string");
 assert.doesNotMatch(xml,/\{\{EMP_|undefined/);assert.match(xml,/A &lt; B &amp; wynik/);assert.match(xml,/w:br/);assert.match(xml,/Operator confirmation: not completed/);assert.equal(values.EMP_15_1_1,"Not assessed");assert.equal(values.EMP_17_0_1,"");assert.equal(values.EMP_11_7_1,"B0");
});
test("invalid draft R1 cannot export as Supported",()=>{
 const d=fixture(),c=d.state.claims[0];c.v05!.readoutRelation="R1";const v=formValues(d,c);assert.equal(v.EMP_11_7_1,"BU");assert.match(v.EMP_13_2_1,/R1/);
});
test("structural reports contain no invented substantive claim and use field-specific states",()=>{
 const d=fixture();d.document.review.reportType="NC";const v=formValues(d);assert.equal(v.EMP_3_0_1,"");assert.equal(v.EMP_5_1_1,"RNA");assert.equal(v.EMP_9_1_1,"Structural NA");assert.equal(v.EMP_11_7_1,"BNA");assert.equal(v.EMP_8_1_5,"X");
});
test("NC2 cannot use Structural NA matching and NC0 requires NA coupling",()=>{
 const d=fixture(),c=d.state.claims[0];
 c.v05!.condition="NC2";c.conditionCitation=c.citation;
 assert.ok(claimIssues(syncV05(c),demoSource).some(x=>x.includes("NC2 wymaga dopasowania")));
 c.v05!.condition="NC0";c.v05!.coupling="FC";
 assert.ok(claimIssues(syncV05(c),demoSource).some(x=>x.includes("NC0 wymaga")));
});
test("excluding every substantive claim does not invent a structural BNA form",async()=>{
 const d=fixture(),c=d.state.claims[0];d.document.review.decisions[c.id]={claim:c,status:"excluded",comment:"Wyłączono",sourceChecked:false,updatedAt:"now"};
 const blob=await createExportPackage([d],new Uint8Array(await readFile("public/templates/EMP_Coding_Form_v0_5.docx")));
 const zip=await JSZip.loadAsync(await blob.arrayBuffer());
 assert.equal(Object.keys(zip.files).filter(x=>x.endsWith(".docx")).length,0);
 assert.match(await zip.file("CZYTAJ_TO.txt")!.async("string"),/no active claims/);
 assert.ok(zip.file("EMP_test-report/analiza.json"));
});
test("ZIP contains matching DOCX forms, exact audit data and summary; excluded claims only remain in JSON",async()=>{
 const d=fixture(),extra=structuredClone(d.state.claims[0]);extra.id="C02";extra.primary=false;d.document.analysis!.claims.push(extra);d.document.review.decisions.C02={claim:extra,status:"excluded",comment:"Wyłączone przez użytkownika",sourceChecked:false,updatedAt:"now"};
 const blob=await createExportPackage([d],new Uint8Array(await readFile("public/templates/EMP_Coding_Form_v0_5.docx")),[{title:"Drugi dokument",error:"Przerwana analiza"}]);
 const zip=await JSZip.loadAsync(await blob.arrayBuffer());assert.equal(Object.keys(zip.files).filter(x=>x.endsWith(".docx")).length,1);assert.match(await zip.file("CZYTAJ_TO.txt")!.async("string"),/INCOMPLETE PUBLICATIONS/);assert.match(await zip.file("EMP_test-report/analiza.json")!.async("string"),/Wyłączone przez użytkownika/);
});
test("a failed publication does not stop later ones; resuming a complete record makes no model request",async()=>{
 const d=fixture(),events:string[]=[];let calls=0;
 const result=await runAutomaticBatch([{id:"failed",title:"A"},{id:"saved",title:"B"}],{import:async()=>{},load:async id=>id==="saved"?{state:d.state,document:d.document}:{state:null,document:null},step:async()=>{calls++;throw new Error("provider failure");},progress:p=>events.push(`${p.id}:${p.phase}`),stop:()=>false});
 assert.equal(calls,1);assert.equal(result.failed.length,1);assert.equal(result.completed.length,1);assert.ok(events.includes("saved:complete"));assert.equal(d.document.review.coverageChecked,false);assert.deepEqual(d.document.review.decisions,{});
});
test("pause retains checkpoint and does not begin another AI step",async()=>{const events:import("../lib/automatic-batch").AutoProgress[]=[];let pause=false,calls=0;const d=fixture();const result=await runAutomaticBatch([{id:"x",title:"X"}],{import:async()=>{},load:async()=>({state:null,document:null}),step:async()=>{calls++;pause=true;return {state:{...d.state,claims:[],complete:false},document:null};},progress:p=>events.push(p),stop:()=>pause});assert.equal(calls,1);assert.equal(result.paused,true);assert.equal(events.at(-1)?.phase,"claims");assert.equal(events.at(-1)?.completed,0);assert.equal(events.at(-1)?.total,d.state.inventory.claims.length);});
test("detail response cannot silently change the inventoried claim",async(t)=>{
 const d=fixture(),c={...d.state.claims[0],id:"C02"};t.mock.method(globalThis,"fetch",async()=>Response.json({status:"completed",output:[{content:[{type:"output_text",text:JSON.stringify(c)}]}]}));
 await assert.rejects(assess(demoSource,"B","fixture","key","test-model",d.state.inventory,0),/id: different inventoried claim/);
});
test("inventory and detail preserve exact request/output reconstruction without credentials",async(t)=>{
 const d=fixture();t.mock.method(globalThis,"fetch",async()=>Response.json({status:"completed",output:[{content:[{type:"output_text",text:JSON.stringify(d.state.inventory)}]}]}));
 const r=await discover(demoSource,"B","fixture","private-test-key","test-model");assert.equal(r.inventory.claims.length,1);assert.equal(r.requestHash.length,64);assert.equal(r.outputHash.length,64);assert.match(r.request.input,/fixture/);assert.match(r.request.instructions,/NORMATIVE CODING RULES/);assert.doesNotMatch(JSON.stringify(r),/private-test-key/);
});
