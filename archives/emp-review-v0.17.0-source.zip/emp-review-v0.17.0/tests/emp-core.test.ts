import { test } from "node:test";
import assert from "node:assert/strict";
import { demoAnalysis, demoSource } from "../lib/demo";
import { analysisSchema, deriveBridge, claimIssues, quoteExists, currentClaims, emptyReview, type RecordDoc } from "../lib/emp";
test("training example parses and every citation is grounded",()=>{analysisSchema.parse(demoAnalysis);for(const c of demoAnalysis.claims)assert.deepEqual(claimIssues(c,demoSource),[]);});
test("matched direct evidence remains Supported despite Partial adequacy",()=>{assert.equal(deriveBridge(demoAnalysis.claims[0]),"B0");});
test("specific coupled withholding condition is Open",()=>{assert.equal(deriveBridge(demoAnalysis.claims[1]),"B1");});
test("uncertainty in secondary substitution overrides direct support",()=>{assert.equal(deriveBridge({...demoAnalysis.claims[0],secondarySubstitutions:["SEU"]}),"BU");});
test("current displaced warrant is inheritance, not Open",()=>{assert.equal(deriveBridge({...demoAnalysis.claims[1],substitution:"SE2",role:"Warrant"}),"B2");});
test("unclear role does not default to assertion",()=>{assert.equal(deriveBridge({...demoAnalysis.claims[1],role:"Unclear"}),"BU");});
test("a clear unsupported assertion with no substituted warrant is B3",()=>{assert.equal(deriveBridge({...demoAnalysis.claims[1],condition:"NC0",conditionCitation:null,coupling:"Not applicable",conditionMatches:"Not applicable",commitment:"Present",role:"Not applicable",focal:"N0"}),"B3");});
test("wrong scope cannot produce supported classification",()=>{assert.equal(deriveBridge({...demoAnalysis.claims[0],scopeMatch:"No"}),"BU");});
test("fabricated or mislocated quotation prevents acceptance",()=>{const c=structuredClone(demoAnalysis.claims[0]);c.citation.quote="An invented quotation";assert.ok(claimIssues(c,demoSource).length);assert.equal(quoteExists({...demoAnalysis.claims[0].citation,blockId:"b3"},demoSource),false);});
test("methodological reports are assessable but context reports are structural",()=>{assert.equal(deriveBridge(demoAnalysis.claims[0],"M"),"B0");assert.equal(deriveBridge(demoAnalysis.claims[0],"NMC"),"BNA");});
test("review overrides do not mutate the original model proposal",()=>{const original=structuredClone(demoAnalysis);const c={...original.claims[0],statement:"Zmienione przez recenzenta"};const doc={analysis:original,review:{...emptyReview,decisions:{[c.id]:{claim:c,status:"draft",comment:"",sourceChecked:false,updatedAt:"now"}}}} as RecordDoc;assert.equal(currentClaims(doc)[0].statement,c.statement);assert.notEqual(original.claims[0].statement,c.statement);});

test("uncertain indispensable family blocks resolved cross-cutting judgement",()=>{const c=structuredClone(demoAnalysis.claims[0]);c.family="Cross-cutting";c.requiredFamilies=["Measurement reliability","Clinical and functional relevance"];c.profile["Measurement reliability"]="U";assert.equal(deriveBridge(c),"BU");});
