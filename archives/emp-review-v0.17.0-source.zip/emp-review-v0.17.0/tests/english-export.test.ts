import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import JSZip from 'jszip';
import {englishWordPackage,needsEnglish,validateEnglishResult} from '../lib/english-export';
import {setLanguage,getLanguage,tr} from '../lib/i18n';

async function pack(text:string){const doc=new JSZip();doc.file('word/document.xml',`<w:document><w:body><w:p><w:r><w:t>${text}</w:t></w:r></w:p></w:body></w:document>`);const zip=new JSZip();zip.file('report.docx',await doc.generateAsync({type:'uint8array'}));zip.file('project.json','{"rationale":"Brak dowodów","code":"B3"}');zip.file('claims.csv','Brak dowodów,B3');return zip.generateAsync({type:'blob'});}
test('old Polish interface preference cannot restore a bilingual product',()=>{setLanguage('pl');assert.equal(getLanguage(),'en');assert.equal(tr('Ustawienia AI'),'AI settings');});
test('English Word export labels translated prose and preserves audit bytes',async()=>{
 const blob=await pack('Brak dowodów. B3; n=42 &amp; 0.5'),before=await JSZip.loadAsync(await blob.arrayBuffer());
 const result=await englishWordPackage(blob,async entries=>entries.map(e=>({...e,text:'No evidence. B3; n=42 & 0.5'}))),after=await JSZip.loadAsync(await result.arrayBuffer());
 for(const path of ['project.json','claims.csv'])assert.deepEqual(await after.file(path)!.async('uint8array'),await before.file(path)!.async('uint8array'));
 const doc=await JSZip.loadAsync(await after.file('report.docx')!.async('uint8array')),xml=await doc.file('word/document.xml')!.async('string');
 assert.match(xml,/\[English translation T1\] No evidence/);assert.match(xml,/42 &amp; 0.5/);assert.doesNotMatch(xml,/Brak dowodów/);
 const audit=JSON.parse(await after.file('english-translations.json')!.async('string'));assert.equal(audit.entries[0].text,'Brak dowodów. B3; n=42 & 0.5');
});
test('English exports avoid AI; Polish without accents is still detected',async()=>{
 assert.equal(needsEnglish('Brak danych dla tej populacji.'),true);let called=false;const original=await pack('Evidence supports B0; n=42.');const result=await englishWordPackage(original,async()=>{called=true;return [];});assert.equal(called,false);assert.equal(result,original);
});
test('translation fails closed on missing entries, altered numbers, altered codes and untranslated prose',()=>{
 const input=[{id:'T1',text:'Brak danych. B3; 42'}];
 for(const output of [[],[{id:'T1',text:'No data. B0; 42'}],[{id:'T1',text:'No data. B3; 43'}],input])assert.throws(()=>validateEnglishResult(input,output));
});
test('translation failure returns no partial Word package',async()=>{const original=await pack('Brak dowodów.');await assert.rejects(englishWordPackage(original,async()=>{throw new Error('Quota exhausted');}),/Quota/);const z=await JSZip.loadAsync(await original.arrayBuffer());assert.equal(await z.file('project.json')!.async('string'),'{"rationale":"Brak dowodów","code":"B3"}');});
test('normative v0.5 template contains English chrome and retains all placeholders and tables',async()=>{
 const z=await JSZip.loadAsync(await readFile('public/templates/EMP_Coding_Form_v0_5.docx')),xml=await z.file('word/document.xml')!.async('string');
 const text=[...xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)].map(m=>m[1]).join(' ');
 assert.doesNotMatch(text,/[ąćęłńóśźż]|Formularz|Wymiar|Rodzina|Strona|Koder/);
 assert.match(text,/Form populated by AI/);assert.match(text,/Manual v0.5/);assert.equal((xml.match(/<w:tbl>/g)||[]).length,22);
 assert.ok((xml.match(/\{\{EMP_/g)||[]).length>100);
});
