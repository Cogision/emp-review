import {test} from 'node:test';
import assert from 'node:assert/strict';
import {FigureStore} from '../lib/figure-store';
import {figureMime,FIGURE_BYTES,checkedFigureReport,type FigureInput,type FigureReport,type FigureRun} from '../lib/figures';
import {analyzeFigure} from '../lib/figure-analyzer';
import {compareFields,claimFields} from '../lib/field-comparison';
import {newManifest,legacyManifest,codingScope,requireManual} from '../lib/versions';
import {demoAnalysis,demoSource,demoTitle,demoCoverage} from '../lib/demo';
import {claimIssues,deriveBridge} from '../lib/emp';
import {roundFixture} from './helpers/round-fixture';
import {fullDraft} from './helpers/full-round-fixture';

const png=new Uint8Array(Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jZV8AAAAASUVORK5CYII=','base64'));
const input=():FigureInput=>({id:crypto.randomUUID(),label:'Figure 1',caption:'Example caption',locator:'p. 2',sourceFileId:''});
const report:FigureReport={kind:'conceptual',readability:'clear',summary:'A synthetic diagram.',observations:[{panel:'A',statement:'A labelled connection.',relation:'consistent',textCitation:{blockId:'b4',quote:'Our findings provide evidence for prognosis during treatment A.'}}],limitations:['No numerical results are shown.'],questions:[]};
function fixture(){
 const base=roundFixture(),binary=new Map<string,Uint8Array>(),bucket=base.env.BUCKET,original={get:bucket.get.bind(bucket),put:bucket.put.bind(bucket),delete:bucket.delete.bind(bucket)};
 bucket.put=(async (key:string,value:unknown)=>{if(typeof value==='string')return original.put(key,value);binary.set(key,value instanceof Uint8Array?value:new Uint8Array(value as ArrayBuffer));}) as typeof bucket.put;
 bucket.get=(async (key:string)=>{if(binary.has(key)){const b=binary.get(key)!;return {arrayBuffer:async()=>b.slice().buffer,body:new Blob([b.slice().buffer]).stream()};}return original.get(key);}) as typeof bucket.get;
 bucket.delete=(async (key:string)=>{binary.delete(key);return original.delete(key);}) as typeof bucket.delete;
 return {...base,binary,store:new FigureStore(base.env,'owner')};
}
test('field comparison exposes nested v0.5 differences and distinguishes absent values',()=>{
 const draft=fullDraft(),c=draft.claims[0],b=structuredClone(draft);b.fullFields![c.id].confidence='Low';
 const diffs=compareFields(claimFields(c,draft),claimFields(c,b)).filter(r=>r.different);
 assert.deepEqual(diffs.map(r=>r.path),['v05.confidence']);
 const values=compareFields({a:false,b:null,c:[],d:{}},{a:undefined,b:undefined,c:undefined,d:null});assert.equal(values.filter(v=>v.different).length,4);
 assert.deepEqual(compareFields({scope:{x:'D',y:'NE'}},{scope:{y:'NE',x:'D'}}).filter(r=>r.different),[]);
 const absent=structuredClone(draft);absent.unanswered={[c.id]:['primary','profile.Decision relevance']};assert.equal(claimFields(c,absent).primary,undefined);
});
test('the complete teaching example is English and retains grounded B0/B1 assessments',()=>{
 assert.doesNotMatch(JSON.stringify({demoTitle,demoCoverage,demoSource,demoAnalysis}),/[ąćęłńóśźż]/i);
 assert.equal(demoAnalysis.language,'en');assert.equal(demoAnalysis.demo,true);
 assert.deepEqual(demoAnalysis.claims.map(c=>claimIssues(c,demoSource)),[[],[]]);
 assert.deepEqual(demoAnalysis.claims.map(c=>deriveBridge(c)),['B0','B1']);
});
test('version manifests preserve unknown historical app versions and actual form coverage',()=>{
 const old={...demoAnalysis,versions:undefined},legacy=legacyManifest(old);assert.equal(legacy.appVersion,null);assert.equal(legacy.recorded,false);assert.equal(legacy.scope,'core');
 assert.equal(newManifest('full').manualVersion,'v0.5');assert.equal(newManifest('full').formVersion,'v0.5');assert.equal(newManifest('core').formVersion,null);
 const d=fullDraft();assert.equal(codingScope({...old,claims:d.claims}),'full');assert.equal(codingScope({...old,claims:[...d.claims,demoAnalysis.claims[0]]}),'core');
 assert.equal(requireManual('v0.5'),'v0.5');assert.throws(()=>requireManual('v0.6'),/not defined/);
});
test('image validation rejects wrong MIME, text masquerading as an image and oversize bytes',()=>{
 assert.equal(figureMime(png,'image/png'),'image/png');assert.throws(()=>figureMime(png,'image/jpeg'),/must match/);
 assert.throws(()=>figureMime(new TextEncoder().encode('<svg onload="alert(1)"></svg>'),'image/png'),/PNG/);
 assert.throws(()=>figureMime(new Uint8Array(FIGURE_BYTES+1),'image/png'),/3 MB/);
});
test('figure uploads are idempotent, owner-scoped and never create a second report',async()=>{
 const f=fixture(),v=input(),saved=await f.store.upload('doc',v,'figure.png','image/png',png),n=f.binary.size;
 assert.deepEqual(await f.store.upload('doc',v,'figure.png','image/png',png),saved);assert.equal(f.binary.size,n);
 await assert.rejects(f.store.upload('doc',{...v,caption:'Changed caption'},'figure.png','image/png',png),/different figure/);
 await assert.rejects(new FigureStore(f.env,'intruder').content('doc',saved.id),/not found/);
 await assert.rejects(f.store.upload('doc',{...input(),sourceFileId:'f9'},'figure.png','image/png',png),/does not belong/);
 assert.equal(f.sql.prepare('SELECT count(*) AS n FROM documents').get()!.n,1);
 const archived=await f.store.archive('doc',saved.id,0,true);assert.ok(archived.archivedAt);
 await assert.rejects(f.store.archive('doc',saved.id,0,false),/changed/);
 assert.equal((await f.store.archive('doc',saved.id,1,false)).archivedAt,null);
});
test('figure input is sent as an actual image and comparisons retain exact article quotations',async()=>{
 const f=fixture(),figure=await f.store.upload('doc',input(),'figure.png','image/png',png);let requestBody:any;
 const run=await analyzeFigure(figure,png,demoSource,'hash',{key:'fixture-key',model:'fixture-model',language:'en',runId:crypto.randomUUID()},async(_url,init)=>{requestBody=JSON.parse(String(init?.body));return Response.json({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify(report)}]}]});});
 assert.equal(requestBody.input[0].content[1].type,'input_image');assert.match(requestBody.input[0].content[1].image_url,/^data:image\/png;base64,/);assert.equal(requestBody.text.format.type,'json_schema');assert.equal(requestBody.store,false);assert.equal(run.review.status,'draft');assert.doesNotMatch(JSON.stringify(run),/fixture-key/);
 const bad=structuredClone(report);bad.observations[0].textCitation!.quote='An invented quotation.';assert.throws(()=>checkedFigureReport(bad,demoSource),/does not match/);
 bad.observations[0].textCitation=null;assert.throws(()=>checkedFigureReport(bad,demoSource),/exact quotation/);
 assert.throws(()=>checkedFigureReport({...report,readability:'unreadable'},demoSource),/unreadable/);
});
test('new figure analyses do not inherit human approval; reviews are audited and guarded',async()=>{
 const f=fixture(),figure=await f.store.upload('doc',input(),'figure.png','image/png',png);
 const make=():FigureRun=>({id:crypto.randomUUID(),figureId:figure.id,sourceHash:'hash',imageHash:figure.imageHash,model:'fixture',language:'en',createdAt:new Date().toISOString(),appVersion:'0.10.0',promptVersion:'fixture',report,review:{revision:0,status:'draft',sourceChecked:false,comment:''}});
 const a=await f.store.saveRun('doc',figure.id,make());await assert.rejects(f.store.review('doc',figure.id,a.id,{revision:0,status:'checked',sourceChecked:false,comment:''}),/Inspect/);
 await f.store.review('doc',figure.id,a.id,{revision:0,status:'checked',sourceChecked:true,comment:'Checked manually.'});
 await assert.rejects(f.store.review('doc',figure.id,a.id,{revision:0,status:'excluded',sourceChecked:true,comment:'Stale.'}),/another tab/);
 const b=await f.store.saveRun('doc',figure.id,make()),runs=await f.store.runs('doc',figure.id);assert.equal(runs.find(r=>r.id===a.id)!.review.status,'checked');assert.equal(runs.find(r=>r.id===b.id)!.review.status,'draft');
 const exp=await f.store.export('doc');assert.equal(exp.items[0].reviewHistory.length,1);assert.deepEqual(exp.items[0].runs.find(r=>r.id===a.id)!.report,report);
 await f.store.archive('doc',figure.id,0,true);await assert.rejects(f.store.saveRun('doc',figure.id,make()),/Restore/);
 f.sql.prepare("DELETE FROM documents WHERE id='doc'").run();assert.equal(f.sql.prepare('SELECT count(*) AS n FROM figure_runs').get()!.n,0);assert.equal(f.sql.prepare('SELECT count(*) AS n FROM figure_review_events').get()!.n,0);
});
test('rounds freeze image bytes and metadata; permissions protect originals and AI results stay hidden',async()=>{
 const f=fixture(),figure=await f.store.upload('doc',input(),'figure.png','image/png',png),round=await f.create();
 assert.equal(round.source!.figures!.length,1);assert.equal(round.source!.figures![0].imageHash,figure.imageHash);
 let d=await f.join(round,'alice');await assert.rejects(f.as('alice').figure(d.round.id,figure.id),/not available/);
 d=await f.owner.action(d.round.id,{action:'approve',memberId:'alice',revision:d.round.revision}) as typeof round;await assert.rejects(f.as('alice').figure(d.round.id,figure.id),/not available/);
 d=await f.join(d,'bob');d=await f.owner.action(d.round.id,{action:'approve',memberId:'bob',revision:d.round.revision}) as typeof round;d=await f.owner.action(d.round.id,{action:'start',revision:d.round.revision}) as typeof round;
 await f.store.archive('doc',figure.id,0,true);f.sql.prepare("DELETE FROM documents WHERE id='doc'").run();
 const frozen=await f.as('alice').figure(d.round.id,figure.id);assert.deepEqual(new Uint8Array(await frozen.object.arrayBuffer()),png);assert.equal(frozen.figure.caption,'Example caption');
 assert.equal((await f.as('alice').detail(d.round.id)).proposal,undefined);assert.equal('runs' in frozen.figure,false);
 await assert.rejects(f.as('stranger').figure(d.round.id,figure.id),/not found/);
});
