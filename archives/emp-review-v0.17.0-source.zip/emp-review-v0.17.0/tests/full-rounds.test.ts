import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import JSZip from 'jszip';
import {roundFixture} from './helpers/round-fixture';
import {fixture} from './helpers/automatic-fixture';
import {blankRoundDraft,blankV05Draft,CORE_CHOICES,parseDraft,submissionIssues,type RoundDetail,type RoundDraft} from '../lib/review-rounds';
import {ProjectAssessmentStore} from '../lib/project-assessment-store';
import {synthesise,type ProjectDocument,type ProjectData} from '../lib/projects';
import {synthesisFingerprint,synthesisInput} from '../lib/project-interpretation';
import {createProjectPackage} from '../lib/project-export';
import {createRoundPackage,roundFormValues} from '../lib/round-export';
import {demoSource} from '../lib/demo';

import {fullDraft} from './helpers/full-round-fixture';
async function revealed(){const f=roundFixture(),round=await f.ready(),id=round.round.id;for(const user of ['alice','bob'])await f.as(user).action(id,{action:'submit',assessmentRevision:0,draft:fullDraft()});return {f,d:await f.owner.action(id,{action:'reveal',revision:round.round.revision}) as RoundDetail};}
async function adjudicate(f:ReturnType<typeof roundFixture>,d:RoundDetail,draft=fullDraft()){
 return f.owner.action(d.round.id,{action:'adjudicate',revision:d.round.revision,draftRevision:d.adjudicationDraft?.revision??0,draft,rationale:'Reviewed both source-grounded assessments together.',claimRationales:{C01:'The quoted result supports the selected scope.'},links:d.submissions!.map(s=>({claimId:'C01',submissionId:s.id,originalClaimId:'C01'}))}) as Promise<RoundDetail>;
}
function setupProject(f:ReturnType<typeof roundFixture>){
 f.sql.prepare("UPDATE documents SET review=? WHERE id='doc'").run(JSON.stringify(fixture().document.review));
 f.sql.prepare("INSERT INTO projects (id,owner,title,created_at,updated_at) VALUES ('project','owner','Synthesis','now','now')").run();
 f.sql.prepare("INSERT INTO project_documents (project_id,document_id,added_at) VALUES ('project','doc','now')").run();
 const original:ProjectDocument={...fixture().document,id:'doc',sourceHash:'hash',studyGroup:''};
 const store=new ProjectAssessmentStore(f.env,'owner');
 const data=(document:ProjectDocument):ProjectData=>({project:{id:'project',title:'Synthesis',question:'',criteria:'',language:'en',revision:1,created_at:'now',updated_at:'now'},documents:[document],generatedAt:'now'});
 return {store,original,data};
}
test('full v0.5 drafts save incomplete fields without inventing codes and cannot submit them',async()=>{
 const f=roundFixture(),d=await f.ready(),draft=fullDraft();draft.fullFields!.C01=blankV05Draft();draft.unanswered={C01:[...CORE_CHOICES]};
 const saved=await f.as('alice').action(d.round.id,{action:'save',assessmentRevision:0,draft}) as RoundDetail;
 assert.equal(saved.own!.draft.claims[0].v05,undefined);assert.equal(saved.own!.draft.fullFields!.C01.condition,undefined);
 await assert.rejects(f.as('alice').action(d.round.id,{action:'submit',assessmentRevision:1,draft}),/complete v0.5/);
 assert.equal((await f.as('alice').detail(d.round.id)).own!.revision,1);
 const complete=fullDraft();assert.deepEqual(submissionIssues(complete,demoSource,'v0.5'),[]);
 const form=complete.fullFields!.C01;form.condition='NC3';complete.claims[0].condition='NC0';
 assert.equal(parseDraft(complete,'v0.5').claims[0].condition,'NC1');
 delete form.scopeCodes!.population;
 assert.ok(submissionIssues(complete,demoSource,'v0.5').some(x=>x.includes('scopeCodes.population')));
});
test('explicit uncertainty is valid; fabricated evidence and incompatible codes remain blocked',()=>{
 const d=fullDraft();d.decisions.C01.status='unresolved';d.decisions.C01.comment='Cannot decide whether evidence supports deployment.';
 d.claims[0].focal='U';d.claims[0].bridgeClear=false;
 assert.deepEqual(submissionIssues(d,demoSource,'v0.5'),[]);
 d.fullFields!.C01.readoutRelation='R1';d.fullFields!.C01.equivalenceEvidence='Equivalence asserted';d.fullFields!.C01.equivalenceCitation={blockId:'p1',quote:'Invented proof of equivalence.'};
 assert.ok(submissionIssues(d,demoSource,'v0.5').length>0);
});
test('full round lock, adjudication provenance and DOCX export preserve original submissions',async()=>{
 const {f,d}=await revealed(),before=JSON.stringify(d.submissions),a=await adjudicate(f,d);
 assert.equal(a.round.manualVersion,'v0.5');assert.equal(JSON.stringify(a.submissions),before);
 assert.equal(a.adjudications![0].actorId,'owner');assert.equal(a.adjudications![0].links.length,2);
 await assert.rejects(f.owner.action(d.round.id,{action:'adjudicate',revision:a.round.revision,draftRevision:a.adjudicationDraft?.revision??0,draft:fullDraft(),rationale:'No per-claim reasoning supplied.',links:a.adjudications![0].links}),/explain the agreed/);
 const exported=await f.owner.export(d.round.id),template=new Uint8Array(await readFile('public/templates/EMP_Coding_Form_v0_5.docx'));
 const zip=await JSZip.loadAsync(await (await createRoundPackage(exported,template)).arrayBuffer());
 const files=Object.keys(zip.files).filter(f=>f.endsWith('.docx'));assert.equal(files.length,3);
 for(const name of files){const form=await JSZip.loadAsync(await zip.file(name)!.async('uint8array')),xml=await form.file('word/document.xml')!.async('string');assert.doesNotMatch(xml,/\{\{EMP_|undefined|Coder_ID: AI-|Formularz wypełniony automatycznie przez AI/);assert.match(xml,/Manual: v0.5/);}
 const v=roundFormValues(exported,a.adjudications![0],a.adjudications![0].draft.claims[0]);
 assert.match(v.EMP_19_0_1,new RegExp(a.adjudications![0].id));assert.match(v.EMP_19_7_1,/owner/);assert.match(v.EMP_21_10_1,/Confirmation: Yes/);assert.equal(v.EMP_15_1_1,'Not assessed');
});
test('legacy core round remains core and keeps its original submission contract',async()=>{
 const f=roundFixture(),d=await f.ready();f.sql.prepare("UPDATE review_rounds SET manual_version='v0.5-core' WHERE id=?").run(d.round.id);
 const draft={...blankRoundDraft(),reportType:'NC' as const,typeRationale:'Structural source.',coverageChecked:true,priorExposure:'no' as const};
 for(const user of ['alice','bob'])await f.as(user).action(d.round.id,{action:'submit',assessmentRevision:0,draft});
 await f.owner.action(d.round.id,{action:'reveal',revision:d.round.revision});const exported=await f.owner.export(d.round.id);
 assert.equal(exported.round.manualVersion,'v0.5-core');assert.equal(exported.submissions![0].draft.metadata,undefined);
 await assert.rejects(createRoundPackage(exported,new Uint8Array()),/Legacy core/);
});
test('project pins an exact adjudication; later adjudications do not replace it or duplicate evidence',async()=>{
 const {f,d}=await revealed(),a=await adjudicate(f,d),{store,original,data}=setupProject(f),id=a.adjudications![0].id;
 await store.select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:id});
 const selected=await store.apply('project',original),fingerprint=await synthesisFingerprint(data(selected),'accepted');
 assert.equal(selected.assessmentBasis!.adjudicationId,id);assert.deepEqual(selected.originalAssessment!.analysis,original.analysis);
 const revised=fullDraft();revised.summary='Later adjudication';const b=await adjudicate(f,a,revised);
 assert.equal((await store.apply('project',original)).assessmentBasis!.adjudicationId,id);
 assert.equal(await synthesisFingerprint(data(await store.apply('project',original)),'accepted'),fingerprint);
 assert.equal(synthesise(data(selected),'all').rows.length,1);assert.equal(synthesise(data(selected),'all').counts.reports,1);
 assert.equal(synthesisInput(data(selected),'accepted').claims[0].assessmentBasis.adjudicationId,id);
 await store.select('project','doc',{revision:1,roundId:d.round.id,adjudicationId:b.adjudications!.find(x=>x.id!==id)!.id});
 assert.notEqual(await synthesisFingerprint(data(await store.apply('project',original)),'accepted'),fingerprint);
 await assert.rejects(store.select('project','doc',{revision:1,roundId:null,adjudicationId:null}),/project changed/);
 assert.equal((await store.history('project')).length,2);
 await store.select('project','doc',{revision:2,roundId:null,adjudicationId:null});assert.deepEqual(await store.apply('project',original),original);
 assert.equal((await f.owner.detail(d.round.id)).adjudications!.length,2);
});
test('project basis selection rejects foreign owners, sources, unknown IDs and unrevealed rounds',async()=>{
 const {f,d}=await revealed(),a=await adjudicate(f,d),{store,original}=setupProject(f),id=a.adjudications![0].id;
 await assert.rejects(new ProjectAssessmentStore(f.env,'alice').options('project','doc'),/not found/);
 await assert.rejects(new ProjectAssessmentStore(f.env,'alice').select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:id}));
 await assert.rejects(store.select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:'unknown'}),/not found/);
 f.sql.prepare("UPDATE review_rounds SET status='collecting' WHERE id=?").run(d.round.id);f.reads.length=0;
 assert.deepEqual((await store.options('project','doc')).options,[]);assert.equal(f.reads.some(k=>k.includes('adjudications/')),false);
 await assert.rejects(store.select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:id}),/not available/);
 f.sql.prepare("UPDATE review_rounds SET status='adjudicated' WHERE id=?").run(d.round.id);
 await store.select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:id});
 f.sql.prepare("UPDATE documents SET source_hash='changed' WHERE id='doc'").run();
 await assert.rejects(store.apply('project',{...original,sourceHash:'changed'}),/not available/);
 assert.equal((await store.history('project')).length,1);
});
test('project exports carry selected basis in all data tables and retain original and adjudicated records',async()=>{
 const {f,d}=await revealed(),a=await adjudicate(f,d),{store,original,data}=setupProject(f),id=a.adjudications![0].id;
 await store.select('project','doc',{revision:0,roundId:d.round.id,adjudicationId:id});const snapshot=data(await store.apply('project',original));snapshot.selectionHistory=await store.history('project');
 const zip=await JSZip.loadAsync(await (await createProjectPackage(snapshot,'all','en')).arrayBuffer());
 for(const file of ['reports.csv','claims.csv','profiles.csv','report.html'])assert.match(await zip.file(file)!.async('string'),new RegExp(id));
 const json=JSON.parse(await zip.file('project.json')!.async('string'));assert.deepEqual(json.manualVersions,['v0.5']);assert.equal(json.selectionHistory.length,1);assert.equal(json.documents[0].adjudication.id,id);assert.ok(json.documents[0].originalAssessment.analysis);
 const form=await JSZip.loadAsync(await zip.file('report.docx')!.async('uint8array'));assert.match(await form.file('word/document.xml')!.async('string'),new RegExp(id));
});
