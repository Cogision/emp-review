import test from 'node:test';
import assert from 'node:assert/strict';
import {HELP_TOPICS,V05_FIELD_HELP,SCOPE_FIELD_HELP,SCOPE_HELP,helpTopic,helpForLabel,helpForFieldPath,searchHelp} from '../lib/help-content';
import {v05Schema,SCOPE_KEYS} from '../lib/v05';

test('every full-form and scope field has a valid help destination',()=>{
 assert.deepEqual(Object.keys(V05_FIELD_HELP).sort(),Object.keys(v05Schema.shape).sort());
 assert.deepEqual(Object.keys(SCOPE_FIELD_HELP).sort(),[...SCOPE_KEYS].sort());
 assert.equal(new Set(HELP_TOPICS.map(t=>t.id)).size,HELP_TOPICS.length);
 for(const id of [...Object.values(V05_FIELD_HELP),...Object.values(SCOPE_FIELD_HELP)])assert.ok(helpTopic(id),id);
 for(const t of HELP_TOPICS)assert.ok(t.short&&t.action&&t.reference,t.id);
});
test('coded help covers actual selectable enums and distinguishes context-dependent codes',()=>{
 for(const field of ['declaredUse','readoutRelation','condition','coupling','commitment','evidenceTiming'] as const){
  const codes=helpTopic(V05_FIELD_HELP[field])!.codes!;
  assert.deepEqual(Object.keys(codes).sort(),[...v05Schema.shape[field].options].sort(),field);
 }
 assert.deepEqual(Object.keys(SCOPE_HELP).sort(),['E','N','X','U','NA'].sort());
 assert.equal(helpForFieldPath('v05.scopeCodes.readout'),'scope');
 assert.equal(helpForFieldPath('profile.Measurement reliability'),'support');
 assert.equal(helpForFieldPath('v05.condition'),'condition');
 assert.equal(helpForFieldPath('scope.readout'),'scope-readout');
 assert.equal(helpForLabel('Assessment filter')?.id,'filter');
});
test('search finds difficult codes and practical distinctions, and category filters compose',()=>{
 for(const [query,id] of [['NC2','condition'],['SEU','substitution'],['accepted','status'],['treatment selection','clinical'],['37 claims','inventory']])assert.ok(searchHelp(query).some(t=>t.id===id),query);
 assert.equal(searchHelp('no-such-concept-1298').length,0);
 assert.ok(searchHelp('NC2','EMP codes').every(t=>t.category==='EMP codes'));
});
