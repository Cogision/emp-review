import {demoAnalysis,demoSource} from '../../lib/demo';
import {emptyReview,syncV05,type Claim} from '../../lib/emp';
import {v05Example} from '../../lib/v05';
import {completedAnalysis,type AutomaticState} from '../../lib/automatic';
import type {ExportData} from '../../lib/form-export';
export function fixture():ExportData{
 const c:Claim=syncV05({...structuredClone(demoAnalysis.claims[0]),v05:{...structuredClone(v05Example),location:"Abstract results",selectionBasis:"Explicit primary/take-home conclusion",declaredUse:"U5",usePredicate:"Prognoza remisji pod leczeniem A",readoutRelation:"R0",scopeCodes:{readout:"E",population:"E",setting:"E",treatment:"E",comparator:"NA",outcome:"E",horizon:"E",inferenceUnit:"E",decisionRule:"NA"},evidenceTiming:"Prospective",observationMode:"Directly observed",evidenceLocation:"Report main text",warrantFamily:"Not applicable",condition:"NC0",coupling:"NA",conditionMatches:"Structural NA",hedging:"No",confidence:"Medium",adequacyRationale:"Ograniczona kalibracja.",notes:"Materiał syntetyczny do testów eksportu, bez analizy rzeczywistej publikacji."}});
 const state:AutomaticState={runId:"synthetic-run",version:"test",model:"Test — nie wywołano AI",startedAt:"2026-09-05T00:00:00Z",inventory:{reportType:"CB",typeRationale:demoAnalysis.typeRationale,bibliography:"Przykład fikcyjny, bez DOI",summary:demoAnalysis.summary,limitations:["Materiał syntetyczny"],complete:true,claims:[{id:c.id,primary:c.primary,statement:c.statement,citation:c.citation}]},claims:[c],audit:[],quality:{C01:[]},complete:true};
 const document={id:"test-report",title:"Przykład syntetyczny — test formularza",stage:"B",coverage:"Fikcyjny tekst do kontroli eksportu.",sourceHash:"synthetic-no-source-hash",createdAt:state.startedAt,updatedAt:state.startedAt,revision:1,analysis:completedAnalysis(state,"synthetic-no-source-hash"),review:structuredClone(emptyReview),source:demoSource};
 return {document,state,audits:[]};
}
