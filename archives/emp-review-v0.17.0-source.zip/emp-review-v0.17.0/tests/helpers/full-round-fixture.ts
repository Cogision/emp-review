import {blankRoundDraft,type RoundDraft} from '../../lib/review-rounds';
import {fixture} from './automatic-fixture';
export function fullDraft():RoundDraft{
 const c=fixture().state.claims[0],d=blankRoundDraft(null,'v0.5');
 return {...d,reportType:'CB',typeRationale:'Contains a primary empirical claim.',claims:[c],fullFields:{[c.id]:c.v05!},decisions:{[c.id]:{status:'accepted',comment:'Checked against the source.',sourceChecked:true}},coverageChecked:true,priorExposure:'no',metadata:{language:'en',bibliography:'Synthetic test report, no DOI.',conflict:'none',conflictDetails:'',operatorConfirmed:true}};
}
