import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {RoundStore} from '../../lib/round-store';
import {blankRoundDraft,type RoundDetail,type RoundDraft} from '../../lib/review-rounds';
import {demoSource} from '../../lib/demo';
export function roundFixture(){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync(`drizzle/${f}`,'utf8'));
 const objects=new Map<string,string>(),reads:string[]=[];
 function prepare(s:string){const bound=(args:unknown[]=[])=>({bind:(...next:unknown[])=>bound(next),first:async()=>sql.prepare(s).get(...args as any[])||null,all:async()=>({results:sql.prepare(s).all(...args as any[])}),run:async()=>({meta:{changes:Number(sql.prepare(s).run(...args as any[]).changes)}})});return bound();}
 const env={DB:{prepare,batch:async(statements:any[])=>{sql.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}}},BUCKET:{put:async(k:string,v:string)=>{objects.set(k,v);},get:async(k:string)=>{reads.push(k);return objects.has(k)?{json:async()=>JSON.parse(objects.get(k)!)}:null;},delete:async(k:string)=>{objects.delete(k);}}} as unknown as {DB:D1Database;BUCKET:R2Bucket};
 objects.set('owner/doc/text.json',JSON.stringify(demoSource));sql.prepare("INSERT INTO documents (id,owner,title,stage,coverage,source_key,source_hash,review,created_at,updated_at) VALUES ('doc','owner','Paper','B','Full text','owner/doc/text.json','hash','{}','now','now')").run();
 const as=(id:string)=>new RoundStore(env,id,`${id}@test.invalid`),owner=as('owner');
 const create=(mode='independent')=>owner.create({documentId:'doc',title:'Round',mode});
 async function join(d:RoundDetail,id:string){const invite=await owner.action(d.round.id,{action:'invite',revision:d.round.revision}) as {token:string};await as(id).join({token:invite.token,name:id});return owner.detail(d.round.id);}
 async function ready(){let d=await create();for(const id of ['alice','bob']){d=await join(d,id);d=await owner.action(d.round.id,{action:'approve',memberId:id,revision:d.round.revision}) as RoundDetail;}d=await owner.action(d.round.id,{action:'start',revision:d.round.revision}) as RoundDetail;return d;}
 const assessment=(summary:string):RoundDraft=>({...blankRoundDraft(null,'v0.5'),metadata:{language:'en',bibliography:'Synthetic source for tests.',conflict:'none',conflictDetails:'',operatorConfirmed:true},reportType:'NC',typeRationale:'A review without primary empirical testing.',summary,coverageChecked:true,priorExposure:'no'});
 return {sql,env,objects,reads,as,owner,create,join,ready,assessment};
}
