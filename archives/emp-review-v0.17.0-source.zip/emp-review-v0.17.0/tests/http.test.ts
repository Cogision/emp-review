import { test } from "node:test";
import assert from "node:assert/strict";
import { readJsonResponse, request } from "../lib/http";

test("framework plain-text 413 produces an actionable upload error", async () => {
  await assert.rejects(readJsonResponse(new Response("Payload Too Large", {status:413})), /10 MB/);
});
test("JSON application validation message is retained", async () => {
  await assert.rejects(readJsonResponse(Response.json({error:"Sprawdź zakres źródła."}, {status:400})), /Sprawdź zakres źródła/);
});
test("HTML gateway errors do not leak HTML or JSON SyntaxErrors", async () => {
  await assert.rejects(readJsonResponse(new Response("<h1>Bad Gateway</h1>", {status:502})), /HTTP 502/);
});
test("malformed success response is not treated as a successful save", async () => {
  await assert.rejects(readJsonResponse(new Response("Not JSON", {status:200})), /Save not confirmed|not confirmed/);
});
test("valid JSON data is returned unchanged", async () => {
  assert.deepEqual(await readJsonResponse(Response.json({id:"document-1"})), {id:"document-1"});
});

test("network errors retain uncertain server outcome and do not blame AI credits",async()=>{
 const original=globalThis.fetch;let calls=0;
 globalThis.fetch=async()=>{calls++;throw new TypeError('Failed to fetch');};
 try{await assert.rejects(request('/api/test'),/server may still be processing/);assert.equal(calls,1);}finally{globalThis.fetch=original;}
});
