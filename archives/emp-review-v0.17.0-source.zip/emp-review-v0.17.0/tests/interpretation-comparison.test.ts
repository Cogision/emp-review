import {test} from "node:test";
import assert from "node:assert/strict";
import JSZip from "jszip";
import {demoAnalysis,demoSource} from "../lib/demo";
import {emptyReview,FAMILIES} from "../lib/emp";
import type {ProjectData} from "../lib/projects";
import {synthesisInput,synthesisFingerprint,validateInterpretation,generateInterpretation} from "../lib/project-interpretation";
import {compareAssessments,type AssessmentState} from "../lib/assessment-comparison";
import {createProjectPackage} from "../lib/project-export";
function fixture():ProjectData{return {project:{id:"project-test",title:"Synthetic project",question:"What is supported?",criteria:"Synthetic only",language:"en",revision:0,created_at:"2026-09-05",updated_at:"2026-09-05"},documents:[{id:"report-a",title:"Synthetic study",stage:"B",coverage:"Full synthetic text",sourceHash:"hash-a",revision:1,createdAt:"2026-09-05",updatedAt:"2026-09-05",studyGroup:"Cohort A",analysis:structuredClone(demoAnalysis),review:structuredClone(emptyReview),source:structuredClone(demoSource)}],generatedAt:"2026-09-05"};}
function output(key="report-a:C01"){return {overview:[{text:"Synthetic overview for testing only",claimKeys:[key]}],findings:[],limitations:[{text:"Unverified synthetic assessments",claimKeys:[key]}],nextQuestions:[]};}
function responseFetch(raw=JSON.stringify(output())):typeof fetch{return async()=>Response.json({status:"completed",output:[{content:[{type:"output_text",text:raw}]}]});}
function state(id="state-a"):AssessmentState{const d=fixture().documents[0];return {document:d,kind:"analysis",meta:{id,document_id:d.id,revision:d.revision,stage:d.stage,source_hash:d.sourceHash,manual_version:"v0.5-core",model:d.analysis!.model||null,actor_type:"ai",created_at:"2026-09-05"}};}

test("synthesis rejects invented, excluded, repeated and schema-invalid references",()=>{
 const data=fixture(),input=synthesisInput(data,"all");const key=input.claims[0].key;
 assert.doesNotThrow(()=>validateInterpretation(JSON.stringify(output(key)),input));
 assert.throws(()=>validateInterpretation(JSON.stringify(output("other:C01")),input),/unknown/);
 assert.throws(()=>validateInterpretation(JSON.stringify(output(key)),synthesisInput(data,"accepted")),/unknown/);
 const bad=output(key);bad.overview[0].claimKeys.push(key);assert.throws(()=>validateInterpretation(JSON.stringify(bad),input),/repeated/);
 assert.throws(()=>validateInterpretation(JSON.stringify({...output(key),invented:12}),input),/incomplete/);
 assert.throws(()=>validateInterpretation("Payload Too Large",input),/valid JSON/);
});
test("synthesis fingerprint detects edits, selection and coverage but ignores view timestamps and row order",async()=>{
 const data=fixture(),base=await synthesisFingerprint(data,"all");data.generatedAt="later";
 assert.equal(await synthesisFingerprint(data,"all"),base);
 assert.notEqual(await synthesisFingerprint(data,"accepted"),base);
 data.project.question+=" Different question";assert.notEqual(await synthesisFingerprint(data,"all"),base);
 const edited=fixture();edited.documents[0].analysis!.claims[0].focal="U";assert.notEqual(await synthesisFingerprint(edited,"all"),base);
 const multi=fixture();multi.documents.push({...structuredClone(multi.documents[0]),id:"report-b"});const h=await synthesisFingerprint(multi,"all");multi.documents.reverse();assert.equal(await synthesisFingerprint(multi,"all"),h);
 const changed=fixture();changed.documents[0].source.warnings.push("Incomplete extraction");assert.notEqual(await synthesisFingerprint(changed,"all"),base);
});
test("AI synthesis request preserves source provenance and audit excludes credentials",async()=>{
 const data=fixture();let sent:any;
 const mock:typeof fetch=async(_u,options)=>{sent=JSON.parse(String(options?.body));return responseFetch()("https://unused");};
 const s=await generateInterpretation(data,"all","en","sk-test-secret","test-model",mock);
 assert.equal(s.model,"test-model");assert.equal(s.input.claims[0].locations[0].exists,true);assert.equal(s.input.claims[0].sourceHash,"hash-a");
 assert.equal(s.audit.request.store,false);assert.equal(s.audit.request.input,sent.input);assert.doesNotMatch(JSON.stringify(s),/sk-test-secret/);
 assert.match(s.audit.request.instructions,/not a fresh full-text review/);
});
test("no eligible claims and oversized input fail before calling the provider; provider failure preserves input",async()=>{
 const data=fixture(),before=JSON.stringify(data);let calls=0;const mock:typeof fetch=async()=>{calls++;return new Response("Bad Gateway",{status:502});};
 await assert.rejects(()=>generateInterpretation(data,"accepted","en","key","model",mock),/No eligible/);assert.equal(calls,0);
 const large=fixture();large.documents[0].analysis!.claims[0].rationale="x".repeat(210000);
 await assert.rejects(()=>generateInterpretation(large,"all","en","key","model",mock),/One assessment/);assert.equal(calls,0);
 await assert.rejects(()=>generateInterpretation(data,"all","en","key","model",mock),/OpenAI API/);assert.equal(JSON.stringify(data),before);
});
test("exports include only matching interpretation in report, retain older snapshot separately",async()=>{
 const data=fixture(),s=await generateInterpretation(data,"all","en","key","model",responseFetch());
 const zip=await JSZip.loadAsync(await (await createProjectPackage(data,"all","en",s)).arrayBuffer());
 assert.match(await zip.file("report.html")!.async("string"),/Synthetic overview for testing only/);
 const word=await JSZip.loadAsync(await zip.file("report.docx")!.async("uint8array"));assert.match(await word.file("word/document.xml")!.async("string"),/Synthetic overview for testing only/);
 data.documents[0].revision++;
 const stale=await JSZip.loadAsync(await (await createProjectPackage(data,"all","en",s)).arrayBuffer());
 assert.doesNotMatch(await stale.file("report.html")!.async("string"),/Synthetic overview for testing only/);
 assert.equal(JSON.parse(await stale.file("project.json")!.async("string")).interpretation.includedInReport,false);
 assert.equal(JSON.parse(await stale.file("synthesis-snapshot.json")!.async("string")).fingerprint,s.fingerprint);
});
test("same C01 in separate reports cannot fabricate a match",()=>{
 const a=state(),b=state("state-b");b.document.id="report-b";b.meta.document_id="report-b";b.document.analysis!.claims[0].statement="An entirely different claim";
 const c=compareAssessments(a,b);assert.equal(c.pairs[0].right,null);assert.equal(c.counts.onlyA,1);assert.equal(c.counts.onlyB,1);
});
test("source/stage/form changes disable formal counts and identical record cannot compare itself",()=>{
 const a=state(),b=state("state-b");assert.throws(()=>compareAssessments(a,a),/different/);
 for(const field of ["source_hash","stage","manual_version"] as const){const other=structuredClone(b);other.meta[field]="different";assert.equal(compareAssessments(a,other).counts.comparable,0);}
});
test("editing claim scope preserves revision pairing but excludes that pair from code counts",()=>{
 const a=state(),b=state("state-b");b.document.analysis!.claims[0].scope.population="Another population";
 const c=compareAssessments(a,b);assert.ok(c.pairs[0].right);assert.equal(c.pairs[0].changedIdentity,true);assert.equal(c.pairs[0].comparable,false);
 assert.ok(c.pairs[0].differences.includes("scope.population"));
});
test("structural and excluded records cannot silently enter substantive agreement",()=>{
 const a=state(),b=state("state-b"),claim=b.document.analysis!.claims[0];b.document.review.decisions[claim.id]={claim,status:"excluded",comment:"out of scope",sourceChecked:false,updatedAt:"now"};
 assert.equal(compareAssessments(a,b).pairs[0].comparable,false);assert.equal(compareAssessments(a,b).counts.excluded,1);
 b.document.review.reportType="NC";assert.equal(compareAssessments(a,b).counts.comparable,0);
});
test("NE/NE and mismatched scope remain separate; U/U does not masquerade as established support",()=>{
 const a=state(),b=state("state-b"),f=FAMILIES[0];
 a.document.analysis!.claims[0].profile[f]="NE";b.document.analysis!.claims[0].profile[f]="NE";
 a.document.analysis!.claims[1].profile[f]="U";b.document.analysis!.claims[1].profile[f]="U";
 let row=compareAssessments(a,b).families[0];assert.deepEqual([row.bothNE,row.assessed,row.sameCode,row.bothU],[1,1,1,1]);
 b.document.analysis!.claims[0].profile[f]="D";row=compareAssessments(a,b).families[0];assert.equal(row.scopeDifference,1);assert.equal(row.assessed,1);
});
test("changes in a substitution or role remain visible even when derived bridge stays unchanged",()=>{
 const a=state(),b=state("state-b");b.document.analysis!.claims[0].substitution="SE2";
 assert.ok(compareAssessments(a,b).pairs[0].differences.includes("substitution"));
 b.document.analysis!.claims[0].role="Unclear";assert.ok(compareAssessments(a,b).pairs[0].differences.includes("role"));
});
test("invalid source quotes are shown but excluded from agreement counts; unordered family sets do not differ",()=>{
 const a=state(),b=state("state-b");b.document.analysis!.claims[0].evidence[0].quote="invented source passage";
 const result=compareAssessments(a,b);assert.equal(result.pairs[0].comparable,false);assert.equal(result.counts.qcPairs,1);
 a.document.analysis!.claims[1].requiredFamilies=[FAMILIES[0],FAMILIES[1]];b.document.analysis!.claims[1].requiredFamilies=[FAMILIES[1],FAMILIES[0]];
 assert.ok(!compareAssessments(a,b).pairs[1].differences.includes("requiredFamilies"));
});
test("legacy Polish export preference produces an English report with the matching English synthesis",async()=>{
 const data=fixture(),s=await generateInterpretation(data,"all","en","key","model",responseFetch());
 const zip=await JSZip.loadAsync(await (await createProjectPackage(data,"all","pl",s)).arrayBuffer());
 assert.match(await zip.file("report.html")!.async("string"),/Synthetic overview for testing only/);
 assert.equal(JSON.parse(await zip.file("project.json")!.async("string")).reportLanguage,"en");
 assert.ok(zip.file("synthesis-snapshot.json"));
});
