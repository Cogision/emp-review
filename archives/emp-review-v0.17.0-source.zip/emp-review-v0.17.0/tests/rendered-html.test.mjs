import assert from "node:assert/strict";
import test from "node:test";
import {readFileSync} from "node:fs";
import {register} from "node:module";
// Render-only smoke test: effects do not run and no storage/AI call is made.
// The production Worker resolves this module in Cloudflare; Node needs an empty binding stub.
register("data:text/javascript,"+encodeURIComponent(`
 export async function resolve(specifier,context,next){
  if(specifier==="cloudflare:workers")return {url:"test:cloudflare-workers",shortCircuit:true};
  return next(specifier,context);
 }
 export async function load(url,context,next){
  if(url==="test:cloudflare-workers")return {format:"module",source:"export const env = {};",shortCircuit:true};
  return next(url,context);
 }
`),import.meta.url);

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

test("renders development preview metadata", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html", "oai-authenticated-user-id":"render-test-user", "oai-authenticated-user-email":"render@example.invalid" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  const html=await response.text();
  assert.match(html, developmentPreviewMeta);
  assert.match(html,/Research projects/);
  assert.match(html,/Account menu for render@example.invalid/);
  assert.match(html,/Open Help &amp; glossary/);
  assert.match(html,/My reviews/);
  assert.match(html,/Saved reports/);
  assert.doesNotMatch(html,/max-h-\[65vh\]/, "The global report sidebar should not occupy the project screen");
  assert.doesNotMatch(html,/Polski|Interface language/);
  assert.match(html,/<html[^>]*lang="en"/);
  const invoke=(pathname,headers={})=>worker.fetch(new Request(`http://localhost${pathname}`,{headers:{accept:'text/html',...headers}}),{ASSETS:{fetch:async()=>new Response('Not found',{status:404})}},{waitUntil(){},passThroughOnException(){}});
  const anonymous=await invoke('/');
  assert.ok([302,303,307,308].includes(anonymous.status),'Anonymous workspace access must start sign-in');
  const signIn=new URL(anonymous.headers.get('location'),'http://localhost');
  assert.equal(signIn.origin,'http://localhost');assert.equal(signIn.pathname,'/login');assert.equal(signIn.searchParams.get('returnTo'),'/');
  const login=await invoke('/login?returnTo=%2F%3Fround%3Dround_123');assert.equal(login.status,200);
  const loginHtml=await login.text();assert.match(loginHtml,/Welcome to EMP Review/);assert.match(loginHtml,/Continue with ChatGPT/);assert.match(loginHtml,/href="\/signin-with-chatgpt\?return_to=%2F%3Fround%3Dround_123"/);assert.match(loginHtml,/target="_top"/);
  const signedIn=await invoke('/login?returnTo=%2F%3Fround%3Dround_123',{'oai-authenticated-user-id':'render-test-user','oai-authenticated-user-email':'render@example.invalid'});
  assert.ok([302,303,307,308].includes(signedIn.status));const returned=new URL(signedIn.headers.get('location'),'http://localhost');assert.equal(returned.pathname,'/');assert.equal(returned.searchParams.get('round'),'round_123');
  const unauthorized=await invoke('/api/account');assert.equal(unauthorized.status,401);
  const join=await invoke('/join');assert.equal(join.status,200);
  const joinHtml=await join.text();assert.match(joinHtml,/Join a review round/);assert.match(joinHtml,/name="referrer" content="no-referrer"/);

});
