import test from 'node:test';
import assert from 'node:assert/strict';
import {nextPendingClaim} from '../lib/review-navigation';
import {demoAnalysis,demoSource} from '../lib/demo';
import {emptyReview,type RecordDoc,type Review} from '../lib/emp';

function fixture():RecordDoc {
 return {id:'navigation',title:'Synthetic report',stage:'B',coverage:'Full text',sourceHash:'synthetic-source',source:structuredClone(demoSource),analysis:{...structuredClone(demoAnalysis),claims:Array.from({length:6},(_,i)=>({...structuredClone(demoAnalysis.claims[0]),id:`C${i}`,primary:i===0}))},review:structuredClone(emptyReview),revision:1,createdAt:'2026-09-05',updatedAt:'2026-09-05'};
}
function decide(d:RecordDoc,id:string,status:Review['decisions'][string]['status']) {
 d.review.decisions[id]={claim:structuredClone(d.analysis!.claims.find(c=>c.id===id)!),status,comment:'Recorded reason',sourceChecked:status==='accepted',updatedAt:'2026-09-05'};
}
test('next decision uses saved overrides and skips all decided outcomes',()=>{
 const d=fixture();decide(d,'C0','accepted');decide(d,'C1','unresolved');decide(d,'C2','excluded');decide(d,'C3','accepted');decide(d,'C4','draft');
 d.review.decisions.C4.claim.statement='Reviewer-corrected text';
 const before=JSON.stringify(d),next=nextPendingClaim(d,'C0');
 assert.equal(next?.id,'C4');assert.equal(next?.statement,'Reviewer-corrected text');assert.equal(JSON.stringify(d),before);
});
test('next decision wraps and unknown IDs start at the first pending claim',()=>{
 const d=fixture();decide(d,'C0','accepted');decide(d,'C5','accepted');
 assert.equal(nextPendingClaim(d,'C4')?.id,'C1');assert.equal(nextPendingClaim(d,'unknown')?.id,'C1');
});
test('all decided, including all unresolved, yields no next draft',()=>{
 const d=fixture();for(const c of d.analysis!.claims)decide(d,c.id,'unresolved');
 assert.equal(nextPendingClaim(d,'C2'),null);d.analysis!.claims=[];d.review=structuredClone(emptyReview);assert.equal(nextPendingClaim(d,''),null);
});
test('human-added draft is reachable and a lone remaining draft stays reachable',()=>{
 const d=fixture();for(const c of d.analysis!.claims)decide(d,c.id,'accepted');
 d.review.decisions.H1={claim:{...structuredClone(d.analysis!.claims[0]),id:'H1',primary:false},status:'draft',comment:'',sourceChecked:false,updatedAt:'now'};
 assert.equal(nextPendingClaim(d,'C5')?.id,'H1');assert.equal(nextPendingClaim(d,'H1')?.id,'H1');
});
