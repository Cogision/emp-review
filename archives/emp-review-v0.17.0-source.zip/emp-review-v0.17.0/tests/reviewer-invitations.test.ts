import {test} from 'node:test';
import assert from 'node:assert/strict';
import {roundFixture} from './helpers/round-fixture';
import {RoundStore} from '../lib/round-store';
import type {CreatedRoundInvitation,RoundDetail} from '../lib/review-rounds';
import {invitationStatus,invitationUrl,recipientEmailSchema} from '../lib/reviewer-invitations';

test('invitation binds authenticated email; a wrong or missing email cannot consume it',async()=>{
 const f=roundFixture(),r=await f.create();
 const invite=await f.owner.action(r.round.id,{action:'invite',revision:r.round.revision,recipientEmail:' Alice@Test.Invalid '}) as CreatedRoundInvitation;
 assert.equal(invite.recipientEmail,'alice@test.invalid');
 await assert.rejects(f.as('bob').join({token:invite.token,name:'Alice',email:'alice@test.invalid'}),/Sign in with the email/);
 await assert.rejects(new RoundStore(f.env,'no-email','').join({token:invite.token,name:'Alice'}),/Sign in with the email/);
 assert.equal(f.sql.prepare('SELECT claimed_by FROM round_invites').get()!.claimed_by,null);
 const alice=new RoundStore(f.env,'alice',' ALICE@test.invalid ');
 assert.equal((await alice.join({token:invite.token,name:'Alice'})).id,r.round.id);
 const pending=await alice.detail(r.round.id);
 assert.equal(pending.round.memberStatus,'pending');assert.equal(pending.source,undefined);assert.equal(pending.invites,undefined);assert.equal(pending.members.length,1);
 assert.equal((await alice.join({token:invite.token,name:'Alice'})).id,r.round.id);
 await assert.rejects(new RoundStore(f.env,'other-id','alice@test.invalid').join({token:invite.token,name:'Other'}),/unavailable/);
});

test('recipient is checked again atomically if invite data changes between read and claim',async()=>{
 const f=roundFixture(),r=await f.create(),invite=await f.owner.action(r.round.id,{action:'invite',revision:r.round.revision,recipientEmail:'alice@test.invalid'}) as CreatedRoundInvitation;
 const batch=f.env.DB.batch.bind(f.env.DB);
 f.env.DB.batch=(async (statements:any[])=>{f.sql.prepare("UPDATE round_invites SET recipient_email='bob@test.invalid'").run();return batch(statements);}) as typeof f.env.DB.batch;
 await assert.rejects(f.as('alice').join({token:invite.token,name:'Alice'}),/unavailable/);
 assert.equal(f.sql.prepare('SELECT claimed_by FROM round_invites').get()!.claimed_by,null);
 assert.equal(f.sql.prepare('SELECT COUNT(*) AS n FROM round_members').get()!.n,0);
});

test('revoked and expired invitations fail; only coordinator can manage recipients',async()=>{
 const f=roundFixture();let d=await f.create();
 const invite=await f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'alice@test.invalid'}) as CreatedRoundInvitation;
 d=await f.owner.detail(d.round.id);
 await assert.rejects(f.as('bob').action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'bob@test.invalid'}),/not found/);
 await assert.rejects(f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'alice@test.invalid'}),/already has/);
 d=await f.owner.action(d.round.id,{action:'revokeInvite',revision:d.round.revision,inviteId:d.invites![0].id}) as RoundDetail;
 await assert.rejects(f.as('alice').join({token:invite.token,name:'Alice'}),/unavailable/);
 const replacement=await f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'alice@test.invalid'}) as CreatedRoundInvitation;
 f.sql.prepare("UPDATE round_invites SET expires_at='2000-01-01T00:00:00.000Z'").run();
 await assert.rejects(f.as('alice').join({token:replacement.token,name:'Alice'}),/unavailable/);
});

test('removing a reviewer before start needs a fresh invitation; consumed tokens cannot be revoked',async()=>{
 const f=roundFixture();let d=await f.create();
 const invite=await f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'alice@test.invalid'}) as CreatedRoundInvitation;
 await f.as('alice').join({token:invite.token,name:'Alice'});d=await f.owner.detail(d.round.id);
 await assert.rejects(f.owner.action(d.round.id,{action:'revokeInvite',revision:d.round.revision,inviteId:d.invites![0].id}),/changed/);
 d=await f.owner.action(d.round.id,{action:'approve',revision:d.round.revision,memberId:'alice'}) as RoundDetail;
 d=await f.owner.action(d.round.id,{action:'reject',revision:d.round.revision,memberId:'alice'}) as RoundDetail;
 await assert.rejects(f.as('alice').detail(d.round.id),/not found/);
 await assert.rejects(f.as('alice').join({token:invite.token,name:'Alice'}),/unavailable/);
 const next=await f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'alice@test.invalid'}) as CreatedRoundInvitation;
 await f.as('alice').join({token:next.token,name:'Alice again'});
 assert.equal((await f.as('alice').detail(d.round.id)).round.memberStatus,'pending');
});

test('recipient emails stay coordinator-only through reveal and export; locked rosters stay locked',async()=>{
 const f=roundFixture();let d=await f.create();
 for(const id of ['alice','bob']){
  const invite=await f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:`${id}@test.invalid`}) as CreatedRoundInvitation;
  await f.as(id).join({token:invite.token,name:id});d=await f.owner.detail(d.round.id);
  assert.equal(d.invites!.some(i=>i.recipientEmail===`${id}@test.invalid`),true);
  d=await f.owner.action(d.round.id,{action:'approve',revision:d.round.revision,memberId:id}) as RoundDetail;
 }
 d=await f.owner.action(d.round.id,{action:'start',revision:d.round.revision}) as RoundDetail;
 await assert.rejects(f.owner.action(d.round.id,{action:'reject',revision:d.round.revision,memberId:'alice'}),/changed/);
 await assert.rejects(f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'new@test.invalid'}),/changed/);
 for(const id of ['alice','bob'])await f.as(id).action(d.round.id,{action:'submit',assessmentRevision:0,draft:f.assessment('Structural review')});
 d=await f.owner.action(d.round.id,{action:'reveal',revision:d.round.revision}) as RoundDetail;
 assert.doesNotMatch(JSON.stringify(await f.as('alice').detail(d.round.id)),/@test.invalid|recipientEmail|token_hash/);
 assert.doesNotMatch(JSON.stringify(await f.owner.export(d.round.id)),/@test.invalid|recipientEmail|token_hash/);
});

test('invalid recipient fails and old unbound codes still work; status distinguishes expiry',async()=>{
 const f=roundFixture(),d=await f.create();
 await assert.rejects(f.owner.action(d.round.id,{action:'invite',revision:d.round.revision,recipientEmail:'not-email'}));
 assert.equal(f.sql.prepare('SELECT COUNT(*) AS n FROM round_invites').get()!.n,0);
 const joined=await f.join(d,'legacy');assert.equal(joined.members[0].status,'pending');
 assert.equal(recipientEmailSchema.safeParse('a@example.org\r\nBcc: b@example.org').success,false);
 const i={id:'i',recipientEmail:null,claimed:false,revoked:false,expiresAt:'2026-01-01T00:00:00.000Z'};
 assert.equal(invitationStatus(i,Date.parse('2026-01-02')),'Expired');
 assert.equal(invitationStatus({...i,claimed:true},Date.parse('2026-01-02')),'Used');
 const link=new URL(invitationUrl('https://example.test','a'.repeat(64)));
 assert.equal(link.pathname,'/join');assert.equal(link.search,'');assert.equal(link.hash,`#invite=${'a'.repeat(64)}`);
});
