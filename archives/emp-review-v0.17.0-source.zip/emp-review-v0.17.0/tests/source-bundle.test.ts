import {test} from "node:test";
import assert from "node:assert/strict";
import {combineSources,getOriginal,originalKey,originalUploads} from "../lib/source-bundle";
import {sourceSchema,quoteExists,type Source} from "../lib/emp";

const paper=(name:string,text:string):Source=>({fileName:name,blocks:[{id:"p1b1",label:"Strona 1",text}],warnings:["Sprawdź ryciny."]});
const a=paper("article.pdf","Primary article result."),b=paper("supplement.pdf","Supplemental validation result.");

test("multiple page-1 blocks retain unique IDs, original file identity and exact grounding",()=>{
 const s=combineSources([a,b]);
 assert.equal(s.blocks.length,2);assert.notEqual(s.blocks[0].id,s.blocks[1].id);
 assert.deepEqual(s.files?.map(f=>f.role),["primary","supplement"]);
 assert.match(s.blocks[1].label,/supplement.pdf/);
 assert.equal(quoteExists({blockId:s.blocks[1].id,quote:b.blocks[0].text},s),true);
 assert.equal(quoteExists({blockId:s.blocks[0].id,quote:b.blocks[0].text},s),false);
 assert.deepEqual(JSON.parse(JSON.stringify(s)).files,s.files);
});
test("selecting another primary preserves file IDs and changes the stored source fingerprint input",()=>{
 const first=combineSources([a,b]),second=combineSources([a,b],1);
 assert.equal(second.files?.find(f=>f.role==="primary")?.fileName,"supplement.pdf");
 assert.deepEqual(first.blocks,second.blocks);assert.notEqual(JSON.stringify(first),JSON.stringify(second));
});
test("malformed manifests, missing file provenance and duplicate primary files are rejected",()=>{
 const s=combineSources([a,b]);
 assert.equal(sourceSchema.safeParse({...s,files:s.files?.map(f=>({...f,role:"primary"}))}).success,false);
 assert.equal(sourceSchema.safeParse({...s,blocks:[{...s.blocks[0],fileId:"f3"}]}).success,false);
 assert.equal(sourceSchema.safeParse({...s,files:undefined}).success,false);
 assert.equal(sourceSchema.safeParse({...s,files:[s.files![0],s.files![0]]}).success,false);
});
test("combined text and block limits are enforced without dropping sources",()=>{
 const big={...a,blocks:Array.from({length:10},(_,i)=>({id:`b${i}`,label:"Part",text:"a".repeat(7000)}))};
 assert.throws(()=>combineSources([big,big]),/120 000/);
 const many={...a,blocks:Array.from({length:301},(_,i)=>({id:`b${i}`,label:"Part",text:"text"}))};
 assert.throws(()=>combineSources([many,many]),/600 fragmentów/);
 assert.throws(()=>combineSources(Array(11).fill(a)),/10 plików/);
});
test("all extraction warnings remain present and identify their file",()=>{
 const s=combineSources([{...a,warnings:Array.from({length:50},(_,i)=>`Missing page ${i}`)},{...b,warnings:Array.from({length:40},(_,i)=>`Table ${i}`)}]);
 assert.equal(s.warnings.length,90);assert.match(s.warnings[50],/f2.*supplement.pdf/);
});
test("downloads use stored manifest, reject foreign IDs and retain legacy links",()=>{
 const s=combineSources([a,b],1);
 assert.equal(getOriginal(s,"1").fileName,"supplement.pdf");
 assert.equal(getOriginal(s,"f1").fileName,"article.pdf");
 assert.throws(()=>getOriginal(s,"f9"),/Nie znaleziono/);
 assert.throws(()=>originalKey("owned/text.json","../../foreign"),/Nieprawidłowy/);
 assert.equal(originalKey("owned/text.json",getOriginal(s,"f2").fileId),"owned/originals/f2");
 assert.equal(originalKey("owned/text.json",getOriginal(a,"1").fileId),"owned/original");
 assert.equal(sourceSchema.safeParse(a).success,true);
});
test("all bundle originals are required and mapped to separate storage keys",()=>{
 const s=combineSources([a,b]),form=new FormData();
 form.set("original_f1",new File(["first"],a.fileName));
 assert.throws(()=>originalUploads(form,s),/f2/);
 form.set("original_f2",new File(["second"],b.fileName));
 const u=originalUploads(form,s);assert.equal(u.length,2);
 assert.deepEqual(u.map(f=>originalKey("source/text.json",f.fileId)),["source/originals/f1","source/originals/f2"]);
 form.append("original_f2",new File(["duplicate"],b.fileName));
 assert.throws(()=>originalUploads(form,s),/Lista oryginałów/);
});
test("server counts aggregate bytes independent of client and content-length",()=>{
 const s=combineSources([a,b]),form=new FormData();
 form.set("original_f1",new File([new Uint8Array(6000000)],a.fileName));
 form.set("original_f2",new File([new Uint8Array(5000000)],b.fileName));
 assert.throws(()=>originalUploads(form,s),/10 MB/);
 const single=new FormData();single.set("file",new File([new Uint8Array(10000000)],a.fileName));
 assert.equal(originalUploads(single,a).length,1);
});
