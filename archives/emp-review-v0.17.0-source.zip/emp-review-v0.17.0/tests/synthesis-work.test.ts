import {test} from 'node:test';
import assert from 'node:assert/strict';
import {demoAnalysis,demoSource} from '../lib/demo';
import {emptyReview} from '../lib/emp';
import type {ProjectData} from '../lib/projects';
import {createSynthesisWork,advanceSynthesisWork,completedSynthesis,SYNTHESIS_CALL_CHARACTERS,type SynthesisWork} from '../lib/synthesis-work';
import {SynthesisWorkStore} from '../lib/synthesis-work-store';
function fixture(n=137,expanded=false):ProjectData{
 const analysis=structuredClone(demoAnalysis);analysis.claims=Array.from({length:n},(_,i)=>({...structuredClone(analysis.claims[0]),id:`C${String(i+1).padStart(3,'0')}`,...(expanded?{rationale:'Detailed assessment text. '.repeat(400)}:{})}));
 return {project:{id:'project-test',title:'Synthetic project',question:'What is supported?',criteria:'Synthetic only',language:'en',revision:0,created_at:'now',updated_at:'now'},documents:[{id:'report-a',title:'Synthetic report',stage:'B',coverage:'Full synthetic text',sourceHash:'hash-a',revision:1,createdAt:'now',updatedAt:'now',studyGroup:'A',analysis,review:structuredClone(emptyReview),source:structuredClone(demoSource)}],generatedAt:'now'};
}
function result(claimKeys:string[],figureKeys:string[]=[]){return {overview:[{text:'A limited pattern in these saved assessments.',claimKeys,figureKeys}],findings:[],limitations:[{text:'These are unverified assessments, not independent studies.',claimKeys,figureKeys}],nextQuestions:[]};}
function mockProvider(seen:string[][]=[]):typeof fetch{return async(_url,options)=>{
 const body=JSON.parse(String(options?.body)),payload=JSON.parse(body.input.slice(body.input.indexOf('\n')+1));
 assert.ok(JSON.stringify(payload).length<=SYNTHESIS_CALL_CHARACTERS);
 let keys:string[];
 if(payload.claims){keys=payload.claims.map((c:any)=>c.key);seen.push(keys);}
 else keys=payload.summaries.flatMap((n:any)=>n.interpretation.overview.flatMap((p:any)=>p.claimKeys));
 const raw=JSON.stringify(result([...new Set(keys)].slice(0,2) as string[]));
 return Response.json({status:'completed',output:[{content:[{type:'output_text',text:raw}]}]});
};}
test('more than 100 claims are all sent in bounded batches and combined, preserving full assessments',async()=>{
 const data=fixture(),original=JSON.stringify(data),seen:string[][]=[];let work=await createSynthesisWork(data,'all','en','test-model');
 assert.ok(work.batchCount>1);
 while(work.tasks.length)work=await advanceSynthesisWork(work,'sk-secret',mockProvider(seen));
 const snapshot=completedSynthesis(work);
 assert.equal(new Set(seen.flat()).size,137);assert.equal(seen.flat().length,137);
 assert.equal(snapshot.input.claims.length,137);assert.equal(snapshot.audit.steps!.filter(s=>s.kind==='assessments').flatMap(s=>s.claimKeys).length,137);
 assert.ok(snapshot.audit.steps!.some(s=>s.kind==='combine'));assert.doesNotMatch(JSON.stringify(snapshot),/sk-secret/);assert.equal(JSON.stringify(data),original);
});
test('37 long assessments also batch by text size, not only claim count',async()=>{
 const work=await createSynthesisWork(fixture(37,true),'all','en','test-model');
 assert.ok(JSON.stringify(work.input).length>200000);assert.ok(work.batchCount>1);
 const assigned=work.tasks.flatMap(t=>t.kind==='assessments'?t.claimKeys:[]);
 assert.equal(assigned.length,37);assert.equal(new Set(assigned).size,37);
});
test('failed step leaves successful progress intact; resume processes only remaining batches',async()=>{
 let work=await createSynthesisWork(fixture(),'all','en','test-model');const seen:string[][]=[];
 work=await advanceSynthesisWork(work,'key',mockProvider(seen));const before=JSON.stringify(work);
 await assert.rejects(()=>advanceSynthesisWork(work,'key',async()=>{throw new Error('offline');}));assert.equal(JSON.stringify(work),before);
 assert.throws(()=>completedSynthesis(work),/not complete/);
 while(work.tasks.length)work=await advanceSynthesisWork(work,'key',mockProvider(seen));
 assert.equal(seen.flat().length,137);assert.equal(completedSynthesis(work).input.claims.length,137);
});
test('combining step cannot cite a real claim absent from its intermediate summaries',async()=>{
 let work=await createSynthesisWork(fixture(),'all','en','test-model');
 while(work.tasks[0]?.kind==='assessments')work=await advanceSynthesisWork(work,'key',mockProvider());
 assert.equal(work.tasks[0].kind,'combine');
 const raw=JSON.stringify(result(['report-a:C050']));
 await assert.rejects(()=>advanceSynthesisWork(work,'key',async()=>Response.json({status:'completed',output:[{content:[{type:'output_text',text:raw}]}]})),/unknown/);
});
class Bucket {
 values=new Map<string,{text:string;etag:string}>();sequence=0;
 async put(key:string,value:string,options?:any){const previous=this.values.get(key);if(options?.onlyIf?.etagMatches!==undefined&&previous?.etag!==options.onlyIf.etagMatches)return null;const etag=String(++this.sequence);this.values.set(key,{text:value,etag});return {etag};}
 async get(key:string){const value=this.values.get(key);return value?{etag:value.etag,json:async()=>JSON.parse(value.text)}:null;}
}
test('owner-scoped checkpoint leases prevent concurrent AI calls and release after failure',async()=>{
 const bucket=new Bucket(),store=new SynthesisWorkStore(bucket as unknown as R2Bucket,'owner-a','project-test');const work=await createSynthesisWork(fixture(),'all','en','model');await store.create(work);
 await assert.rejects(()=>new SynthesisWorkStore(bucket as unknown as R2Bucket,'owner-b','project-test').read(work.id),/not found/);
 let release!:()=>void;const gate=new Promise<void>(r=>{release=r;});let started!:()=>void;const begins=new Promise<void>(r=>{started=r;});let calls=0;
 const first=store.step(work.id,'key',async(...args)=>{calls++;started();await gate;return mockProvider()(...args);});await begins;
 await assert.rejects(()=>store.step(work.id,'key',mockProvider()),/still running/);release();await first;assert.equal(calls,1);
 const before=await store.read(work.id);
 await assert.rejects(()=>store.step(work.id,'key',async()=>{throw new Error('offline');}));
 const after=await store.read(work.id);assert.equal(after.work.completedBatches,before.work.completedBatches);assert.equal(after.work.lockUntil,undefined);
});
test('a single oversized record is identified before inference and no data is truncated',async()=>{
 const data=fixture(1);data.documents[0].analysis!.claims[0].rationale='x'.repeat(210000);
 await assert.rejects(()=>createSynthesisWork(data,'all','en','model'),/report-a:C001.*200,000/);
 assert.equal(data.documents[0].analysis!.claims[0].rationale.length,210000);
});
test('large intermediate summaries combine through multiple bounded levels',async()=>{
 const work=await createSynthesisWork(fixture(20),'all','en','model');
 const dense=(key:string)=>{const paragraph={text:'Limited synthetic interpretation. '.repeat(48),claimKeys:[key],figureKeys:[]};return {overview:[paragraph,paragraph,paragraph],findings:Array.from({length:7},()=>({...paragraph,kind:'gap' as const})),limitations:[paragraph],nextQuestions:[]};};
 // Model a resumed checkpoint with 19 large, previously validated batch results.
 work.nodes=work.input.claims.slice(0,19).map(c=>({claimKeys:[c.key],figureKeys:[],result:dense(c.key)}));
 work.tasks=[{kind:'assessments',claimKeys:[work.input.claims[19].key],figureKeys:[]}];work.batchCount=20;work.completedBatches=19;
 let current=await advanceSynthesisWork(work,'key',mockProvider());
 assert.ok(current.tasks.length>1);assert.ok(current.tasks.every(t=>t.kind==='combine'));
 while(current.tasks.length)current=await advanceSynthesisWork(current,'key',mockProvider());
 assert.equal(completedSynthesis(current).input.claims.length,20);
 assert.ok(current.steps.filter(s=>s.kind==='combine').length>=3);
});
