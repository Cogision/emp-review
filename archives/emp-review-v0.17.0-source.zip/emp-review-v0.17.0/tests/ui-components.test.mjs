import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test, { after } from "node:test";
import { fileURLToPath } from "node:url";

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createServer } from "vite";

const root = fileURLToPath(new URL("..", import.meta.url));
const vite = await createServer({
  appType: "custom",
  configFile: false,
  root,
  resolve: { alias: { "@": root } },
  server: { middlewareMode: true },
});

after(async () => {
  await vite.close();
});

async function readCssTree(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const contents = await Promise.all(
    entries.map(async (entry) => {
      const entryPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        return readCssTree(entryPath);
      }
      return entry.name.endsWith(".css") ? readFile(entryPath, "utf8") : "";
    }),
  );
  return contents.join("\n");
}

test("emits the catalog's animation and scrolling utilities", async () => {
  const css = await readCssTree(path.join(root, "dist"));

  assert.match(css, /--tw-enter-opacity/);
  assert.match(css, /scrollbar-width:\s*thin/);
  assert.match(css, /scrollbar-width:\s*none/);
  assert.match(css, /scrollbar-gutter:\s*stable/);
  assert.match(css, /scroll-fade-reveal-b/);
  assert.match(css, /mask-image:/);
  assert.match(css, /tw-shimmer/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test("forwards progress semantics to the primitive", async () => {
  const { Progress } = await vite.ssrLoadModule("/components/ui/progress.tsx");
  const html = renderToStaticMarkup(React.createElement(Progress, { value: 37 }));

  assert.match(html, /aria-valuenow="37"/);
  assert.match(html, /aria-valuetext="37%"/);
  assert.match(html, /data-state="loading"/);
});

test("emits chart themes for the starter's media dark mode", async () => {
  const { ChartStyle } = await vite.ssrLoadModule("/components/ui/chart.tsx");
  const html = renderToStaticMarkup(
    React.createElement(ChartStyle, {
      id: "contract",
      config: {
        latency: { theme: { light: "#ffffff", dark: "#000000" } },
      },
    }),
  );

  assert.match(html, /\[data-chart=contract\]/);
  assert.match(html, /@media \(prefers-color-scheme: dark\)/);
  assert.doesNotMatch(html, /\.dark/);
});

test("renders sidebar skeletons deterministically", async () => {
  const { SidebarMenuSkeleton } = await vite.ssrLoadModule(
    "/components/ui/sidebar.tsx",
  );
  const first = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));
  const second = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));

  assert.equal(first, second);
  assert.match(first, /--skeleton-width:70%/);
});

test('assessment controls expose separate help buttons and associated selected-code guidance', async () => {
  const { Choice, TextField } = await vite.ssrLoadModule('/components/claim-editor.tsx');
  const html=renderToStaticMarkup(React.createElement(Choice,{label:'Support for this exact claim',value:'N0',options:['D','I','N0','U'],onChange(){}}));
  assert.match(html,/aria-label="Help: Support for this exact claim"/);
  const id=html.match(/<label for="([^"]+)"/)[1];
  assert.ok(html.includes(`id="${id}"`));
  assert.ok(html.includes(`aria-describedby="${id}-hint"`));
  assert.match(html,/permitted source bundle reports no relevant evidence/);
  assert.doesNotMatch(html,/<label[^>]*>[^<]*<button/);
  const text=renderToStaticMarkup(React.createElement(TextField,{label:'Use predicate',helpId:'claim',value:'Example',onChange(){}}));
  const textId=text.match(/<label for="([^"]+)"/)[1];
  assert.ok(text.match(/<textarea[^>]*>/)[0].includes(`id="${textId}"`));
  assert.match(text,/aria-label="Help: Use predicate"/);
});

test('collection overview keeps scope warnings visible and methods collapsed across filters', async () => {
  const { default: Overview } = await vite.ssrLoadModule('/components/collection-overview.tsx');
  const { synthesise } = await vite.ssrLoadModule('/lib/projects.ts');
  const { demoAnalysis, demoSource } = await vite.ssrLoadModule('/lib/demo.ts');
  const { emptyReview } = await vite.ssrLoadModule('/lib/emp.ts');
  const analysis=structuredClone(demoAnalysis);
  analysis.automatic={inventoryComplete:false};
  const data={project:{id:'example'},documents:[{id:'example-report',analysis,source:demoSource,review:emptyReview,studyGroup:''}],generatedAt:'2026-09-05'};
  const render=filter=>renderToStaticMarkup(React.createElement(Overview,{data,summary:synthesise(data,filter),filter,onFilter(){}}));
  const all=render('all'),visible=all.split('<details')[0];
  assert.match(visible,/1 report has a claim list flagged as incomplete by AI/);
  assert.match(visible,/Exploratory scope includes drafts, unresolved decisions and unverified AI proposals/);
  assert.match(visible,/Needs checking in view/);
  assert.doesNotMatch(visible,/0 unavailable|0 structural|Form coverage|No meta-analysis/);
  assert.doesNotMatch(all,/<details[^>]*\bopen(?:=|\s|>)/);
  assert.match(all,/Scope &amp; methodology/);
  assert.match(all,/No meta-analysis/);
  const accepted=render('accepted');
  assert.match(accepted,/No claim assessments meet this filter yet/);
  assert.match(accepted,/Explore all active assessments/);
  assert.match(accepted,/assessments hidden by this filter/);
  assert.match(accepted.split('<details')[0],/1 report has a claim list flagged as incomplete by AI/);
});


test('reviewer access panel labels email, renders real invite states and locks actions',async()=>{
 const {default:Panel}=await vite.ssrLoadModule('/components/round-invitations-panel.tsx');
 const invites=[
  {id:'expired',recipientEmail:'old@example.invalid',expiresAt:'2000-01-01',claimed:false,revoked:false},
  {id:'live',recipientEmail:'new@example.invalid',expiresAt:'2099-01-01',claimed:false,revoked:false},
  {id:'legacy',recipientEmail:null,expiresAt:'2099-01-01',claimed:true,revoked:false},
 ];
 const html=renderToStaticMarkup(React.createElement(Panel,{invites,disabled:true,onCreate:async()=>{},onRevoke:async()=>{}}));
 assert.match(html,/Reviewer email/);assert.match(html,/type="email"/);assert.match(html,/Expired/);assert.match(html,/Awaiting reviewer/);assert.match(html,/Legacy invitation code/);assert.match(html,/Used/);
 assert.equal((html.match(/Revoke invitation/g)||[]).length,1);
 assert.doesNotMatch(html,/Email sent|Access granted/);
 for(const button of html.match(/<button[^>]*>/g)||[])assert.match(button,/disabled/);
});

test('automatic analysis has one claim bar and distinct pause, export and completion states',async()=>{
 const {default:Panel}=await vite.ssrLoadModule('/components/automatic-progress.tsx');
 const current={id:'one',title:'Example publication',phase:'claims',completed:22,total:38};
 const render=(overrides={})=>renderToStaticMarkup(React.createElement(Panel,{items:[current],running:true,stopping:false,exportReady:false,onStop(){},onResume(){},onDownload(){},error:'',...overrides}));
 const single=render();assert.equal((single.match(/role="progressbar"/g)||[]).length,1);assert.match(single,/22 of 38 claims assessed/);assert.doesNotMatch(single,/Completed publications|Publication details|Resume analysis/);
 const batch=render({items:[{id:'done',title:'Earlier report',phase:'complete',completed:10,total:10},current,{id:'next',title:'Next report',phase:'waiting',completed:0,total:0}]});
 assert.equal((batch.match(/role="progressbar"/g)||[]).length,1);assert.match(batch.replace(/<!--[\s\S]*?-->/g,''),/1 of 3 publications complete/);assert.match(batch,/<details[^>]*>/);assert.doesNotMatch(batch,/<details[^>]*\bopen/);
 const paused=render({running:false});assert.match(paused,/Analysis paused/);assert.match(paused,/Resume analysis/);assert.doesNotMatch(paused,/Pause after this step|animate-spin/);
 const exporting=render({exporting:true,exportReady:true});assert.match(exporting,/Preparing Word forms/);assert.doesNotMatch(exporting,/role="progressbar"|Pause after this step|Resume analysis|Download Word forms/);
 const complete=render({items:[{...current,phase:'complete',completed:38}],running:false,exportReady:true});assert.match(complete,/Analysis complete/);assert.match(complete,/Download Word forms/);assert.doesNotMatch(complete,/Resume analysis|role="progressbar"/);
 const empty=render({items:[{...current,total:0,completed:0}]});assert.doesNotMatch(empty,/role="progressbar"|NaN|Infinity/);
 const failed=render({items:[{...current,phase:'error',error:'Connection interrupted.'}],running:false});assert.match(failed,/Analysis needs attention/);assert.match(failed,/Retry unfinished analyses/);assert.match(failed,/role="alert"/);assert.doesNotMatch(failed,/Analysis complete/);
 const reviewable=render({items:[{...current,phase:'complete',completed:38}],running:false,exportReady:true,onReview(){},onDismiss(){}});
 assert.match(reviewable,/Review claims/);assert.match(reviewable,/Dismiss/);assert.doesNotMatch(reviewable,/role="progressbar"/);
 const active=render({onReview(){},onDismiss(){},exportReady:true});assert.doesNotMatch(active,/>Dismiss<|>Review claims</);
});

test('claim inventory retains scientific scope, source checks and structural report routing',async()=>{
 const {default:Inventory}=await vite.ssrLoadModule('/components/claim-inventory.tsx');
 const {demoAnalysis,demoSource}=await vite.ssrLoadModule('/lib/demo.ts');
 const {emptyReview}=await vite.ssrLoadModule('/lib/emp.ts');
 const document={analysis:structuredClone(demoAnalysis),source:demoSource,review:structuredClone(emptyReview)};
 const props={document,disabled:false,onOpen(){},onAdd(){},onContinue(){},onCoverage(){}};
 const html=renderToStaticMarkup(React.createElement(Inventory,props));
 assert.match(html,/Check the claim list/);assert.match(html,/not an independent study/);assert.match(html,/Continue to assessments/);
 assert.doesNotMatch(html,/<details[^>]*\bopen/);assert.match(html,/I have checked the source for missed claims/);
 document.review.reportType='NC';
 const structural=renderToStaticMarkup(React.createElement(Inventory,props));
 assert.match(structural,/Check report summary/);assert.doesNotMatch(structural,/Add a missed claim|Continue to assessments/);
 const locked=renderToStaticMarkup(React.createElement(Inventory,{...props,disabled:true}));
 const mainButton=(locked.match(/<button[^>]*>[\s\S]*?Check report summary[\s\S]*?<\/button>/)||[])[0];
 assert.ok(mainButton);assert.match(mainButton,/disabled/);
});
