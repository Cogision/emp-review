import { test } from "node:test";
import assert from "node:assert/strict";
import nextConfig from "../next.config.ts";

// Exercise the installed runtime guard that rejected real multipart uploads,
// without a browser, network calls, or test documents in production storage.
const vinextEntry = import.meta.resolve("vinext");
const { handleProgressiveServerActionRequest, readActionFormDataWithLimit } =
  await import(new URL("./server/app-server-action-execution.js", vinextEntry));
const { parseBodySizeLimit } = await import(new URL("./config/next-config.js", vinextEntry));
const configuredLimit = parseBodySizeLimit(nextConfig.experimental.serverActions.bodySizeLimit);

async function uploadRequest(size) {
  const form = new FormData();
  form.set("source", JSON.stringify({text:"Przykład tekstu źródłowego"}));
  form.set("file", new Blob([new Uint8Array(size)], {type:"application/pdf"}), "transport-test.pdf");
  const req = new Request("https://emp.test/api/documents", {
    method:"POST", body:form, headers:{Origin:"https://emp.test",Host:"emp.test"},
  });
  req.headers.set("Content-Length", String((await req.clone().arrayBuffer()).byteLength));
  return req;
}
async function preflight(request, maxActionBodySize) {
  let fileSize = null;
  const response = await handleProgressiveServerActionRequest({
    request, contentType:request.headers.get("content-type"), actionId:null,
    maxActionBodySize, allowedOrigins:[], clearRequestContext(){},
    readFormDataWithLimit:readActionFormDataWithLimit,
    async decodeAction(form){fileSize=form.get("file").size;return null;},
  });
  return {response,fileSize};
}
test("reproduce the original 8 MB multipart rejection under the runtime default", async () => {
  const {response} = await preflight(await uploadRequest(8_000_000), 1024*1024);
  assert.equal(response.status,413);
  assert.equal(await response.text(),"Payload Too Large");
});
test("configured runtime admits 8 MB and the advertised 10 MB upload", async () => {
  for (const size of [8_000_000,10_000_000]) {
    const {response,fileSize} = await preflight(await uploadRequest(size), configuredLimit);
    assert.equal(response,null); // normal API routing continues
    assert.equal(fileSize,size);
  }
});
test("runtime still rejects multipart bodies beyond the bounded limit", async () => {
  const {response} = await preflight(await uploadRequest(configuredLimit+1), configuredLimit);
  assert.equal(response.status,413);
});
