# Public source snapshot: EMP Review v0.25.0

Source commit: 286761ca039b710820aa824f9e6890f7c3284cc6
Published application: https://emp-review-focal.dw1975.chatgpt.site

This archive contains the application source, lockfile, tests and database migrations through 0011. It is a source backup, not a backup of user accounts, uploaded reports or the running database.

## Private pilot material

The tracked `lib/pilot-import-data.server.json` in the deployed environment bundles user-supplied full texts, original PDFs and pilot assessments. In this public archive it is replaced by an empty JSON array (`[]`). This excludes those source documents from public redistribution while preserving the application's import contract. General source upload, analysis, review, projects, reconciliation and deletion remain in the source.

The owner-specific preloaded five-paper pilot requires the separately retained private bundle. Dataset-dependent tests in `tests/pilot-import.test.ts` likewise require it. The deployed application and its existing data are unaffected by this archive substitution.

## Deployment identity

The original `.openai/hosting.json` is retained as provenance. Adapt its project identifier before publishing an independent copy; do not deploy a fork to the original Site. Configure your own runtime resources and secrets. See `README.md` for development and build instructions.

## v0.25 changes

- Compare two to five saved or imported AI analyses of the same source, with explicit claim/scope differences.
- Request a single source-grounded recommended draft, keep originals and resume saved progress.
- Delete completed reports from the workspace, with project and working-draft cleanup; frozen review-round copies remain separate.

The application source was typechecked and built before publication; focused logic and UI rendering tests passed. This public archive excludes the private pilot dataset described above.
