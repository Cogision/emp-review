## App 0.24.0: recoverable drafts and actionable article reviews

Working drafts now save to the signed-in account, separately from the source and confirmed assessment. This covers per-claim detailed edits, review and AI-correction notes, initial focal selection, reporting settings, source import text and original files, and the last article/step. Draft metadata uses an account-scoped D1 record; immutable payloads and original uploads use R2. Migration 0010 adds only the draft table. Separate draft revisions reject concurrent overwrites. Stale assessment drafts remain available to download, and restoring text never restores an unsubmitted source-check confirmation. Wait for the saved indicator before closing; failures preserve the open text and offer recovery. Project, figure and independent round forms retain their existing explicit save actions.

Article evidence and summary show a contextual next task leading to the relevant claim and source passage. Three correction routes distinguish checking an AI reading, recording a possible narrower wording and specifying a missing test. Narrower wording and missing-test notes are reviewer working annotations, included as such in the short HTML summary. They never replace an authorial claim or change its classification, review status or percentage denominator. Scientific coding rules and the same-claim comparison protocol remain unchanged.

The Site display name is EMP Review, without a release number in sign-in. The current app version remains available inside the workspace. Validation covers draft ownership, concurrent writes, recovery after reload, clear/write races, next-task routing and preservation of original assessment data. Browser and live authenticated AI execution are not covered by these local checks.

Historical release notes follow.

## App 0.23.1: stable navigation and readable claim percentages

Article steps share one retained workspace. Moving between evidence, source and summary keeps the selected claim, review note and unsent AI notes. Saved revisions invalidate source confirmations and stale AI proposals without deleting text. Project and round panels retain their state when an article is opened; returning to a project refreshes its data without resetting its results view. The current article or unfinished source import can be resumed from other workspace screens. Destructive replacement still warns about the affected unsaved work. Drafts are kept in the open workspace, not persisted across reloads.

Claim outcomes (%) is visible near the top of project Results. Its optional expanded view selects one existing collection/material/review-status stratum and shows one table with explicit counts, denominator and plain-language outcome descriptions. Different methods remain selectable without pooling them. Missing denominators and blocked assessments retain their explanation and never display a fabricated 0%. Scientific classification and calculation rules are unchanged.

Historical release notes follow.

## App 0.23.0: guided article review and shared projects

Home offers one article or a project. Article review follows Source → Claims → Evidence & links → Summary. The two checkpoints are claim selection and source-checked final assessment. Each active claim has its own row and review status; the final form changes only explicitly selected rows. Scientific uncertainty remains unresolved. Evidence adequacy remains separate from inference type; no aggregate quality score is introduced. Full coding and provenance remain available on demand.

The printable five-column summary preserves quotations, source identity, original/current claim comparisons and row-level verification. AI checks can target central or contextual claims without changing the selected proposition, role or quotation. Linked additional sources remain separate assessments. Changed propositions are visibly unsuitable for direct before/after comparison. Counts lead project results; central-claim and all-claim-category percentages are optional.

Projects add an optional category, goal and planned article count. Existing reports can be attached. Email-bound project invitations require authenticated sign-in and owner approval. Project members receive the article inventory and links to their assigned rounds; they do not receive private source objects, owner assessments, independent drafts or project management rights. Round invitations and approvals remain separate; approved project collaborators can be selected when inviting a reviewer. Removing project membership does not revoke an independently assigned round. No real invitations are sent by this change.

Migration 0009 adds project metadata and membership/invitation/event tables while preserving existing records. Regression checks cover source/claim identity, unresolved decisions, per-row verification, invitation races and isolation of project and round permissions. AI execution and authenticated multi-account interaction are not exercised by these local tests.

Historical release notes follow.

## App 0.18.0: one central claim, one publication profile

The default flow is **save source → confirm focus → review publication profile**. AI selects one central authorial claim and zero to two contextual claims, based on the main objective and take-home conclusion before evidence judgments. Reviewers can change the selection, statement and exact quotation before confirming it. The confirmed selection is checkpointed and grounded in the saved source; AI assessment cannot start beforehand. Interrupted assessments resume at the next unfinished claim. Selection edits survive a failed confirmation request and use the unsaved-change guard.

The short publication profile shows the central claim, what the study shows, evidence required, the suggested or reviewed bridge judgment, and the existing five independent EMP evidence-family cells. Contextual claims, source quotations, full coding and further source-stage work are available on demand. A printable HTML report preserves scope, review status and provenance. This changes selection and presentation, not the normative v0.5 coding rules.

Project Synthesis opens with publication-level comparisons. EI is B2 divided by included clinical-use (CB) reports, using only each report's active central claim. The default includes source-checked reviewer decisions, including unresolved decisions in the denominator. Pending reports are counted separately. An explicit provisional view includes AI proposals. Source stages, focal versus legacy selection, and full versus core field coverage are separate strata. Contexts never add observations or upgrade the central profile. M, NC and NMC reports are outside the EI denominator. Duplicate document IDs count once; duplicate article uploads still require manual reconciliation. These are descriptive collection statistics, not field prevalence, a quality score or independent-dataset counts.

Import accepts files, pasted text, or a PubMed link/PMID/DOI. The identifier lookup uses the fixed [Europe PMC REST endpoint](https://europepmc.org/RestfulWebService), exact record matching and bounded responses. The user checks the retrieved title and abstract before saving a Stage A source with retrieval provenance. Missing abstracts are explicitly unavailable. Arbitrary URLs, automatic full-text retrieval and inferred abstracts are not supported.

Existing comprehensive runs, original proposals, reviewer rounds, adjudications and detailed exports remain available. No database migration or data deletion is required. Full text can be added as another source-stage review; automated stage pairing, duplicate-article merging and blind A/B comparison are not implemented. Focal review is an exploratory protocol and does not claim validated reviewer reliability. Foreground AI steps still require the tab to remain open; completed checkpoints can be resumed later. Live authenticated model execution and multi-account reviewer testing require the configured application and are not covered by mocked regression tests.

Historical release notes follow.

## App 0.17.0: task-focused review workflow

- Projects open on Reports, with separate Review and Synthesis views. The next-action button opens pending work directly. Panels stay mounted so tab changes preserve figure selections and synthesis state.
- Source import happens before preparation. Full EMP v0.5 AI, independent full-form rounds, core AI and core manual preparation have explicit labels. Full-form preparation remains restricted to full texts. Separate publications are the default import mode; supplements can be bundled explicitly.
- AI completion opens the claim inventory and never starts a Word download. Completed progress can be dismissed. Saved reports are available on demand, without a global document sidebar.
- The claim inventory has the completeness check. Assessment view focuses on one claim, its quotation, evidence and decision. Save decision & next advances only after a successful save to the next draft, including wraparound; Save draft stays put. Unresolved and excluded are completed decisions, not claims of scientific support.
- Report files, figures, versions, source context and extra quotations are available on demand. Scientific coding fields and validation are preserved.
- Review rounds separate My review, Manage round and Compare & agree. Role and release gates remain enforced. Switching panels retains one-time invitation links; supplied invitation codes no longer require re-entry.
- Synthesis opens with accepted, source-checked scope. Exploratory all-active scope is explicit and does not filter the Review queue. One selected assessment per report and separate approved figure selections remain the basis. Export retains current-input fingerprint validation.
- Help recipes and term explanations follow the new navigation. Account profiles and sign-in from 0.16.0 remain available through the account menu.

## App 0.16.2: Source preview on demand

- The extracted source preview starts collapsed under Source text, before and during analysis.
- Expanding it reveals the original extraction notes and passages; the assessment Source tab and quotation navigation are unchanged.

## App 0.16.1: Clear analysis progress

- A single progress panel per analysis mode. Automatic analysis shows the current publication’s saved claim count; batch totals remain text.
- Source text stays available during analysis, while the preparation card and start controls are hidden.
- Paused, failed, completed and Word preparation states have distinct messages and actions. Completed queues no longer show Resume.
- Pause displays the latest saved checkpoint, including the step that just finished.

## App 0.16.0: Account and sign-in

- Dedicated `/login` page with ChatGPT sign-in and safe return to the requested workspace or round.
- Account menu with Profile & settings, AI connection and guarded sign-out.
- A persistent account profile stores display name and optional affiliation in D1, scoped to the authenticated user ID. Email is read-only from the sign-in identity.
- Profile updates use revision checks; they never rename existing round members or immutable submissions. Saved names prefill future reviewer forms.
- Profile edits prompt before dismissal; AI keys remain in tab memory. Settings respect active project and round operations.

## App 0.15.0: People & access

Each coordinated round now has a People & access panel: create an invitation for a reviewer’s ChatGPT email, copy a sign-in link or open an email draft, inspect invitation and membership status, revoke unused invitations, and approve or decline join requests. Approved reviewers can be removed before the roster locks. The panel does not send email automatically or change the Sites audience. Private documents and projects remain owner-scoped. If the Site audience is restricted, the owner must separately grant Site access.

New email-bound invitations require both the one-time code and the matching authenticated email; membership is still attached to the stable authenticated user ID and requires coordinator approval. Recipient addresses are shown only to the coordinator and excluded from shared events and exports. Invitations expire after seven days. Their raw codes are shown at creation only; legacy unbound codes remain valid under their original rules. Join links carry the code in a URL fragment. A temporary, 30-minute tab-local handoff preserves it across ChatGPT sign-in, and is cleared after joining; it is never the authority for access. A manual-code fallback remains available when browser storage is unavailable. Root workspace navigation now initiates ChatGPT sign-in before loading private APIs.

The panel governs round membership, not application-wide administrator privileges or platform sharing. Existing rounds, locked submissions, adjudications and the manual version remain unchanged. No invitations to real people were created during development.

## App 0.14.1: compact collection overview

The project overview now has one count row, a filter, conditional notices and a collapsed Scope & methodology section. It replaces the repeated narrative and duplicate project-header metrics. Pending analyses, AI-flagged incomplete inventories and unavailable figure selections remain visible when present. Accepted-only and empty views explain their scope. Export narratives and synthesis calculations are unchanged.

## App 0.14.0: contextual help and glossary

English help now includes 62 searchable topics, practical workflow guides, eight common distinctions, troubleshooting and the bundled normative v0.5 coding reference. Field help opens by pointer, keyboard or touch, with examples and code definitions; selected code meanings stay visible below coded controls. All full v0.5 fields have explicit topic mappings. Context links connect review rounds, adjudication, field comparison, project synthesis, figures and versions to the same guidance. Help opens without navigation, changing the assessment or calling AI. Manual v0.5 and saved assessments are unchanged.

## App 0.13.0: resumable project synthesis

The 100-claim / 200,000-character bound now applies to each AI request, not the whole collection. Larger inputs are partitioned without truncating selected assessment or figure records, then intermediate syntheses are combined in bounded rounds. Each completed step is checkpointed with an owner-scoped conditional lease. The UI can pause after a step and resume a frozen input snapshot after a failure or reload. More steps mean more time and API usage. The final qualitative narrative is selective; the snapshot retains every original input and every intermediate request/output, including explicit processing coverage. References validate provenance, not semantic correctness.

Existing project limits (100 reports / 12 MB loaded source and assessment data) still apply. A single record plus shared project metadata must fit one 200,000-character call; an oversized record is identified before inference. Output is never silently shortened to fit. Summary combination can lose nuance and remains unverified. No change to Manual v0.5.

# Current product: English-only UX (app 0.12)

The interface, new analysis requests, new project syntheses and Word template labels are English. Historical records retain their original language and manual version. The coding manual remains v0.5.

Word exports detect Polish passages (including common unaccented Polish words) and translate those passages through the configured AI connection. A visible `[English translation T…]` label identifies each changed passage, including quotations. `english-translations.json` records the original and English text. Original JSON/CSV data, quotations and hashes are not rewritten. Numeric values and coding tokens are checked, missing/invalid translations fail the export, and saved analysis remains available. This is presentation translation, not scientific recoding or a guarantee of semantic equivalence. Names and source identifiers may retain their original spelling. Detection is designed for the previous Polish/English workflow, not arbitrary-language detection. Existing English exports do not call the translation API. Project source JSON can be downloaded separately without AI.

Same-document tabs retain unsaved edits. Leaving an import or claim warns before discarding; summary actions respect unsaved drafts and source view has a return action. Project details are protected when closing their editor. Messages distinguish saved records, failed requests and export preparation. Stale module errors still advise saving and reloading without rerunning analysis.

Historical release notes follow; language options described below apply to those older releases only.

# EMP Review — MVP

Private EMP Review workspace: assisted and automated reviews, full v0.5 reviewer rounds, and project synthesis from explicitly selected assessments.

## Use
Import up to ten PDF, DOCX, TXT/MD files at once or paste text. Choose one article with supplements, or sequential separate publication imports. Declare the source stage and missing material. Run AI analysis, inspect exact source passages, edit suggestions, accept or mark unresolved, then check for omitted claims and export JSON/CSV. The training example is synthetic and clearly labelled.

## AI connection
The server calls OpenAI Responses API. A server-side `OPENAI_API_KEY` may be supplied as a secret through Sites runtime settings; optional `OPENAI_MODEL` defaults to `gpt-4.1`. The UI also supports a session-only key kept in React memory and sent to the authenticated server only for analysis or an explicitly requested connection test. It is never stored in D1/R2, browser storage or history. Provider billing is separate. No live model call was verified without a supplied key.

## Persistence and provenance
D1 stores owner-scoped documents, immutable original model proposals, human reviews, and append-only revision events. R2 stores source text and original files. Every API operation checks the authenticated user ID. Optimistic revision checks prevent stale updates. Source text has a SHA-256 hash; exports preserve the source, model, prompt version, raw proposal and human history. CSV is a compact convenience table, not the complete manual workbook.

## Methodological scope
This is an assisted calibration/review workflow, not blinded independent coding or a claim of full v0.5 validation. The core implements five independent profile cells, focal support, separate adequacy, substitution/conditions and B0–B3/BU/BNA derivation. SEU overrides resolved codes. Each CB/M assessment has one primary claim. No profile sum, maturity score or gap distance is calculated. The focal comparison provides descriptive EI proportions for the selected collection, with explicit denominators and source-stage strata; these are not field prevalence. The full v0.5 workbook contains additional fields and validation-study procedures not implemented here: blind A/B locking/pairing, transition taxonomy, complete sampling/register management, and complete validation-study functionality. Reviewer-round adjudication is implemented separately and does not assert inter-rater reliability. Automatic v0.5 analysis adds the nine categorical scope fields, observation/timing/source descriptors, readout equivalence with a citation, normative commitment/condition codes, warrant fields, and the reconstruction annex. Separate imports preserve source stages but do not establish blinded independence.

## Limits
PDF text layer only (up to 80 pages); no automatic PDF figure extraction, OCR, full-text literature retrieval or supplement discovery. Abstract lookup is available for PubMed identifiers and DOIs through Europe PMC. Separate uploaded figures have optional visual interpretation as described below. 10 MB originals in total and 120,000 extracted characters per review (for separate publication imports: 10 MB per file), the default focal mode selects 1 central claim plus up to 2 contexts; legacy assisted mode proposes up to 12 claims; comprehensive automated mode inventories up to 80 material claims and assesses each separately. If the model reports an incomplete inventory, exports explicitly report that limitation. Source warnings are visible; missing extraction must not be interpreted as absent evidence. Claims can be added by the reviewer. AI generation uses schema validation and exact quotation checks; semantic accuracy still requires review. No evidence of improved human reliability is claimed.

## Development
`npm run test:core` tests consequential rule and grounding cases. `npx tsc --noEmit` checks types. Use the Sites build and publish workflow. Generated Drizzle migrations own schema changes; runtime does not initialize tables. No browser QA or live AI call was performed in the build environment.

## Primary integration references
[OpenAI structured responses](https://developers.openai.com/api/docs/guides/structured-outputs), [PDF.js examples](https://mozilla.github.io/pdf.js/examples/), [Mammoth text extraction](https://github.com/mwilliamson/mammoth.js).

## AI troubleshooting
Settings trim surrounding whitespace, support fine-tuned model IDs containing colons, and use the configured default for an empty model field. Invalid key/model fields receive specific messages. The optional “Sprawdź połączenie” button makes a small billed Responses API request using the chosen key, model and JSON format, without sending a document. Success verifies this short request only, not long-document completion or semantic accuracy. There is no automatic switch to another model or automatic retry.

Provider errors expose only bounded diagnostic identifiers (HTTP status, code, parameter and request ID); raw provider messages, API keys and source text are never logged. Analysis errors stay visible until the document is changed or a new analysis starts. Failed analysis does not replace a saved result. The JSON requirement is explicit in both instructions and input. Regression tests mock upstream Responses and cover successful output, rejected parameters, access/quota errors and incomplete responses. A real user-account model call still requires the session key and has not been verified by the development environment.

## Multiple source files
A combined review has exactly one primary article and up to nine supplements. Its source manifest records file names and roles; every block has a short file-prefixed identifier, fileId and file-labelled locator. This manifest is included in the source hash and JSON export; CSV includes the claim's source file. Every original can be downloaded separately through the authenticated owned document. Deletion removes the entire bundle. Old single-file records remain readable.

Separate publications are uploaded sequentially in individual requests and remain separate reviews. The UI preserves successful imports after partial failure and retries only unfinished entries; repeated import IDs return the existing identical review. Each upload attempt uses an isolated R2 prefix to avoid concurrent retries overwriting sources. Definite pre-commit storage failures are cleaned up; database errors with an unknown commit outcome retain objects until the outcome can be established. In assisted mode import does not launch paid analysis. In automatic mode the explicit “Przeanalizuj i eksportuj v0.5” action authorizes the entire sequential queue. Uploaded source and review histories are immutable; add a new review to analyse a different source bundle.

The 12 MB request guard remains in place. Actual file sizes and the combined 120,000-character/600-block limits are checked on the server. Files that exceed limits or fail extraction are shown explicitly; no source text or extraction warning is silently discarded. Manifests and quote matching are covered by multi-file regression tests.


## Automatic v0.5 workflow
Choose **Automatyczny · analiza i formularze Word v0.5**, full-text Stage B, and either one article plus supplements or separate publications. One action imports, inventories material authorial claims, codes every enumerated claim, and downloads a ZIP containing one filled English DOCX form with the original field layout per claim (or a structural form for NC/NMC), a report summary, complete JSON data, and exact request/output audit annexes. The source form/manual is the user's `EMP_missing_bridge_manual_and_tool_v0_5_2026-09-04.zip`, dated 4 September 2026. `public/templates/EMP_Coding_Form_v0_5.docx` preserves the form's field layout and uses local replacement tokens; the normative coding instructions in `lib/manual-v05.ts` are derived from the original manual's coding sections.

This mode is Stage B only. It never fabricates an earlier Stage A record, a human signature, independent coder, or adjudication. The optional transition module is prospectively Disabled. Model uncertainty remains coded as permitted by each field; a full run is not a claim of validated completeness or semantic correctness. Reviewer corrections can be saved and included in subsequent form exports; original model outputs remain separately available. Excluded claims remain in JSON but are omitted from substantive forms.

Each AI step is a separate bounded request with immutable R2 request/output and checkpoint objects, linked by an owner-scoped D1 revision event. The request audit includes the exact effective application instructions, model input and parameters, and hashes; it never includes the API key or Authorization header. No provider snapshot is inferred from a model alias. No previous_response_id, tool/browsing access or chat memory is supplied. The detail step sees its own inventory candidate. The full manual's worked examples are disclosed in the annex.

The browser runs the sequential queue and should stay open. Pause stops before the next stage, after the current request completes. To resume after a refresh, open the saved document and use **Analiza automatyczna v0.5 / wznów**; same-model completed steps are reused. A failed publication does not stop other publications. Resubmitting an already completed run only reads it. Pending files not yet imported need to be reselected after closing the browser. This is a checkpointed foreground workflow, not a background worker service.

Export failure does not remove completed analysis; it can be downloaded again from the queue or document summary. A ZIP with failed publications explicitly names them in CZYTAJ_TO.txt and includes forms only for successful analyses. At most 80 inventoried claims per report: the inventory `complete` flag and limitations expose omissions; no guessed percentage or claim of exhaustive correctness. Reference traces may be large, as each contains the full source visible to the model.

Deleting a document removes all its R2 originals, source, retry objects, automatic checkpoints and audit versions before deleting the D1 record; partial storage cleanup leaves the database row to permit retry. No new database migration is required.

Validation: core/rule, queue continuation/pause/reuse, identity/quote matching, DOCX field coverage, structural missingness and ZIP contents are covered by regression tests. A synthetic DOCX was rendered to PDF for layout review. Live paid inference needs the user's configured API key and was not exercised by development tests.

## App iteration 0.6: projects and bilingual workflows
The coding method remains EMP v0.5. The interface starts in English; Polish is optional and remembered on the current browser. The language of a new AI analysis is selected separately. Existing quotations and scientific narratives are not translated or recoded when changing the interface. Project report templates can be exported in either language; original narratives retain their stored language. The individual v0.5 form retains its bilingual normative template.

Create research projects with a question and selection criteria. Add imported or existing reports; label publications from the same study/cohort without merging their profiles. There is a limit of 100 reports and 12 million serialized source/assessment characters per project synthesis. Reports may belong to multiple projects. Deleting a project only removes its grouping; deleting a review removes its project memberships.

Project synthesis is a deterministic descriptive summary of current saved assessments, with five separate EMP family count distributions. It is not an LLM narrative review or a meta-analysis. Report, claim and user-assigned study-group counts remain separate. NC/NMC reports and excluded claims are outside substantive counts; NE is outside the assessed denominator. The accepted-only filter also requires source verification, valid fields and a resolved bridge. All-active mode includes unverified AI proposals. Cross-report scope equivalence and dataset independence are not inferred.

Exports contain editable DOCX, printable HTML, a vector SVG matrix, claims/profiles/reports/codebook CSVs and complete current JSON including source hashes, revisions, original AI proposals and reviewer decisions. Full model request/output audit is retained in individual automatic v0.5 exports. New assessment and review saves also create immutable R2 snapshots indexed in D1; this is a provenance foundation, not a multi-coder collaboration feature.

The current analysis queue must remain open in a browser tab. It checkpoints each step and can be resumed without redoing completed claims. This hosting setup does not provide an autonomous task queue. UI progress reports completed publications/claims rather than a fabricated model percentage.

Validation in this iteration: core regression tests, project denominator/filter/provenance/export tests, type checking, append-only migration checks and generated Word layout checks. Live AI calls and agent-side browser interaction were not tested in this iteration. The working assumptions for the next iteration are in ROADMAP.md.

## App iteration 0.7: linked interpretation and saved-assessment comparison
EMP coding remains v0.5; no new manual or figure-analysis capability is introduced.

Projects now offer an optional AI interpretation of the selected saved assessments. It describes patterns, differences in scope, evidence gaps, limitations and questions, with exact assessment references for every paragraph. This is not a new full-text review: the model receives effective recorded claims, evidence descriptions, source quotations, QC/status metadata and project scope. The existing matrix and collection counts remain deterministic. The request is bounded at 100 claims and 200,000 serialized input characters; oversize input is rejected before inference and never truncated. A citation validates provenance, not semantic correctness. Output stays explicitly unverified.

Every successful synthesis is an immutable R2 snapshot indexed in owner-scoped D1. It includes selected model, output language, filter, project/document revisions, source hashes, exact effective input, raw request without credentials, raw output and validated interpretation. The interface offers the most recent 100 saved syntheses. Its content fingerprint ignores view timestamps and detects edits, scope/filter/eligibility changes. A matching language is additionally required for inclusion in a report. A stale or differently filtered/languaged synthesis remains separately downloadable; current DOCX/HTML exports include it only when the selected snapshot matches their input. ZIP project.json records inclusion and synthesis-snapshot.json preserves the original source state. The language choice is retained on same-project refresh.

The expandable comparison panel compares two saved document/review states, including the current state. Earlier states exist from app 0.6 onward (the latest 100 earlier revisions are listed). These are saved assessments/revisions, not necessarily independent coders. Two corrections of one initial AI analysis are explicitly identified as sharing an origin. The comparison never asserts accuracy, kappa or inter-rater reliability. It does not invite other users or implement blind coding.

Within a document, stable claim IDs preserve revision continuity, but changed statement/citation/scope excludes a pair from automatic code counts. Across documents, pairing requires the same source hash and unique exact normalized statement, source locator/quote and scope. Local C01 IDs do not imply equivalence across reports. Different source/stage/form yields descriptive comparison only. Structural report types, exclusions, changed identities and QC failures stay out of substantive agreement counts. NE/NE and NE disagreements are shown separately; U/U denotes shared uncertainty. All claim fields, review status and raw/derived values are preserved in downloadable comparison JSON. Original assessments are never overwritten.

The generation indicator shows elapsed time and indeterminate progress, without inventing an AI completion percentage. Generation still requires an open foreground workflow; durable background jobs and shared multi-user permissions remain proposals in ROADMAP.md.

## App iteration 0.8: review rounds and inventory recovery
The **Review rounds / Rundy recenzentów** tab adds a round for one saved full-text (Stage B) report. The collaborative editor implements **EMP v0.5-core**; it preserves optional detailed v0.5 fields in existing AI proposals, but does not claim that a manually created core assessment fills the complete normative form. The individual automatic workflow still exports the original full v0.5 DOCX forms.

A coordinator freezes the extracted source bundle, source hash, mode and original AI proposal (assisted mode only). Independent mode starts from the source and a blank core form, without importing prior claims or ratings. Assisted mode gives every reviewer the same original saved AI proposal, leaving all human decisions unconfirmed. It does not launch extra inference or expose the owner's private edits. A prior-exposure declaration records possible earlier access; hiding other assessments does not erase earlier knowledge or prove blinding.

The coordinator generates single-use, seven-day codes, which are stored only as SHA-256 hashes. A code allows an authenticated Site account to request membership. The coordinator checks the displayed authenticated email/account ID and approves the request. **Site access is a separate prerequisite**: the Site remains private and no platform audience, account permissions or invitations to named people have been changed by this release. The owner must first grant the intended participants access through the Site's sharing controls. In-app codes do not bypass that gate.

At least two approved reviewers and no pending requests are required to start. The roster then locks. Each reviewer saves their own draft and submits an immutable assessment. Unresolved judgments with an explanation are valid submissions; unfinished defaults are not. The coordinator can see submission status, but neither the API nor exports return others' assessments before reveal. Reveal is guarded atomically by all assigned reviewers having submitted. Cancellation preserves the audit without revealing unfinished assessments.

After reveal, participants can select claim pairs explicitly, inspect field differences and export all original submissions, optional shared AI proposal, adjudications and audit in JSON. Identical C01 labels are never automatically paired. The coordinator can use a submission as the starting point for a separate adjudication, linking its claims back to the originals and adding a rationale. Subsequent adjudications are new immutable records. They do not overwrite submissions or calculate a reliability statistic. Adjudications are not yet merged into project synthesis. Drafts use an explicit Save draft button and unsaved-change guards; there is no implicit autosave.

Five additive D1 tables store metadata, assignments and audit; source snapshots, draft revisions and adjudications use R2. Round snapshots survive deletion of the original private document. Existing owner-only document and project APIs remain isolated. The round API is guarded by the stable platform account identity, independent of user-supplied display names.

The automatic inventory step now distinguishes schema errors from ungrounded quotations. It recovers only exact matches after whitespace normalization or a unique matching location, restoring the exact original substring and recording every adjustment. It never fuzzy-matches changed words, numbers, punctuation or joined passages. An invalid inventory gets at most one targeted AI repair in the same chosen model; candidates cannot be silently removed or rewritten to pass. Persistent failures identify fields/claim IDs. Every attempted inventory request/output is recorded without credentials, including failed validation; successful export audits include the original attempt, repair and source-locator adjustments. A false completeness flag stays false. This may add one API call for an invalid inventory; a valid response uses one call.

Validation: 86 regression tests passed, including actual SQLite migrations exercised through the collaboration store, source isolation, invite redemption, permissions, locked submissions, stale-write conflicts, reveal gates, immutable adjudication, literal citation recovery and bounded repair. Type checking and production build are also required. Live model inference and interaction between real invited accounts were not exercised in development.

## App 0.8.1: automatic form recovery
The assessment step now requests the complete normative v0.5 field schema and its exact English categorical values through Structured Outputs. The claim identity is pinned to the saved inventory; the model no longer has to recopy its statement/quotation or independently produce compatibility codes already derived from v0.5. An older full-shaped response remains readable but cannot change the frozen identity. Scientific rules and the manual version are unchanged.

A schema or quotation failure receives at most one targeted repair by the same model. Case/outer whitespace changes in enum tokens and unambiguous whitespace/locator corrections are auditable; missing scientific choices never receive guessed defaults. Changed words/numbers or ambiguous quotations cannot become evidence. QC inconsistencies remain visible and force an unresolved derived bridge. Persistent errors identify the exact claim and fields rather than hiding every cause behind one message.

Each generated attempt is recorded without credentials, including validation failures; successful form exports retain the initial and repaired responses, corrections and exact requests. Step-level pipeline versions preserve provenance when an older run resumes. Immutable checkpoints let a failed claim be retried without re-evaluating earlier claims. Only an explicit model rejection of Structured Outputs allows legacy JSON mode with the same full field contract and local validation; this fallback is also recorded. Invalid schemas, access/quota failures, timeouts and refusals do not trigger a fallback.

Regression tests cover missing fields, enum formatting, changed identities, exact citation recovery, bounded repairs, provider compatibility, auditable requests and resumption of an old checkpoint. Model responses in tests are fixtures; the user's failing live response was not retained by the earlier assessment implementation and was not replayed. The protocol uses the official [Structured Outputs format](https://developers.openai.com/api/docs/guides/structured-outputs).

## App 0.9: complete reviewer forms and selected adjudications

New rounds use **v0.5**, including every normative claim field, all nine categorical scope dimensions, bibliographic metadata, conflict declaration and operator confirmation. Manual forms start with unset categorical choices; absence is not automatically coded as U, NE, NA or No. Incomplete fields can be saved as a draft. Submission checks completeness, consistency and exact source quotations. Explicit uncertainty with an explanation remains possible; it does not waive missing-field or citation checks. Editing claim coding resets its review decision and source check. Earlier v0.5-core rounds keep their original manual label and submission rules.

Adjudication supports multiple explicit original-claim links and a reason per final claim. It records the authenticated adjudicator, time and source submission IDs in a separate immutable snapshot. Original submissions and older adjudications remain intact. After reveal, **Download full v0.5 Word forms** exports the original normative template, one DOCX per active claim (or a structural NC/NMC form), together with round.json and the full adjudication history. The annex distinguishes human coding, shared AI assistance, actual declarations and unavailable generation metadata. It does not invent an independent Stage A assessment or signature. Legacy core rounds retain their JSON export and cannot be exported as full v0.5 forms.

In a project's reports table, **Choose assessment / Wybierz ocenę** selects either the current document assessment or one specific released adjudication from a round coordinated by the source-document owner. Selection requires the exact original document, source hash and stage. It is pinned to the adjudication ID, not to the newest round result. An atomic revision guard and append-only selection event prevent stale writes. Reverting to the document assessment is explicit. No reviewer submission or private document assessment is overwritten.

Counts, descriptive synthesis, AI synthesis input, and CSV/JSON/DOCX/HTML export all use that selected assessment once per report. Each records the actual manual version, round and adjudication ID. Project JSON also preserves the original private assessment, the chosen adjudication and selection history. Unresolved decisions cannot become accepted evidence; the accepted-only filter still requires valid fields, source confirmation and a resolved bridge. A basis change invalidates a previous AI synthesis fingerprint, even when the claim IDs match. Earlier synthesis snapshots keep their own immutable input.

Validation includes real SQLite migrations and store-level scenarios for incomplete drafts, normative fields, hidden submissions, exact-source permissions, stale selection conflicts, immutable submissions/adjudications, version pinning, no double counting, and provenance across export formats. Generated Word forms are rendered for layout checks. Development tests do not claim scientific validity, live model accuracy, or a completed pilot between real reviewer accounts.


## App 0.10: field comparison, article figures and recorded versions
The teaching example is entirely English, including its title, source labels, claim scopes, reasons and questions. It is synthetic core coding, not a published study or a full-form AI run. Changing the interface language does not rewrite its source quotations.

Comparisons now flatten every nested normative v0.5 field into a labelled row, with difference-only filtering, search and source links. Missing choices, false, null and empty lists remain distinct. Required-family and secondary-substitution sets are compared without artificial ordering differences. Review rounds retain explicit selection of the two submissions and claims; saved document comparisons preserve their stricter identity/QC/comparability rules. The same comparison is available under a document's Versions and assessment history panel. JSON exports preserve the selected origins and raw fields.

Article figures accept PNG, JPEG and WebP, up to 3 MB each and 12 active images per document (36 including archive). Multi-selection uploads each file separately and reuses upload IDs after an interrupted response. Each image has a parent article/supplement, label, optional caption/location and immutable SHA-256 identity. Stored originals and labels are not overwritten; an amended image/caption can be uploaded separately and the previous attachment archived. Figures never create project reports or inflate study denominators.

An explicit Analyse this figure action sends the actual image, user-entered caption and extracted article text to the selected OpenAI Responses model. It requires image-input and Structured Outputs support. The result distinguishes conceptual/empirical content, readability, panel observations, possible discrepancies, limitations and questions. Comparisons with article text require exact stored quotations. A failed, refused, incomplete or ungrounded result is not saved. There is no silent model substitution. Up to 20 successful analyses are retained for each image; reviewer status/notes are scoped to one particular result, guarded against stale updates, with an append-only audit. New analyses never inherit earlier human approval. These supplementary interpretations do not automatically change EMP codes or enter AI project synthesis.

New rounds copy active image bytes and metadata into their immutable source bundle. All reviewers see the same originals, including after the parent document is deleted; pending/unapproved users and reviewers in recruiting rounds cannot read the images. Figure AI interpretations are never copied into an independent round. Images added later require a new round. The full Word ZIP includes these verified original image files and their identities in round.json, and its source inventory lists the figures. Old rounds remain readable without attachments.

Version metadata separates app 0.10.0, normative manual v0.5, full form template v0.5, core/full field coverage and document revision. A new run records its generation version; a later human save records the app at that save without rewriting the original generation. Missing historical app metadata stays unknown. Only the actually defined v0.5 manual is available. The panel describes this release without inventing v0.6 rules or upgrading old assessments. Rule-level migration will require a published new manual and an explicit field mapping.

The additive 0005 migration adds optional document version metadata and owner-scoped figure/run/review-event tables. Regression tests exercise real SQLite migrations, grounding, binary request shape, retry identity, round access and immutable originals. Paid live inference is not exercised by fixtures. Network failures now advise checking the saved state before retrying and do not misdiagnose missing credits.


## App 0.11: resumable adjudication and selected visual observations
Coordinators can save incomplete adjudication drafts, including partial v0.5 fields, unanswered categorical choices, original-claim links and per-claim reasons. Drafts are private to the coordinator and excluded from shared round exports and project assessment options. Save and resume is explicit; unsaved-change guards remain active. Discarding unsaved changes restores the saved draft. Deleting a saved draft is a separate action. Revision guards and tombstones prevent an older tab from overwriting or resurrecting a discarded draft. Finalization retains full form/quotation checks, writes a separate immutable adjudication and clears its draft atomically. Earlier submissions and adjudications are preserved.

Projects can explicitly select individual observations from a checked, source-confirmed figure analysis and record why they are relevant. The selection pins the article, image hash, analysis run, observation indices, reviewer event/revision, selector and time. Merely approving or reanalysing a figure does not select it. Revoked/changed reviews, archived/restored figures or changed sources make earlier selections stale until explicitly confirmed again. Stale choices remain visible with reasons but provide no citable synthesis observations. Selecting figures never adds claims, studies or reports and never changes EMP codes.

AI synthesis receives only the selected eligible observations, with source quotations, limitations and approval provenance. References distinguish assessment keys from visual-observation keys. Input fingerprints include selections and eligibility, invalidating a previously generated interpretation after either changes. Figure-only views may describe those observations and limitations without drawing EMP conclusions. Current project exports refresh server data first, so cached approval in an older tab cannot include a revoked observation as current evidence. CSV/JSON retain the exact provenance, and Word/HTML display the selected observations and their references. Historical synthesis snapshots retain their own input separately. Source image binaries remain downloadable with the article/round; the project report contains observation records.

All three export actions now load their exporter code with the initial application bundle, removing the separate lazy export-chunk request that could fail in a tab kept open across deployments. Recognized stale-module errors advise saving edits, reloading and exporting already-saved results; they do not restart AI analysis or assume a billing problem. Existing old tabs need one reload to use the updated code. Other network or template-download failures remain possible and are reported.

Migration 0006 adds coordinator draft pointers and project figure selections without modifying existing records. Validation: 125 core regression tests, TypeScript checks, production build/SSR smoke test and rendered project Word samples. Model responses in tests are fixtures; no paid live inference, real multi-account pilot or browser interaction is claimed. The normative manual and form remain v0.5.
