## Completed: app 0.20.0 article-first reading and review

- The default article view shows four report questions alongside source passages. On narrow screens the passages precede the optional review form.
- Human review can be saved in the article report. Explicit selection and source attestations are retained; unresolved decisions need a reason, and unresolved or invalid coding cannot be accepted.
- Detailed coding, metadata and audit exports are available through More options. Primary-claim links open the article report.
- Project prompts lead to the report; EI results initially display all assessment groups separately. Adjudicated project selections retain their frozen assessment view.
- This is a presentation and navigation change over the same EMP coding and validation rules, not a newly validated abbreviated protocol.

## Completed: app 0.19.1 review guidance

- Project prompts identify the report and explain the decision; reports and provisional results remain readable before verification.
- Source-check, field-validation and unresolved-classification messages explain their own blockers, with direct navigation to source passages, the editor and the decision form.
- Accepting an assessment is explicitly distinguished from supporting the authors’ claim. Saved decisions show any remaining source or selection check.
- Claim-selection editing permits justified additions beyond three, consistent with focal-v2. Scientific classification and verification requirements are preserved.

## Completed: app 0.19.0 reporting and focal follow-up

- One central-claim calculation across the interface, Word/HTML and CSV/JSON exports, with unresolved and resolved denominators, extreme bounds, explicit pending coverage and full class counts.
- Separate AI, manual-draft, human-checked and released-adjudication groups; explicit source-stage/protocol/field/source-selection strata.
- Focal-v2 normally selects 1–3 claims; justified material additions are supported by AI selection and reviewer editing. All contextual claims include the four report questions.
- Focused additional-source review preserves the earlier claim, scope, source hash and revision. The evidence question is addressed during assessment; a saved semantic comparison becomes stale when the current proposition or scope changes.
- Explicit calibration/exclusion and duplicate dispositions. Possible duplicate imports withhold affected percentages until reconciled, without deleting records.
- Versioned reporting/focal addendum 1.1. Manual v0.5 coding rules and its scientific primary validation endpoint remain unchanged.
- Prospective validation against independent full-text reference coding remains required. Software tests do not establish methodological equivalence.

## Completed: app 0.18.0 focal workflow

- One central claim plus up to two contextual claims, confirmed before AI evidence assessment.
- Abstract/file/text intake, including exact PMID/DOI lookup with explicit missing-abstract handling.
- Short five-family publication profile and printable HTML, with detailed coding on demand.
- Central-claim EI comparison, reviewer/provisional separation, stage/protocol strata and explicit unresolved and pending counts.
- Existing data retained; no schema migration required.

## Next focal evaluation

- Pilot selection accuracy, time to a reviewed profile, source errors and reviewer workload on a small prespecified article set.
- Evaluate the new linked-source workflow in the prospective pilot. It does not establish blinded A/B coding.
- Reconcile the full corpus and inspect report-to-study relationships before final research reporting; automatic identity checks do not establish independence.
- Keep exhaustive coding and full reviewer rounds available for cases that require them.

## Completed: app 0.13.0

- Bounded multi-stage synthesis, checkpointed after each AI request.
- Resume/pause UI with counts for all selected claims and approved figure observations.
- Conditional owner-scoped leases and idempotent finalisation.
- Complete original input and intermediate provenance retained in the synthesis snapshot.

## Completed: English-only UX pass
- English UI and Word template; English defaults enforced for new AI requests.
- Unsaved draft/import protection, source return action and consistent export messages.
- Auditable presentation translation of legacy Polish Word passages; original data preserved.

## Suggested next iteration
- Persist a reusable English rendering per assessment revision to avoid repeated translation costs.
- Add a resumable server-side job queue and explicit per-stage cost/usage feedback.
- Run task-based usability sessions covering import, source checking, adjudication and export.

# Next iteration after app 0.11

Implemented: full v0.5 reviewer forms, explicit adjudication selection in project synthesis, field-by-field comparisons, consistently English teaching example, article-linked figures with optional AI interpretation and review history, frozen figures in new rounds, separate method/form/app/assessment version metadata, resumable coordinator adjudication drafts, and explicit selection of approved figure observations in project synthesis and export. EMP remains v0.5.

## 1. Adjudication ergonomics
Give every unmatched submitted claim an explicit disposition. Allow reviewers to carry a chosen source passage or checked visual observation into an adjudication with an exact origin link and rationale. Do not merge sidecar AI observations automatically. Pilot independent and assisted rounds with real authorized accounts.

## 2. Selective figure extraction and synthesis
Extract relevant figures and legends from PDF pages, avoiding duplicate image uploads. Add explicit claim-to-figure provenance and a human decision on whether a visual observation changes coding. The current explicit selection and fingerprint mechanism already supports checked observations in project interpretation; extend it to claim-level coding changes with a separate human rationale. Source images, captions and conceptual models must not become independent studies or numerical evidence by default.

## 3. A defined next manual
Before enabling manual 0.6, publish its normative differences from 0.5, classify changes as wording/form/rule changes, and map stable field IDs. Preview affected assessments, preserve earlier records, and create a separate evaluation rather than relabelling results. A formatting change alone must not invalidate scientific coding.

## 4. Durable analysis jobs
Add a supported queue and worker infrastructure with cancellation, bounded cost, idempotency and checkpoint reuse. Closing the browser should not abandon an accepted job. The current automatic pipeline and figure analysis remain foreground workflows; the hosting bindings currently provide D1/R2, not an autonomous task queue.

## Evaluation before wider rollout
Measure omitted claims, source errors, incorrect acceptance, reviewer time and workload on independently adjudicated cases. Check whether synthesis faithfully reflects selected assessments and uncertainty. Treat improved reliability as an empirical question, not a consequence of agreement between model runs.
