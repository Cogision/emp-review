import {z} from 'zod';
import {owner,sameOrigin,jsonBody,failure} from '@/lib/server';
import {lookupAbstract} from '@/lib/abstract-lookup';
export async function POST(req:Request){try{sameOrigin(req);await owner();const {identifier}=z.object({identifier:z.string().trim().min(1).max(300)}).parse(await jsonBody(req,2000));return Response.json(await lookupAbstract(identifier));}catch(e){return failure(e);}}
