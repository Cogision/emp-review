import {z} from 'zod';
import {bindings,db,owner,rowFor,fullDoc,sameOrigin,jsonBody,failure,AppError,updateDoc} from '@/lib/server';
import {parseAiSettings} from '@/lib/ai-settings';
import {proposeAssessmentCorrection} from '@/lib/automatic';
import {currentClaims} from '@/lib/emp';
import {publicationProfile} from '@/lib/publication-profile';
import {applyCorrection,correctionRequestSchema,correctionInstruction,type CorrectionProposal} from '@/lib/assessment-correction';
type Ctx={params:Promise<{id:string}>};
async function proposalFor(id:string,who:string,proposalId?:string,claimId?:string){
 const query=proposalId?"SELECT payload FROM events WHERE document_id=? AND owner=? AND kind='correction_proposal' AND id=?":"SELECT payload FROM events WHERE document_id=? AND owner=? AND kind='correction_proposal' ORDER BY created_at DESC LIMIT 1";
 const scoped=claimId&&!proposalId?"SELECT payload FROM events WHERE document_id=? AND owner=? AND kind='correction_proposal' AND json_extract(payload,'$.proposal.before.id')=? ORDER BY created_at DESC LIMIT 1":query;
 const stmt=db().prepare(scoped),event=await (proposalId?stmt.bind(id,who,proposalId):claimId?stmt.bind(id,who,claimId):stmt.bind(id,who)).first<{payload:string}>();
 if(!event)return null;
 const obj=await bindings().BUCKET.get(JSON.parse(event.payload).proposalKey);
 if(!obj)throw new AppError('The saved correction proposal could not be loaded. Try again.',503);
 return obj.json<CorrectionProposal>();
}
export async function GET(req:Request,ctx:Ctx){try{
 const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),proposal=await proposalFor(id,who,undefined,new URL(req.url).searchParams.get('claimId')||undefined);
 return Response.json({proposal:proposal?.baseRevision===row.revision?proposal:null});
}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who);
 const input=correctionRequestSchema.parse(await jsonBody(req,12000));
 if(input.revision!==row.revision)throw new AppError('This report changed. Reopen it before requesting or applying a correction.',409);
 const document=await fullDoc(row);
 if(input.action==='apply'){
  const proposal=await proposalFor(id,who,input.proposalId);
  if(!proposal)throw new AppError('Correction proposal not found.',404);
  let review;try{review=applyCorrection(document,proposal);}catch(e){throw new AppError((e as Error).message,409);}
  return Response.json({document:await updateDoc(row,document.analysis,review,'review',{action:'correction_applied',proposalId:proposal.id,previousDecision:document.review.decisions[proposal.before.id]||null,decision:review.decisions[proposal.before.id]})});
 }
 const p=publicationProfile(document),claim=input.claimId?currentClaims(document).find(c=>c.id===input.claimId&&document.review.decisions[c.id]?.status!=='excluded'):p.central;
 if(!document.analysis||!claim||!['CB','M'].includes(p.type||''))throw new AppError('Choose an active claim in a completed assessment before requesting a correction.',409);
 const {key,model}=parseAiSettings(input,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});
 const proposalId=crypto.randomUUID(),prefix=`${row.source_key.replace(/text.json$/,'')}corrections/${proposalId}/`;
 const instruction=correctionInstruction(input.feedback);
 const result=await proposeAssessmentCorrection(document.source,row.stage,row.coverage,key,model,claim,p.type!,instruction,async(attempt,issues)=>{
  const attemptId=crypto.randomUUID(),attemptKey=`${prefix}${attemptId}.json`;
  await bindings().BUCKET.put(attemptKey,JSON.stringify({...attempt,issues}),{httpMetadata:{contentType:'application/json'}});
  await db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) SELECT ?,id,owner,revision,'correction_attempt',?,? FROM documents WHERE id=? AND owner=?").bind(attemptId,JSON.stringify({proposalId,baseRevision:row.revision,attemptKey,issues}),attempt.createdAt,id,who).run();
 });
 const proposal:CorrectionProposal={id:proposalId,documentId:id,baseRevision:row.revision,sourceHash:row.source_hash,createdAt:new Date().toISOString(),model,feedback:input.feedback,instruction,before:claim,candidate:result.candidate};
 const proposalKey=`${prefix}proposal.json`;
 await bindings().BUCKET.put(proposalKey,JSON.stringify(proposal),{httpMetadata:{contentType:'application/json'}});
 const saved=await db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) SELECT ?,id,owner,revision,'correction_proposal',?,? FROM documents WHERE id=? AND owner=? AND revision=?").bind(proposalId,JSON.stringify({proposalKey,proposal,technicalCorrections:result.corrections}),proposal.createdAt,id,who,row.revision).run();
 if(!saved.meta.changes)throw new AppError('This report changed while the correction was being prepared. Request a fresh correction.',409);
 return Response.json({proposal});
}catch(e){return e instanceof z.ZodError?Response.json({error:'The request could not be read. Your note is optional and may contain up to 4,000 characters. Reopen the assessment if the request still fails.'},{status:400}):failure(e);}}
