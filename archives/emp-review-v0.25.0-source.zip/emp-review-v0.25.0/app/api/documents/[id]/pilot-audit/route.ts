import {owner,rowFor,bindings,failure,AppError} from '@/lib/server';
export async function GET(_req:Request,ctx:{params:Promise<{id:string}>}){try{
 const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),key=row.source_key.replace(/text\.json$/,'pilot-audit.json');
 const obj=await bindings().BUCKET.get(key);if(!obj)throw new AppError('No supplied-pilot audit is attached to this record.',404);
 return new Response(obj.body,{headers:{'Content-Type':'application/json','Content-Disposition':`attachment; filename="EMP-pilot-audit-${id}.json"`,'Cache-Control':'private, no-store'}});
}catch(e){return failure(e);}}
