import {z} from 'zod';
import {bindings,db,owner,rowFor,fullDoc,sameOrigin,jsonBody,failure,AppError,updateDoc} from '@/lib/server';
import {ReconciliationStore} from '@/lib/reconciliation-store';
import {activeClaims,readAnalysisExport,validateReconciliationInputs,reconciliationContext,applyReconciliation,type ReconciliationInput} from '@/lib/analysis-reconciliation';
import {parseAiSettings} from '@/lib/ai-settings';
import {proposeAssessmentCorrection} from '@/lib/automatic';
import type {Analysis,Review} from '@/lib/emp';
import type {VersionManifest} from '@/lib/versions';
type Ctx={params:Promise<{id:string}>};
const schema=z.discriminatedUnion('action',[
 z.object({action:z.literal('start'),revision:z.number().int(),claimSelectionConfirmed:z.literal(true),inputs:z.array(z.discriminatedUnion('origin',[
  z.object({origin:z.literal('saved'),documentId:z.string().min(1).max(100),snapshotId:z.string().min(1).max(100)}),
  z.object({origin:z.literal('upload'),label:z.string().min(1).max(200),data:z.unknown()})
 ])).min(1).max(4),key:z.string().optional(),model:z.string().optional()}),
 z.object({action:z.literal('next'),id:z.string().uuid(),revision:z.number().int(),key:z.string().optional(),model:z.string().optional()}),
 z.object({action:z.literal('apply'),id:z.string().uuid(),revision:z.number().int(),reviewed:z.literal(true)})
]);
export async function GET(req:Request,ctx:Ctx){try{const who=await owner(),{id}=await ctx.params;await rowFor(id,who);const history=await db().prepare('SELECT id,base_revision,created_at FROM analysis_reconciliations WHERE document_id=? AND owner=? ORDER BY created_at DESC LIMIT 100').bind(id,who).all();return Response.json({session:await new ReconciliationStore(bindings(),who,id).get(new URL(req.url).searchParams.get('session')||undefined),history:history.results});}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),document=await fullDoc(row),input=schema.parse(await jsonBody(req,6_000_000)),store=new ReconciliationStore(bindings(),who,id);
 if(input.action==='start'){
  if(input.revision!==row.revision)throw new AppError('The report changed. Reopen it before comparing analyses.',409);
  const settings=parseAiSettings(input,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});
  const inputs:ReconciliationInput[]=[{label:'Open report · r'+row.revision,document,origin:'current'}];
  for(const item of input.inputs){
   if(item.origin==='upload'){inputs.push({label:item.label,origin:'upload',document:(()=>{try{return readAnalysisExport(item.data);}catch(e){throw new AppError((e as Error).message);}})()});continue;}
   const other=await rowFor(item.documentId,who);let d=await fullDoc(other);
   if(item.snapshotId!==`current:${other.revision}`){
    const run=await db().prepare('SELECT snapshot_key,revision,source_hash,stage FROM assessment_runs WHERE id=? AND document_id=? AND owner=?').bind(item.snapshotId,other.id,who).first<{snapshot_key:string;revision:number;source_hash:string;stage:string}>();
    if(!run)throw new AppError('A selected version is no longer available. Refresh the list.',409);
    const obj=await bindings().BUCKET.get(run.snapshot_key);if(!obj)throw new AppError('The selected version could not be loaded.',503);
    const snap=await obj.json<{documentId:string;revision:number;sourceHash:string;stage:string;analysis:Analysis;review:Review;versions?:VersionManifest;createdAt:string}>();
    if(snap.documentId!==other.id||snap.revision!==run.revision||snap.sourceHash!==other.source_hash||snap.sourceHash!==run.source_hash||snap.stage!==run.stage)throw new AppError('The saved source could not be verified.',409);
    d={...d,analysis:snap.analysis,review:snap.review,revision:snap.revision,updatedAt:snap.createdAt,versions:snap.versions};
   }
   inputs.push({origin:'saved',label:`${d.title} · r${d.revision}`,document:d});
  }
  try{validateReconciliationInputs(inputs);}catch(e){throw new AppError((e as Error).message);}
  const session=await store.save({id:crypto.randomUUID(),documentId:id,baseRevision:row.revision,sourceHash:row.source_hash,createdAt:new Date().toISOString(),model:settings.model,revision:0,inputs,candidates:[],originalUploads:input.inputs.filter(x=>x.origin==='upload')});
  return Response.json({session});
 }
 const session=await store.get(input.id);if(!session)throw new AppError('Comparison not found.',404);
 if(session.revision!==input.revision||session.baseRevision!==row.revision)throw new AppError('The report or comparison changed. Reload before continuing.',409);
 if(input.action==='apply'){
  let review;try{review=applyReconciliation(document,session);}catch(e){throw new AppError((e as Error).message,409);}
  return Response.json({document:await updateDoc(row,document.analysis,review,'review',{action:'reconciliation_applied',sessionId:session.id,model:session.model,sourceRevision:session.baseRevision,inputLabels:session.inputs.map(x=>x.label),decisions:review.decisions})});
 }
 const {key,model}=parseAiSettings(input,{key:bindings().OPENAI_API_KEY,model:bindings().OPENAI_MODEL});if(model!==session.model)throw new AppError('Resume with the same AI model, or start a new comparison.');
 const claim=activeClaims(session.inputs[0].document)[session.candidates.length];if(!claim)return Response.json({session});
 const result=await proposeAssessmentCorrection(document.source,document.stage,document.coverage,key,model,claim,document.review.reportType||document.analysis!.reportType,'Recommend one assessment after examining the conflicting analyses. Preserve the selected proposition and explain the decision.',async(attempt,issues)=>{
  const attemptId=crypto.randomUUID(),attemptKey=`documents/${who}/${id}/reconciliations/${session.id}/attempt-${attemptId}.json`;
  await bindings().BUCKET.put(attemptKey,JSON.stringify({...attempt,issues}),{httpMetadata:{contentType:'application/json'}});
 },reconciliationContext(session,claim));
 return Response.json({session:await store.save({...session,candidates:[...session.candidates,result.candidate]},session.revision)});
}catch(e){if(e instanceof z.ZodError)return Response.json({error:'Choose two to five analyses and confirm the target claim selection.'},{status:400});return failure(e);}}
