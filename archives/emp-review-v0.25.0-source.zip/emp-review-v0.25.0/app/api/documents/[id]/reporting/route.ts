import {z} from 'zod';
import {reportingSchema} from '@/lib/reporting-schema';
import {centralClaim,makeStageLink,reportSettings,validateReporting,normalizePublicationId} from '@/lib/reporting';
import {owner,rowFor,fullDoc,updateDoc,sameOrigin,jsonBody,failure,AppError} from '@/lib/server';
type Ctx={params:Promise<{id:string}>};
export async function PATCH(req:Request,ctx:Ctx){try{
 sameOrigin(req);const who=await owner(),{id}=await ctx.params,row=await rowFor(id,who),d=await fullDoc(row);
 const b=z.object({revision:z.number().int(),reporting:reportingSchema}).parse(await jsonBody(req,120000));
 if(b.revision!==d.revision)throw new AppError('The report changed. Reopen it before saving.',409);
 const next=b.reporting,old=reportSettings(d);next.publicationId=normalizePublicationId(next.publicationId);
 if(next.duplicateOf){const target=await fullDoc(await rowFor(next.duplicateOf,who));if(target.stage!==d.stage||reportSettings(target).duplicateOf)throw new AppError('Choose an original report from the same source stage, not another duplicate.');}
 if(next.stageLink){
  const submitted=next.stageLink;
  const frozen=old.stageLink?.documentId===submitted.documentId?old.stageLink:makeStageLink(await fullDoc(await rowFor(submitted.documentId,who)),submitted.question);
  if(frozen.documentId===id)throw new AppError('Choose another source review.');
  const c=centralClaim(d);if(submitted.relation!=='pending'&&!c)throw new AppError('Select the current central claim before comparing propositions.');
  next.stageLink={...frozen,question:submitted.question,relation:submitted.relation,reason:submitted.reason,...(c?{comparedClaimId:c.id,comparedStatement:c.statement,comparedScope:JSON.stringify(c.scope)}:{})};
 }
 validateReporting(next,d);
 return Response.json(await updateDoc(row,d.analysis,{...d.review,reporting:next},'reporting',{before:old,after:next}));
}catch(e){return e instanceof z.ZodError?Response.json({error:'Check the reporting settings.'},{status:400}):failure(e);}}
