import {bindings,owner,failure,sameOrigin,jsonBody} from '@/lib/server';
import {DraftStore,draftScope} from '@/lib/draft-store';
export const dynamic='force-dynamic';
const response=(data:unknown)=>Response.json(data,{headers:{'Cache-Control':'private, no-store'}});
export async function GET(req:Request){try{const store=new DraftStore(bindings(),await owner());return response(await store.get(draftScope(new URL(req.url).searchParams.get('scope'))));}catch(e){return failure(e);}}
export async function PUT(req:Request){try{sameOrigin(req);const store=new DraftStore(bindings(),await owner()),body=await jsonBody(req,2_100_000);return response(await store.put(draftScope(new URL(req.url).searchParams.get('scope')),body.revision,body.value??null));}catch(e){return failure(e);}}
