import {getChatGPTUser} from '@/app/chatgpt-auth';
import {canImportSuppliedPilot,importPilotRecord,suppliedPilotId,type PilotRecord} from '@/lib/pilot-import';
import bundle from '@/lib/pilot-import-data.server.json';
import {bindings,sameOrigin,jsonBody,failure,AppError} from '@/lib/server';

const records=bundle as unknown as PilotRecord[];
export async function GET(){try{
 const user=await getChatGPTUser();if(!canImportSuppliedPilot(user))throw new AppError('This supplied-paper pilot is available only in its owner’s account.',403);
 return Response.json({projectId:await suppliedPilotId(user!.id,'project'),records:records.map(r=>({pilotId:r.pilotId,stage:r.stage,title:r.title}))},{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return failure(e);}}
export async function POST(req:Request){try{
 sameOrigin(req);const user=await getChatGPTUser();if(!canImportSuppliedPilot(user))throw new AppError('This supplied-paper pilot is available only in its owner’s account.',403);
 const body=await jsonBody(req,1000),record=records.find(r=>r.pilotId===body?.pilotId&&r.stage===body?.stage);
 if(!record)throw new AppError('Choose a prepared pilot record.',400);
 return Response.json(await importPilotRecord(bindings(),user,record),{headers:{'Cache-Control':'private, no-store'}});
}catch(e){return failure(e);}}
