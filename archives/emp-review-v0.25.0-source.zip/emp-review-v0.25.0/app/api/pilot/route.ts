import {z} from 'zod';
import {pilotManifest,pilotId} from '@/lib/pilot';
import {lookupAbstract} from '@/lib/abstract-lookup';
import {emptyReview,sourceSchema} from '@/lib/emp';
import {reportingDefaults} from '@/lib/reporting-schema';
import {newManifest} from '@/lib/versions';
import {sha256} from '@/lib/automatic';
import {db,bindings,owner,sameOrigin,jsonBody,rowFor,fullDoc,failure,AppError} from '@/lib/server';
export async function GET(){try{
 const who=await owner(),ids=await Promise.all(pilotManifest.records.map(r=>pilotId(who,r.id)));
 const rows=await db().prepare('SELECT id,analysis IS NOT NULL AS analyzed FROM documents WHERE owner=? AND id IN (?,?,?,?,?)').bind(who,...ids).all<{id:string;analyzed:number}>();
 return Response.json({records:pilotManifest.records.map((r,i)=>({recordId:r.id,documentId:ids[i],imported:rows.results.some(d=>d.id===ids[i]),analyzed:!!rows.results.find(d=>d.id===ids[i])?.analyzed}))});
}catch(e){return failure(e);}}
export async function POST(req:Request){try{
 sameOrigin(req);const who=await owner(),{recordId}=z.object({recordId:z.string().max(5)}).parse(await jsonBody(req,1000));
 const record=pilotManifest.records.find(r=>r.id===recordId);if(!record)throw new AppError('Pilot article not found.',404);
 const id=await pilotId(who,recordId),projectId=await pilotId(who,'project'),now=new Date().toISOString();
 await db().prepare("INSERT INTO projects (id,owner,title,question,criteria,language,revision,created_at,updated_at) VALUES (?,?,?,?,?,'en',0,?,?) ON CONFLICT(id) DO NOTHING").bind(projectId,who,'EMP five-article pilot','Can readers understand the report and correct an assessment without detailed coding?','Purposeful calibration set, excluded from the main EI frequency. Stage A for all five. Prespecified full-text follow-up: P01, P02, P05. User observations and reference judgments are pending.',now,now).run();
 if(!await db().prepare('SELECT id FROM documents WHERE id=? AND owner=?').bind(id,who).first()){
  const result=await lookupAbstract(record.pmid);
  if(!result.abstract)throw new AppError('The abstract is not available from the source service. No placeholder analysis was created.',422);
  const source=sourceSchema.parse(result.source),sourceText=JSON.stringify(source),hash=await sha256(sourceText),sourceKey=`documents/${who}/${id}/${crypto.randomUUID()}/text.json`;
  const review=structuredClone(emptyReview);review.reporting={...reportingDefaults(),publicationId:`doi:${record.doi}`,role:'calibration',reason:`Five-article pilot ${record.id}; not part of the research frequency.`,sourceSelection:'uniform',selectionReason:'Prespecified Stage A for all five pilot papers.'};
  const coverage='Title and abstract retrieved through Europe PMC. Full text and supplements not reviewed. Pilot reference judgment and user observations pending.';
  await bindings().BUCKET.put(sourceKey,sourceText,{httpMetadata:{contentType:'application/json'}});
  try{await db().batch([
   db().prepare('INSERT INTO documents (id,owner,title,stage,coverage,source_key,source_hash,analysis,review,version_manifest,revision,created_at,updated_at) VALUES (?,?,?,\'A\',?,?,?,NULL,?,?,0,?,?)').bind(id,who,result.title.slice(0,200),coverage,sourceKey,hash,JSON.stringify(review),JSON.stringify(newManifest('core')),now,now),
   db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) VALUES (?,?,?,0,'import',?,?)").bind(crypto.randomUUID(),id,who,JSON.stringify({pilotId:record.id,protocol:'EMP-pilot-1',sourceHash:hash,reporting:review.reporting}),now)
  ]);}catch(e){
   // Concurrent clicks keep the first immutable source; clean only this unreferenced attempt.
   const saved=await db().prepare('SELECT source_key FROM documents WHERE id=? AND owner=?').bind(id,who).first<{source_key:string}>();
   if(saved?.source_key!==sourceKey)await bindings().BUCKET.delete(sourceKey);
   if(!saved)throw e;
  }
 }
 await db().batch([
  db().prepare("INSERT INTO project_documents (project_id,document_id,study_group,added_at) VALUES (?,?,'',?) ON CONFLICT(project_id,document_id) DO NOTHING").bind(projectId,id,now),
  db().prepare('UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND owner=?').bind(now,projectId,who)
 ]);
 return Response.json({document:await fullDoc(await rowFor(id,who)),projectId});
}catch(e){return e instanceof z.ZodError?Response.json({error:'Choose an article from the pilot.'},{status:400}):failure(e);}}
