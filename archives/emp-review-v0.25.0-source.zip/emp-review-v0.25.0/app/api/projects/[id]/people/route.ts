import {ZodError} from 'zod';
import {sameOrigin,jsonBody,failure} from '@/lib/server';
import {projectAccessStore} from '@/lib/project-access-server';
type Context={params:Promise<{id:string}>};
export async function GET(_req:Request,ctx:Context){try{return Response.json(await(await projectAccessStore()).people((await ctx.params).id));}catch(e){return failure(e);}}
export async function POST(req:Request,ctx:Context){try{sameOrigin(req);return Response.json(await(await projectAccessStore()).action((await ctx.params).id,await jsonBody(req,5000)));}catch(e){return e instanceof ZodError?Response.json({error:'Check the invitation details and refresh the project.'},{status:400}):failure(e);}}
