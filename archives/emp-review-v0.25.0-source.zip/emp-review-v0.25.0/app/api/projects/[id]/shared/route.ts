import {failure} from '@/lib/server';
import {projectAccessStore} from '@/lib/project-access-server';
export async function GET(_req:Request,ctx:{params:Promise<{id:string}>}){try{return Response.json(await(await projectAccessStore()).shared((await ctx.params).id));}catch(e){return failure(e);}}
