import {ZodError} from 'zod';
import {sameOrigin,jsonBody,failure} from '@/lib/server';
import {projectAccessStore} from '@/lib/project-access-server';
export async function POST(req:Request){try{sameOrigin(req);return Response.json(await(await projectAccessStore()).join(await jsonBody(req,5000)));}catch(e){return e instanceof ZodError?Response.json({error:'Check the invitation code and your name.'},{status:400}):failure(e);}}
