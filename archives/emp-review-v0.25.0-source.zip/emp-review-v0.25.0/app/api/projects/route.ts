import {z} from "zod";
import {db,owner,sameOrigin,jsonBody,failure} from "@/lib/server";
import {projectAccessStore} from '@/lib/project-access-server';
export async function GET(){try{return Response.json({projects:await(await projectAccessStore()).list()});}catch(e){return failure(e);}}
export async function POST(req:Request){try{sameOrigin(req);const who=await owner(),v=z.object({title:z.string().trim().min(1).max(200),category:z.string().trim().max(120).default(''),targetCount:z.number().int().min(1).max(100).nullable().default(null),question:z.string().max(4000).default(""),criteria:z.string().max(4000).default(""),language:z.enum(["en","pl"]).default("en").transform(()=>"en" as const)}).parse(await jsonBody(req,20000)),id=crypto.randomUUID(),now=new Date().toISOString();
 await db().prepare("INSERT INTO projects (id,owner,title,question,criteria,category,target_count,language,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,0,?,?)").bind(id,who,v.title,v.question,v.criteria,v.category,v.targetCount,v.language,now,now).run();return Response.json({id,...v,target_count:v.targetCount,role:'owner',revision:0,created_at:now,updated_at:now},{status:201});
}catch(e){return e instanceof z.ZodError?Response.json({error:"Enter a project title and valid project details."},{status:400}):failure(e);}}
