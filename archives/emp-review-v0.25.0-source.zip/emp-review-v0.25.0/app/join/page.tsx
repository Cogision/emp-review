import {getChatGPTUser} from '../chatgpt-auth';
import RoundJoin from '@/components/round-join';
export const dynamic='force-dynamic';
export const metadata={title:'Join EMP Review',referrer:'no-referrer',robots:{index:false,follow:false}};
export default async function Page({searchParams}:{searchParams:Promise<{project?:string}>}){return <RoundJoin kind={(await searchParams).project==='1'?'project':'round'} user={await getChatGPTUser()}/>;}
