import ReviewWorkspace from "@/components/review-workspace";
import {DraftProvider} from '@/components/draft-state';
import {requireChatGPTUser} from './chatgpt-auth';
import {validRoundId} from '@/lib/reviewer-invitations';
import {canImportSuppliedPilot} from '@/lib/pilot-import';
export const dynamic='force-dynamic';
export default async function Page({searchParams}:{searchParams:Promise<{round?:string;project?:string}>}){
 const params=await searchParams,roundId=typeof params.round==='string'&&validRoundId(params.round)?params.round:'';
 const projectId=typeof params.project==='string'&&validRoundId(params.project)?params.project:'';
 return <AuthenticatedWorkspace roundId={roundId} projectId={projectId}/>;
}
async function AuthenticatedWorkspace({roundId,projectId}:{roundId:string;projectId:string}){
 const user=await requireChatGPTUser(roundId?`/?round=${encodeURIComponent(roundId)}`:projectId?`/?project=${encodeURIComponent(projectId)}`:'/');
 return <DraftProvider key={user.id}><ReviewWorkspace initialRoundId={roundId} initialProjectId={projectId} suppliedPilotAvailable={canImportSuppliedPilot(user)} user={{displayName:user.displayName,email:user.email}}/></DraftProvider>;
}
