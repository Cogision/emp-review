import {requireChatGPTUser} from '@/app/chatgpt-auth';
import {canImportSuppliedPilot} from '@/lib/pilot-import';
import CompletedPilotImport from '@/components/completed-pilot-import';
export const dynamic='force-dynamic';
export default async function Page(){
 const user=await requireChatGPTUser('/pilot/completed');
 if(!canImportSuppliedPilot(user))return <main className="max-w-xl mx-auto p-8"><h1 className="text-2xl font-semibold">This pilot belongs to another account</h1><p className="mt-4">Sign in with the account that supplied these papers to open its private collection.</p><a className="block mt-6 underline" href="/">Return to your workspace</a></main>;
 return <CompletedPilotImport/>;
}
