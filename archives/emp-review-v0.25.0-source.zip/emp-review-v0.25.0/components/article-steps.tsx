'use client';
import {Button} from './ui/button';
export const ARTICLE_STEPS=['Source','Claims','Evidence & links','Summary'] as const;
export default function ArticleSteps({step,available=1,disabled=false,onStep}:{step:number;available?:number;disabled?:boolean;onStep?:(step:number)=>void}){
 return <nav aria-label="Article analysis steps" className="max-w-6xl mx-auto mb-7"><ol className="grid grid-cols-2 sm:grid-cols-4 gap-2">{ARTICLE_STEPS.map((label,i)=><li key={label}><Button variant={step===i+1?'secondary':'ghost'} className={`w-full h-auto min-h-12 justify-start whitespace-normal text-left px-3 py-3 ${step===i+1?'border border-primary/30':''}`} aria-current={step===i+1?'step':undefined} disabled={disabled||i+1>available||!onStep} onClick={()=>onStep?.(i+1)}><span className={`rounded-full w-6 h-6 shrink-0 flex items-center justify-center text-sm ${step===i+1?'bg-primary text-primary-foreground':'bg-muted text-muted-foreground'}`}>{i+1}</span><span>{label}</span></Button></li>)}</ol></nav>;
}
