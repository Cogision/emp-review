'use client';
import {articleResultRows} from '@/lib/article-results';
import type {RecordDoc} from '@/lib/emp';
export default function ArticleWorkStatus({document:d,unsaved,busy}:{document:RecordDoc;unsaved:boolean;busy:boolean}){
 const rows=articleResultRows(d),checked=rows.filter(r=>r.checked).length;
 const progress=!d.analysis?'Source saved':rows.some(r=>r.blocked)?'An assessment needs clarification':rows.length&&checked===rows.length?'Human review complete':checked?`${checked} of ${rows.length} claim assessments checked`:'Awaiting your review';
 return <div role="status" aria-live="polite" className="mb-5 rounded-xl border bg-white px-4 py-3 flex flex-wrap justify-between gap-2 text-sm"><span className="font-medium">{busy?'Working…':unsaved?'Working changes · not applied':'Saved'} · {progress}</span><span className="text-muted-foreground">{unsaved?'Check the draft save status before closing. Assessment confirmation remains a separate action.':d.updatedAt?`Last saved ${new Date(d.updatedAt).toLocaleString('en-GB')}`:'The source is saved.'}</span></div>;
}
