'use client';
import {useEffect,useState,useRef} from 'react';
import {useDurableState,DraftNotice} from './draft-state';
import {correctionChanges,type CorrectionProposal} from '@/lib/assessment-correction';
import {deriveBridge,type RecordDoc} from '@/lib/emp';
import {assessmentState} from '@/lib/assessment-state';
import {BRIDGE_LABELS} from '@/lib/publication-profile';
import {Button} from './ui/button';
import {Textarea} from './ui/textarea';
const labels:Record<string,string>={evidenceSummary:'What the data show',evidenceRequired:'Evidence required',rationale:'Assessment reason',focal:'Focal support',role:'Role of the evidence',substitution:'Evidence transfer',bridgeClear:'Can the bridge be determined?'};
export default function AssessmentCorrection({document:d,claimId,apiKey,model,disabled,reviewDirty,initialFeedback,onDirty,onBusy,onApplied}:{document:RecordDoc;claimId?:string;apiKey:string;model:string;disabled:boolean;reviewDirty:boolean;initialFeedback:string;onDirty:(v:boolean)=>void;onBusy:(s:string)=>void;onApplied:(d:RecordDoc)=>void}){
 const touched=useRef(false);
 const note=useDurableState<string|null>(`article:${d.id}:correction:${claimId||'central'}`,null,d.sourceHash);
 const [savedFeedback,setSavedFeedback]=useState(initialFeedback),[proposal,setProposal]=useState<CorrectionProposal|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
 const feedback=note.value??savedFeedback??initialFeedback,setFeedback=note.set;
 useEffect(()=>{let live=true;fetch(`/api/documents/${d.id}/correction${claimId?`?claimId=${encodeURIComponent(claimId)}`:''}`).then(async r=>{const data=await r.json() as {error?:string;proposal:CorrectionProposal;document:RecordDoc};if(!r.ok)throw new Error(data.error||'Could not load the saved proposal.');if(live&&data.proposal&&!touched.current){setProposal(data.proposal);setSavedFeedback(data.proposal.feedback);}}).catch(e=>{if(live)setError(e.message);});return()=>{live=false;};},[d.id,claimId]);
 useEffect(()=>onDirty(feedback!==savedFeedback),[feedback,savedFeedback,onDirty]);
 useEffect(()=>()=>onDirty(false),[onDirty]);
 async function run(action:'propose'|'apply'){
  setError('');
  touched.current=true;
  const requestFeedback=feedback.trim();
  setBusy(true);onBusy(action==='propose'?'Checking the assessment against the saved source…':'Applying the correction as a draft…');
  try{const r=await fetch(`/api/documents/${d.id}/correction`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(action==='propose'?{action,revision:d.revision,feedback:requestFeedback,claimId,key:apiKey||undefined,model}:{action,revision:d.revision,proposalId:proposal?.id})});const data=await r.json() as {error?:string;proposal:CorrectionProposal;document:RecordDoc};if(!r.ok)throw new Error(data.error||'The correction could not be saved.');if(action==='propose'){setProposal(data.proposal);setFeedback(requestFeedback);setSavedFeedback(requestFeedback);}else{setProposal(null);setError('');onDirty(false);onApplied(data.document);}}
  catch(e){setError((e as Error).message);}finally{setBusy(false);onBusy('');}
 }
 const stale=!!proposal&&proposal.baseRevision!==d.revision;
 const changes=proposal?correctionChanges(proposal.before,proposal.candidate):[],type=d.review.reportType||d.analysis?.reportType||'CB';
 return <div id={`article-correction-${claimId||'central'}`} className="mt-5 space-y-4 border-t pt-5 scroll-mt-6"><h3 className="font-semibold">Check the assessment with AI</h3><p className="text-sm text-muted-foreground">AI can check the current assessment against the saved source and suggest justified corrections. You can leave the note empty for a general check. AI may also conclude that no changes are needed. The selected claim and its quotation stay fixed. Return to Claims if the selection needs changing.</p><DraftNotice draft={note} label="Correction note"/><label className="grid gap-2 text-sm font-medium">Your note (optional)<Textarea disabled={disabled||busy||note.blocked} value={feedback} onChange={e=>{touched.current=true;setFeedback(e.target.value);}} maxLength={4000} placeholder="Leave empty for a general check, or add a specific question."/></label><Button type="button" disabled={disabled||busy||note.blocked} onClick={()=>void run('propose')}>{busy?'Checking…':proposal?'Check again with AI':'Check assessment and suggest corrections'}</Button>
 {feedback!==savedFeedback&&<Button variant="ghost" disabled={disabled||busy||note.blocked} onClick={()=>setFeedback(savedFeedback)}>Discard unsent request</Button>}
 {error&&<p role="alert" className="rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm">{error}</p>}
 {proposal&&<section className="rounded-xl border p-4 space-y-4"><h4 className="font-semibold">AI review result · not applied</h4>{stale&&<p role="status" className="text-sm text-amber-900">The saved assessment has changed. Check again before applying a correction. Your note is kept.</p>}{!proposal.feedback.trim()&&<p className="text-sm">General assessment check · no additional note supplied</p>}<p className="text-sm">{BRIDGE_LABELS[assessmentState(d,proposal.before).bridge]} → {BRIDGE_LABELS[deriveBridge(proposal.candidate,type)]}</p><p className="text-sm whitespace-pre-wrap">{proposal.candidate.rationale}</p>{changes.length===0?<p className="text-sm">AI retained the existing assessment. Check its explanation against the source.</p>:<><p className="text-sm">{changes.length} changed fields. Applying replaces the current editable assessment with a draft. The original analysis and earlier decisions remain in history. Human verification must be repeated.</p><details><summary className="cursor-pointer text-sm font-semibold">Compare all changes before applying</summary><div className="mt-3 divide-y">{changes.map(x=><div key={x.field} className="py-3"><h5 className="text-sm font-semibold">{labels[x.field]||x.field}</h5><div className="grid sm:grid-cols-2 gap-3 mt-2 text-sm"><div className="rounded bg-slate-50 p-3"><b>Current</b><p className="whitespace-pre-wrap break-words mt-2">{x.before}</p></div><div className="rounded bg-primary/5 p-3"><b>Proposed</b><p className="whitespace-pre-wrap break-words mt-2">{x.after}</p></div></div></div>)}</div></details><Button disabled={disabled||busy||note.blocked||stale||feedback!==savedFeedback} onClick={()=>void run('apply')}>Apply as a draft for review</Button>{reviewDirty&&<p className="text-sm">Your review note is kept. Check the revised assessment before confirming it.</p>}</>}<p className="text-xs text-muted-foreground">{proposal.model} · {new Date(proposal.createdAt).toLocaleString('en-GB')} · This proposal is saved. You can leave it unapplied.</p></section>}
 </div>;
}
