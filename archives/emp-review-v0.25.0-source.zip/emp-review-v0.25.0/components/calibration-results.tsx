'use client';
import {calibrationMetrics,calibrationNarrative,calibrationCalculationLines,calibrationComparisonNotice} from '@/lib/publication-profile';
import {BASIS_LABELS,SOURCE_SELECTION_LABELS} from '@/lib/reporting';
import {Button} from './ui/button';

type Summary=ReturnType<typeof calibrationMetrics>;
const stageLabel=(stage:string)=>stage==='A'?'Title and abstract':stage==='B'?'Full text':'Excerpts';

export default function CalibrationResults({summary,onOpen,onShowAll,disabled}:{summary:Summary;onOpen:(id:string)=>void;onShowAll:()=>void;disabled:boolean}){
 if(!summary.recordCount)return null;
 const visible=summary.groups.some(g=>g.metrics.strata.some(s=>s.included>0));
 return <section className="rounded-2xl border border-primary/20 bg-primary/5 p-5 sm:p-6 space-y-6" aria-label="Pilot and calibration results">
  <div>
   <h3 className="text-xl font-semibold">Pilot and calibration results</h3>
   <p className="mt-2">These results describe your saved assessments. Calibration records remain excluded from the main research percentage.</p>
  </div>
  {!visible&&summary.view!=='provisional'&&<div className="rounded-xl border bg-white p-4 space-y-3">
   <p>No calibration assessments match the selected review status. Saved proposals are still available.</p>
   <Button variant="outline" disabled={disabled} onClick={onShowAll}>Show all saved pilot results</Button>
  </div>}
  {summary.groups.map(group=>{
   const notice=calibrationComparisonNotice(group),strata=group.metrics.strata.filter(g=>g.included>0);
   const comparisons=group.comparisons.filter(c=>c.status==='changed'||c.status==='pending');
   return <section key={group.key} className="space-y-4">
    <div><h4 className="text-lg font-semibold">{group.label}</h4><p className="text-sm text-muted-foreground">{group.papers} papers · {group.recordCount} saved source-stage assessments</p></div>
    {notice&&<div className="rounded-xl border border-amber-300 bg-amber-50 p-4 space-y-2 text-amber-950" role="note">
     <h5 className="font-semibold">{notice.title}</h5><p className="leading-relaxed">{notice.text}</p>
    </div>}
    <div className="grid md:grid-cols-2 gap-4">{strata.map(g=><article key={g.key} className="rounded-xl border bg-white p-5 space-y-3">
     <h5 className="font-semibold">{stageLabel(g.stage)}</h5>
     <p className="inline-block rounded-md bg-muted px-2 py-1 text-sm font-medium">{BASIS_LABELS[g.basis]}</p>
     <p className="text-lg leading-relaxed">{calibrationNarrative(g)}</p>
     <p className="text-sm">{g.basis==='ai'?'These are AI proposals awaiting human verification.':`${g.pending} assessments await human source verification.`}</p>
    </article>)}</div>
    {!group.metrics.strata.length&&<p>This group has no clinical-use (CB) claim in the denominator. Its saved report classifications are shown in the table below.</p>}
    {comparisons.length>0&&<div className="space-y-3">
     <h5 className="font-semibold">Central claims across saved source reviews</h5>
     {comparisons.map(c=><article key={c.documentId} className="rounded-xl border bg-white p-4 sm:p-5 space-y-4">
      <div><p className="text-sm font-semibold text-amber-900">{c.status==='changed'?'Changed claim · not a direct comparison':'Claim comparison needs checking'}</p><h6 className="mt-1 font-medium break-words">{c.title}</h6></div>
      <div className="grid md:grid-cols-2 gap-4">
       <div><p className="text-sm font-medium mb-2">{stageLabel(c.earlierStage)} · earlier claim saved for comparison</p><p className="border-l-2 border-muted pl-3 leading-relaxed break-words">{c.earlierStatement}</p></div>
       <div><p className="text-sm font-medium mb-2">{stageLabel(c.stage)} · current central claim</p><p className="border-l-2 border-primary/40 pl-3 leading-relaxed break-words">{c.currentStatement||'No central claim selected.'}</p></div>
      </div>
      <p className="text-sm leading-relaxed">{c.stale?'An edit invalidated the earlier comparison. Compare the current claim again.':c.reason||'Whether these are the same proposition has not yet been checked.'}</p>
      <Button variant="outline" disabled={disabled} onClick={()=>onOpen(c.documentId)}>Open assessment</Button>
     </article>)}
    </div>}
    <details className="rounded-xl border bg-white p-4">
     <summary className="cursor-pointer font-medium">Calculation details and denominators</summary>
     <div className="mt-4 space-y-5">
      <p className="text-sm">Only one central clinical-use (CB) claim per eligible article and source stage enters each ratio. Contextual claims do not add observations. Methodological reports and reports without an applicable EMP claim remain in the table below.</p>
      <p className="text-sm">{group.types.CB} CB · {group.types.M} methodological · {group.types.NMC} no applicable EMP claim{group.types.NC?` · ${group.types.NC} non-empirical`:''}{group.types.pending?` · ${group.types.pending} awaiting classification`:''}</p>
      {strata.map(g=><div key={g.key} className="border-t pt-4 space-y-2">
       <p className="font-medium">{stageLabel(g.stage)} · {BASIS_LABELS[g.basis]}</p>
       <p className="text-sm text-muted-foreground">{SOURCE_SELECTION_LABELS[g.sourceSelection]} · {g.protocol} · {g.fieldScope} fields</p>
       {calibrationCalculationLines(g).map((line,i)=><p key={i} className="text-sm">{line}</p>)}
       <p className="text-sm">{g.counts.B0} supported within scope · {g.counts.B1} open · {g.counts.B2} inheritance · {g.counts.B3} unbridged · {g.counts.BU} unresolved</p>
      </div>)}
     </div>
    </details>
    {(group.metrics.duplicates.length>0||group.metrics.brokenDuplicates.length>0)&&<p className="text-amber-900" role="status">Duplicate calibration records need reconciliation in the reports’ reporting settings. Affected percentages are withheld.</p>}
   </section>;
  })}
  <p className="border-t pt-4 text-sm">The pilot does not estimate prevalence in psychiatry. A lower full-text percentage does not show that reading the full text reduced evidential inheritance.</p>
 </section>;
}
