'use client';
import {useId,useMemo,useState} from 'react';
import {claimCategoryMetrics,type ClaimCountScope,type AssessmentView} from '@/lib/claim-category-metrics';
import {selectClaimCategoryGroup,collectionKey,collectionName,sourceName,basisName,methodName,type ClaimCategorySummary,type ClaimCategorySelection,type ClaimCategoryGroup} from '@/lib/claim-category-view';
import {metricPercent,BRIDGE_LABELS} from '@/lib/publication-profile';
import type {ProjectData} from '@/lib/projects';
import {Switch} from './ui/switch';
import {Choice} from './claim-editor';
import {Button} from './ui/button';
import {Table,TableHeader,TableBody,TableRow,TableHead,TableCell} from './ui/table';
const outcomeNames:Record<string,string>={B0:'Supported within scope',B1:'Open: a specified test is needed',B2:'Evidential inheritance',B3:'Assertion without an evidential bridge',BU:'Unresolved'};
const outcomeHelp:Record<string,string>={B0:'The evidence matches this claim. See the article assessment for evidence adequacy.',B1:'The authors explicitly leave the necessary test open.',B2:'Evidence for a different claim is used as support for this one.',B3:'Support is missing; no substituted evidence was identified.',BU:'The available source does not settle the assessment.'};
export function ClaimCategoryTables({summary,group:selected}:{summary:ClaimCategorySummary;group?:ClaimCategoryGroup}){
 const g=selected||summary.groups[0];
 if(!g)return <p className="text-base">No active claims match these choices. A percentage cannot be calculated.</p>;
 const inherited=g.categories.find(c=>c.code==='B2')!;
 return <article className="space-y-5" aria-label="Selected claim outcomes">
  <div className="rounded-xl bg-primary/5 p-5 space-y-2"><p className="text-lg font-semibold">{g.missingCentral&&!g.total?`${g.reports} ${g.reports===1?'article needs':'articles need'} a central claim selected`:`${g.total} claims from ${g.reports} ${g.reports===1?'article':'articles'}`}</p><p className="text-base">{sourceName(g.stage)} · {basisName(g.basis)}</p><p className="text-base">{g.blocked?'Percentages need clarification before they can be reported.':`${inherited.count} of ${g.total} claims show evidential inheritance${inherited.percent===null?'':` (${metricPercent(inherited.percent)})`}.`}</p></div>
  {g.reason&&<p className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-base text-amber-950" role="status">{g.reason}</p>}
  <Table><TableHeader><TableRow><TableHead className="text-sm">Assessment</TableHead><TableHead className="text-right text-sm">Claims</TableHead><TableHead className="text-right text-sm">Share (%)</TableHead></TableRow></TableHeader><TableBody>{g.categories.map(c=><TableRow key={c.code} className={c.code==='B2'?'bg-primary/5':''}><TableCell className="whitespace-normal"><p className="text-base font-medium">{outcomeNames[c.code]}</p><p className="text-sm text-muted-foreground mt-1">{outcomeHelp[c.code]}</p></TableCell><TableCell className="text-right tabular-nums text-base">{c.count}</TableCell><TableCell className="text-right tabular-nums whitespace-normal text-base">{c.percent===null?'Not calculated':metricPercent(c.percent)}</TableCell></TableRow>)}</TableBody></Table>
  {g.unavailable>0&&<p className="text-base">{Object.entries(g.counts).filter(([code,count])=>count&&!g.categories.some(c=>c.code===code)).map(([code,count])=>`${count} ${BRIDGE_LABELS[code]||code}`).join(' · ')}</p>}
  <p className="text-sm leading-relaxed">Each share uses all {g.total} claims in this group, including unresolved claims. Percentages describe the saved assessments; they do not express confidence.</p>
  <details><summary className="cursor-pointer text-sm font-medium">Calculation details</summary><div className="space-y-2 mt-3 text-sm"><p>{g.central} central · {g.contextual} contextual claims. An article may contribute more than one claim.</p><p>{methodName(g)}.</p><p>{!g.total?'A denominator is not available until one central claim is selected for each article.':<>Calculation: category count ÷ {g.total} × 100. For evidential inheritance: {inherited.count} / {g.total}{inherited.percent!==null?` = ${metricPercent(inherited.percent)}`:'; percentage not calculated'}.</>}</p><p>Changing the selected group changes the denominator. Abstract and full-text results are not a direct before/after comparison unless the same articles and claims are assessed.</p></div></details>
 </article>;
}
export default function ClaimCategoryPercentages({data,view,disabled}:{data:ProjectData;view:AssessmentView;disabled:boolean}){
 const [show,setShow]=useState(false),[scope,setScope]=useState<ClaimCountScope>('all'),[selection,setSelection]=useState<ClaimCategorySelection>({});
 const id=useId(),summary=useMemo(()=>show?claimCategoryMetrics(data,view,scope):null,[data,view,scope,show]),chosen=summary?selectClaimCategoryGroup(summary,selection):null;
 function choose(values:ClaimCategorySelection){setSelection({...selection,...values,method:values.method});}
 return <section id="claim-percentages" className="scroll-mt-5 rounded-2xl border border-primary/30 bg-white p-5 sm:p-6 space-y-5" aria-label="Claim percentages">
  <div className="flex flex-wrap items-center justify-between gap-4"><div><h3 className="text-xl font-semibold">Claim outcomes (%)</h3><p className="text-base text-muted-foreground mt-2">See how the claims in a selected group were assessed.</p></div><div className="flex items-center gap-3"><Switch id={id} checked={show} disabled={disabled} onCheckedChange={setShow}/><label htmlFor={id} className="text-base font-medium cursor-pointer">Show percentages</label></div></div>
  {summary&&chosen&&<div className="space-y-6">
   <fieldset disabled={disabled} className="space-y-4"><legend className="sr-only">Choose the claims to count</legend><div><p className="text-sm font-medium mb-2">Claims counted</p><div className="flex flex-wrap gap-2">{[['all','All active claims'],['central','Central claims only']].map(([value,label])=><Button key={value} type="button" variant={scope===value?'secondary':'outline'} aria-pressed={scope===value} disabled={disabled} onClick={()=>setScope(value as ClaimCountScope)}>{label}</Button>)}</div></div>
    <div className="grid md:grid-cols-3 gap-4">
     {chosen.collections.length>1?<Choice label="Group of articles" value={chosen.collection} options={chosen.collections.map(key=>[key,collectionName(summary.groups.find(g=>collectionKey(g)===key)!)])} onChange={collection=>choose({collection})}/>:chosen.group&&<div><p className="text-sm text-muted-foreground">Group of articles</p><p className="text-base mt-2">{collectionName(chosen.group)}</p></div>}
     {chosen.stages.length>1?<Choice label="Source material" value={chosen.stage} options={chosen.stages.map(stage=>[stage,sourceName(stage)])} onChange={stage=>choose({collection:chosen.collection,stage})}/>:chosen.group&&<div><p className="text-sm text-muted-foreground">Source material</p><p className="text-base mt-2">{sourceName(chosen.stage)}</p></div>}
     {chosen.bases.length>1?<Choice label="Assessments" value={chosen.basis} options={chosen.bases.map(basis=>[basis,basisName(basis)])} onChange={basis=>choose({collection:chosen.collection,stage:chosen.stage,basis})}/>:chosen.group&&<div><p className="text-sm text-muted-foreground">Assessments</p><p className="text-base mt-2">{basisName(chosen.basis)}</p></div>}
    </div>
    {chosen.methods.length>1&&<Choice label="Analysis method" value={chosen.group.key} options={chosen.methods.map(g=>[g.key,methodName(g)])} onChange={method=>choose({collection:chosen.collection,stage:chosen.stage,basis:chosen.basis,method})}/>}
   </fieldset>
   <ClaimCategoryTables summary={summary} group={chosen.group}/>
  </div>}
 </section>;
}
