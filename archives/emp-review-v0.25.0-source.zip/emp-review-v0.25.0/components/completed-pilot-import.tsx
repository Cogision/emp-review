'use client';
import {useEffect,useRef,useState} from 'react';
import {Button} from './ui/button';
type RecordInfo={pilotId:string;stage:'A'|'B';title:string};
export default function CompletedPilotImport(){
 const [progress,setProgress]=useState(0),[working,setWorking]=useState('Opening your collection…'),[error,setError]=useState('');
 const running=useRef(false);
 async function run(){
  if(running.current)return;running.current=true;setError('');setProgress(0);
  try{
   const response=await fetch('/api/pilot/completed',{cache:'no-store'}),data=await response.json() as {records:RecordInfo[];error?:string};
   if(!response.ok)throw new Error(data.error||'The prepared pilot could not be opened.');
   let projectId='';
   for(let i=0;i<data.records.length;i++){
    const r=data.records[i];setWorking(`${r.pilotId} · ${r.stage==='A'?'Abstract':'Full text'} · ${r.title}`);
    const res=await fetch('/api/pilot/completed',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pilotId:r.pilotId,stage:r.stage})}),saved=await res.json() as {projectId:string;error?:string};
    if(!res.ok)throw new Error(saved.error||'The current record could not be saved.');projectId=saved.projectId;setProgress(i+1);
   }
   window.location.replace(`/?project=${encodeURIComponent(projectId)}`);
  }catch(e){setError((e as Error).message);running.current=false;}
 }
 useEffect(()=>{void run();},[]);
 return <main className="max-w-2xl mx-auto p-6 sm:p-10 space-y-6"><p className="text-sm text-muted-foreground">EMP · Supplied-paper pilot</p><h1 className="text-3xl font-semibold">Saving your five-article pilot</h1><p>Ten assessments will appear in one collection: an abstract assessment and a full-text assessment for each paper. Each contains the source, selected claims and AI reasoning.</p><div role="status" aria-live="polite" className="rounded-xl border p-5 space-y-3"><p className="font-semibold">{progress} of 10 assessments saved</p><progress className="w-full" value={progress} max={10}/><p className="text-sm">{working}</p></div><p className="text-sm text-muted-foreground">AI proposals · Not verified by a human · Calibration, excluded from the main research percentage. Previously saved decisions are preserved.</p>{error&&<div role="alert" className="border border-amber-300 rounded-xl p-5 space-y-4"><p>{error}</p><p className="text-sm">Saved records are safe. Resume to finish the remaining records without creating duplicates.</p><Button onClick={()=>void run()}>Resume import</Button></div>}<a href="/" className="inline-block underline text-sm">Return to workspace</a></main>;
}
