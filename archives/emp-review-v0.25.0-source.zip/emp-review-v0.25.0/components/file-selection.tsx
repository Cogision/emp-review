"use client";
import {tr,getLanguage} from "@/lib/i18n";
import { useRef } from "react";
import { FileText, Upload, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { type Source } from "@/lib/emp";
export type ImportFile={id:string;file:File;source:Source|null;error?:string;savedId?:string;submitted?:{stage:string;coverage:string}};
export default function FileSelection({items,mode,onMode,primaryId,onPrimary,onAdd,onRemove,busy,error}:{
 items:ImportFile[];mode:"bundle"|"separate";onMode:(v:"bundle"|"separate")=>void;primaryId:string;onPrimary:(id:string)=>void;
 onAdd:(files:File[])=>void;onRemove:(id:string)=>void;busy:boolean;error:string;
}){
 const input=useRef<HTMLInputElement>(null);
 return <div className="space-y-4">
  <input ref={input} type="file" multiple className="hidden" accept=".pdf,.docx,.txt,.md" onChange={e=>{onAdd(Array.from(e.target.files||[]));e.target.value="";}}/>
  <button type="button" disabled={busy} onClick={()=>input.current?.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();if(!busy)onAdd(Array.from(e.dataTransfer.files));}} className="w-full border-2 border-dashed rounded-xl min-h-40 flex flex-col items-center justify-center p-5 hover:bg-muted/40 border-[#b6c7b8]">
   <Upload size={25} className="text-primary mb-3"/><span className="font-medium">{items.length?tr("Add more files"):tr("Select files or drag them here")}</span><span className="text-sm text-muted-foreground mt-2">{tr("PDF, DOCX, TXT, MD · up to 10 files")}</span>
  </button>
  <details open={items.length>1?true:undefined}><summary className="cursor-pointer text-sm font-medium">{mode==='bundle'?'One article and its supplements':'Separate articles'}</summary><fieldset disabled={busy} className="grid gap-2 mt-3"><legend className="text-sm font-medium mb-2">{tr("How should the files be treated?")}</legend>
   <label className={`rounded-lg border p-3 flex gap-3 items-start cursor-pointer ${mode==="bundle"?"border-primary/40 bg-primary/5":""}`}><input type="radio" name="file-mode" value="bundle" checked={mode==="bundle"} onChange={()=>onMode("bundle")} className="mt-1 accent-primary"/><span className="text-sm"><b>{tr("Article and supplements")}</b><span className="block text-muted-foreground mt-1">{tr("One review. Select the main file; the remaining files supplement its analysis.")}</span></span></label>
   <label className={`rounded-lg border p-3 flex gap-3 items-start cursor-pointer ${mode==="separate"?"border-primary/40 bg-primary/5":""}`}><input type="radio" name="file-mode" value="separate" checked={mode==="separate"} onChange={()=>onMode("separate")} className="mt-1 accent-primary"/><span className="text-sm"><b>{tr("Separate publications")}</b><span className="block text-muted-foreground mt-1">{tr("Each file receives its own review and analysis.")}</span></span></label>
  </fieldset></details>
  <p className="text-xs text-muted-foreground">{mode==="bundle"?tr("Up to 10 MB of files and 120,000 characters in total per review."):tr("Up to 10 MB and 120,000 characters per publication. Files are saved sequentially.")}</p>
  {items.length>0&&<ul className="space-y-2">{items.map(item=><li key={item.id} className="rounded-xl border p-3 bg-white"><div className="flex items-start gap-3"><FileText size={17} className="shrink-0 mt-1 text-primary"/><div className="flex-1 min-w-0"><p className="text-sm font-medium break-words">{item.file.name}</p><p className="text-xs text-muted-foreground mt-1">{(item.file.size/1000000).toLocaleString(getLanguage()==="pl"?"pl-PL":"en-GB",{maximumFractionDigits:2})} MB{item.source&&tr(" · {0} passages", [item.source.blocks.length])}</p>{mode==="bundle"&&item.source&&<label className="inline-flex gap-2 items-center mt-2 text-xs"><input type="radio" name="primary-file" checked={primaryId===item.id} onChange={()=>onPrimary(item.id)} disabled={busy} className="accent-primary"/>{primaryId===item.id?tr("Main file"):tr("Set as main file")}</label>}{mode==="separate"&&item.savedId&&<p className="text-xs text-primary mt-2 flex items-center gap-1"><Check size={14}/>{tr("Review saved")}</p>}</div><Button aria-label={tr("Remove from queue: {0}", [item.file.name])} type="button" size="icon" variant="ghost" disabled={busy} onClick={()=>onRemove(item.id)}><X size={16}/></Button></div>{item.submitted&&!item.savedId&&item.error&&<p className="text-xs text-muted-foreground mt-2">{tr("Retrying will retain the source coverage from the first save attempt.")}</p>}{item.error&&<p role="alert" className="text-sm text-amber-900 mt-2">{tr(item.error)}</p>}{item.source&&<details className="mt-2 text-xs text-muted-foreground"><summary className="cursor-pointer">{tr("Text preview and notes")}</summary><p className="line-clamp-4 mt-2 leading-relaxed">{item.source.blocks[0]?.text}</p>{item.source.warnings.map((w,i)=><p key={i} className="mt-2 text-amber-800">{tr(w)}</p>)}</details>}</li>)}</ul>}
  {error&&<p role="alert" className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-sm text-amber-950">{error}</p>}
 </div>;
}
