'use client';
import {useEffect} from 'react';
import {useDurableState,DraftNotice} from './draft-state';
import type {AutomaticState} from '@/lib/automatic';
import type {Source} from '@/lib/emp';
import {Button} from './ui/button';
import {Textarea} from './ui/textarea';
import {Choice} from './claim-editor';
import {Checkbox} from './ui/checkbox';
import {quoteExists} from '@/lib/emp';
export default function FocalSelection({documentId,state,source,busy:working,onConfirm,onDirty}:{documentId:string;state:AutomaticState;source:Source;busy:boolean;onConfirm:(selection:unknown)=>void;onDirty?:(dirty:boolean)=>void}){
 const memory=useDurableState(`article:${documentId}:selection:${state.runId}`,{claims:state.inventory.claims,included:state.inventory.claims.map(c=>c.id),extensionReason:state.inventory.extensionReason||'',rationale:state.inventory.summary.slice(0,2000)},state.runId);
 const {claims,included,extensionReason,rationale}=memory.value,busy=working||memory.blocked;
 const setClaims=(update:(cs:typeof claims)=>typeof claims)=>memory.set(v=>({...v,claims:update(v.claims)}));
 const setIncluded=(update:(ids:string[])=>string[])=>memory.set(v=>({...v,included:update(v.included)}));
 const setExtensionReason=(extensionReason:string)=>memory.set(v=>({...v,extensionReason})),setRationale=(rationale:string)=>memory.set(v=>({...v,rationale}));
 useEffect(()=>{onDirty?.(JSON.stringify(claims)!==JSON.stringify(state.inventory.claims)||JSON.stringify(included)!==JSON.stringify(state.inventory.claims.map(c=>c.id))||rationale!==state.inventory.summary.slice(0,2000)||extensionReason!==(state.inventory.extensionReason||''));},[claims,included,rationale,extensionReason,state,onDirty]);
 const eligible=['CB','M'].includes(state.inventory.reportType);
 const selected=claims.filter(c=>included.includes(c.id));
 const valid=!eligible||selected.length>0&&(selected.length<=3||!!extensionReason.trim())&&selected.filter(c=>c.primary).length===1&&selected.every(c=>c.statement.trim()&&quoteExists(c.citation,source));
 return <section className="max-w-3xl mx-auto rounded-2xl border bg-white p-6 space-y-5">
 <div><p className="text-sm text-primary mb-2">Step 2 of 4 · Confirm the claims</p><h2 className="text-2xl font-semibold">Which claims should be assessed?</h2><p className="mt-2 text-muted-foreground">Choose the claim that answers the authors’ main question. Normally keep one or two contextual claims. Add more only when a material distinction requires it.</p></div>
 <DraftNotice draft={memory} label="Claim selection"/>
 {!eligible&&<p>{state.inventory.reportType}: {state.inventory.typeRationale}</p>}
 {claims.map(c=><article key={c.id} className={`rounded-xl border p-4 space-y-3 ${c.primary?'border-primary bg-primary/5':''}`}>
 <div className="flex gap-3 items-center"><label className="flex gap-2 items-center text-sm"><Checkbox checked={included.includes(c.id)} disabled={busy||c.primary} onCheckedChange={v=>setIncluded(ids=>v?[...ids,c.id]:ids.filter(id=>id!==c.id))}/>{c.primary?'Central claim':'Optional context'}</label>{!c.primary&&<Button variant="link" size="sm" disabled={busy} onClick={()=>{setClaims(cs=>cs.map(x=>({...x,primary:x.id===c.id})));setIncluded(ids=>[...new Set([...ids,c.id])]);}}>Use as central claim</Button>}</div>
 <p className="font-medium leading-relaxed">{c.statement}</p><blockquote className="text-sm border-l-2 pl-3 whitespace-pre-wrap">{c.citation.quote}</blockquote>
 <details><summary className="text-sm cursor-pointer">Edit claim or source quotation</summary><div className="mt-3 space-y-3"><label className="grid gap-2 text-sm">Claim<Textarea value={c.statement} maxLength={5000} disabled={busy} onChange={e=>setClaims(cs=>cs.map(x=>x.id===c.id?{...x,statement:e.target.value}:x))}/></label><Choice label="Source passage" value={c.citation.blockId} options={source.blocks.map(b=>[b.id,b.label])} onChange={blockId=>setClaims(cs=>cs.map(x=>x.id===c.id?{...x,citation:{...x.citation,blockId}}:x))}/><p className="text-sm max-h-48 overflow-y-auto whitespace-pre-wrap">{source.blocks.find(b=>b.id===c.citation.blockId)?.text}</p><label className="grid gap-2 text-sm">Exact quotation<Textarea disabled={busy} value={c.citation.quote} maxLength={2500} onChange={e=>setClaims(cs=>cs.map(x=>x.id===c.id?{...x,citation:{...x.citation,quote:e.target.value}}:x))}/></label>{!quoteExists(c.citation,source)&&<p role="alert" className="text-sm text-amber-900">Copy an exact passage from the selected source.</p>}</div></details>
 </article>)}
 {eligible&&<Button variant="outline" disabled={busy||claims.length>=80} onClick={()=>{const id=Array.from({length:80},(_,i)=>`C${String(i+1).padStart(2,'0')}`).find(id=>!claims.some(c=>c.id===id))!;setClaims(cs=>[...cs,{id,primary:false,statement:'',citation:{blockId:source.blocks[0].id,quote:''}}]);setIncluded(ids=>[...ids,id]);}}>Add a material contextual claim</Button>}
 {selected.length>3&&<label className="grid gap-2 text-sm">Why are more than three claims necessary?<Textarea value={extensionReason} maxLength={2000} onChange={e=>setExtensionReason(e.target.value)} placeholder="Describe the material distinction that would otherwise be lost."/></label>}
 <details><summary className="text-sm cursor-pointer">Why this selection?</summary><label className="grid gap-2 mt-3 text-sm">Selection rationale<Textarea value={rationale} onChange={e=>setRationale(e.target.value)} maxLength={2000}/></label></details>
 <Button disabled={busy||!valid||!rationale.trim()} onClick={()=>onConfirm({claims:selected,rationale,extensionReason})}>{eligible?'Confirm claim selection':'Confirm report type and finish'}</Button>
 <p className="text-sm text-muted-foreground">This confirms which claims the authors make. Their evidence is assessed in the next step.</p>
 </section>;
}
