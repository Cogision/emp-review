'use client';
import {useEffect,useRef,useState} from 'react';
import {useDurableState,DraftNotice} from './draft-state';
import type {RecordDoc} from '@/lib/emp';
import {reportSettings,makeStageLink,stageComparison,SOURCE_SELECTION_LABELS} from '@/lib/reporting';
import type {Reporting} from '@/lib/reporting-schema';
import {request} from '@/lib/http';
import {Button} from './ui/button';
import {Input} from './ui/input';
import {Textarea} from './ui/textarea';
import {Choice} from './claim-editor';
import {toast} from 'sonner';

type Entry={id:string;title:string;stage:string;analyzed:number};
export default function ReportingSettings({document:d,reports,disabled,onSaved,onBusy,onDirty}:{document:RecordDoc;reports:Entry[];disabled:boolean;onSaved:(d:RecordDoc)=>void;onBusy:(v:boolean)=>void;onDirty:(v:boolean)=>void}){
 const memory=useDurableState(`article:${d.id}:reporting`,reportSettings(d),`${d.sourceHash}:${d.revision}`),value=memory.value,setValue=memory.set;
 const [working,setWorking]=useState(false);
 const previousSettings=useRef(JSON.stringify(reportSettings(d)));
 useEffect(()=>{const next=JSON.stringify(reportSettings(d));if(next!==previousSettings.current){if(JSON.stringify(value)===previousSettings.current)setValue(reportSettings(d));previousSettings.current=next;}},[d.revision]);
 const changed=JSON.stringify(value)!==JSON.stringify(reportSettings(d)),pair=stageComparison(d);
 useEffect(()=>{onDirty(changed);return()=>onDirty(false);},[changed,onDirty]);
 function field<K extends keyof Reporting>(key:K,v:Reporting[K]){setValue(old=>({...old,[key]:v}));}
 async function link(id:string){if(id==='none'){field('stageLink',undefined);return;}setWorking(true);onBusy(true);try{const parent=await request<RecordDoc>(`/api/documents/${id}`);field('stageLink',makeStageLink(parent,'Check whether the full source supplies the evidence required by the earlier central claim.'));}catch(e){toast.error((e as Error).message);}finally{setWorking(false);onBusy(false);}}
 async function save(){setWorking(true);onBusy(true);try{const saved=await request<RecordDoc>(`/api/documents/${d.id}/reporting`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision:d.revision,reporting:value})});await memory.controller.clear(reportSettings(saved)).catch(()=>toast.error('Settings saved. The earlier draft could not be cleared; check its notice.'));onDirty(false);onSaved(saved);toast.success('Reporting settings saved.');}catch(e){toast.error((e as Error).message);}finally{setWorking(false);onBusy(false);}}
 return <details className="rounded-xl border bg-white p-5 mb-5"><summary className="cursor-pointer font-medium">Reporting scope, duplicate imports & source links{pair?.status==='pending'?' · proposition comparison pending':''}</summary><DraftNotice draft={memory} label="Reporting settings"/><fieldset disabled={disabled||working||memory.blocked} className="mt-5 space-y-4">
 <label className="grid gap-2 text-sm">Publication identifier<Input value={value.publicationId} maxLength={320} onChange={e=>field('publicationId',e.target.value)} placeholder="DOI, PMID or a stable publication identifier"/></label>
 <Choice label="Role in the collection" value={value.role} options={[["audit","Audit report"],["calibration","Calibration / worked example"],["excluded","Excluded from central-claim results"]]} onChange={v=>field('role',v as Reporting['role'])}/>
 {value.role!=='audit'&&<label className="grid gap-2 text-sm">Reason<Textarea value={value.reason} maxLength={2000} onChange={e=>field('reason',e.target.value)}/></label>}
 <Choice label="How was this source stage selected?" value={value.sourceSelection} options={Object.entries(SOURCE_SELECTION_LABELS)} onChange={v=>field('sourceSelection',v as Reporting['sourceSelection'])}/>
 {value.sourceSelection!=='unspecified'&&<label className="grid gap-2 text-sm">Selection rule<Textarea value={value.selectionReason} maxLength={2000} onChange={e=>field('selectionReason',e.target.value)} placeholder="Name the prespecified rule or explain why this report was selected for follow-up."/></label>}
 <Choice label="Duplicate of another saved report at this source stage" value={value.duplicateOf||'none'} options={[["none","Not marked as a duplicate"],...reports.filter(r=>r.id!==d.id&&r.stage===d.stage).map(r=>[r.id,r.title] as [string,string])]} onChange={v=>field('duplicateOf',v==='none'?'':v)}/>
 {value.duplicateOf&&<label className="grid gap-2 text-sm">Duplicate reason<Textarea value={value.duplicateReason} maxLength={2000} onChange={e=>field('duplicateReason',e.target.value)}/><span className="text-muted-foreground">This preserves both records and excludes this duplicate from the central-claim denominator.</span></label>}
 <Choice label="Earlier source review of this publication" value={value.stageLink?.documentId||'none'} options={[["none","No linked source review"],...reports.filter(r=>r.id!==d.id&&r.analyzed).map(r=>[r.id,`${r.stage} · ${r.title}`] as [string,string])]} onChange={v=>void link(v)}/>
 {value.stageLink&&<div className="rounded-lg bg-muted/40 p-4 space-y-4"><p className="text-sm font-medium">Frozen earlier proposition</p><blockquote className="text-sm border-l-2 pl-3">{value.stageLink.statement}</blockquote>
 <label className="grid gap-2 text-sm">Question for this source<Textarea value={value.stageLink.question} maxLength={2000} onChange={e=>field('stageLink',{...value.stageLink!,question:e.target.value})}/></label>
 <Choice label="Does the current central claim express the same proposition?" value={value.stageLink.relation} options={[["pending","Not yet checked"],["same","Same proposition"],["changed","Materially different proposition"]]} onChange={v=>field('stageLink',{...value.stageLink!,relation:v as 'pending'|'same'|'changed'})}/>
 {value.stageLink.relation!=='pending'&&<label className="grid gap-2 text-sm">Reason for the comparison<Textarea value={value.stageLink.reason} maxLength={2000} onChange={e=>field('stageLink',{...value.stageLink!,reason:e.target.value})}/></label>}
 <p className="text-sm text-muted-foreground">A changed claim is a claim-selection shift. These linked reviews are not a blinded A/B experiment. Changes to the current proposition require a new comparison.</p></div>}
 <label className="grid gap-2 text-sm">Reason for more than three focal claims, when needed<Textarea value={value.extensionReason} maxLength={2000} onChange={e=>field('extensionReason',e.target.value)} placeholder={d.analysis?.selection?.extensionReason||'Explain which material distinction needs an additional claim.'}/></label>
 <div className="flex gap-3"><Button disabled={!changed||working} onClick={()=>void save()}>Save reporting settings</Button>{changed&&<Button variant="outline" onClick={()=>void memory.controller.clear(reportSettings(d)).catch(()=>{})}>Discard changes</Button>}</div>
 </fieldset></details>;
}
