"use client";
import {useEffect,useState} from 'react';
import {Copy,Mail,UserPlus} from 'lucide-react';
import {Button} from './ui/button';
import {Input} from './ui/input';
import type {CreatedRoundInvitation,RoundInvitation} from '@/lib/review-rounds';
import {invitationMessage,invitationStatus,invitationUrl,recipientEmailSchema} from '@/lib/reviewer-invitations';

export default function RoundInvitationsPanel({invites,disabled,onCreate,onRevoke,collaborators=[]}:{
 invites:RoundInvitation[];disabled:boolean;collaborators?:{name:string;email:string}[];
 onCreate:(email:string)=>Promise<CreatedRoundInvitation|undefined>;
 onRevoke:(id:string)=>Promise<unknown>;
}){
 const [email,setEmail]=useState(''),[created,setCreated]=useState<(CreatedRoundInvitation&{url:string})|null>(null),[message,setMessage]=useState(''),[error,setError]=useState(''),[now,setNow]=useState(Date.now);
 useEffect(()=>{const timer=setInterval(()=>setNow(Date.now()),30000);return()=>clearInterval(timer);},[]);
 const parsed=recipientEmailSchema.safeParse(email);
 const matching=created&&invites.find(i=>i.recipientEmail===created.recipientEmail&&i.expiresAt===created.expiresAt);
 const active=created&&new Date(created.expiresAt).getTime()>now&&(!matching||invitationStatus(matching,now)==='Awaiting reviewer');
 async function create(e:React.FormEvent){
  e.preventDefault();if(disabled)return;setError('');setMessage('');
  if(!parsed.success){setError('Enter a valid email address.');return;}
  const result=await onCreate(parsed.data);
  if(result){setCreated({...result,url:invitationUrl(window.location.origin,result.token)});setEmail('');setMessage('Invitation created. Copy the link or open an email draft to share it. No email has been sent.');}
 }
 async function copy(value:string){try{await navigator.clipboard.writeText(value);setMessage('Copied. You can now send it to the reviewer.');}catch{setError('Clipboard access is unavailable. Select and copy the invitation link below.');}}
 return <div className="space-y-5">
  {collaborators.length>0&&<label className="grid gap-2 text-sm font-medium">Choose a project collaborator (optional)<select className="rounded-md border bg-white p-2" value="" disabled={disabled} onChange={e=>setEmail(e.target.value)}><option value="">Choose a collaborator</option>{collaborators.map(c=><option key={c.email} value={c.email}>{c.name} · {c.email}</option>)}</select><span className="font-normal text-muted-foreground">They still join this article’s round and need your approval.</span></label>}
  <form onSubmit={e=>void create(e)} className="flex flex-wrap items-end gap-3">
   <label className="grid gap-2 text-sm font-medium flex-1 min-w-56" htmlFor="reviewer-invitation-email">Reviewer email
    <Input id="reviewer-invitation-email" type="email" autoComplete="email" placeholder="reviewer@example.org" value={email} maxLength={254} disabled={disabled} onChange={e=>setEmail(e.target.value)} aria-describedby="reviewer-email-help" required/>
   </label>
   <Button disabled={disabled||!parsed.success} type="submit"><UserPlus size={16}/>Create invitation</Button>
  </form>
  <p id="reviewer-email-help" className="text-sm text-muted-foreground">Use the email address on the reviewer’s ChatGPT account. They request to join, and you approve their account before starting the round.</p>
  {message&&<p role="status" className="text-sm text-primary">{message}</p>}
  {error&&<p role="alert" className="text-sm text-amber-900">{error}</p>}
  {created&&active&&<div className="rounded-xl bg-muted/60 border p-4 space-y-3">
   <p className="font-medium break-all">Invitation for {created.recipientEmail}</p>
   <label className="grid gap-2 text-sm">Invitation link<Input readOnly value={created.url} onFocus={e=>e.target.select()}/></label>
   <div className="flex flex-wrap gap-2">
    <Button type="button" variant="outline" size="sm" onClick={()=>void copy(created.url)}><Copy size={15}/>Copy link</Button>
    <Button type="button" variant="outline" size="sm" onClick={()=>void copy(invitationMessage(created.url))}>Copy instructions</Button>
    <Button variant="outline" size="sm" asChild><a href={`mailto:${encodeURIComponent(created.recipientEmail||'')}?subject=${encodeURIComponent('Invitation to EMP Review')}&body=${encodeURIComponent(invitationMessage(created.url))}`}><Mail size={15}/>Open email draft</a></Button>
   </div>
   <p className="text-sm text-muted-foreground">Copy this link before leaving. For security, it cannot be retrieved later; revoke the unused invitation and create a new one if needed.</p>
  </div>}
  {invites.length>0&&<div className="space-y-2"><h4 className="text-sm font-semibold">Invitations</h4><ul className="divide-y border rounded-xl px-4">
   {invites.map(i=>{const status=invitationStatus(i,now);return <li key={i.id} className="flex flex-wrap items-center justify-between gap-3 py-3"><div className="min-w-0"><p className="text-sm font-medium break-all">{i.recipientEmail||'Legacy invitation code'}</p><p className="text-sm text-muted-foreground">{status} · {status==='Expired'?'Expired':'Expires'} {new Date(i.expiresAt).toLocaleString('en-GB')}</p></div>{status==='Awaiting reviewer'&&<Button type="button" variant="outline" size="sm" disabled={disabled} onClick={()=>void onRevoke(i.id)}>Revoke invitation</Button>}</li>;})}
  </ul></div>}
 </div>;
}
