CREATE TABLE `workspace_drafts` (
	`owner` text NOT NULL,
	`scope` text NOT NULL,
	`payload_key` text,
	`revision` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`owner`, `scope`)
);
