CREATE TABLE `analysis_reconciliations` (
	`id` text PRIMARY KEY NOT NULL,
	`document_id` text NOT NULL,
	`owner` text NOT NULL,
	`base_revision` integer NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`payload_key` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`document_id`) REFERENCES `documents`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `reconciliations_document` ON `analysis_reconciliations` (`document_id`);