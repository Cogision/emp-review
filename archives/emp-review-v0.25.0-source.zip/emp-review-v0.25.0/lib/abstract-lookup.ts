import {AppError} from './app-error';
import type {Source} from './emp';
export type ArticleId={kind:'pmid'|'doi';value:string};
export function parseArticleId(raw:string):ArticleId{
 const input=raw.trim();if(!input||input.length>300||/[\x00-\x1f]/.test(input))throw new AppError('Enter a PMID, PubMed article URL, DOI or DOI URL.');
 if(/^\d{1,10}$/.test(input))return {kind:'pmid',value:input};
 if(/^10\.\d{4,9}\/\S+$/i.test(input))return {kind:'doi',value:input};
 if(/^doi:\s*10\./i.test(input))return parseArticleId(input.replace(/^doi:\s*/i,''));
 try{const u=new URL(input);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw new Error();
  if(u.hostname==='pubmed.ncbi.nlm.nih.gov'&&/^\/\d{1,10}\/?$/.test(u.pathname))return {kind:'pmid',value:u.pathname.replaceAll('/','')};
  if(['doi.org','dx.doi.org'].includes(u.hostname))return parseArticleId(decodeURIComponent(u.pathname.slice(1)));
 }catch{}
 throw new AppError('Use a PubMed article link, PMID or DOI. Other websites are not fetched.');
}
function plain(value:unknown){if(typeof value!=='string')return '';return value.replace(/<\/(?:p|h\d|div|sec|title)>/gi,'\n').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]*>/g,'').replace(/&(?:amp|lt|gt|quot|apos|nbsp);/g,s=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&nbsp;':' '}[s]||s)).replace(/&#(x[\da-f]+|\d+);/gi,(_,n)=>{const c=n[0].toLowerCase()==='x'?parseInt(n.slice(1),16):Number(n);return c>0&&c<=0x10ffff?String.fromCodePoint(c):'';}).trim();}
export async function lookupAbstract(input:string,fetcher:typeof fetch=fetch){
 const id=parseArticleId(input),url=new URL('https://www.ebi.ac.uk/europepmc/webservices/rest/search');
 url.search=new URLSearchParams({query:id.kind==='pmid'?`EXT_ID:${id.value} AND SRC:MED`:`DOI:"${id.value.replace(/\\/g,'\\\\').replace(/"/g,'\\"')}"`,format:'json',resultType:'core',synonym:'false',pageSize:'10'}).toString();
 let response:Response;try{response=await fetcher(url,{redirect:'error',signal:AbortSignal.timeout(15000),headers:{Accept:'application/json'}});}catch{throw new AppError('The abstract service is unavailable. Try again or paste the abstract.',502);}
 if(!response.ok||!response.body)throw new AppError('The abstract service could not return this record. Try again later.',502);
 const reader=response.body.getReader(),chunks:Uint8Array[]=[];let bytes=0;
 try{for(;;){const item=await reader.read();if(item.done)break;bytes+=item.value.length;if(bytes>2000000){await reader.cancel();throw new AppError('The returned record is too large. Paste the abstract instead.',502);}chunks.push(item.value);}}finally{reader.releaseLock();}
 const all=new Uint8Array(bytes);let offset=0;for(const c of chunks){all.set(c,offset);offset+=c.length;}
 let data:any;try{data=JSON.parse(new TextDecoder().decode(all));}catch{throw new AppError('The abstract service returned an unreadable record.',502);}
 if(!Array.isArray(data.resultList?.result))throw new AppError('The abstract service returned an unexpected record.',502);
 const matches=data.resultList.result.filter((r:any)=>id.kind==='pmid'?r.source==='MED'&&String(r.pmid||r.id)===id.value:typeof r.doi==='string'&&r.doi.toLowerCase()===id.value.toLowerCase());
 const med=matches.filter((r:any)=>r.source==='MED'),candidates=med.length?med:matches;
 if(!candidates.length)throw new AppError('No exact article match was found. Check the identifier or paste the abstract.',404);
 if(candidates.length!==1)throw new AppError('More than one matching record was found. Use its PMID to select the article.',409);
 const r=candidates[0],title=plain(r.title),abstract=plain(r.abstractText);
 if(!title)throw new AppError('The article record has no title. Paste the source instead.',502);
 const retrieval={provider:'Europe PMC',recordSource:String(r.source),recordId:String(r.id),pmid:String(r.pmid||''),doi:String(r.doi||''),requestedIdentifier:`${id.kind}:${id.value}`,retrievedAt:new Date().toISOString(),url:r.source==='MED'?`https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(r.pmid||r.id)}/`:`https://europepmc.org/article/${encodeURIComponent(r.source)}/${encodeURIComponent(r.id)}`};
 const source:Source={fileName:'Retrieved abstract',blocks:[{id:'b1',label:'Title and bibliographic record',text:[title,plain(r.authorString),plain(r.pubYear),plain(r.journalInfo?.journal?.title),retrieval.doi?`DOI: ${retrieval.doi}`:'',retrieval.pmid?`PMID: ${retrieval.pmid}`:''].filter(Boolean).join('\n')},...(abstract?[{id:'b2',label:'Abstract',text:abstract}]:[])],warnings:['Title and abstract retrieved through Europe PMC. Full text, figures and supplements were not reviewed.'],retrieval};
 return {title,abstract:abstract||null,status:abstract?'ready':'abstract_unavailable',source};
}
