import {z} from 'zod';
import {claimSchema,reviewSchema,sourceSchema,currentClaims,type RecordDoc,type Claim} from './emp';
import {codingScope,legacyManifest} from './versions';
import {applyCorrection,type CorrectionProposal} from './assessment-correction';
import {articleResultRows} from './article-results';

const importedDocument=z.object({id:z.string().min(1).max(100),title:z.string().max(1000),stage:z.enum(['A','B','Excerpt']),coverage:z.string().max(5000),sourceHash:z.string().max(200),revision:z.number().int().nonnegative(),createdAt:z.string().max(80),updatedAt:z.string().max(80),source:sourceSchema,review:reviewSchema,
 analysis:z.object({reportType:z.enum(['CB','M','NC','NMC']),typeRationale:z.string().max(5000),summary:z.string().max(5000),limitations:z.array(z.string().max(800)).max(30),claims:z.array(claimSchema).max(80),model:z.string().max(200).optional(),generatedAt:z.string().max(80).optional()}).passthrough(),
 versions:z.object({appVersion:z.string().nullable(),manualVersion:z.string(),formVersion:z.string().nullable(),scope:z.enum(['core','full']),schemaVersion:z.string().nullable(),recorded:z.boolean()}).optional()});
export type ReconciliationInput={label:string;document:RecordDoc;origin:'saved'|'upload'|'current'};
export type Reconciliation={id:string;documentId:string;baseRevision:number;sourceHash:string;createdAt:string;model:string;revision:number;inputs:ReconciliationInput[];candidates:Claim[];originalUploads?:unknown[];appliedRevision?:number};
export function readAnalysisExport(raw:unknown):RecordDoc{
 const envelope=raw&&typeof raw==='object'&&'document' in raw?(raw as {document:unknown}).document:raw;
 const parsed=importedDocument.safeParse(envelope);
 if(!parsed.success)throw new Error('Use a Full JSON record exported by EMP Review, including its source text and assessments. Word, PDF and summary exports cannot be reconciled.');
 const d=parsed.data as RecordDoc;
 if(Object.keys(d.review.decisions).length>80||Object.entries(d.review.decisions).some(([id,v])=>id!==v.claim.id)||new Set(d.analysis!.claims.map(c=>c.id)).size!==d.analysis!.claims.length)throw new Error('The imported claim identifiers are inconsistent.');
 return d;
}
const norm=(s:string)=>s.replace(/\s+/gu,' ').trim();
export function sourceContent(d:RecordDoc){
 const s=d.source;
 return JSON.stringify(s.files?s.files.map(f=>[f.role,norm(s.blocks.filter(b=>b.fileId===f.id).map(b=>b.text).join('\n'))]):[['primary',norm(s.blocks.map(b=>b.text).join('\n'))]]);
}
export const activeClaims=(d:RecordDoc)=>currentClaims(d).filter(c=>d.review.decisions[c.id]?.status!=='excluded');
export function claimIdentity(c:Claim){return JSON.stringify([norm(c.statement),norm(c.citation.quote),c.primary,Object.entries(c.scope).map(([k,v])=>[k,norm(v)]).sort(([a],[b])=>a.localeCompare(b))]);}
export function reconciliationCompatibility(anchor:RecordDoc,other:RecordDoc){
 if(!anchor.analysis||!other.analysis)return 'A completed analysis is required.';
 if(sourceContent(anchor)!==sourceContent(other))return 'The source text or its supplements differ. Choose analyses of the same saved text.';
 if(anchor.stage!==other.stage)return 'Abstracts, full texts and excerpts must be compared separately.';
 if((anchor.review.reportType||anchor.analysis.reportType)!==(other.review.reportType||other.analysis.reportType))return 'Report types differ. Resolve the report type before reconciling its claims.';
 if((anchor.versions||legacyManifest(anchor.analysis,anchor.review)).manualVersion!==(other.versions||legacyManifest(other.analysis,other.review)).manualVersion||codingScope(anchor.analysis,anchor.review)!==codingScope(other.analysis,other.review))return 'The coding manual or form coverage differs. Choose analyses made with the same rules and form.';
 if(!['CB','M'].includes(anchor.review.reportType||anchor.analysis.reportType))return 'This report type has no substantive claims to reconcile.';
 const claims=activeClaims(other);
 if(!claims.length||claims.length>80||claims.filter(c=>c.primary).length!==1)return 'Each analysis needs exactly one central claim and a completed claim inventory.';
 return '';
}
export function reconciliationRows(inputs:ReconciliationInput[]){
 const anchor=inputs[0].document;
 return articleResultRows(anchor).map(row=>({...row,versions:inputs.map(input=>{
  const matches=activeClaims(input.document).filter(c=>claimIdentity(c)===claimIdentity(row.claim));
  const ambiguous=matches.length!==1||activeClaims(anchor).filter(c=>claimIdentity(c)===claimIdentity(row.claim)).length!==1;
  const matched=ambiguous?undefined:articleResultRows(input.document).find(r=>r.claim.id===matches[0].id);
  return {label:input.label,claim:matched?.claim,assessment:matched?.label||'Different or missing claim / scope',sameClaim:!!matched};
 })}));
}
export function validateReconciliationInputs(inputs:ReconciliationInput[]){
 if(inputs.length<2||inputs.length>5)throw new Error('Compare two to five analyses, including the open report.');
 const seen=new Set<string>();
 for(const input of inputs){
  const problem=reconciliationCompatibility(inputs[0].document,input.document);if(problem)throw new Error(`${input.label}: ${problem}`);
  // The same exported assessment under another filename is not another opinion.
  const fingerprint=JSON.stringify(activeClaims(input.document).map(c=>({...c,id:''})).sort((a,b)=>claimIdentity(a).localeCompare(claimIdentity(b))));
  if(seen.has(fingerprint))throw new Error(`${input.label}: this assessment is already included unchanged. Remove the duplicate.`);seen.add(fingerprint);
 }
}
export function reconciliationContext(session:Reconciliation,claim:Claim){return session.inputs.map(input=>{
 const exact=activeClaims(input.document).filter(c=>claimIdentity(c)===claimIdentity(claim));
 return {label:input.label,origin:input.origin,model:input.document.analysis?.model,unverifiedInput:true,identity:exact.length===1?'Same proposition and scope':'Different or missing proposition / scope; not an equivalent assessment',assessments:exact.length===1?exact:activeClaims(input.document).filter(c=>c.primary===claim.primary),inventory:activeClaims(input.document).map(c=>({primary:c.primary,statement:c.statement}))};
});}
export function applyReconciliation(d:RecordDoc,session:Reconciliation){
 if(session.appliedRevision||session.documentId!==d.id||session.sourceHash!==d.sourceHash||session.baseRevision!==d.revision)throw new Error('The report changed. Prepare a new recommendation before applying it.');
 const before=activeClaims(session.inputs[0].document);
 if(before.length!==session.candidates.length||new Set(session.candidates.map(c=>c.id)).size!==before.length)throw new Error('The recommendation is not complete. Resume preparation first.');
 let review=structuredClone(d.review);
 for(const c of before){const candidate=session.candidates.find(x=>x.id===c.id);if(!candidate)throw new Error('A recommended claim is missing.');if(JSON.stringify(candidate.scope)!==JSON.stringify(c.scope))throw new Error('The selected claim scope changed. Review claim selection separately.');
  const proposal:CorrectionProposal={id:session.id,documentId:d.id,baseRevision:d.revision,sourceHash:d.sourceHash,createdAt:session.createdAt,model:session.model,feedback:'Reconciliation of multiple analyses against the same source. See the saved comparison and recommendation.',before:c,candidate};
  review=applyCorrection({...d,review},proposal);
 }
 review.coverageChecked=false;
 return review;
}
