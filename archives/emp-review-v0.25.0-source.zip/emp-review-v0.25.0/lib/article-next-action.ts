import {currentClaims,type RecordDoc} from './emp';
import {assessmentState} from './assessment-state';
export function articleNextAction(d:RecordDoc,selectedId?:string){
 const type=d.review.reportType||d.analysis?.reportType;if(type==='NC'||type==='NMC')return {step:4,title:'Check the report type and source coverage',detail:'This report is outside substantive claim assessment. Its retained claims do not contribute to the results.',button:'Open summary',complete:true};
 const claims=currentClaims(d).filter(c=>d.review.decisions[c.id]?.status!=='excluded'),rows=claims.map(claim=>({claim,...assessmentState(d,claim)}));
 if(!d.analysis)return {step:2,title:'Confirm which claims should be assessed',detail:'Check the proposed central claim against the authors’ wording.',button:'Go to claim selection'};
 if(claims.length&&claims.filter(c=>c.primary).length!==1)return {step:2,title:'Choose one central claim',detail:'Identify the claim that answers the article’s main question.',button:'Check claim selection'};
 const blocked=rows.find(r=>['TECH','DISPUTED','LEGACY'].includes(r.bridge));
 if(blocked)return {step:3,claimId:blocked.claim.id,title:'Clarify this assessment before confirming it',detail:blocked.issues[0]||d.review.decisions[blocked.claim.id]?.comment||blocked.claim.rationale,button:'Open the assessment'};
 if(!rows.length)return {step:4,title:'Check the article summary',detail:'This report has no active substantive claim assessments. Review its recorded type and source coverage.',button:'Open summary',complete:true};
 if(!d.review.coverageChecked)return {step:2,title:'Check the selected claims',detail:'Confirm that the central and contextual claims accurately represent this article.',button:'Check claim selection'};
 const row=(selectedId&&rows.find(r=>r.claim.id===selectedId&&!r.checked))||rows.find(r=>r.claim.primary&&!r.checked)||rows.find(r=>!r.checked);
 if(!row)return {step:4,title:rows.length?'Your review is complete':'Check the article summary',detail:rows.length?'All active claim assessments have been checked. Unresolved findings retain their recorded meaning.':'The report type and source determine which findings can be assessed.',button:'Open summary',complete:true};
 const from=row.claim.v05?.bridgeFrom||row.claim.v05?.warrantClaim;
 const detail=row.bridge==='B2'&&from?`Check whether the cited passage uses “${from}” to support “${row.claim.statement}”.`:row.claim.questions?.[0]||row.claim.evidenceRequired||row.claim.rationale;
 return {step:3,claimId:row.claim.id,title:row.bridge==='BU'?'Check what prevents a decision':row.bridge==='B2'?'Check the proposed evidence transfer':'Compare this assessment with the source',detail,button:'Read the cited evidence'};
}
export const CORRECTION_ROUTES=[
 {id:'reading',title:'AI may have misread the source',detail:'Check the interpretation against the source. The selected claim stays fixed.'},
 {id:'scope',title:'The claim may be too broad',detail:'Record a possible narrower wording alongside the original claim.'},
 {id:'test',title:'A necessary test is missing',detail:'Name the missing test. This alone does not change the assessment category.'},
] as const;
export type ClaimReflection={narrower:string;missingTest:string};
