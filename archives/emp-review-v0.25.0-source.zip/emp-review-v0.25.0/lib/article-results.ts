import {currentClaims,deriveBridge,type Claim,type RecordDoc,type Review} from './emp';
import {assessmentState,validateDecisionMeaning} from './assessment-state';
import {stageComparison,centralClaim} from './reporting';
import {BRIDGE_LABELS} from './publication-profile';
import type {ClaimReflection} from './article-next-action';

export function articleResultRows(d:RecordDoc){
 const type=d.review.reportType||d.analysis?.reportType;
 if(type==='NC'||type==='NMC')return [];
 return currentClaims(d).filter(c=>d.review.decisions[c.id]?.status!=='excluded').sort((a,b)=>Number(b.primary)-Number(a.primary)).map(claim=>{
  const state=assessmentState(d,claim);
  const blocked=['TECH','DISPUTED','LEGACY'].includes(state.bridge);
  const label=state.bridge==='B0'&&claim.adequacy==='Not assessed'?'Evidence matches the claim; adequacy not assessed':state.bridge==='B0'&&claim.adequacy!=='Yes'?'Evidence matches the claim; limitations remain':BRIDGE_LABELS[state.bridge]||'Awaiting assessment';
  const from=claim.v05?.bridgeFrom?.trim()||claim.v05?.warrantClaim?.trim()||'';
  const to=claim.v05?.bridgeTo?.trim()||claim.statement;
  const transition=state.bridge==='B2'?(from?`${from} → ${to}`:`Evidence invoked: ${claim.evidenceSummary}\nClaim it is used to support: ${claim.statement}`):state.bridge==='B1'?'The missing test is explicitly left open.':state.bridge==='B3'?'Support is missing; no substituted evidence was identified.':state.bridge==='B0'?'No missing bridge identified for this claim.':blocked?'The assessment needs checking before the inference can be reported.':'The supplied source does not settle this assessment.';
  const nextLabel=blocked||state.bridge==='BU'?'Check the available material':state.bridge==='B0'?(claim.adequacy==='Yes'?'Retain the stated scope':claim.adequacy==='Not assessed'?'Assess evidence adequacy':'Check the evidence limitations'):state.bridge==='B2'?'Check the transfer and the missing test':state.bridge==='B1'?'Identify the test left open':'Identify the support this claim requires';
  const nextDetail=blocked?(state.issues.join(' ')||d.review.decisions[claim.id]?.comment||'Review the recorded disagreement.'):state.bridge==='B0'?(claim.adequacy==='Yes'?'Interpret this finding within its recorded population, measure and use.':claim.v05?.adequacyRationale||claim.rationale):claim.evidenceRequired;
  const verification=state.checked?'Human checked':state.workflow==='unreviewed'?'AI proposal · not reviewed':state.label;
  return {claim,...state,label,blocked,transition,nextLabel,nextDetail,verification};
 });
}

/** One explicit final source check may cover several displayed claims. Scientific
 * uncertainty remains an unresolved decision, while malformed/disputed work blocks
 * confirmation. Unselected and excluded rows are never changed. */
export function confirmArticleResults(d:RecordDoc,input:{claimIds:string[];sourceChecked:boolean;selectionChecked:boolean;comment:string}):Review{
 if(!input.sourceChecked||!input.selectionChecked)throw new Error('Confirm the claim selection and compare every selected assessment with its source passages.');
 if(input.comment.length>4000)throw new Error('Keep your note within 4,000 characters.');
 const rows=articleResultRows(d),ids=new Set(input.claimIds);
 if(!ids.size||ids.size!==input.claimIds.length||[...ids].some(id=>!rows.some(r=>r.claim.id===id)))throw new Error('Choose the active claim assessments you checked.');
 if(rows.filter(r=>r.claim.primary).length!==1)throw new Error('Select exactly one central claim before confirming the review.');
 const selected=rows.filter(r=>ids.has(r.claim.id));
 if(selected.some(r=>r.blocked))throw new Error('Correct or clarify the flagged assessments before confirming them. You can deselect those rows and review them later.');
 const review=structuredClone(d.review),now=new Date().toISOString();
 review.coverageChecked=true;
 for(const row of selected){
  const c=row.claim,old=d.review.decisions[c.id];
  const unresolved=row.bridge==='BU'||deriveBridge(c,d.review.reportType||d.analysis?.reportType)==='BU';
  const scientificReason=(old?.concern==='evidence-uncertainty'?old.comment?.trim():'')||c.rationale.trim();
  const reason=(unresolved?[scientificReason,input.comment.trim()].filter(Boolean).join('\n'):input.comment.trim()||old?.comment?.trim()||c.rationale.trim()).slice(0,4000);
  if(unresolved&&!reason)throw new Error('Record the missing evidence before confirming an unresolved assessment.');
  review.decisions[c.id]={claim:structuredClone(c),status:unresolved?'unresolved':'accepted',...(unresolved?{concern:'evidence-uncertainty' as const}:{}),...(old?.correction?{correction:old.correction}:{}),comment:reason,sourceChecked:true,updatedAt:now};
 }
 validateDecisionMeaning(d,review);
 return review;
}

const escape=(s:unknown)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export function articleResultsHtml(d:RecordDoc,notes:Record<string,ClaimReflection>={}){
 const e=escape,rows=articleResultRows(d),pair=stageComparison(d);
 const comparison=pair?`<h2>Comparison with the earlier source</h2><p>${e(pair.comparable?'Same central proposition confirmed. Source stages have separate denominators.':'These assessments cannot be compared directly until the same proposition is confirmed.')}</p><p>Earlier claim: ${e(pair.link.statement)}</p><p>Current claim: ${e(centralClaim(d)?.statement||'Central claim needs selection')}</p><p>${e(pair.link.reason)}</p>`:'';
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${e(d.title)} · EMP article summary</title><style>@page{size:A4 landscape;margin:15mm}body{font:16px/1.5 system-ui,sans-serif;color:#203030;margin:30px}h1{font-size:25px}h2{font-size:19px}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #cbd5d1;white-space:pre-wrap;overflow-wrap:anywhere}th{background:#eff3f1}tr{break-inside:avoid}blockquote{border-left:2px solid #647373;margin:12px 0;padding-left:14px;white-space:pre-wrap}small{font-size:13px}p{white-space:pre-wrap}</style></head><body><h1>${e(d.title)}</h1><p>Article summary · ${e(d.stage==='A'?'Title and abstract':d.stage==='B'?'Full text':'Excerpts')}</p><p>${e(d.coverage)}</p>${comparison}<table><thead><tr><th>Claim</th><th>Available evidence</th><th>Assessment</th><th>Gap or evidence transition</th><th>What next?</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${r.claim.primary?'Central claim':'Contextual claim'}</b><p>${e(r.claim.statement)}</p></td><td>${e(r.claim.evidenceSummary)}</td><td><b>${e(r.label)}</b><p>${e(r.verification)}</p><p>Adequacy: ${e(r.claim.adequacy)}</p></td><td>${e(r.transition)}</td><td><b>${e(r.nextLabel)}</b><p>${e(r.nextDetail)}</p>${notes[r.claim.id]?.narrower?`<p><b>Reviewer working proposal for narrower wording:</b> ${e(notes[r.claim.id].narrower)}</p>`:''}${notes[r.claim.id]?.missingTest?`<p><b>Reviewer working note on the missing test:</b> ${e(notes[r.claim.id].missingTest)}</p>`:''}</td></tr>`).join('')}</tbody></table>${!rows.length?`<p>${e(d.analysis?.typeRationale||'No claim assessments available.')}</p>`:''}<h2>Evidence and reasoning</h2>${rows.map(r=>`<section><h3>${e(r.claim.statement)}</h3><p>${e(r.claim.rationale)}</p><p>Required evidence: ${e(r.claim.evidenceRequired)}</p>${[{label:'Authors’ claim',value:r.claim.citation},...r.claim.evidence.map(value=>({label:'Evidence',value})),...(r.claim.conditionCitation?[{label:'Authors’ stated condition',value:r.claim.conditionCitation}]:[])].map(x=>`<p><b>${x.label}</b> · ${e(x.value.blockId)}</p><blockquote>${e(x.value.quote)}</blockquote>`).join('')}</section>`).join('')}<p>Reviewer working notes do not alter the authors’ original claims, assessment categories or counts. Each row has its own review status. Missing evidence alone does not establish evidential inheritance. No overall maturity or confidence score is calculated. Narrowing a claim would require a new assessment and would not supply evidence for its original wording.</p><footer><small>Record ${e(d.id)} · revision ${d.revision} · source ${e(d.sourceHash)} · original analysis ${e(d.analysis?.model||'Manual')}</small></footer></body></html>`;
}
