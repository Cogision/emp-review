import {deriveBridge,type RecordDoc,type Review} from './emp';
import {publicationProfile} from './publication-profile';
import {validateDecisionMeaning} from './assessment-state';

export type ArticleDecision={status:'accepted'|'unresolved'|'draft';concern?:'evidence-uncertainty'|'disagreement'|'technical';comment:string;sourceChecked:boolean;selectionChecked:boolean};

/** Keep the short form and its validation aligned: uncertainty is a valid result,
 * while an incomplete or inconsistent analysis needs a correction first. */
export function articleReviewGuidance(document:RecordDoc){
 const p=publicationProfile(document),claim=p.central;
 const state=!claim?'selection':p.issues.length?'technical':deriveBridge(claim,p.type||'CB')==='BU'?'unresolved':'resolved';
 return {state,issues:p.issues,reason:claim?.rationale.trim()||'',questions:claim?.questions.filter(q=>q.trim())||[]};
}

/** Save the central assessment through the existing review schema and validation rules. */
export function articleReview(document:RecordDoc,input:ArticleDecision):Review{
 const p=publicationProfile(document),claim=p.central;
 if(!claim)throw new Error('Choose one central claim before saving your review.');
 if(input.comment.length>4000)throw new Error('Keep your note within 4,000 characters.');
 if(input.status==='accepted'){
  if(!input.selectionChecked)throw new Error('Confirm that the selected claim represents the article’s main conclusion.');
  if(!input.sourceChecked)throw new Error('Compare the assessment with the source passages, then confirm the source check.');
  const guidance=articleReviewGuidance(document);
  if(guidance.state==='technical')throw new Error(`The analysis needs a correction: ${guidance.issues.join(' ')} Choose “Ask AI to check”, or save it for later.`);
  if(guidance.state==='unresolved')throw new Error(`The current assessment is unresolved. ${guidance.reason} Save an unresolved review with the reason, or choose “Ask AI to check” if you disagree.`);
 }
 if(input.status==='unresolved'&&!input.comment.trim())throw new Error('Explain which missing or ambiguous evidence prevents a decision.');
 const review=structuredClone(document.review);
 review.coverageChecked=input.selectionChecked;
 review.decisions[claim.id]={claim:structuredClone(claim),status:input.status,...(document.review.decisions[claim.id]?.correction?{correction:document.review.decisions[claim.id].correction}:{}),...(input.concern?{concern:input.concern}:{}),comment:input.comment.trim(),sourceChecked:input.sourceChecked,updatedAt:new Date().toISOString()};
 validateDecisionMeaning(document,review);
 return review;
}
