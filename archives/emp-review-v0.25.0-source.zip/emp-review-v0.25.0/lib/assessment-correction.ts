import {z} from 'zod';
import {claimSchema,currentClaims,type Claim,type RecordDoc} from './emp';
import {assessmentState} from './assessment-state';
import {recoverCitation} from './citation-recovery';

export const correctionRequestSchema=z.discriminatedUnion('action',[
 z.object({action:z.literal('propose'),revision:z.number().int(),feedback:z.string().trim().max(4000).default(''),claimId:z.string().min(1).max(80).optional(),key:z.string().optional(),model:z.string().optional()}),
 z.object({action:z.literal('apply'),revision:z.number().int(),proposalId:z.string().uuid()})
]);
export const GENERAL_ASSESSMENT_CHECK='Independently check whether the saved source supports the current assessment of the selected claim. Review the evidence summary, required evidence, EMP codes and reasoning. Identify any errors and propose only changes justified by the source. Do not assume the assessment is wrong. If it is already justified, retain it unchanged and explain why. Preserve the selected claim. State any missing evidence or source limitations; do not invent evidence or imply human verification.';
export function correctionInstruction(feedback:string){return feedback.trim()||GENERAL_ASSESSMENT_CHECK;}
export type CorrectionProposal={id:string;documentId:string;baseRevision:number;sourceHash:string;createdAt:string;model:string;feedback:string;instruction?:string;before:Claim;candidate:Claim};
export function correctionChanges(before:Claim,after:Claim){
 const changes:{field:string;before:string;after:string}[]=[];
 const show=(v:unknown)=>v===undefined?'Not recorded':typeof v==='string'?v:JSON.stringify(v,null,2);
 const walk=(a:unknown,b:unknown,path:string)=>{
  if(JSON.stringify(a)===JSON.stringify(b))return;
  if(a&&b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b)){
   for(const key of new Set([...Object.keys(a),...Object.keys(b)]))walk((a as Record<string,unknown>)[key],(b as Record<string,unknown>)[key],path?`${path}.${key}`:key);
  }else changes.push({field:path,before:show(a),after:show(b)});
 };
 walk(before,after,'');return changes;
}
export function applyCorrection(d:RecordDoc,p:CorrectionProposal){
 if(p.documentId!==d.id||p.baseRevision!==d.revision||p.sourceHash!==d.sourceHash)throw new Error('This report changed after the proposal was prepared. Request a fresh correction.');
 const c=currentClaims(d).find(c=>c.id===p.before.id&&d.review.decisions[c.id]?.status!=='excluded');
 if(!c||JSON.stringify(c)!==JSON.stringify(p.before))throw new Error('The selected claim changed. Request a fresh correction.');
 const candidate=claimSchema.parse(p.candidate);
 const originalCitation=recoverCitation(c.citation,d.source)?.citation;
 if(candidate.id!==c.id||candidate.primary!==c.primary||candidate.statement!==c.statement||!originalCitation||JSON.stringify(candidate.citation)!==JSON.stringify(originalCitation))throw new Error('A correction cannot change the selected claim, its role or its source quotation.');
 const issues=assessmentState(d,candidate).issues;
 if(issues.length)throw new Error('The proposed correction still has a preparation problem: '+issues[0]);
 const review=structuredClone(d.review);
 review.decisions[c.id]={claim:candidate,status:'draft',correction:{proposalId:p.id,model:p.model,createdAt:p.createdAt},comment:`AI correction applied for review. ${p.feedback.trim()?`Your request: ${p.feedback}`:'General assessment check requested with no additional note.'}`.slice(0,4000),sourceChecked:false,updatedAt:new Date().toISOString()};
 return review;
}
