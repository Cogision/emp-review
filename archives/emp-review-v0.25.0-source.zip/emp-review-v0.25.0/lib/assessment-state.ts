import {claimIssues,deriveBridge,type Claim,type RecordDoc,type Review} from './emp';

export const WORKFLOW_LABELS:Record<string,string>={unreviewed:'AI proposal · not reviewed',draft:'Draft · not reviewed',reviewed:'Human checked',uncertain:'Evidence unresolved',disagreement:'Correction requested',technical:'Analysis needs repair',legacy:'Earlier unresolved decision · clarify its reason'};
export function assessmentState(d:RecordDoc,c:Claim){
 const decision=d.review.decisions[c.id],type=d.review.reportType||d.analysis?.reportType||'CB';
 const issues=claimIssues(c,d.source);
 if(c.v05?.methodologicalGeneralisation&&type!=='M')issues.push('Methodological generalisation requires report type M.');
 const technical=issues.length>0||decision?.concern==='technical';
 const workflow=technical?'technical':decision?.concern==='disagreement'?'disagreement':decision?.status==='unresolved'&&!decision.concern?'legacy':decision?.status==='unresolved'?'uncertain':decision?.status==='accepted'&&decision.sourceChecked&&d.review.coverageChecked?'reviewed':decision?'draft':d.analysis?.model==='Manual'?'draft':'unreviewed';
 const bridge=technical?'TECH':workflow==='disagreement'?'DISPUTED':workflow==='legacy'?'LEGACY':decision?.status==='unresolved'?'BU':deriveBridge(c,type);
 return {issues,workflow,bridge,label:WORKFLOW_LABELS[workflow],checked:!technical&&!['disagreement','legacy'].includes(workflow)&&!!decision?.sourceChecked&&d.review.coverageChecked&&['accepted','unresolved'].includes(decision.status)};
}

/** Existing records may retain their old meaning; changed decisions must say why they are unresolved. */
export function validateDecisionMeaning(d:RecordDoc,review:Review){
 for(const [id,decision]of Object.entries(review.decisions)){
  if(JSON.stringify(d.review.decisions[id])===JSON.stringify(decision))continue;
  if(decision.concern==='evidence-uncertainty'&&decision.status!=='unresolved')throw new Error('Evidence uncertainty must use an unresolved decision.');
  if(['disagreement','technical'].includes(decision.concern||'')&&(decision.status!=='draft'||!decision.comment.trim()))throw new Error('Save a correction or technical problem as a draft with a reason.');
  if(decision.status==='unresolved'){
   if(decision.concern!=='evidence-uncertainty'||!decision.comment.trim())throw new Error('Explain which missing or ambiguous evidence prevents a decision.');
   const state=assessmentState({...d,review},decision.claim);
   if(state.issues.length)throw new Error('Repair the analysis first, or save the technical problem for later. A preparation error is not unresolved evidence.');
  }
 }
}

const phrase=(s:string)=>s.trim().replace(/[.!?]+$/,'');
export function bridgeExplanation(c:Claim,bridge:string){
 if(bridge==='B2')return `The authors use evidence for ${phrase(c.v05?.bridgeFrom||c.evidenceSummary)} to support ${phrase(c.v05?.bridgeTo||c.statement)}; this requires ${phrase(c.evidenceRequired)}.`;
 if(bridge==='B3')return 'The required support has not been established, but no transfer of another finding into its place was identified.';
 if(bridge==='BU')return 'The available evidence does not settle the assessment; the reason and the source limits are recorded below.';
 return '';
}
