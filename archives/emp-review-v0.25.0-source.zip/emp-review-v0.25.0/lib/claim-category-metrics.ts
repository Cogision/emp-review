import {currentClaims} from './emp';
import {assessmentState} from './assessment-state';
import {publicationMetrics,calibrationMetrics,claimReportingBasis,BRIDGE_LABELS} from './publication-profile';
import type {ProjectData} from './projects';

export type ClaimCountScope='all'|'central';
export type AssessmentView=Parameters<typeof publicationMetrics>[1];
export const CLAIM_CATEGORY_CODES=['B0','B1','B2','B3','BU'] as const;
const matchesView=(view:AssessmentView,basis:string)=>view==='provisional'||view===basis;

/** Supplementary claim-level frequencies. Never used as the one-article research metric. */
export function claimCategoryMetrics(data:ProjectData,view:AssessmentView='provisional',scope:ClaimCountScope='all'){
 const research=publicationMetrics(data,view),pilot=calibrationMetrics(data,view);
 const populations=[
  {key:'research',label:'Research collection',metrics:research},
  ...pilot.groups.map(g=>({key:`calibration:${g.key}`,label:g.label,metrics:g.metrics})),
 ];
 const groups=populations.flatMap(population=>{
  const duplicateIds=new Set(population.metrics.duplicates.flat().map(d=>d.id));
  const strata=new Map<string,{key:string;population:string;label:string;stage:string;reportType:string;basis:ReturnType<typeof claimReportingBasis>;protocol:string;fieldScope:string;sourceSelection:string;total:number;counts:Record<string,number>;reportIds:Set<string>;central:number;contextual:number;duplicateBlocked:boolean;missingCentral:number}>();
  for(const r of population.metrics.rows){
   const inPopulation=population.key==='research'?r.settings.role==='audit'&&!r.document.analysis?.demo:r.settings.role==='calibration'||r.document.analysis?.demo;
   if(!inPopulation||r.settings.duplicateOf||!['CB','M'].includes(r.type||''))continue;
   const claims=currentClaims(r.document).filter(c=>r.document.review.decisions[c.id]?.status!=='excluded');
   const selected=scope==='all'?claims:r.central?[r.central]:[];
   const entries=selected.length?selected:scope==='central'?[null]:[];
   for(const claim of entries){
    const basis=claimReportingBasis(r.document,claim);if(!matchesView(view,basis))continue;
    const key=[population.key,r.document.stage,r.type,basis,r.protocol,r.fieldScope,r.settings.sourceSelection].join('|');
    const g=strata.get(key)||{key,population:population.key,label:population.label,stage:r.document.stage,reportType:r.type!,basis,protocol:r.protocol,fieldScope:r.fieldScope,sourceSelection:r.settings.sourceSelection,total:0,counts:Object.fromEntries(CLAIM_CATEGORY_CODES.map(c=>[c,0])),reportIds:new Set<string>(),central:0,contextual:0,duplicateBlocked:false,missingCentral:0};
    g.reportIds.add(r.document.id);
    g.duplicateBlocked ||= duplicateIds.has(r.document.id)||population.metrics.brokenDuplicates.length>0;
    if(claim){
     const {bridge}=assessmentState(r.document,claim);g.total++;g.counts[bridge]=(g.counts[bridge]||0)+1;
     if(claim.primary)g.central++;else g.contextual++;
    }else g.missingCentral++;
    strata.set(key,g);
   }
  }
  return [...strata.values()].map(({reportIds,...g})=>{
   const unavailable=Object.entries(g.counts).filter(([code])=>!CLAIM_CATEGORY_CODES.some(c=>c===code)).reduce((n,[,count])=>n+count,0);
   const blocked=g.duplicateBlocked||unavailable>0||g.missingCentral>0;
   const reason=g.duplicateBlocked?'Percentages are withheld until duplicate reports are reconciled.':g.missingCentral?`${g.missingCentral} reports need one central claim selected. Percentages are withheld.`:unavailable?`${unavailable} claims await repair, correction or clarification. Percentages are withheld.`:'';
   return {...g,reports:reportIds.size,unavailable,blocked,reason,categories:CLAIM_CATEGORY_CODES.map(code=>({code,label:BRIDGE_LABELS[code],count:g.counts[code],denominator:g.total,percent:!blocked&&g.total?100*g.counts[code]/g.total:null}))};
  });
 });
 return {unit:'claim' as const,scope,view,groups};
}
