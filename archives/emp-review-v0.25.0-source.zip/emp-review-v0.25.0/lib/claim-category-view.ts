import type {claimCategoryMetrics} from './claim-category-metrics';
export type ClaimCategorySummary=ReturnType<typeof claimCategoryMetrics>;
export type ClaimCategoryGroup=ClaimCategorySummary['groups'][number];
export type ClaimCategorySelection={collection?:string;stage?:string;basis?:string;method?:string};
export const sourceName=(stage:string)=>stage==='B'?'Full text':stage==='A'?'Abstract':'Excerpts';
export const basisName=(basis:string)=>({ai:'AI suggestions · awaiting review',reviewed:'Human-checked assessments',adjudicated:'Agreed assessments',manual:'Manual drafts · awaiting review'}[basis]||basis);
export const collectionKey=(g:ClaimCategoryGroup)=>`${g.population}|${g.reportType}`;
export const collectionName=(g:ClaimCategoryGroup)=>`${g.label} · ${g.reportType==='M'?'methodological reports':'clinical-use reports'}`;
export const methodName=(g:ClaimCategoryGroup)=>`${g.protocol==='focal-v1'?'Focused claim selection':g.protocol==='focal-v1-extended'?'Extended focused selection':g.protocol==='legacy-selection'?'Earlier / comprehensive selection':g.protocol} · ${g.fieldScope==='full'?'full coding':'core coding'} · ${{uniform:'uniform source review',selective:'selective follow-up',prespecified:'prespecified sample',unspecified:'source selection not recorded'}[g.sourceSelection]||g.sourceSelection}`;
const unique=<T,>(values:T[])=>[...new Set(values)];
/** Select an existing stratum. Never pool incompatible denominators for display. */
export function selectClaimCategoryGroup(summary:ClaimCategorySummary,selection:ClaimCategorySelection){
 const groups=summary.groups;
 const collections=unique(groups.map(collectionKey)),collection=collections.includes(selection.collection||'')?selection.collection!:collections[0];
 const inCollection=groups.filter(g=>collectionKey(g)===collection);
 const stages=unique(inCollection.map(g=>g.stage)).sort((a,b)=>(({B:0,A:1,Excerpt:2} as Record<string,number>)[a]??3)-(({B:0,A:1,Excerpt:2} as Record<string,number>)[b]??3));
 const stage=stages.includes(selection.stage||'')?selection.stage!:stages[0];
 const inStage=inCollection.filter(g=>g.stage===stage),bases=unique(inStage.map(g=>g.basis));
 const basis=bases.find(b=>b===selection.basis)||bases[0];
 const methods=inStage.filter(g=>g.basis===basis),group=methods.find(g=>g.key===selection.method)||methods[0];
 return {collections,collection,stages,stage,bases,basis,methods,group};
}
