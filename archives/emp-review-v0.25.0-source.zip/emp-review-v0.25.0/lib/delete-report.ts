import {AppError} from './app-error';
/** Delete an owned workspace report; frozen review-round and project snapshots remain independent. */
export async function deleteReport(env:{DB:D1Database;BUCKET:R2Bucket},who:string,id:string){
 const row=await env.DB.prepare('SELECT id FROM documents WHERE id=? AND owner=?').bind(id,who).first();
 if(!row)throw new AppError('Report not found.',404);
 const scopes=`article:${id}:%`,drafts=await env.DB.prepare('SELECT scope,payload_key,revision FROM workspace_drafts WHERE owner=? AND (scope LIKE ? OR scope=?)').bind(who,scopes,'resume').all<{scope:string;payload_key:string|null;revision:number}>();
 const resume=drafts.results.find(d=>d.scope==='resume');let clearResume=false;
 if(resume?.payload_key){const obj=await env.BUCKET.get(resume.payload_key);if(obj){const value=await obj.json<{data?:{id?:string}}>();clearResume=value.data?.id===id;}}
 let cursor:string|undefined;
 do{const page=await env.BUCKET.list({prefix:`documents/${who}/${id}/`,cursor});if(page.objects.length)await env.BUCKET.delete(page.objects.map(o=>o.key));cursor=page.truncated?page.cursor:undefined;}while(cursor);
 await env.DB.batch([
  env.DB.prepare('DELETE FROM assessment_runs WHERE document_id=? AND owner=?').bind(id,who),
  env.DB.prepare('UPDATE projects SET revision=revision+1,updated_at=? WHERE owner=? AND id IN (SELECT project_id FROM project_documents WHERE document_id=?)').bind(new Date().toISOString(),who,id),
  env.DB.prepare('DELETE FROM project_documents WHERE document_id=?').bind(id),
  env.DB.prepare('DELETE FROM events WHERE document_id=? AND owner=?').bind(id,who),
  env.DB.prepare('DELETE FROM workspace_drafts WHERE owner=? AND scope LIKE ?').bind(who,scopes),
  ...(clearResume&&resume?[env.DB.prepare('UPDATE workspace_drafts SET payload_key=NULL,revision=revision+1,updated_at=? WHERE owner=? AND scope=? AND revision=?').bind(new Date().toISOString(),who,'resume',resume.revision)]:[]),
  env.DB.prepare('DELETE FROM documents WHERE id=? AND owner=?').bind(id,who),
 ]);
 for(const draft of drafts.results)if(draft.payload_key&&(draft.scope!=='resume'||clearResume))try{await env.BUCKET.delete(draft.payload_key);}catch{/* Metadata deletion is committed; an unreachable payload can be cleaned later. */}
}
