import {HttpError,request} from './http';
import type {SavedDraft} from './draft-store';
export type DraftStatus='loading'|'ready'|'saving'|'saved'|'error'|'conflict';
type Envelope<T>={format:1;base:string;data:T};
export type DraftSnapshot<T>={value:T;status:DraftStatus;restored:boolean;error:string;updatedAt:string|null;recovery?:T;reset:number};
type Transport=(scope:string,revision?:number,value?:unknown)=>Promise<SavedDraft>;
const transport:Transport=(scope,revision,value)=>request('/api/drafts?scope='+encodeURIComponent(scope),revision===undefined?undefined:{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({revision,value})});
/** One writer per open workspace/scope. Queued writes survive component navigation. */
export class DraftController<T>{
 private snapshot:DraftSnapshot<T>;private listeners=new Set<()=>void>();private revision=0;private loaded=false;private loading:Promise<void>|null=null;private pending:ReturnType<typeof setTimeout>|null=null;private writing:Promise<void>|null=null;private generation=0;private saved='';private pause=false;private clearing=false;private retired=false;
 constructor(readonly scope:string,private initial:T,private base:string,private strict=true,private send:Transport=transport){this.snapshot={value:initial,status:'loading',restored:false,error:'',updatedAt:null,reset:0};}
 getSnapshot=()=>this.snapshot;
 subscribe=(fn:()=>void)=>{this.listeners.add(fn);return()=>{this.listeners.delete(fn);};};
 private emit(change:Partial<DraftSnapshot<T>>){this.snapshot={...this.snapshot,...change};this.listeners.forEach(fn=>fn());}
 private envelope():Envelope<T>{return {format:1,base:this.base,data:this.snapshot.value};}
 load=()=>{if(this.retired)return Promise.resolve();if(this.loaded)return Promise.resolve();if(this.loading)return this.loading;this.loading=(async()=>{try{const saved=await this.send(this.scope);this.revision=saved.revision;this.loaded=true;const value=saved.value as Envelope<T>|null;
   if(value&&value.format===1&&value.data!==undefined){if(this.strict&&value.base!==this.base){this.pause=true;this.emit({status:'conflict',recovery:value.data,error:'The article changed after this draft was saved. Review the earlier draft before using it.'});}else{this.emit({value:value.data,status:'saved',restored:true,updatedAt:saved.updatedAt});}}else this.emit({status:'ready'});
   this.saved=JSON.stringify(this.envelope());
  }catch(e){this.emit({status:'error',error:(e as Error).message});}finally{this.loading=null;}})();return this.loading;};
 set=(next:T|((v:T)=>T))=>{if(this.retired||!this.loaded||this.pause||this.clearing)return;const value=typeof next==='function'?(next as (v:T)=>T)(this.snapshot.value):next;this.generation++;this.emit({value,status:'ready',error:''});this.schedule();};
 private schedule(){if(this.pending)clearTimeout(this.pending);this.pending=setTimeout(()=>{this.pending=null;void this.flush();},650);}
 flush=async():Promise<void>=>{if(this.pending){clearTimeout(this.pending);this.pending=null;}if(this.writing){await this.writing;if(!this.pause)return this.flush();return;}if(this.retired||!this.loaded||this.pause||this.clearing)return;
  const value=this.envelope(),serial=JSON.stringify(value);if(serial===this.saved)return;const generation=this.generation;this.emit({status:'saving'});
  this.writing=(async()=>{try{const result=await this.send(this.scope,this.revision,value);this.revision=result.revision;this.saved=serial;this.emit({...(this.pause?{}:{status:generation===this.generation?'saved':'ready'}),updatedAt:result.updatedAt});}catch(e){if(e instanceof HttpError&&e.status===409){this.pause=true;this.emit({status:'conflict',error:e.message});}else this.emit({status:'error',error:'Draft not saved. '+(e as Error).message});}finally{this.writing=null;}})();await this.writing;
  if(this.generation!==generation&&!this.pause&&!this.clearing&&this.snapshot.status!=='error')await this.flush();
 };
 clear=async(initial:T=this.initial)=>{if(this.pending){clearTimeout(this.pending);this.pending=null;}this.clearing=true;this.generation++;try{await this.load();if(!this.loaded)throw new Error('Read the saved draft before clearing it.');if(this.writing)await this.writing;if(this.pause&&!this.snapshot.recovery)throw new Error('Compare the draft saved in the other tab first.');const result=await this.send(this.scope,this.revision,null);this.revision=result.revision;this.pause=false;this.initial=initial;this.emit({value:initial,status:'ready',restored:false,error:'',recovery:undefined,updatedAt:result.updatedAt,reset:this.snapshot.reset+1});this.saved=JSON.stringify(this.envelope());}catch(e){this.emit({status:'error',error:'The draft could not be cleared. '+(e as Error).message});throw e;}finally{this.clearing=false;}};
 setBase(base:string,initial:T){if(this.retired)return;if(base===this.base)return;const changed=JSON.stringify(this.snapshot.value)!==JSON.stringify(this.initial);this.base=base;this.initial=initial;this.generation++;if(this.strict){if(changed){this.pause=true;this.emit({status:'conflict',recovery:this.snapshot.value,error:'The saved assessment changed. Review this draft before using it.'});}else{this.emit({value:initial,status:'ready'});this.saved=JSON.stringify(this.envelope());}}}
 retry=async()=>{if(this.retired)return;if(!this.loaded){await this.load();return;}if(this.pause){const saved=await this.send(this.scope);const value=saved.value as Envelope<T>|null;if(value&&JSON.stringify(value)===JSON.stringify(this.envelope())){this.revision=saved.revision;this.saved=JSON.stringify(this.envelope());this.pause=false;this.emit({status:'saved',error:'',updatedAt:saved.updatedAt});}else {this.revision=saved.revision;this.emit({recovery:value?.data,error:'Your text and the saved draft differ. Download either version before discarding, or reload the workspace to use the saved version.'});}return;}await this.flush();};
 retire=async()=>{this.retired=true;this.pause=true;if(this.pending)clearTimeout(this.pending);this.pending=null;if(this.writing)await this.writing;};
 /** After an explicit deletion, adopt the authoritative bookmark without replaying local writes. */
 reloadSaved=async()=>{if(this.retired)return;this.clearing=true;if(this.pending)clearTimeout(this.pending);this.pending=null;try{if(this.loading)await this.loading;if(this.writing)await this.writing;this.loaded=false;this.pause=false;this.emit({value:this.initial,status:'loading',error:'',restored:false,recovery:undefined});await this.load();}finally{this.clearing=false;}};
 get hasPending(){return !this.retired&&(this.pause||this.snapshot.status==='error'||this.loaded&&JSON.stringify(this.envelope())!==this.saved);}
 get blocked(){return !this.loaded||this.pause||this.clearing;}
}
