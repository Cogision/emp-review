import {AppError} from './app-error';
export type SavedDraft<T=unknown>={revision:number;updatedAt:string|null;value:T|null};
type Row={revision:number;updated_at:string;payload_key:string|null};
export function draftScope(value:unknown){if(typeof value!=='string'||!(/^(resume|import|article:[a-zA-Z0-9-]+:[a-zA-Z0-9:_-]+)$/.test(value))||value.length>220)throw new AppError('Invalid draft location.');return value;}
/** Draft revisions are independent of assessment revisions and never confirm a review. */
export class DraftStore{
 constructor(private env:{DB:D1Database;BUCKET:R2Bucket},private owner:string){}
 private async row(scope:string){draftScope(scope);if(scope.startsWith('article:')){const id=scope.split(':')[1];if(!await this.env.DB.prepare('SELECT id FROM documents WHERE id=? AND owner=?').bind(id,this.owner).first())throw new AppError('Article not found.',404);}return this.env.DB.prepare('SELECT revision,updated_at,payload_key FROM workspace_drafts WHERE owner=? AND scope=?').bind(this.owner,scope).first<Row>();}
 async get(scope:string):Promise<SavedDraft>{const row=await this.row(scope);if(!row)return {revision:0,updatedAt:null,value:null};if(!row.payload_key)return {revision:row.revision,updatedAt:row.updated_at,value:null};const obj=await this.env.BUCKET.get(row.payload_key);if(!obj)throw new AppError('The saved draft is temporarily unavailable. Try again.',503);return {revision:row.revision,updatedAt:row.updated_at,value:await obj.json()};}
 async put(scope:string,revision:number,value:unknown):Promise<SavedDraft>{
  if(!Number.isSafeInteger(revision)||revision<0)throw new AppError('Invalid draft revision.');
  const prior=await this.row(scope);if((prior?.revision||0)!==revision)throw new AppError('This draft changed in another tab. Your text is kept here. Compare the saved draft before continuing.',409);
  const raw=JSON.stringify(value);if(raw.length>2_000_000)throw new AppError('This draft is too large. Save the source as an article before continuing.',413);
  const now=new Date().toISOString(),key=value===null?null:`drafts/${encodeURIComponent(this.owner)}/${crypto.randomUUID()}.json`;
  if(key)await this.env.BUCKET.put(key,raw,{httpMetadata:{contentType:'application/json'}});
  const result=await this.env.DB.prepare('INSERT INTO workspace_drafts (owner,scope,payload_key,revision,updated_at) SELECT ?,?,?,1,? WHERE length(?)=0 OR EXISTS (SELECT 1 FROM documents WHERE id=? AND owner=?) ON CONFLICT(owner,scope) DO UPDATE SET payload_key=excluded.payload_key,revision=workspace_drafts.revision+1,updated_at=excluded.updated_at WHERE workspace_drafts.revision=?').bind(this.owner,scope,key,now,scope.startsWith('article:')?scope.split(':')[1]:'',scope.split(':')[1]||'',this.owner,revision).run();
  if(result.meta.changes!==1){if(key)await this.env.BUCKET.delete(key);throw new AppError('This draft changed in another tab. Your text is kept here.',409);}
  // Retain old immutable payloads on a failed cleanup; the new pointer is already committed.
  if(prior?.payload_key)try{await this.env.BUCKET.delete(prior.payload_key);}catch{}
  return {revision:revision+1,updatedAt:now,value};
 }
}
