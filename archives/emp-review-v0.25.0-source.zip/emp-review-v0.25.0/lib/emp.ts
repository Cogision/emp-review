import { z } from "zod";
import {reportingSchema} from './reporting-schema';
import { v05Schema, SCOPE_KEYS, SCOPE_LABELS } from "./v05";
import type {VersionManifest} from './versions';
export const FAMILIES = ["Measurement reliability", "Operational specificity", "Clinical and functional relevance", "Response to perturbation", "Decision relevance"] as const;
export const FAMILY_PL: Record<string,string> = {
  "Measurement reliability":"Rzetelność pomiaru", "Operational specificity":"Swoistość operacyjna",
  "Clinical and functional relevance":"Znaczenie kliniczne i funkcjonalne", "Response to perturbation":"Odpowiedź na perturbację", "Decision relevance":"Znaczenie dla decyzji"
};
export const SUPPORT_PL: Record<string,string> = {D:"Bezpośrednie wsparcie", I:"Dowód z innego zakresu", N0:"Brak odpowiedniego dowodu w źródle", U:"Nie można rozstrzygnąć", NE:"Nie twierdzono / nie oceniano"};
const text = z.string().max(5000);
export const citationSchema = z.object({blockId:z.string().max(40),quote:z.string().max(2500)});
const sourceFileId=z.string().regex(/^f(?:[1-9]|10)$/);
export const blockSchema=z.object({id:z.string().max(40),label:z.string().max(160),text:z.string().max(15000),fileId:sourceFileId.optional()});
export const sourceSchema=z.object({retrieval:z.object({provider:z.string().max(60),recordSource:z.string().max(40),recordId:z.string().max(100),pmid:z.string().max(20),doi:z.string().max(300),requestedIdentifier:z.string().max(320),retrievedAt:z.string().max(40),url:z.string().url().max(1000)}).optional(),blocks:z.array(blockSchema).min(1).max(600),fileName:z.string().max(200),warnings:z.array(z.string().max(650)).max(600),files:z.array(z.object({id:sourceFileId,fileName:z.string().min(1).max(200),role:z.enum(["primary","supplement"])})).min(1).max(10).optional()}).superRefine((s,ctx)=>{
 if(s.blocks.reduce((n,b)=>n+b.text.length,0)>120000) ctx.addIssue({code:"custom",message:"Maximum text length: 120,000 characters."});
 if(new Set(s.blocks.map(b=>b.id)).size!==s.blocks.length) ctx.addIssue({code:"custom",message:"Duplicate passage identifiers."});
 if(s.files){
  const ids=new Set(s.files.map(f=>f.id));
  if(ids.size!==s.files.length||s.files.filter(f=>f.role==="primary").length!==1)ctx.addIssue({code:"custom",message:"Select one main file; file identifiers must be unique."});
  if(s.blocks.some(b=>!b.fileId||!ids.has(b.fileId)))ctx.addIssue({code:"custom",message:"Each passage must reference a file in this bundle."});
  if(s.files.some(f=>!s.blocks.some(b=>b.fileId===f.id)))ctx.addIssue({code:"custom",message:"Every file in the bundle must contain extracted text."});
 }else if(s.blocks.some(b=>b.fileId))ctx.addIssue({code:"custom",message:"The source file list is missing."});
});
export type Source=z.infer<typeof sourceSchema>;
export type Citation=z.infer<typeof citationSchema>;
const profileCode=z.enum(["D","I","N0","U","NE"]);
const se=z.enum(["SE0","SE1","SE2","SE3","SE4","SE5","SE6","SE7","SEU"]);
export const claimSchema=z.object({
 id:z.string().max(40), primary:z.boolean(), statement:text, citation:citationSchema,
 family:z.enum([...FAMILIES,"Cross-cutting"]), requiredFamilies:z.array(z.enum(FAMILIES)).max(5),
 readout:text, context:text, selectionRationale:text, evidenceRequired:text, evidenceSummary:text,
 evidence:z.array(citationSchema).max(5), kindMatch:z.enum(["Yes","No","Unclear"]), scopeMatch:z.enum(["Yes","No","Unclear"]),
 scope:z.object({readout:text,population:text,setting:text,treatment:text,comparator:text,outcome:text,horizon:text,inferenceUnit:text,decisionRule:text}),
 focal:z.enum(["D","I","N0","U"]), adequacy:z.enum(["Yes","Partial","No","Not assessed"]),
 profile:z.object({"Measurement reliability":profileCode,"Operational specificity":profileCode,"Clinical and functional relevance":profileCode,"Response to perturbation":profileCode,"Decision relevance":profileCode}),
 substitution:se, secondarySubstitutions:z.array(se.exclude(["SE0"])).max(2),
 role:z.enum(["Warrant","Motivation-background","Not applicable","Unclear"]),
 condition:z.enum(["NC0","NC1","NC2","Unclear"]), coupling:z.enum(["FC","Not coupled","Unclear","Not applicable"]),
 conditionMatches:z.enum(["Yes","No","Unclear","Not applicable"]), conditionCitation:citationSchema.nullable(),
 commitment:z.enum(["Present","Conditional-future","Unclear"]), polarity:z.enum(["Positive","Negative"]),
 bridgeClear:z.boolean(), rationale:text, questions:z.array(z.string().max(800)).max(5),
 v05:v05Schema.optional(),
});
export type Claim=z.infer<typeof claimSchema>;
export const analysisSchema=z.object({reportType:z.enum(["CB","M","NMC","NC"]),typeRationale:text,summary:text,limitations:z.array(z.string().max(800)).max(12),claims:z.array(claimSchema).max(12)}).superRefine((a,ctx)=>{
 const assessable=a.reportType==="CB"||a.reportType==="M";
 if(assessable && (a.claims.length===0||a.claims.filter(c=>c.primary).length!==1)) ctx.addIssue({code:"custom",message:"Exactly one primary claim is required."});
 if(!assessable && a.claims.length) ctx.addIssue({code:"custom",message:"NMC/NC reports do not receive claim assessments."});
 if(new Set(a.claims.map(c=>c.id)).size!==a.claims.length) ctx.addIssue({code:"custom",message:"Duplicate claim IDs."});
});
export type Analysis=z.infer<typeof analysisSchema> & {selection?:{policy:"focal-v1"|"focal-v2";confirmedAt:string;confirmedBy:string;rationale:string;extensionReason?:string};versions?:VersionManifest;language?:"en"|"pl";model?:string;generatedAt?:string;promptVersion?:string;demo?:boolean;sourceHash?:string;automatic?:{runId:string;status:"complete";inventoryComplete:boolean;claimCount:number;completedAt:string}};
export const decisionSchema=z.object({claim:claimSchema,status:z.enum(["draft","accepted","unresolved","excluded"]),concern:z.enum(['evidence-uncertainty','disagreement','technical']).optional(),correction:z.object({proposalId:z.string().max(80),model:z.string().max(200),createdAt:z.string().max(40)}).optional(),comment:z.string().max(4000),sourceChecked:z.boolean(),updatedAt:z.string().max(40)});
export const reviewSchema=z.object({decisions:z.record(decisionSchema),coverageChecked:z.boolean(),reportType:z.enum(["CB","M","NMC","NC"]).nullable(),reportComment:z.string().max(4000),reporting:reportingSchema.optional()});
export type Review=z.infer<typeof reviewSchema>;
export const emptyReview:Review={decisions:{},coverageChecked:false,reportType:null,reportComment:""};
export type RecordDoc={id:string;title:string;stage:string;coverage:string;sourceHash:string;createdAt:string;updatedAt:string;revision:number;analysis:Analysis|null;review:Review;source:Source;versions?:VersionManifest};
export const CLASS_PL:Record<string,string>={B0:"Wsparte",B1:"Otwarte",B2:"Dziedziczenie dowodowe",B3:"Twierdzenie bez pomostu",BU:"Nierozstrzygnięte",BNA:"Nie dotyczy"};
export function deriveBridge(c:Claim,reportType:string="CB") {
 if(reportType==="NMC"||reportType==="NC")return "BNA";
 if([c.substitution,...c.secondarySubstitutions].includes("SEU")||c.focal==="U"||!c.bridgeClear)return "BU";
 if(c.family==="Cross-cutting"&&(c.requiredFamilies.length<2||c.requiredFamilies.some(f=>c.profile[f]==="U"||c.profile[f]==="NE")))return "BU";
 if(c.v05){
  const v=c.v05;
  if(c.focal==="D")return c.kindMatch==="Yes"&&c.scopeMatch==="Yes"&&Object.values(v.scopeCodes).every(x=>x==="E"||x==="NA")&&["R0","R1"].includes(v.readoutRelation)&&v.evidenceLocation!=="Programme or external report"&&(c.family!=="Cross-cutting"||c.requiredFamilies.every(f=>c.profile[f]==="D"))?"B0":"BU";
  if(v.condition==="NC2"&&v.coupling==="FC"&&v.conditionMatches==="Yes"&&v.commitment==="Conditional-future"&&!!c.conditionCitation?.quote.trim()&&["Motivation-background","Not applicable"].includes(c.role))return "B1";
  if(c.substitution!=="SE0"&&c.role==="Warrant")return "B2";
  if(c.role==="Unclear"||v.condition==="NCU"||v.coupling==="U"||(v.condition==="NC2"&&v.conditionMatches==="Unclear"))return "BU";
  return c.role!=="Warrant"?"B3":"BU";
 }
 if(c.focal==="D")return c.kindMatch==="Yes"&&c.scopeMatch==="Yes"?"B0":"BU";
 const open=c.condition==="NC2"&&c.coupling==="FC"&&c.conditionMatches==="Yes"&&!!c.conditionCitation?.quote.trim()&&c.commitment==="Conditional-future"&&["Motivation-background","Not applicable"].includes(c.role);
 if(open)return "B1";
 if(c.substitution!=="SE0"&&c.role==="Warrant")return "B2";
 if(c.role==="Unclear"||c.condition==="Unclear"||c.coupling==="Unclear"||c.conditionMatches==="Unclear"||c.commitment==="Unclear")return "BU";
 if(c.role!=="Warrant"&&c.substitution==="SE0"&&c.secondarySubstitutions.length===0)return "B3";
 return "BU";
}
export function quoteExists(c:Citation,s:Source) { const b=s.blocks.find(b=>b.id===c.blockId); return !!c.quote.trim() && !!b?.text.includes(c.quote); }
export function claimIssues(c:Claim,s:Source) {
 const out:string[]=[];
 if(!c.statement.trim()||!c.evidenceSummary.trim()||!c.evidenceRequired.trim()||!c.rationale.trim()||!c.readout.trim()||!c.context.trim()||Object.values(c.scope).some(v=>!v.trim()))out.push("Complete the claim, readout, context, scope, evidence summary, required evidence and rationale.");
 if(!quoteExists(c.citation,s))out.push("The claim quotation was not found in the selected source passage. Check its text and location.");
 if(c.evidence.some(e=>!quoteExists(e,s)))out.push("At least one evidence quotation does not match the source. Check its text and location.");
 if(c.condition==="NC2"&&!c.conditionCitation?.quote.trim())out.push("NC2 requires an exact source quotation of the specific condition.");
 if(c.conditionCitation&&!quoteExists(c.conditionCitation,s))out.push("The condition quotation does not match the source. Check its text and location.");
 if(c.focal==="D"){
  const conflicts:string[]=[];
  if(c.kindMatch!=="Yes")conflicts.push(`Appropriate type of evidence? = ${c.kindMatch} (direct support requires a matching evidence type)`);
  const scopeConflicts=c.v05?SCOPE_KEYS.filter(k=>!["E","NA"].includes(c.v05!.scopeCodes[k])):[];
  if(scopeConflicts.length)conflicts.push(`Nine scope dimensions: ${scopeConflicts.map(k=>`${SCOPE_LABELS[k]} = ${c.v05!.scopeCodes[k]}`).join(', ')} (each relevant dimension must match: E; use NA only when it does not apply)`);
  else if(c.scopeMatch!=="Yes")conflicts.push(`Does all relevant scope match? = ${c.scopeMatch} (direct support requires matching scope)`);
  if(c.v05&&!['R0','R1'].includes(c.v05.readoutRelation))conflicts.push(`Readout relation = ${c.v05.readoutRelation} (direct support requires the same readout, R0, or documented empirical equivalence, R1)`);
  if(c.v05?.evidenceLocation==="Programme or external report")conflicts.push("Evidence location = Programme or external report (external evidence cannot provide direct support within this report)");
  if(conflicts.length)out.push(`D (direct support) conflicts with these fields: ${conflicts.join('; ')}. Check them against the source, then revise the conflicting fields or the support code.`);
 }
 if(["D","I"].includes(c.focal)&&!c.evidence.length)out.push("Add a source quotation documenting the evidence used for this assessment.");
 if(c.family==="Cross-cutting"&&(c.requiredFamilies.length<2||(c.focal==="D"&&c.requiredFamilies.some(f=>c.profile[f]!=="D"))))out.push("A cross-cutting claim requires at least two evidence families. Direct support (D) requires D in each required family.");
 if(deriveBridge(c)==="B2"&&!c.rationale.trim())out.push("Describe the specific transfer of evidence to this claim.");
 if(c.v05){const v=c.v05;
  if(!c.selectionRationale.trim())out.push("Explain why this claim was selected.");
  if(c.adequacy==="Not assessed"&&!v.adequacyRationale.trim())out.push("Explain why evidence adequacy was not assessed.");
  if([c.substitution,...c.secondarySubstitutions].includes("SE7")&&!v.substitutionDetail.trim())out.push("SE7 requires a description of the evidence substitution.");
  if(v.evidenceLocation==="Multiple report locations; specify"&&!v.evidenceLocationDetail.trim())out.push("Specify all evidence locations in Exact evidence location.");
  if(c.substitution!=="SE0"&&c.role==="Warrant"&&(!v.bridgeFrom.trim()||!v.bridgeTo.trim()))out.push("Complete Bridge: from and Bridge: to to describe the link from evidence to claim.");
  if(new Set(c.requiredFamilies).size!==c.requiredFamilies.length||(c.family!=="Cross-cutting"&&c.requiredFamilies.length))out.push("Required evidence families must be distinct and are only used for cross-cutting claims.");
  if(v.readoutRelation==="R1"&&(!v.equivalenceEvidence.trim()||!v.equivalenceCitation||!quoteExists(v.equivalenceCitation,s)))out.push("R1 requires a description of empirical equivalence and an exact source quotation documenting it.");
  if(v.condition==="NC2"&&(!c.conditionCitation||!quoteExists(c.conditionCitation,s)))out.push("NC2 requires an exact source quotation of the specific condition.");
  if(["U8","UX"].includes(v.declaredUse)&&!v.usePredicate.trim())out.push("Describe the intended use in Use predicate.");
  if(v.condition!=="NC2"&&v.conditionMatches!=="Structural NA")out.push("Condition match must be Structural NA when Condition status is not NC2.");
  if(v.condition==="NC2"&&v.conditionMatches==="Structural NA")out.push("NC2 requires a condition match of Yes, No or Unclear.");
  if(v.condition==="NC0"&&v.coupling!=="NA")out.push("NC0 requires Condition coupling to be NA.");
  if(c.role==="Warrant"&&(!v.warrantClaim.trim()||v.warrantFamily==="Not applicable"))out.push("Specify the directly supported claim used as a warrant and its evidence family.");
  if(v.methodologicalGeneralisation&&!v.generalisationTarget.trim())out.push("Specify the target scope of the methodological generalisation.");
 }
 return [...new Set(out)];
}
export function syncV05(c:Claim):Claim{if(!c.v05)return c;const v=c.v05;return {...c,commitment:v.commitment==="Conditional-future"?"Conditional-future":v.commitment==="Mixed"?"Unclear":"Present",polarity:v.polarity==="Negative"?"Negative":"Positive",condition:v.condition==="NC3"?"NC1":v.condition==="NCU"?"Unclear":v.condition,coupling:v.coupling==="FC"?"FC":v.coupling==="NA"?"Not applicable":v.coupling==="U"?"Unclear":"Not coupled",conditionMatches:v.conditionMatches==="Structural NA"?"Not applicable":v.conditionMatches,scopeMatch:Object.values(v.scopeCodes).some(x=>x==="N"||x==="X")?"No":Object.values(v.scopeCodes).some(x=>x==="U")?"Unclear":"Yes"};}
export function currentClaims(d:RecordDoc) {const claims=d.analysis?.claims||[];return [...claims.map(c=>d.review.decisions[c.id]?.claim||c),...Object.values(d.review.decisions).filter(x=>!claims.some(c=>c.id===x.claim.id)).map(x=>x.claim)];}
export function emptyClaim(id:string):Claim {return {id,primary:false,statement:"",citation:{blockId:"",quote:""},family:FAMILIES[2],requiredFamilies:[],readout:"",context:"",selectionRationale:"Added by reviewer",evidenceRequired:"",evidenceSummary:"",evidence:[],kindMatch:"Unclear",scopeMatch:"Unclear",scope:{readout:"",population:"",setting:"",treatment:"",comparator:"",outcome:"",horizon:"",inferenceUnit:"",decisionRule:""},focal:"U",adequacy:"Not assessed",profile:Object.fromEntries(FAMILIES.map(f=>[f,"U"])) as Claim["profile"],substitution:"SEU",secondarySubstitutions:[],role:"Unclear",condition:"Unclear",coupling:"Unclear",conditionMatches:"Unclear",conditionCitation:null,commitment:"Unclear",polarity:"Positive",bridgeClear:false,rationale:"",questions:[]};}
