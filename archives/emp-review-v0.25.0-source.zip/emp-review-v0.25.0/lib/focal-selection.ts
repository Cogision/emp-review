import {z} from 'zod';
import {AppError} from './app-error';
import {citationSchema,quoteExists,type Source} from './emp';
import type {AutomaticState} from './automatic';
export const focalChoiceSchema=z.object({rationale:z.string().trim().min(1).max(2000),extensionReason:z.string().trim().max(2000).default(''),claims:z.array(z.object({id:z.string().regex(/^C(?:0[1-9]|[1-7][0-9]|80)$/),primary:z.boolean(),statement:z.string().trim().min(1).max(5000),citation:citationSchema})).max(80)});
export function confirmFocalSelection(state:AutomaticState,input:unknown,source:Source,actor:string):AutomaticState{
 if(!state.selection||state.selection.confirmedAt||state.claims.length)throw new AppError('The selection is already frozen. Open the report to review its assessments.',409);
 const choice=focalChoiceSchema.parse(input),eligible=['CB','M'].includes(state.inventory.reportType);
 if(new Set(choice.claims.map(c=>c.id)).size!==choice.claims.length|| (eligible&&(choice.claims.length<1||choice.claims.filter(c=>c.primary).length!==1)) || (!eligible&&choice.claims.length))throw new AppError('Choose exactly one central claim.');
 if(choice.claims.length>3&&!choice.extensionReason)throw new AppError('Explain why more than three material claims are necessary.');
 if(choice.claims.some(c=>!quoteExists(c.citation,source)))throw new AppError('Each selected claim needs an exact quotation from its source passage.');
 return {...structuredClone(state),inventory:{...state.inventory,complete:false,claims:[...choice.claims].sort((a,b)=>Number(b.primary)-Number(a.primary))},selection:{policy:choice.claims.length>3?'focal-v2':state.selection.policy,confirmedAt:new Date().toISOString(),confirmedBy:actor,rationale:choice.rationale,extensionReason:choice.extensionReason}};
}
