import dictionary from "./translations.json";
export type Language="en"|"pl";
const en:Record<string,string>=dictionary;
const pl:Record<string,string>=Object.fromEntries(Object.entries(en).map(([a,b])=>[b,a]));
let language:Language="en";
const listeners=new Set<()=>void>();
export const getLanguage=()=>language;
export const subscribeLanguage=(fn:()=>void)=>{listeners.add(fn);return()=>{listeners.delete(fn);};};
export function setLanguage(value:Language){language="en";if(typeof window!=="undefined"){try{localStorage.setItem("emp-interface-language","en");}catch{}document.documentElement.lang="en";}listeners.forEach(fn=>fn());}
export function translate(message:string,lang:Language,values:unknown[]=[]){
 if(/Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module|Loading chunk [\w-]+ failed/i.test(message))return lang==='pl'?'Nie udało się wczytać części aplikacji. Zapisz bieżące zmiany, odśwież stronę i ponów operację. Zapisane wyniki możesz wyeksportować bez ponownego uruchamiania analizy AI.':'Part of the application could not be loaded. Save current edits, reload the page, and try again. Saved results can be exported without running AI analysis again.';
 let translated=(lang==="en"?en[message]:pl[message])||message;
 if(translated===message){
  // Stored diagnostics can contain claim IDs or several validation messages.
  // Translate known messages without changing IDs, quotations or free text.
  if(message.includes('\n'))translated=message.split('\n').map(line=>translate(line,lang)).join('\n');
  else {
   const claimPrefix=message.match(/^([A-Za-z][A-Za-z0-9_-]{0,39}: )(.+)$/);
   if(claimPrefix)translated=claimPrefix[1]+translate(claimPrefix[2],lang);
  }
  const diagnostic=message.match(/^(.*?)( \(HTTP [\s\S]*)$/);
  if(diagnostic)translated=translate(diagnostic[1],lang)+diagnostic[2];
  if(lang==="en")translated=translated.replace(/^Strona (\d+)/,"Page $1").replace(/^Fragment (\d+)/,"Passage $1");
 }
 return translated.replace(/\{(\d+)\}/g,(all,n)=>Number(n)<values.length?String(values[Number(n)]):all);
}
export const tr=(message:string,values:unknown[]=[])=>translate(message,language,values);
