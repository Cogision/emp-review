import {analysisSchema,sourceSchema,emptyReview,claimIssues,type Analysis,type Source,type Review} from './emp';
import {reportingDefaults,reportingSchema} from './reporting-schema';
import {newManifest} from './versions';
import {pilotId} from './pilot';
import {AppError} from './app-error';

export type PilotRecord={pilotId:string;stage:'A'|'B';title:string;coverage:string;publicationId:string;source:Source;analysis:Analysis;rawAssessment:unknown;comparison:{same_proposition:string;shift_codes:string[];explanation:string};originals:{fileId:string;fileName:string;sha256:string;contentType:string;base64:string}[]};
type Storage={DB:D1Database;BUCKET:R2Bucket};
type Saved={id:string;source_key:string;source_hash:string;revision:number;analysis:string|null};
export const PILOT_IMPORT_VERSION='EMP-supplied-pilot-2026-09-06-v1';
// Owner email verified through the current Sites access configuration. Identity still
// comes exclusively from Sites dispatch; an import request never supplies an owner.
export function canImportSuppliedPilot(user:{id:string;email:string}|null){return !!user?.id&&user.email.trim().toLowerCase()==='d.wiener@cogision.com';}
export function suppliedPilotId(who:string,key:string){return pilotId(who,`${PILOT_IMPORT_VERSION}:${key}`);}
export async function digest(value:string|Uint8Array){const bytes=typeof value==='string'?new TextEncoder().encode(value):value;return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes as BufferSource)),b=>b.toString(16).padStart(2,'0')).join('');}

export async function importPilotRecord(env:Storage,user:{id:string;email:string}|null,record:PilotRecord){
 if(!canImportSuppliedPilot(user))throw new AppError('This supplied-paper pilot is available only in its owner’s account.',403);
 const who=user!.id,{DB,BUCKET}=env,id=await suppliedPilotId(who,`${record.pilotId}:${record.stage}`),projectId=await suppliedPilotId(who,'project'),now=new Date().toISOString();
 const saved=()=>DB.prepare('SELECT id,source_key,source_hash,revision,analysis FROM documents WHERE id=? AND owner=?').bind(id,who).first<Saved>();
 const link=async()=>{await DB.batch([
  DB.prepare("INSERT INTO projects (id,owner,title,question,criteria,language,revision,created_at,updated_at) VALUES (?,?,?,?,?,'en',0,?,?) ON CONFLICT(id) DO NOTHING").bind(projectId,who,'EMP five-article pilot · supplied papers','Can a short article report preserve the reasoning of the pilot assessment?','Five supplied papers, separately assessed at Stage A (abstract) and Stage B (full text), including the supplied Drysdale erratum. All ten assessments are AI proposals and calibration records excluded from the main research frequency. Source selection: all five at both stages. No human verification, observed usability test or validation of the short protocol is implied. P02 and P03 change the primary proposition across stages; P04 is NMC; P05 is external oncology calibration.',now,now),
  DB.prepare("INSERT INTO project_documents (project_id,document_id,study_group,added_at) SELECT ?,id,?,? FROM documents WHERE id=? AND owner=? ON CONFLICT(project_id,document_id) DO NOTHING").bind(projectId,record.pilotId,now,id,who),
 ]);};
 // Reopening or retrying must preserve later human edits and their revision history.
 if(await saved()){await link();return {documentId:id,projectId,reused:true};}
 const source=sourceSchema.parse(record.source),parsed=analysisSchema.parse(record.analysis);
 for(const c of parsed.claims)if(claimIssues(c,source).length)throw new AppError('A prepared assessment failed source validation.',422);
 const text=JSON.stringify(source),hash=await digest(text),versions=newManifest('core');
 const analysis:Analysis={...parsed,model:record.analysis.model,language:'en',generatedAt:record.analysis.generatedAt,promptVersion:record.analysis.promptVersion,sourceHash:hash,versions};
 const review:Review=structuredClone(emptyReview);
 review.reporting={...reportingDefaults(),publicationId:record.publicationId,role:'calibration',reason:`${PILOT_IMPORT_VERSION} · ${record.pilotId}. User-requested calibration import, excluded from the main research frequency. AI proposals; no human source verification.`,sourceSelection:'uniform',selectionReason:'All five supplied articles assessed separately at A and B. Stage A sources were locked before the full-text assessments.'};
 if(record.stage==='B'){
  const parentId=await suppliedPilotId(who,`${record.pilotId}:A`),parent=await DB.prepare('SELECT id,source_hash,revision,analysis FROM documents WHERE id=? AND owner=?').bind(parentId,who).first<Saved>();
  if(!parent)throw new AppError('Save this article’s abstract assessment first. Resume the import to continue.',409);
  const a:Analysis|null=parent.analysis?JSON.parse(parent.analysis):null,primary=a?.claims.find(c=>c.primary),current=analysis.claims.find(c=>c.primary);
  if(primary&&current)review.reporting.stageLink={documentId:parentId,revision:parent.revision,sourceHash:parent.source_hash,stage:'A',claimId:primary.id,statement:primary.statement,scope:JSON.stringify(primary.scope),linkedAt:now,question:'What changes when the supplied full text is assessed after the locked abstract?',relation:parent.revision===0?(record.comparison.same_proposition==='Yes'?'same':'changed'):'pending',reason:`AI comparison of the imported assessments, not human adjudication. ${record.comparison.explanation}`.slice(0,2000),comparedClaimId:current.id,comparedStatement:current.statement,comparedScope:JSON.stringify(current.scope)};
 }
 reportingSchema.parse(review.reporting);
 const attempt=crypto.randomUUID(),prefix=`documents/${who}/${id}/${attempt}/`,sourceKey=`${prefix}text.json`,snapshotKey=`${prefix}assessments/${attempt}.json`,keys:string[]=[];
 async function put(key:string,value:string|Uint8Array,contentType='application/json'){keys.push(key);await BUCKET.put(key,value,{httpMetadata:{contentType}});}
 try{
  await put(sourceKey,text);
  for(const f of record.originals){
   if(!source.files?.some(s=>s.id===f.fileId&&s.fileName===f.fileName))throw new AppError('Original source does not match its registered file.',422);
   const bytes=Uint8Array.from(atob(f.base64),c=>c.charCodeAt(0));if(await digest(bytes)!==f.sha256)throw new AppError('Original source checksum failed.',422);
   await put(`${prefix}originals/${f.fileId}`,bytes,f.contentType);
  }
  if(record.originals.length!==source.files?.length)throw new AppError('The prepared source bundle is incomplete.',422);
  await put(`${prefix}pilot-audit.json`,JSON.stringify({version:PILOT_IMPORT_VERSION,pilotId:record.pilotId,stage:record.stage,sourceHash:hash,rawAssessment:record.rawAssessment,comparison:record.comparison,comparisonTiming:'Post-assessment metadata; never part of the locked Stage A source.',verification:'AI proposal; human verification not performed',originals:record.originals.map(({base64,...f})=>f)}));
  await put(snapshotKey,JSON.stringify({version:'EMP-assessment-snapshot-0.10.0',versions,documentId:id,revision:0,sourceHash:hash,stage:record.stage,analysis,review,kind:'pilot-ai-import',createdAt:now}));
  await DB.batch([
   DB.prepare('INSERT INTO documents (id,owner,title,stage,coverage,source_key,source_hash,analysis,review,version_manifest,revision,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,0,?,?) ON CONFLICT(id) DO NOTHING').bind(id,who,record.title,record.stage,record.coverage,sourceKey,hash,JSON.stringify(analysis),JSON.stringify(review),JSON.stringify(versions),now,now),
   DB.prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) SELECT ?,id,owner,0,'pilot-ai-import',?,? FROM documents WHERE id=? AND owner=? AND source_key=?").bind(attempt,JSON.stringify({version:PILOT_IMPORT_VERSION,pilotId:record.pilotId,stage:record.stage,sourceHash:hash,actorType:'ai',auditKey:`${prefix}pilot-audit.json`}),now,id,who,sourceKey),
   DB.prepare("INSERT INTO assessment_runs (id,document_id,owner,actor_type,actor_id,model,manual_version,source_hash,stage,revision,snapshot_key,created_at) SELECT ?,id,owner,'ai',?,?,'v0.5-core',source_hash,stage,0,?,? FROM documents WHERE id=? AND owner=? AND source_key=?").bind(attempt,analysis.model||'Codex',analysis.model||'Codex',snapshotKey,now,id,who,sourceKey),
  ]);
 }catch(e){
  const existing=await saved();if(existing?.source_key!==sourceKey)await Promise.all(keys.map(k=>BUCKET.delete(k)));
  if(!existing)throw e;
 }
 const existing=await saved();if(!existing)throw new AppError('The assessment was not saved. Resume the import to try again.',503);
 if(existing.source_key!==sourceKey)await Promise.all(keys.map(k=>BUCKET.delete(k)));
 await link();return {documentId:id,projectId,reused:existing.source_key!==sourceKey};
}
