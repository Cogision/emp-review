import {headers} from 'next/headers';
import {bindings,owner} from './server';
import {ProjectAccessStore} from './project-access';
export async function projectAccessStore(){return new ProjectAccessStore(bindings(),await owner(),(await headers()).get('oai-authenticated-user-email')||'');}
