import {z} from 'zod';
import {AppError} from './app-error';
import {normalizeReviewerEmail,recipientEmailSchema} from './reviewer-invitations';
import type {Project} from './projects';

const fail=(message:string,status=400):never=>{throw new AppError(message,status);};
const tokenHash=async(token:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(b=>b.toString(16).padStart(2,'0')).join('');
type ProjectRow=Project&{owner:string};
export type ProjectMember={id:string;name:string;email:string;status:'pending'|'approved'|'rejected'};
export type ProjectInvitation={id:string;recipientEmail:string;expiresAt:string;claimed:boolean;revoked:boolean};
export type ProjectPeople={revision:number;members:ProjectMember[];invites:ProjectInvitation[]};
export type SharedProject={project:Project;membership:'pending'|'approved';articles:{id:string;title:string;stage:string}[];rounds:{id:string;title:string;documentId:string;status:string;membership:string}[]};

/** Project membership grants an article inventory and assigned round links only.
 * Private documents, owner proposals and independent drafts remain behind their
 * original authorization paths. This store never reads source/assessment objects. */
export class ProjectAccessStore{
 constructor(private env:{DB:D1Database},private who:string,private email=''){if(!who)fail('Sign in.',401);}
 private q(sql:string,...args:unknown[]){return this.env.DB.prepare(sql).bind(...args);}
 private async project(id:string){const p=await this.q('SELECT * FROM projects WHERE id=?',id).first<ProjectRow>();if(!p)fail('Project not found.',404);return p!;}
 private async owned(id:string){const p=await this.project(id);if(p.owner!==this.who)fail('Project not found.',404);return p;}
 async list(){return (await this.q("SELECT p.id,p.title,CASE WHEN m.status='pending' THEN '' ELSE p.question END AS question,CASE WHEN m.status='pending' THEN '' ELSE p.criteria END AS criteria,CASE WHEN m.status='pending' THEN '' ELSE p.category END AS category,CASE WHEN m.status='pending' THEN NULL ELSE p.target_count END AS target_count,p.language,p.revision,p.created_at,p.updated_at,CASE WHEN p.owner=? THEN 'owner' ELSE 'member' END AS role,CASE WHEN m.status='pending' THEN 0 ELSE (SELECT COUNT(*) FROM project_documents pd WHERE pd.project_id=p.id) END AS document_count FROM projects p LEFT JOIN project_members m ON m.project_id=p.id AND m.user_id=? WHERE p.owner=? OR m.status IN ('pending','approved') ORDER BY p.updated_at DESC LIMIT 200",this.who,this.who,this.who).all<Project>()).results;}
 async shared(id:string):Promise<SharedProject>{
  const p=await this.project(id),member=await this.q("SELECT status FROM project_members WHERE project_id=? AND user_id=? AND status IN ('pending','approved')",id,this.who).first<{status:'pending'|'approved'}>();
  if(!member)fail('Project not found.',404);
  const project:Project={id:p.id,title:p.title,category:member!.status==='approved'?p.category:'',target_count:member!.status==='approved'?p.target_count:null,question:member!.status==='approved'?p.question:'',criteria:member!.status==='approved'?p.criteria:'',language:p.language,revision:p.revision,created_at:p.created_at,updated_at:p.updated_at,role:'member'};
  if(member!.status==='pending')return {project,membership:'pending',articles:[],rounds:[]};
  const articles=(await this.q('SELECT d.id,d.title,d.stage FROM project_documents pd JOIN documents d ON d.id=pd.document_id WHERE pd.project_id=? ORDER BY pd.added_at,d.id LIMIT 100',id).all<SharedProject['articles'][number]>()).results;
  const rounds=(await this.q("SELECT r.id,r.title,r.source_document_id AS documentId,r.status,m.status AS membership FROM review_rounds r JOIN round_members m ON m.round_id=r.id AND m.user_id=? JOIN project_documents pd ON pd.document_id=r.source_document_id WHERE pd.project_id=? AND m.status IN ('pending','approved') ORDER BY r.created_at DESC LIMIT 200",this.who,id).all<SharedProject['rounds'][number]>()).results;
  // Removal during loading must not return an overview captured before removal.
  if(!await this.q("SELECT 1 FROM project_members WHERE project_id=? AND user_id=? AND status='approved'",id,this.who).first())fail('Project access changed. Reload the page.',409);
  return {project,membership:'approved',articles,rounds};
 }
 async people(id:string):Promise<ProjectPeople>{
  const p=await this.owned(id);
  const members=(await this.q('SELECT user_id AS id,name,email,status FROM project_members WHERE project_id=? ORDER BY created_at,user_id',id).all<ProjectMember>()).results;
  const invites=(await this.q('SELECT id,recipient_email AS recipientEmail,expires_at AS expiresAt,claimed_by,revoked_at FROM project_invites WHERE project_id=? ORDER BY created_at DESC LIMIT 100',id).all<{id:string;recipientEmail:string;expiresAt:string;claimed_by:string|null;revoked_at:string|null}>()).results.map(i=>({id:i.id,recipientEmail:i.recipientEmail,expiresAt:i.expiresAt,claimed:!!i.claimed_by,revoked:!!i.revoked_at}));
  return {revision:p.revision,members,invites};
 }
 async action(id:string,body:unknown){
  const input=z.discriminatedUnion('action',[
   z.object({action:z.literal('invite'),revision:z.number().int(),recipientEmail:recipientEmailSchema}),
   z.object({action:z.literal('revoke'),revision:z.number().int(),inviteId:z.string().uuid()}),
   z.object({action:z.enum(['approve','reject','remove']),revision:z.number().int(),memberId:z.string().min(1).max(200)})
  ]).parse(body),p=await this.owned(id);
  if(input.revision!==p.revision)fail('The project changed. Refresh before continuing.',409);
  const event=crypto.randomUUID(),now=new Date().toISOString(),extra:D1PreparedStatement[]=[];
  let invitation:{token:string;recipientEmail:string;expiresAt:string}|undefined;
  if(input.action==='invite'){
   const count=await this.q("SELECT COUNT(*) AS n FROM project_invites WHERE project_id=? AND revoked_at IS NULL AND claimed_by IS NULL AND expires_at>?",id,now).first<{n:number}>();if((count?.n||0)>=50)fail('Use or revoke outstanding invitations before adding more.');
   const token=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-',''),hash=await tokenHash(token),expiresAt=new Date(Date.now()+7*86400000).toISOString();
   extra.push(this.q("INSERT INTO project_invites (id,project_id,token_hash,recipient_email,expires_at,created_at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM project_access_events WHERE id=?)",crypto.randomUUID(),id,hash,input.recipientEmail,expiresAt,now,event));
   invitation={token,recipientEmail:input.recipientEmail,expiresAt};
  }else if(input.action==='revoke'){
   if(!await this.q('SELECT 1 FROM project_invites WHERE id=? AND project_id=? AND claimed_by IS NULL',input.inviteId,id).first())fail('Unused invitation not found.',404);
   extra.push(this.q('UPDATE project_invites SET revoked_at=? WHERE id=? AND project_id=? AND claimed_by IS NULL AND EXISTS(SELECT 1 FROM project_access_events WHERE id=?)',now,input.inviteId,id,event));
  }else{
   const m=await this.q('SELECT status FROM project_members WHERE project_id=? AND user_id=?',id,input.memberId).first<{status:string}>();
   if(!m||input.action==='approve'&&m.status!=='pending')fail('Member request changed. Refresh the list.',409);
   extra.push(this.q('UPDATE project_members SET status=? WHERE project_id=? AND user_id=? AND EXISTS(SELECT 1 FROM project_access_events WHERE id=?)',input.action==='approve'?'approved':'rejected',id,input.memberId,event));
  }
  const result=await this.env.DB.batch([
   this.q('INSERT INTO project_access_events (id,project_id,actor,kind,detail,created_at) SELECT ?,id,?,?,?,? FROM projects WHERE id=? AND owner=? AND revision=?',event,this.who,input.action,JSON.stringify(input),now,id,this.who,input.revision),
   this.q('UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM project_access_events WHERE id=?)',now,id,event),...extra
  ]);
  if(result[0].meta.changes!==1)fail('The project changed. Refresh before continuing.',409);
  return {...await this.people(id),...(invitation?{invitation}:{})};
 }
 async join(body:unknown){
  const v=z.object({token:z.string().trim().regex(/^[a-f0-9]{64}$/),name:z.string().trim().min(1).max(120)}).parse(body),hash=await tokenHash(v.token),email=normalizeReviewerEmail(this.email);
  const invite=await this.q('SELECT * FROM project_invites WHERE token_hash=?',hash).first<{id:string;project_id:string;recipient_email:string;claimed_by:string|null;revoked_at:string|null;expires_at:string}>();
  if(!invite)fail('Invitation unavailable or expired.',404);
  if((await this.project(invite!.project_id)).owner===this.who)fail('You already own this project.',409);
  if(!email||invite!.recipient_email!==email)fail('Sign in with the email address this invitation was created for. The code has not been used.',403);
  if(invite!.claimed_by===this.who&&await this.q("SELECT 1 FROM project_members WHERE project_id=? AND user_id=? AND status IN ('pending','approved')",invite!.project_id,this.who).first())return {id:invite!.project_id};
  const event=crypto.randomUUID(),now=new Date().toISOString();
  const result=await this.env.DB.batch([
   this.q("UPDATE project_invites SET claimed_by=?,claim_id=? WHERE id=? AND claimed_by IS NULL AND revoked_at IS NULL AND expires_at>? AND recipient_email=? AND NOT EXISTS(SELECT 1 FROM project_members WHERE project_id=project_invites.project_id AND user_id=? AND status!='rejected')",this.who,event,invite!.id,now,email,this.who),
   this.q("INSERT INTO project_members (project_id,user_id,name,email,status,created_at) SELECT project_id,?,?,?,'pending',? FROM project_invites WHERE id=? AND claim_id=? ON CONFLICT(project_id,user_id) DO UPDATE SET name=excluded.name,email=excluded.email,status='pending',created_at=excluded.created_at WHERE project_members.status='rejected'",this.who,v.name,email,now,invite!.id,event),
   this.q("INSERT INTO project_access_events (id,project_id,actor,kind,detail,created_at) SELECT ?,project_id,?,'join_requested','{}',? FROM project_invites WHERE id=? AND claim_id=?",event,this.who,now,invite!.id,event),
   this.q('UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM project_invites WHERE id=? AND claim_id=?)',now,invite!.project_id,invite!.id,event)
  ]);
  if(result[0].meta.changes!==1)fail('Invitation unavailable, expired, or already used.',409);
  return {id:invite!.project_id};
 }
}
