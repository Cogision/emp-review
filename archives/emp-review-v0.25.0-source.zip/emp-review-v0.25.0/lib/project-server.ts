import {ProjectFigureStore} from "./project-figure-store";
import {legacyManifest} from './versions';
import { bindings, db, rowFor, sourceFor, AppError, type Row } from "./server";
import type { Project, ProjectData } from "./projects";
import {ProjectAssessmentStore} from "./project-assessment-store";
export const PROJECT_LIMIT=100;
export async function projectFor(id:string,who:string):Promise<Project>{const p=await db().prepare("SELECT id,title,question,criteria,category,target_count,language,revision,created_at,updated_at FROM projects WHERE id=? AND owner=?").bind(id,who).first<Project>();if(!p)throw new AppError("Project not found.",404);return p;}
export async function projectData(id:string,who:string):Promise<ProjectData>{
 const project=await projectFor(id,who);
 const result=await db().prepare("SELECT d.*,p.study_group FROM project_documents p JOIN documents d ON d.id=p.document_id WHERE p.project_id=? AND d.owner=? ORDER BY p.added_at,d.id LIMIT 101").bind(id,who).all<Row&{study_group:string}>();
 if(result.results.length>PROJECT_LIMIT)throw new AppError("A project can contain up to 100 reports. Split this collection before generating a synthesis.",413);
 const documents=[],assessments=new ProjectAssessmentStore(bindings(),who);let bytes=0;
 for(const row of result.results){bytes+=(row.analysis?.length||0)+row.review.length;if(bytes>20000000)throw new AppError("This collection is too large for one synthesis. Split it into smaller projects.",413);
  const source=await sourceFor(row);bytes+=JSON.stringify(source).length;if(bytes>12000000)throw new AppError("This collection is too large for one synthesis. Split it into smaller projects.",413);const projected=await assessments.apply(id,{id:row.id,title:row.title,stage:row.stage,coverage:row.coverage,sourceHash:row.source_hash,revision:row.revision,updatedAt:row.updated_at,createdAt:row.created_at,studyGroup:row.study_group,versions:row.version_manifest?JSON.parse(row.version_manifest):legacyManifest(row.analysis?JSON.parse(row.analysis):null,JSON.parse(row.review)),analysis:row.analysis?JSON.parse(row.analysis):null,review:JSON.parse(row.review),source});documents.push(projected);
 }
 const figureSelections=await new ProjectFigureStore(bindings(),who).list(id);
 if(JSON.stringify({documents,figureSelections}).length>12000000)throw new AppError("The selected assessments exceed the project size limit. Split the collection into smaller projects.",413);
 if((await projectFor(id,who)).revision!==project.revision)throw new AppError("The project changed while loading. Reload it / Projekt zmienił się podczas wczytywania. Odśwież go.",409);
 return {project,documents,figureSelections,selectionHistory:await assessments.history(id),generatedAt:new Date().toISOString()};
}
export async function attachDocument(projectId:string,documentId:string,who:string){
 await projectFor(projectId,who);await rowFor(documentId,who);
 const now=new Date().toISOString();
 const results=await db().batch([
  db().prepare("UPDATE projects SET revision=revision+1,updated_at=? WHERE id=? AND owner=? AND (SELECT COUNT(*) FROM project_documents WHERE project_id=?)<100 AND NOT EXISTS (SELECT 1 FROM project_documents WHERE project_id=? AND document_id=?)").bind(now,projectId,who,projectId,projectId,documentId),
  db().prepare("INSERT INTO project_documents (project_id,document_id,study_group,added_at) SELECT ?,?,'',? WHERE (SELECT COUNT(*) FROM project_documents WHERE project_id=?)<100 ON CONFLICT(project_id,document_id) DO NOTHING").bind(projectId,documentId,now,projectId)
 ]);
 if(!results[1].meta.changes&&!await db().prepare("SELECT 1 FROM project_documents WHERE project_id=? AND document_id=?").bind(projectId,documentId).first())throw new AppError("A project can contain up to 100 reports.",413);
}
