import {reportSettings,duplicateGroups,identityKeys,normalizePublicationId,stageComparison,REPORTING_POLICY,reportingNotes,SOURCE_SELECTION_LABELS,BASIS_LABELS} from './reporting';
import {pilotManifest} from './pilot';
import {currentClaims,claimIssues,deriveBridge,FAMILIES,type RecordDoc,type Claim} from './emp';
import {assessmentState,bridgeExplanation} from './assessment-state';
import {codingScope} from './versions';
import type {ProjectData} from './projects';
export const BRIDGE_LABELS:Record<string,string>={B0:'Supported within scope',B1:'Open, pending a specified test',B2:'Evidential inheritance',B3:'Unbridged assertion',BU:'Unresolved',BNA:'Not applicable',TECH:'Analysis needs repair',DISPUTED:'Correction requested',LEGACY:'Clarify earlier unresolved decision',PENDING:'Awaiting assessment'};
export const PROFILE_LABELS:Record<string,string>={D:'Direct evidence',I:'Indirect / displaced evidence',N0:'No appropriate evidence identified',U:'Unresolved',NE:'Not evaluated'};
export function claimReportingBasis(d:ProjectData['documents'][number],claim:Claim|null):keyof typeof BASIS_LABELS{
 const saved=claim?d.review.decisions[claim.id]:undefined;
 const reviewed=!!saved?.sourceChecked&&d.review.coverageChecked&&(['accepted','unresolved'].includes(saved.status)||!!saved.concern);
 const manualProposal=!!saved&&!saved.correction&&(saved.status==='unresolved'||!!saved.concern||JSON.stringify(saved.claim)!==JSON.stringify(d.analysis?.claims.find(c=>c.id===saved.claim.id)));
 return d.assessmentBasis?.kind==='adjudicated'?'adjudicated':reviewed?'reviewed':manualProposal||!d.analysis?.model||/^manual$/i.test(d.analysis.model)?'manual':'ai';
}
export function publicationProfile(d:RecordDoc){
 const effectiveType=d.review.reportType||d.analysis?.reportType||null;
 const structural=effectiveType==='NC'||effectiveType==='NMC';
 const claims=(structural?[]:currentClaims(d)).filter(c=>d.review.decisions[c.id]?.status!=='excluded'),primaries=claims.filter(c=>c.primary),central=primaries.length===1?primaries[0]:null;
 const type=d.review.reportType||d.analysis?.reportType||null,decision=central?d.review.decisions[central.id]:null;
 const state=central?assessmentState(d,central):{issues:[],bridge:'PENDING',checked:false,workflow:'draft',label:'Awaiting assessment'};
 const {issues,bridge,checked,workflow,label}=state;
 const reviewRecorded=!!decision?.sourceChecked&&d.review.coverageChecked&&(['accepted','unresolved'].includes(decision.status)||!!decision.concern);
 const policy=d.analysis?.selection?.policy;
 const protocol=policy==='focal-v1'&&claims.length>3?'focal-v1-extended':policy||'legacy-selection';
 const typeRationale=d.review.reportType&&d.review.reportType!==d.analysis?.reportType?d.review.reportComment||`Reviewer classification: ${d.review.reportType}. Check the report-type note in detailed coding.`:d.analysis?.typeRationale||'Not assessed';
 return {workflow,workflowLabel:label,reviewRecorded,typeRationale,central,context:claims.filter(c=>!c.primary),type,bridge,issues,checked,status:decision?.status||'draft',protocol,fieldScope:codingScope(d.analysis,d.review),eligible:type==='CB',selectionIssue:!!d.analysis&&['CB','M'].includes(type||'')&&!central};
}
export function publicationMetrics(data:ProjectData,view:'reviewed'|'provisional'|'ai'|'adjudicated'='reviewed',population:'research'|'calibration'='research'){
 const rows=[...new Map(data.documents.map(d=>[d.id,d])).values()].map(document=>({document,...publicationProfile(document),settings:reportSettings(document)}));
 const selected=rows.filter(r=>population==='calibration'?(r.settings.role==='calibration'||r.document.analysis?.demo):r.settings.role==='audit'&&!r.document.analysis?.demo);
 const active=selected.filter(r=>!r.settings.duplicateOf);
 const duplicates=duplicateGroups(active.map(r=>r.document));
 const duplicateIds=new Set(duplicates.flat().map(d=>d.id));
 const brokenDuplicates=selected.filter(r=>r.settings.duplicateOf&&!selected.some(t=>t.document.id===r.settings.duplicateOf&&!t.settings.duplicateOf&&t.document.stage===r.document.stage));
 const strata=new Map<string,{key:string;stage:string;protocol:string;fieldScope:string;basis:keyof typeof BASIS_LABELS;sourceSelection:keyof typeof SOURCE_SELECTION_LABELS;total:number;reviewed:number;pending:number;included:number;duplicateReports:number;counts:Record<string,number>}>();
 for(const r of active){if(!r.eligible)continue;
  const basis=claimReportingBasis(r.document,r.central);
  const sourceSelection=r.settings.sourceSelection;
  const key=[r.document.stage,r.protocol,r.fieldScope,sourceSelection,basis].join('|');
  const g=strata.get(key)||{key,stage:r.document.stage,protocol:r.protocol,fieldScope:r.fieldScope,basis,sourceSelection,total:0,reviewed:0,pending:0,included:0,duplicateReports:0,counts:{B0:0,B1:0,B2:0,B3:0,BU:0,TECH:0,DISPUTED:0,LEGACY:0,PENDING:0}};
  g.total++;if(r.checked)g.reviewed++;else g.pending++;
  if(duplicateIds.has(r.document.id))g.duplicateReports++;
  const include=view==='provisional'||view==='reviewed'&&basis==='reviewed'||view==='ai'&&basis==='ai'||view==='adjudicated'&&basis==='adjudicated';
  if(include){g.included++;g.counts[r.bridge]=(g.counts[r.bridge]||0)+1;}strata.set(key,g);
 }
 return {policy:REPORTING_POLICY,population,view,rows,duplicates:duplicates.map(g=>g.map(d=>({id:d.id,title:d.title,stage:d.stage}))),brokenDuplicates:brokenDuplicates.map(r=>r.document.id),
  strata:[...strata.values()].map(g=>{const unavailable=g.counts.TECH+g.counts.DISPUTED+g.counts.LEGACY+g.counts.PENDING,resolved=g.counts.B0+g.counts.B1+g.counts.B2+g.counts.B3,duplicateBlocked=g.duplicateReports>0||brokenDuplicates.length>0,blocked=duplicateBlocked||unavailable>0,rate=(n:number,d:number)=>!blocked&&d?100*n/d:null;return {...g,unavailable,duplicateBlocked,blocked,percent:rate(g.counts.B2,g.included),resolved,resolvedPercent:rate(g.counts.B2,resolved),lower:rate(g.counts.B2,g.included),upper:rate(g.counts.B2+g.counts.BU,g.included)};}),
  pendingAnalysis:active.filter(r=>!r.document.analysis).length,awaitingReview:active.filter(r=>r.eligible&&!r.checked).length,
  nonCB:active.filter(r=>r.type&&r.type!=='CB').length,calibration:rows.filter(r=>r.settings.role==='calibration'||r.document.analysis?.demo).length,
  excluded:rows.filter(r=>r.settings.role==='excluded'&&!r.document.analysis?.demo).length,reconciledDuplicates:rows.filter(r=>!!r.settings.duplicateOf).length};
}
export const metricPercent=(n:number|null)=>n===null?'Not estimated':`${Number(n.toFixed(1))}%`;
export function metricSummary(g:ReturnType<typeof publicationMetrics>['strata'][number]){
 if(g.duplicateBlocked)return 'Percentage withheld until duplicate report records are reconciled.';
 if(g.unavailable)return `${g.counts.B2} inheritance; ${g.counts.BU} evidence unresolved; ${g.unavailable} awaiting repair, correction or clarification out of ${g.included} eligible reports. Percentage withheld until these records are classifiable.`;
 if(!g.included)return 'No assessments in this reporting group.';
 return `Evidential inheritance: ${g.counts.B2} / ${g.included} (${metricPercent(g.percent)}). Unresolved: ${g.counts.BU} / ${g.included}. Among resolved: ${g.counts.B2} / ${g.resolved} (${metricPercent(g.resolvedPercent)}).`;
}
export function calibrationNarrative(g:ReturnType<typeof publicationMetrics>['strata'][number]){
 if(g.blocked||!g.included)return metricSummary(g);
 const n=g.included,unresolved=g.counts.BU;
 if(unresolved===n)return n===1?'The assessed central claim remains unresolved.':`All ${n} assessed central claims remain unresolved.`;
 const finding=g.counts.B2
  ?`${g.basis==='ai'?'AI proposed':'The saved assessments record'} evidential inheritance for ${g.counts.B2} of ${n} assessed central ${n===1?'claim':'claims'}.`
  :`${g.basis==='ai'?'AI did not flag':'The saved assessments do not record'} evidential inheritance among ${n} assessed central ${n===1?'claim':'claims'}.`;
 return [finding,unresolved?`${unresolved} ${unresolved===1?'claim remains':'claims remain'} unresolved.`:'',g.counts.B0===n?`${n===1?'The claim was':`All ${n} were`} assessed as supported within ${n===1?'its':'their'} scope.`:''].filter(Boolean).join(' ');
}
export function calibrationCalculationLines(g:ReturnType<typeof publicationMetrics>['strata'][number]){
 if(g.blocked||!g.included)return [metricSummary(g)];
 return [
  `Including unresolved assessments: ${g.counts.B2} / ${g.included} (${metricPercent(g.percent)}). The denominator includes ${g.counts.BU} unresolved ${g.counts.BU===1?'claim':'claims'}.`,
  g.resolved?`Resolved assessments only: ${g.counts.B2} / ${g.resolved} (${metricPercent(g.resolvedPercent)}). This denominator excludes ${g.counts.BU} unresolved ${g.counts.BU===1?'claim':'claims'}.`:'Resolved assessments only: not estimated because no claims have been resolved.',
  'These percentages describe shares of assessed claims, not confidence in an assessment.',
 ];
}
/** Descriptive calibration results never enter the research population. Known pilot
 * subjects identify the comparison group only; current saved judgments determine CB eligibility. */
export function calibrationMetrics(data:ProjectData,view:Parameters<typeof publicationMetrics>[1]='provisional'){
 const documents=[...new Map(data.documents.map(d=>[d.id,d])).values()].filter(d=>reportSettings(d).role==='calibration'||d.analysis?.demo);
 const labels:Record<string,string>={psychiatry:'Psychiatric pilot papers',external:'External calibration · oncology',other:'Other calibration papers',synthetic:'Synthetic examples'};
 const grouped=new Map<string,typeof documents>();
 for(const d of documents){
  const keys=identityKeys(d),paper=pilotManifest.records.find(p=>keys.includes(normalizePublicationId(p.doi))||keys.includes(`pmid:${p.pmid}`));
  const key=d.analysis?.demo?'synthetic':paper?.id==='P05'?'external':paper?'psychiatry':'other';
  grouped.set(key,[...(grouped.get(key)||[]),d]);
 }
 const groups=Object.keys(labels).filter(k=>grouped.has(k)).map(key=>{
  const docs=grouped.get(key)!,metrics=publicationMetrics({...data,documents:docs},view,'calibration');
  const types={CB:0,M:0,NMC:0,NC:0,pending:0};for(const r of metrics.rows)types[r.type||'pending']++;
  const comparisons=metrics.rows.filter(r=>!r.settings.duplicateOf).flatMap(r=>{
   const pair=stageComparison(r.document);if(!pair)return [];
   return [{documentId:r.document.id,title:r.document.title,stage:r.document.stage,status:pair.status,earlierDocumentId:pair.link.documentId,earlierStage:pair.link.stage,earlierStatement:pair.link.statement,currentStatement:r.central?.statement||'',reason:pair.link.reason,stale:pair.stale}];
  });
  return {key,label:labels[key],papers:new Set(docs.map(d=>identityKeys(d)[0]||d.id)).size,recordCount:docs.length,types,metrics,comparisons,hasBothStages:docs.some(d=>d.stage==='A')&&docs.some(d=>d.stage==='B')};
 });
 const changedClaims=documents.flatMap(d=>stageComparison(d)?.status==='changed'?[{documentId:d.id,title:d.title,stage:d.stage}]:[]);
 return {policy:'EMP-calibration-descriptive-1',view,includedInResearchMetric:false as const,recordCount:documents.length,groups,changedClaims};
}
export function calibrationComparisonNotice(group:ReturnType<typeof calibrationMetrics>['groups'][number]){
 if(!group.hasBothStages)return null;
 const changed=group.comparisons.filter(c=>c.status==='changed').length,pending=group.comparisons.filter(c=>c.status==='pending').length;
 return {
  title:changed?'These stages cannot be compared directly':'A direct comparison requires the same central claims',
  text:[changed?`${changed} saved source ${changed===1?'comparison records a changed central claim':'comparisons record changed central claims'}. These are not reclassifications of the same claim.`:'These are separate summaries of the saved assessments at each source stage.',pending?`${pending} claim ${pending===1?'comparison still needs':'comparisons still need'} checking.`:'','The eligible articles can also differ between stages. To assess what the full text adds, evaluate the same central claim and material scope in the same articles at both stages.'].filter(Boolean).join(' '),
 };
}
export function calibrationReportLines(data:ProjectData){const c=calibrationMetrics(data);if(!c.recordCount)return [];return [
 'Pilot and calibration results',
 `${c.recordCount} calibration assessment records. These descriptive results are excluded from the main research percentage. Real psychiatric papers, external oncology calibration and synthetic examples are kept separate.`,
 'Each source stage and assessment basis has its own denominator. Only the selected primary CB claim enters each ratio; context claims do not add observations. Methodological (M) and no-applicable-claim (NMC) reports remain in the report inventory.',
 ...c.groups.flatMap(group=>[`${group.label}: ${group.papers} papers, ${group.recordCount} source-stage records. CB ${group.types.CB}; M ${group.types.M}; NMC ${group.types.NMC}; NC ${group.types.NC}; type pending ${group.types.pending}.`,
  ...(group.hasBothStages?[calibrationComparisonNotice(group)!.title,calibrationComparisonNotice(group)!.text]:[]),
  ...group.metrics.strata.filter(g=>g.included>0).flatMap(g=>[`${g.stage==='A'?'Title and abstract':g.stage==='B'?'Full text':'Excerpts'} | ${BASIS_LABELS[g.basis]}`,calibrationNarrative(g),`${g.pending} profiles await human source verification.`]),
  ...group.comparisons.filter(p=>p.status==='changed'||p.status==='pending').flatMap(p=>[`${p.status==='changed'?'Changed central claim':'Claim comparison needs checking'}: ${p.title}`,`Earlier central claim (${p.earlierStage}): ${p.earlierStatement}`,`Current central claim (${p.stage}): ${p.currentStatement||'No central claim selected.'}`,p.stale?'An edit invalidated the earlier comparison. Compare the current claim again.':p.reason]),
  'Calculation details',
  ...group.metrics.strata.flatMap(g=>[`${g.stage==='A'?'Title and abstract':g.stage==='B'?'Full text':'Excerpts'} | ${BASIS_LABELS[g.basis]} | ${SOURCE_SELECTION_LABELS[g.sourceSelection]} | ${g.protocol} | ${g.fieldScope} fields`,...calibrationCalculationLines(g),`Primary-claim classes: supported ${g.counts.B0}; open ${g.counts.B1}; inheritance ${g.counts.B2}; unbridged ${g.counts.B3}; unresolved ${g.counts.BU}.`]),
  ...(group.metrics.duplicates.length||group.metrics.brokenDuplicates.length?['Duplicate calibration records need reconciliation; affected percentages are withheld.']:[]),
  ...(!group.metrics.strata.length?['No CB denominator in this calibration group. Its saved assessments remain in the inventory.']:[])]),
 'The articles eligible as CB can differ between source stages. Do not interpret a lower full-text percentage as an improvement in the same set of claims. The pilot does not estimate prevalence in psychiatry or validate the abbreviated protocol.',
 ];}
export function metricReportLines(data:ProjectData){const m=publicationMetrics(data,'provisional'),pilot=calibrationReportLines(data);const research=[
 `Central-claim results | ${REPORTING_POLICY}`,
 'One primary claim per eligible CB report and source stage. Contextual claims do not change these denominators. Human-checked assessments, released adjudications and unreviewed proposals are separate.',
 ...m.strata.flatMap(g=>[`${g.stage} | ${g.protocol} | ${g.fieldScope} fields | ${SOURCE_SELECTION_LABELS[g.sourceSelection]} | ${BASIS_LABELS[g.basis]}`,metricSummary(g),`Class distribution: B0 supported ${g.counts.B0}; B1 open ${g.counts.B1}; B2 inheritance ${g.counts.B2}; B3 unbridged ${g.counts.B3}; BU evidence unresolved ${g.counts.BU}; technical ${g.counts.TECH}; correction requested ${g.counts.DISPUTED}; earlier reason unspecified ${g.counts.LEGACY}; awaiting assessment ${g.counts.PENDING}.`,g.included?`Unresolved-case bounds: ${metricPercent(g.lower)} to ${metricPercent(g.upper)}. These are extreme bounds, not a confidence interval.`:'',`${g.pending} reports awaiting source-checked review in this group.`].filter(Boolean)),
 `${m.pendingAnalysis} reports awaiting analysis; ${m.awaitingReview} CB reports awaiting source-checked review. ${m.nonCB} non-CB; ${m.calibration} calibration/examples; ${m.excluded} excluded; ${m.reconciledDuplicates} reconciled duplicate records.`,
 ...m.duplicates.map(g=>`Possible duplicate imports: ${g.map(d=>d.title+' ['+d.id+']').join('; ')}. Affected percentages are withheld.`),
 ...(m.brokenDuplicates.length?[`Duplicate references need repair: ${m.brokenDuplicates.join(', ')}. Percentages withheld.`]:[]),
 'Technical failures and disputed or unclassified records remain visible. Affected percentages are withheld until these records are classifiable. They are never recoded as scientific uncertainty.',
 'The headline includes unresolved assessments in the selected group. Pending reviews are shown separately; they are not coded as absence of inheritance. The resolved-case ratio follows the denominator form of manual v0.5 §12.3; final audit estimates additionally require the frozen corpus, complete coverage and adjudication specified there.',
 'These percentages describe the audited collection. Selective full-text follow-ups are separate from uniform and prespecified reviews. Unspecified selection does not establish a representative sample. No population prevalence or total maturity score is inferred.',
 ];return pilot.length?[...pilot,...(m.rows.some(r=>r.settings.role==='audit'&&!r.document.analysis?.demo)?research:['Main research percentage: this calibration collection is excluded.'])]:research;}
function scopeText(c:Claim){return Object.entries(c.scope).map(([k,v])=>`${k}: ${v}`).join('; ');}
export function publicationMarkdown(d:RecordDoc){
 const p=publicationProfile(d),c=p.central;
 const lines=[`# ${d.title}`,'',`EMP publication profile | ${d.stage} | ${p.protocol} | ${p.fieldScope} fields`, `Review: ${p.workflowLabel}`,`Source coverage: ${d.coverage}`,`Report type: ${p.type||'Not assessed'}`,...reportingNotes(d),''];
 if(!c)return [...lines,p.type==='NC'||p.type==='NMC'?p.typeRationale:'Choose exactly one active central claim to generate the profile.'].join('\n');
 lines.push('## Central claim',c.statement,'','Source quotation:',c.citation.quote,`Passage: ${c.citation.blockId}`,'','## Evidence',c.evidenceSummary,'','## Evidence needed for this claim',c.evidenceRequired,'','## Assessment',`${BRIDGE_LABELS[p.bridge]} (${p.bridge})`,bridgeExplanation(c,p.bridge),c.rationale,...p.issues.map(x=>'Analysis check: '+x),'','## Five-family profile',`Readout: ${c.readout}`,`Scope: ${scopeText(c)}`,'');
 for(const f of FAMILIES)lines.push(`- ${f}: ${c.profile[f]} · ${PROFILE_LABELS[c.profile[f]]}`);
 lines.push('','Codes describe evidence kind and scope. They do not form a quality score. Context does not upgrade this central profile.');
 if(p.context.length){lines.push('','## Contextual claims');for(const x of p.context)lines.push('',x.statement,x.citation.quote,'Evidence: '+x.evidenceSummary,'Required evidence: '+x.evidenceRequired,'Assessment: '+BRIDGE_LABELS[assessmentState(d,x).bridge],x.rationale,`Review: ${d.review.decisions[x.id]?.status||'draft'}`);}
 lines.push('','## Source passages',...c.evidence.map(e=>`${e.blockId}: ${e.quote}`),'','## Provenance',`Document: ${d.id}`,`Source hash: ${d.sourceHash}`,`Revision: ${d.revision}`,`Saved: ${d.updatedAt}`,`Original analysis model: ${d.analysis?.model||'Manual'}`,...(d.review.decisions[c.id]?.correction?[`Correction proposal: ${d.review.decisions[c.id].correction!.model} · ${d.review.decisions[c.id].correction!.createdAt}`]:[]),...d.analysis?.limitations||[]);
 return lines.join('\n');
}
const htmlEscape=(s:unknown)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export function publicationHtml(d:RecordDoc){
 const p=publicationProfile(d),c=p.central,e=htmlEscape;
 const content=c?`<section><h2>Central claim</h2><p class="claim">${e(c.statement)}</p></section><section><h2>What the study shows</h2><p>${e(c.evidenceSummary)}</p><h2>What this claim requires</h2><p>${e(c.evidenceRequired)}</p></section><section><h2>${e(BRIDGE_LABELS[p.bridge])}</h2><p>${e(bridgeExplanation(c,p.bridge))}</p><p>${e(c.rationale)}</p>${p.issues.map(x=>`<p>Analysis check: ${e(x)}</p>`).join('')}</section><section><h2>Five-family evidence profile</h2><p>Readout: ${e(c.readout)}. ${e(c.context)}</p><table><thead><tr><th>Family</th><th>Evidence</th></tr></thead><tbody>${FAMILIES.map(f=>`<tr><td>${e(f)}</td><td>${e(c.profile[f])} · ${e(PROFILE_LABELS[c.profile[f]])}</td></tr>`).join('')}</tbody></table><p class="small">Codes describe kind and scope, not overall quality. No total score is calculated; context does not upgrade the central profile.</p></section>${p.context.length?`<section><h2>Contextual claims</h2>${p.context.map(x=>`<h3>${e(x.statement)}</h3><blockquote>${e(x.citation.quote)}</blockquote><p><b>What the study shows:</b> ${e(x.evidenceSummary)}</p><p><b>What this claim requires:</b> ${e(x.evidenceRequired)}</p><p><b>${e(BRIDGE_LABELS[assessmentState(d,x).bridge])}:</b> ${e(x.rationale)}</p><p class="small">Review: ${e(d.review.decisions[x.id]?.status||'draft')}</p>`).join('')}</section>`:''}<section><h2>Source quotations and scope</h2><blockquote>${e(c.citation.quote)}</blockquote><p class="small">${e(c.citation.blockId)}</p>${c.evidence.map(x=>`<blockquote>${e(x.quote)}</blockquote><p class="small">${e(x.blockId)}</p>`).join('')}<p>${e(scopeText(c))}</p></section>`:`<p>${e(p.selectionIssue?'Choose one active central claim before completing this profile.':p.typeRationale)}</p>`;
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EMP profile · ${e(d.title)}</title><style>@page{size:A4;margin:18mm}body{font:16px/1.55 system-ui,sans-serif;color:#203030;max-width:850px;margin:36px auto;padding:0 22px}h1{font-size:25px;line-height:1.25}h2{font-size:17px;margin:24px 0 8px}h3{font-size:16px}p{white-space:pre-wrap;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:9px;text-align:left;border-bottom:1px solid #ccd3d3}blockquote{border-left:2px solid #647373;padding-left:16px;white-space:pre-wrap;margin:16px 0}.small{font-size:13px;color:#526060}.claim{font-size:19px}section{margin-bottom:20px}tr{break-inside:avoid}h2,h3{break-after:avoid}@media print{body{margin:0;max-width:none;padding:0}}</style></head><body><p class="small">EMP · Publication profile · ${e(d.stage)} · ${e(p.protocol)}</p><h1>${e(d.title)}</h1><p>${e(p.workflowLabel)}</p><p class="small">${e(d.coverage)}</p>${content}<section><h2>Reporting scope and source links</h2>${reportingNotes(d).map(n=>`<p class="small">${e(n)}</p>`).join('')}</section><footer class="small">Report: ${e(d.id)} · Revision ${d.revision}<br>Source hash: ${e(d.sourceHash)}<br>Original analysis model: ${e(d.analysis?.model||'Manual')}${c&&d.review.decisions[c.id]?.correction?`<br>Correction model: ${e(d.review.decisions[c.id].correction!.model)}`:''}<br>${e(d.source.retrieval?.url||d.source.fileName)}<p>${e(d.analysis?.limitations.join('\n')||'')}</p></footer></body></html>`;
}
