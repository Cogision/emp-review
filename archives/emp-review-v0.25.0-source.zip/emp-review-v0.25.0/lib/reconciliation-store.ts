import {AppError} from './app-error';
import type {Reconciliation} from './analysis-reconciliation';
type Env={DB:D1Database;BUCKET:R2Bucket};
export class ReconciliationStore{
 constructor(private env:Env,private owner:string,private documentId:string){}
 async get(id?:string){
  const query=id?'SELECT payload_key FROM analysis_reconciliations WHERE document_id=? AND owner=? AND id=?':'SELECT payload_key FROM analysis_reconciliations WHERE document_id=? AND owner=? ORDER BY created_at DESC LIMIT 1';
  const row=await (id?this.env.DB.prepare(query).bind(this.documentId,this.owner,id):this.env.DB.prepare(query).bind(this.documentId,this.owner)).first<{payload_key:string}>();
  if(!row)return null;const obj=await this.env.BUCKET.get(row.payload_key);if(!obj)throw new AppError('The saved comparison could not be loaded. Try again.',503);return obj.json<Reconciliation>();
 }
 async save(value:Reconciliation,previousRevision?:number){
  const revision=previousRevision===undefined?0:previousRevision+1,next={...value,revision};
  const key=`documents/${this.owner}/${this.documentId}/reconciliations/${value.id}/${crypto.randomUUID()}.json`;
  await this.env.BUCKET.put(key,JSON.stringify(next),{httpMetadata:{contentType:'application/json'}});
  const result=previousRevision===undefined?await this.env.DB.prepare('INSERT INTO analysis_reconciliations (id,document_id,owner,base_revision,revision,payload_key,created_at) SELECT ?,id,owner,?,0,?,? FROM documents WHERE id=? AND owner=? AND revision=?').bind(value.id,value.baseRevision,key,value.createdAt,this.documentId,this.owner,value.baseRevision).run():await this.env.DB.prepare('UPDATE analysis_reconciliations SET payload_key=?,revision=revision+1 WHERE id=? AND document_id=? AND owner=? AND revision=? AND EXISTS (SELECT 1 FROM documents WHERE id=? AND owner=? AND revision=?)').bind(key,value.id,this.documentId,this.owner,previousRevision,this.documentId,this.owner,value.baseRevision).run();
  if(result.meta.changes!==1){await this.env.BUCKET.delete(key);throw new AppError('This report or comparison changed in another tab. Reload the saved comparison.',409);}
  return next;
 }
}
