import {z} from 'zod';

export const stageLinkSchema=z.object({
 documentId:z.string().uuid(),revision:z.number().int().nonnegative(),sourceHash:z.string().min(1).max(100),
 stage:z.enum(['A','B','Excerpt']),claimId:z.string().max(40),statement:z.string().max(5000),scope:z.string().max(50000).optional(),
 linkedAt:z.string().max(40),question:z.string().trim().min(1).max(2000),
 relation:z.enum(['pending','same','changed']),reason:z.string().max(2000),
 comparedClaimId:z.string().max(40).optional(),comparedStatement:z.string().max(5000).optional(),comparedScope:z.string().max(50000).optional(),
});
export const reportingSchema=z.object({
 publicationId:z.string().trim().max(320).default(''),
 role:z.enum(['audit','calibration','excluded']).default('audit'),reason:z.string().trim().max(2000).default(''),
 sourceSelection:z.enum(['unspecified','uniform','prespecified','selective']).default('unspecified'),
 selectionReason:z.string().trim().max(2000).default(''),
 duplicateOf:z.string().uuid().or(z.literal('')).default(''),duplicateReason:z.string().trim().max(2000).default(''),
 extensionReason:z.string().trim().max(2000).default(''),stageLink:stageLinkSchema.optional(),
});
export type Reporting=z.infer<typeof reportingSchema>;
export type StageLink=z.infer<typeof stageLinkSchema>;
export const reportingDefaults=():Reporting=>reportingSchema.parse({});
