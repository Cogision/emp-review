import {currentClaims,type RecordDoc} from './emp';
import {reportingDefaults,type Reporting,type StageLink} from './reporting-schema';
import {AppError} from './app-error';

export const REPORTING_POLICY='EMP-reporting-1.2';
export const SOURCE_SELECTION_LABELS={unspecified:'Selection not recorded',uniform:'Uniform source review',prespecified:'Prespecified subsample',selective:'Selective follow-up'};
export const BASIS_LABELS={reviewed:'Human-checked assessments',adjudicated:'Released adjudications',ai:'Unreviewed AI proposals',manual:'Unreviewed manual drafts'};
export function reportSettings(d:RecordDoc):Reporting{return {...reportingDefaults(),...d.review.reporting};}
export function centralClaim(d:RecordDoc){const c=currentClaims(d).filter(c=>c.primary&&d.review.decisions[c.id]?.status!=='excluded');return c.length===1?c[0]:null;}
export function normalizePublicationId(raw:string){
 const value=raw.trim().toLowerCase().replace(/^https?:\/\/(?:dx\.)?doi\.org\//,'').replace(/^doi:\s*/,'');
 if(/^10\.\d{4,9}\/\S+$/.test(value))return 'doi:'+value.replace(/[.,;]+$/,'');
 const pmid=value.match(/^(?:pmid:\s*|https?:\/\/pubmed\.ncbi\.nlm\.nih\.gov\/)?(\d{1,10})\/?$/);
 if(pmid)return 'pmid:'+pmid[1];
 return value;
}
export function identityKeys(d:RecordDoc){
 const s=reportSettings(d),r=d.source.retrieval;
 const title=d.title.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
 const identifiers=[s.publicationId,r?.doi,r?.pmid?`pmid:${r.pmid}`:''].filter(Boolean).map(v=>normalizePublicationId(v!));
 return [...new Set(identifiers.concat(d.sourceHash?[`hash:${d.sourceHash}`]:[],!identifiers.length&&title.length>=25?[`title:${title}`]:[]))];
}
/** Flag possible same-report imports. Never select a winner by its assessment. */
export function duplicateGroups<T extends RecordDoc>(docs:T[]){
 const remaining=[...docs],groups:T[][]=[];
 while(remaining.length){const group=[remaining.shift()!],keys=new Set(identityKeys(group[0]));let changed=true;
  while(changed){changed=false;for(let i=remaining.length-1;i>=0;i--){const d=remaining[i];if(d.stage!==group[0].stage)continue;const aliases=identityKeys(d);if(aliases.some(k=>keys.has(k))){group.push(d);aliases.forEach(k=>keys.add(k));remaining.splice(i,1);changed=true;}}}
  if(group.length>1)groups.push(group);
 }return groups;
}
export function makeStageLink(parent:RecordDoc,question:string):StageLink{
 const c=centralClaim(parent);if(!c||!parent.analysis)throw new AppError('Select a central claim in the earlier source review first.');
 if(!question.trim())throw new AppError('State the question to check in the additional source.');
 return {documentId:parent.id,revision:parent.revision,sourceHash:parent.sourceHash,stage:parent.stage as StageLink['stage'],claimId:c.id,statement:c.statement,scope:JSON.stringify(c.scope),linkedAt:new Date().toISOString(),question:question.trim(),relation:'pending',reason:''};
}
export function stageComparison(d:RecordDoc){
 const link=reportSettings(d).stageLink,c=centralClaim(d);if(!link)return null;
 const stale=link.relation!=='pending'&&(!c||link.comparedClaimId!==c.id||link.comparedStatement!==c.statement||link.comparedScope!==JSON.stringify(c.scope));
 return {link,status:stale?'pending':link.relation,stale,comparable:!stale&&link.relation==='same'&&!!c};
}
export function validateReporting(s:Reporting,d:RecordDoc){
 if(s.role!=='audit'&&!s.reason.trim())throw new AppError('Give the reason for calibration or exclusion.');
 if(s.sourceSelection!=='unspecified'&&!s.selectionReason.trim())throw new AppError('Describe how this source stage was selected.');
 if(s.duplicateOf===d.id)throw new AppError('A report cannot be its own duplicate.');
 if(s.duplicateOf&&!s.duplicateReason.trim())throw new AppError('Explain why this is a duplicate of the selected report.');
 if(d.analysis?.selection&&currentClaims(d).filter(c=>d.review.decisions[c.id]?.status!=='excluded').length>3&&!(s.extensionReason||d.analysis.selection.extensionReason)?.trim())throw new AppError('Explain why more than three material claims are necessary.');
 if(s.stageLink&&s.stageLink.relation!=='pending'&&!s.stageLink.reason.trim())throw new AppError('Explain whether the central proposition is the same or has changed.');
}
export function reportingNotes(d:RecordDoc){const r=reportSettings(d),pair=stageComparison(d);return [
 `Collection role: ${d.analysis?.demo?'Calibration example':r.role}${r.reason?`. ${r.reason}`:''}`,
 `Source selection: ${SOURCE_SELECTION_LABELS[r.sourceSelection]}${r.selectionReason?`. ${r.selectionReason}`:''}`,
 ...(r.publicationId?[`Publication identifier: ${r.publicationId}`]:[]),
 ...(r.duplicateOf?[`Duplicate of ${r.duplicateOf}: ${r.duplicateReason}`]:[]),
 ...(r.extensionReason||d.analysis?.selection?.extensionReason?[`Additional-claim rationale: ${r.extensionReason||d.analysis?.selection?.extensionReason}`]:[]),
 ...(pair?[`Focused check: ${pair.link.question}`,`Earlier source: ${pair.link.documentId}, ${pair.link.stage}, revision ${pair.link.revision}, hash ${pair.link.sourceHash}`,`Frozen earlier proposition: ${pair.link.statement}`,`Proposition comparison: ${pair.status}. ${pair.link.reason}`,pair.comparable?'Same proposition confirmed; source stages still have separate denominators.':'Do not interpret a class difference as reclassification of the same proposition.','Linked follow-up is not a blinded or independently locked A/B experiment.']:[]),
 ];}
