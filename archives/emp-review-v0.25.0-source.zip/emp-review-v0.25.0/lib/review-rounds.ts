import { z } from 'zod';
import { claimSchema, claimIssues, quoteExists, type Claim, type Source, type Analysis, syncV05, FAMILIES } from './emp';
import { AppError } from './app-error';
import {v05Schema, type V05} from './v05';
export const ROUND_MANUAL='v0.5';
export const v05DraftSchema=v05Schema.deepPartial();
export type V05Draft=z.infer<typeof v05DraftSchema>;
export const CORE_CHOICES=['family','kindMatch','focal','adequacy',...FAMILIES.map(f=>`profile.${f}`),'substitution','role','bridgeClear'];
export function blankV05Draft():V05Draft {
 const fields:Record<string,unknown>={scopeCodes:{},equivalenceCitation:null};
 for(const [key,schema] of Object.entries(v05Schema.shape))if(schema instanceof z.ZodString)fields[key]='';
 return fields as V05Draft;
}
const formMetadataSchema=z.object({language:z.enum(['en','pl']),bibliography:z.string().max(5000),conflict:z.enum(['','none','declared','unclear']),conflictDetails:z.string().max(5000),operatorConfirmed:z.boolean()});
export const roundDraftSchema=z.object({
 reportType:z.enum(['','CB','M','NC','NMC']),typeRationale:z.string().max(5000),summary:z.string().max(10000),
 claims:z.array(claimSchema).max(80),
 decisions:z.record(z.object({status:z.enum(['draft','accepted','unresolved','excluded']),comment:z.string().max(5000),sourceChecked:z.boolean()})),
 coverageChecked:z.boolean(),priorExposure:z.enum(['','yes','no','unsure']),
 fullFields:z.record(v05DraftSchema).optional(),unanswered:z.record(z.array(z.string().max(120)).max(30)).optional(),metadata:formMetadataSchema.optional(),
});
export type RoundDraft=z.infer<typeof roundDraftSchema>;
export type RoundStatus='recruiting'|'collecting'|'revealed'|'adjudicated'|'cancelled';
export type RoundMode='independent'|'assisted';
export type RoundSummary={id:string;title:string;status:RoundStatus;mode:RoundMode;manualVersion:string;sourceHash:string;stage:string;createdAt:string;revision:number;coordinator:boolean;memberStatus:string|null};
export type RoundMember={id:string;name:string;email?:string;status:'pending'|'approved'|'rejected';submittedAt:string|null};
export type RoundSource={documentId?:string;source:Source;title:string;coverage:string;stage:string;sourceHash:string;figures?:import('./figures').FrozenFigure[];versions?:import('./versions').VersionManifest};
export type RoundSubmission={id:string;reviewerId:string;reviewerName:string;submittedAt:string;draft:RoundDraft};
export type Adjudication={id:string;createdAt:string;basedOn:string[];draft:RoundDraft;rationale:string;actorId?:string;actorName?:string;claimRationales?:Record<string,string>;finalizedFromDraftRevision?:number;links:{claimId:string;submissionId:string;originalClaimId:string}[]};
export type AdjudicationDraft=Pick<Adjudication,'draft'|'rationale'|'links'|'basedOn'> & {claimRationales:Record<string,string>;actorId:string;updatedAt:string};
export type RoundInvitation={id:string;expiresAt:string;claimed:boolean;revoked:boolean;recipientEmail:string|null};
export type CreatedRoundInvitation={token:string;expiresAt:string;recipientEmail?:string|null};
export type RoundDetail={round:RoundSummary;who:string;members:RoundMember[];source?:RoundSource;proposal?:Analysis|null;own?:{draft:RoundDraft;revision:number;submittedAt:string|null;submissionId:string|null};adjudicationDraft?:{value:AdjudicationDraft|null;revision:number};submissions?:RoundSubmission[];adjudications?:Adjudication[];events?:{id:string;actor:string;kind:string;createdAt:string;detail:string}[];invites?:RoundInvitation[]};
export function blankRoundDraft(proposal?:Analysis|null,manualVersion='v0.5-core'):RoundDraft {
 const d:RoundDraft={reportType:proposal?.reportType||'',typeRationale:proposal?.typeRationale||'',summary:proposal?.summary||'',claims:structuredClone(proposal?.claims||[]),decisions:{},coverageChecked:false,priorExposure:''};
 if(manualVersion==='v0.5'){
  d.fullFields=Object.fromEntries(d.claims.map(c=>[c.id,c.v05||blankV05Draft()]));d.unanswered={};
  d.metadata={language:proposal?.language||'en',bibliography:'',conflict:'',conflictDetails:'',operatorConfirmed:false};
 }
 return d;
}
// Drafts may be incomplete. Only a complete normative form creates canonical v05 codes.
export function prepareRoundDraft(d:RoundDraft,manualVersion='v0.5-core'):RoundDraft {
 if(manualVersion!=='v0.5')return d;
 const fullFields={...d.fullFields};
 const claims=d.claims.map(c=>{
  const fields=fullFields[c.id]||c.v05||blankV05Draft();fullFields[c.id]=fields;
  const parsed=v05Schema.safeParse(fields),{v05,...core}=c;
  return parsed.success?syncV05({...core,v05:parsed.data}):core;
 });
 return {...d,claims,fullFields};
}
export function submissionIssues(input:RoundDraft,s:Source,manualVersion='v0.5-core'):string[]{
 const d=prepareRoundDraft(input,manualVersion),issues:string[]=[];
 if(manualVersion==='v0.5'){
  if(!d.metadata?.bibliography.trim())issues.push('Complete the bibliographic reference.');
  if(!d.metadata?.conflict)issues.push('Declare any conflicts of interest, or select None declared.');
  if(d.metadata?.conflict&&d.metadata.conflict!=='none'&&!d.metadata.conflictDetails.trim())issues.push('Explain the declared or uncertain conflict of interest.');
  if(!d.metadata?.operatorConfirmed)issues.push('Confirm authorship of the assessment and completion of the source checks.');
 }
 if(!d.reportType)issues.push('Choose the report type.');
 if(!d.typeRationale.trim())issues.push('Explain why you selected this report type.');
 if(!d.coverageChecked)issues.push('Confirm that you checked the source coverage.');
 if(!d.priorExposure)issues.push('State whether you have previously seen AI or other assessments of this article: Yes, No or Not sure.');
 if(new Set(d.claims.map(c=>c.id)).size!==d.claims.length)issues.push('Claim IDs must be unique.');
 const active=d.claims.filter(c=>d.decisions[c.id]?.status!=='excluded');
 if(['NC','NMC'].includes(d.reportType)&&active.length)issues.push('NC/NMC reports must not have active claims. Review the report type or exclude the claims with an explanation.');
 if(['CB','M'].includes(d.reportType)&&(!active.length||active.filter(c=>c.primary).length!==1))issues.push('Select exactly one primary active claim.');
 for(const c of d.claims){const v=d.decisions[c.id];
  if(!v||v.status==='draft'){issues.push(`${c.id}: choose Your decision on this claim: Assessment complete, Unresolved or Excluded from this assessment.`);continue;}
  if(v.status==='excluded'){if(!v.comment.trim())issues.push(`${c.id}: explain why this claim was excluded.`);continue;}
  if(manualVersion==='v0.5'){
   const parsed=v05Schema.safeParse(d.fullFields?.[c.id]);
   if(!parsed.success)issues.push(`${c.id}: complete v0.5 fields: ${parsed.error.issues.map(x=>x.path.join('.')).join(', ')}`);
   if(d.unanswered?.[c.id]?.length)issues.push(`${c.id}: choose codes for: ${d.unanswered[c.id].join(', ')}`);
  }
  if(!v.sourceChecked)issues.push(`${c.id}: check this claim against the frozen source and confirm the source check.`);
  if(!c.statement.trim()||!quoteExists(c.citation,s))issues.push(`${c.id}: provide the claim and an exact quotation from the selected source passage.`);
  if(v.status==='unresolved'&&!v.comment.trim())issues.push(`${c.id}: explain what remains unresolved.`);
  if(manualVersion==='v0.5'&&c.v05?.methodologicalGeneralisation&&d.reportType!=='M')issues.push(`${c.id}: methodological generalisation requires report type M.`);
  if(v.status==='accepted'||manualVersion==='v0.5')for(const m of claimIssues(c,s))issues.push(`${c.id}: ${m}`);
 }
 return issues;
}
export function parseDraft(value:unknown,manualVersion='v0.5-core'):RoundDraft{const p=roundDraftSchema.safeParse(value);if(!p.success)throw new AppError('Invalid assessment fields.',400);return prepareRoundDraft(p.data,manualVersion);}
export function assertSubmission(d:RoundDraft,s:Source,manualVersion='v0.5-core'){const issues=submissionIssues(d,s,manualVersion);if(issues.length)throw new AppError(issues.slice(0,8).join('\n'),422);}
export function safeRound(r:{id:string;title:string;status:string;mode:string;manual_version:string;source_hash:string;stage:string;created_at:string;revision:number;coordinator_id:string},who:string,memberStatus:string|null):RoundSummary{return {id:r.id,title:r.title,status:r.status as RoundStatus,mode:r.mode as RoundMode,manualVersion:r.manual_version,sourceHash:r.source_hash,stage:r.stage,createdAt:r.created_at,revision:r.revision,coordinator:r.coordinator_id===who,memberStatus};}
export function fieldDifferences(a:Claim,b:Claim){return Object.keys(a).filter(k=>k!=='id'&&JSON.stringify(a[k as keyof Claim])!==JSON.stringify(b[k as keyof Claim]));}
