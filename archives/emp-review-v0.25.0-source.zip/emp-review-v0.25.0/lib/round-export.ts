import JSZip from 'jszip';
import {fillForm,formValues} from './form-export';
import {assertSubmission,parseDraft,type RoundSubmission,type Adjudication} from './review-rounds';
import {fieldDifferences} from './review-rounds';
import type {Claim,RecordDoc} from './emp';
import type {RoundStore} from './round-store';
import {figureHash,type FrozenFigure} from './figures';
export type RoundExport=Awaited<ReturnType<RoundStore['export']>>;

export function roundFormValues(data:RoundExport,record:RoundSubmission|Adjudication,c?:Claim){
 const round=data.round,source=data.source!;
 const adjudicated='basedOn' in record,submittedAt=adjudicated?record.createdAt:record.submittedAt;
 const coderId=adjudicated?record.actorId||'Not recorded':record.reviewerId,coderName=adjudicated?record.actorName||coderId:record.reviewerName;
 const d=parseDraft(record.draft,round.manualVersion),m=d.metadata;
 const l=(en:string,_polish:string)=>en;
 const document:RecordDoc={id:source.documentId||round.id,title:source.title,stage:source.stage,coverage:source.coverage,sourceHash:source.sourceHash,createdAt:round.createdAt,updatedAt:submittedAt,revision:0,source:source.source,analysis:null,review:{decisions:Object.fromEntries(d.claims.map(c=>[c.id,{...d.decisions[c.id],...(d.decisions[c.id]?.status==='unresolved'?{concern:'evidence-uncertainty' as const}:{}),claim:c,updatedAt:submittedAt}])),coverageChecked:d.coverageChecked,reportType:d.reportType||null,reportComment:d.typeRationale}};
 const values=formValues({document,state:{language:m?.language||'en',runId:record.id,audit:[],startedAt:submittedAt,model:'Human',version:round.manualVersion,inventory:{reportType:d.reportType||'CB',typeRationale:d.typeRationale,bibliography:m?.bibliography||source.title,complete:d.coverageChecked}}},c);
 const set=(table:number,row:number,value:string)=>{values[`EMP_${table}_${row}_1`]=value;};
 const label=adjudicated?l('Human adjudication','Rozstrzygnięcie przez człowieka'):l('Individual reviewer assessment','Indywidualna ocena recenzenta');
 set(1,1,`Coder_ID: ${coderId}\nCoder_name: ${coderName}\nType: ${round.mode==='assisted'?'Model-assisted':'Human'}\nManual: ${round.manualVersion}\n${label}\nAssessment_ID: ${record.id}`);
 set(1,2,round.mode==='assisted'?`Model_assistance_record_ID: ${round.id}/shared-proposal\n${l('Frozen proposal in round.json; AI provenance in the annex.','Zamrożona propozycja w round.json; pochodzenie AI w aneksie.')}`:'Not applicable · Human assessment from the frozen source');
 set(1,4,`Source_bundle_ID: ${round.id}\nSHA-256: ${source.sourceHash}\n${l('Frozen source snapshot in round.json. Original binary hashes were not recorded.','Zamrożone źródło w round.json. Nie zapisano sum kontrolnych oryginalnych plików binarnych.')}`);
 set(1,5,`${source.coverage}\n${(source.source.files||[{fileName:source.source.fileName,role:'primary'}]).map(f=>`${f.fileName} (${f.role})`).join('\n')}${source.figures?.length?`\n${l('Frozen figures','Zamrożone ryciny')}: ${source.figures.map(f=>`${f.label} (${f.locator||f.fileName})`).join('; ')}\n${l('Image files and hashes: figures/ and round.json.','Pliki obrazów i sumy kontrolne: figures/ oraz round.json.')}`:''}\n${l('Scope: extracted passages in round.json and the listed frozen figures. Source checked by reviewer:','Zakres: odczytane fragmenty w round.json i wymienione zamrożone ryciny. Kontrola źródła przez recenzenta:')} ${d.coverageChecked?'Yes':'No'}\n${source.source.warnings.join('\n')}`);
 set(1,6,`Blind_independent: ${adjudicated||round.mode==='assisted'?'No':d.priorExposure==='no'?'Declared; not independently verified':'No / Uncertain'}\nPrior_exposure: ${d.priorExposure}\nConflict_status: ${m?.conflict||'Not recorded'}\n${m?.conflictDetails||''}\n${adjudicated?l('Submitted assessments were visible during adjudication.','Złożone oceny były widoczne podczas rozstrzygania.'):l('Other submissions hidden until reveal. Prior exposure outside this round is self-reported.','Inne oceny ukryte do ujawnienia. Wcześniejszy kontakt poza rundą jest deklaracją recenzenta.')}`);
 set(13,0,c?`Hedging present: ${c.v05?.hedging}\nConfidence: ${c.v05?.confidence} (${l('coder judgment, not a probability','ocena kodera, nie prawdopodobieństwo')})`:'Structural NA');
 set(13,2,`${label}\nStatus: ${c?d.decisions[c.id]?.status:d.reportType}\n${c?.v05?.notes||''}\n${c?.questions.join('\n')||''}\n${c?d.decisions[c.id]?.comment||'':''}\nCoverage checked: ${d.coverageChecked?'Yes':'No'}\n${l('Code and source checks are structural checks, not validation of scientific correctness.','Kontrola kodów i cytatów nie potwierdza trafności naukowej oceny.')}`);
 set(13,3,`Assessment_ID: ${record.id}\n${adjudicated?'Adjudication_saved':'Submission_locked'}: ${submittedAt}\n${l('Immutable stored assessment. No handwritten signature; timestamp does not establish prospective blinding.','Niezmienna zapisana ocena. Brak podpisu odręcznego; data zapisu nie dowodzi prospektywnego zaślepienia.')}`);
 for(let r=0;r<8;r++)set(19,r,'');
 if(adjudicated){
  const links=c?record.links.filter(x=>x.claimId===c.id):[];
  const originals=links.flatMap(link=>{const s=data.submissions?.find(s=>s.id===link.submissionId),claim=s?.draft.claims.find(c=>c.id===link.originalClaimId);return s&&claim?[{s,claim}]:[];});
  set(19,0,`Adjudication_ID: ${record.id}\nRound_ID: ${round.id}\n${c?`Claim_ID: ${c.id}`:`Report_type: ${d.reportType}`}\nBased_on: ${record.basedOn.join(', ')}`);
  set(19,1,c?[...new Set(originals.flatMap(x=>fieldDifferences(x.claim,c)))].join(', '):'Report-level adjudication');
  set(19,2,c?originals.map(x=>`${x.s.reviewerName} · ${x.s.id}/${x.claim.id}\n${fieldDifferences(x.claim,c).map(k=>`${k}: ${JSON.stringify(x.claim[k as keyof Claim])}`).join('\n')||'No coding differences from final assessment.'}`).join('\n\n'):(data.submissions||[]).map(s=>`${s.reviewerName}: ${s.draft.reportType}; ${s.draft.typeRationale}`).join('\n'));
  set(19,3,c?`${d.decisions[c.id]?.status}\n${[...new Set(originals.flatMap(x=>fieldDifferences(x.claim,c)))].map(k=>`${k}: ${JSON.stringify(c[k as keyof Claim])}`).join('\n')||'Coding unchanged; full final fields above.'}`:`${d.reportType}\n${d.typeRationale}`);
  set(19,4,c?`${c.citation.blockId}: ${c.citation.quote}\n${c.evidence.map(x=>`${x.blockId}: ${x.quote}`).join('\n')}`:source.coverage);
  set(19,5,`${record.rationale}\n${c?record.claimRationales?.[c.id]||'':''}`);
  set(19,6,`${round.manualVersion} · ${l('Manual unchanged; this is a new assessment, not a manual revision.','Manual niezmieniony; jest to nowa ocena, a nie zmiana manuala.')}`);
  set(19,7,`${coderName} (${coderId})\n${submittedAt}\nCoordinator also a reviewer: ${(data.reviewers||[]).some(r=>r.id===coderId)?'Yes':'No'}; third-party independence is not inferred.`);
 }else set(19,0,l('Not adjudicated in this individual submission. See separate adjudication files.','Ta indywidualna ocena nie zawiera rozstrzygnięcia. Rozstrzygnięcia znajdują się w osobnych plikach.'));
 for(let r=0;r<11;r++)set(21,r,l('Not applicable · no AI proposal shown in this independent round.','Nie dotyczy · w tej niezależnej rundzie nie pokazano propozycji AI.'));
 if(round.mode==='assisted'){
  const p=data.sharedAIProposal;
  set(21,0,`Model_assistance_record_ID: ${round.id}/shared-proposal\nRound_ID: ${round.id}\nAssessment_ID: ${record.id}`);
  set(21,1,`Model: ${p?.model||'Not recorded'}\nGenerated_at: ${p?.generatedAt||'Not recorded'}\nPrompt_version: ${p?.promptVersion||'Not recorded'}`);
  for(const r of [2,3,4])set(21,r,l('The original generation request is not part of the round record. Obtain its audit from the original automatic analysis export; no parameters or prompt are inferred.','Oryginalnego żądania generacji nie ma w zapisie rundy. Pobierz audyt z eksportu oryginalnej analizy automatycznej; parametrów ani promptu nie odtwarzano przez zgadywanie.'));
  set(21,5,l('No new AI request is made by this round. Original generation tool settings are not recorded here.','Runda nie wysyła nowego żądania AI. Ustawienia narzędzi oryginalnej generacji nie są tu zapisane.'));
  set(21,6,`Source: round.json → source\nProposal: round.json → sharedAIProposal\nSHA-256: ${round.sourceHash}`);
  set(21,7,`Workbook prefilled: Yes\nShared frozen AI proposal: Yes\nPrior_exposure: ${d.priorExposure}\nOther submissions visible during coding: ${adjudicated?'Yes':'No'}`);
  set(21,8,l('Separate human drafts seeded from one shared AI proposal. This is not independent AI replication.','Osobne szkice ludzi oparte na jednej wspólnej propozycji AI. Nie jest to niezależna replikacja AI.'));
  set(21,9,`Original parsed proposal: round.json → sharedAIProposal\nHuman assessment: ${record.id}\n${l('Human edits are stored separately; raw model output remains in the original analysis audit.','Zmiany człowieka zapisano osobno; surowa odpowiedź modelu pozostaje w audycie oryginalnej analizy.')}`);
 }
 set(21,10,`Operator: ${coderName} (${coderId})\nConfirmation: ${m?.operatorConfirmed?'Yes':'Not recorded'}\nDate: ${submittedAt}\n${l('In-app declaration; no handwritten signature.','Deklaracja w aplikacji; bez podpisu odręcznego.')}`);
 return values;
}

export async function createRoundPackage(data:RoundExport,template:Uint8Array,images:Array<{figure:FrozenFigure;bytes:Uint8Array}>=[]){
 if(data.round.manualVersion!=='v0.5')throw new Error('Legacy core round: use its original JSON export.');
 if(!['revealed','adjudicated'].includes(data.round.status)||!data.source)throw new Error('Reveal the round before exporting.');
 const zip=new JSZip();zip.file('round.json',JSON.stringify(data,null,2));
 for(const figure of data.source.figures||[]){const image=images.find(i=>i.figure.id===figure.id);if(!image||await figureHash(image.bytes)!==figure.imageHash)throw new Error('A frozen figure is missing or its hash does not match. Retry the export.');zip.file(`figures/${figure.id}.${figure.mime==='image/png'?'png':figure.mime==='image/webp'?'webp':'jpg'}`,image.bytes);}
 for(const record of [...data.submissions||[],...data.adjudications||[]]){
  const d=parseDraft(record.draft,'v0.5');assertSubmission(d,data.source.source,'v0.5');
  const recordNote=`Manual v0.5 | ${'basedOn' in record?'Human adjudication':'Human reviewer submission'}. ${data.round.mode==='assisted'?'Shared AI proposal.':'Source-based independent round.'} One form per report, claim and stage. Details of actual checks and declarations follow.`;
  const dir=zip.folder(`${'basedOn' in record?'adjudications':'submissions'}/${record.id}`)!;
  const structural=['NC','NMC'].includes(d.reportType),claims=structural?[]:d.claims.filter(c=>d.decisions[c.id]?.status!=='excluded');
  if(structural)dir.file('EMP_structural_v0_5.docx',await fillForm(template,roundFormValues(data,record),recordNote));
  for(const [index,c] of claims.entries())dir.file(`EMP_${index+1}_v0_5.docx`,await fillForm(template,roundFormValues(data,record,c),recordNote));
 }
 zip.file('README.txt','EMP v0.5 round export. One original normative form per active claim, or a structural NC/NMC form. Individual submissions and adjudications are separate immutable records in round.json. Excluded claims remain in JSON. Adjudication mappings are explicit; no agreement statistic or A/B-stage comparison is inferred. AI-assisted rounds preserve the original parsed proposal; the original raw generation audit is available from the source document automatic export, not reconstructed here.\n');
 return zip.generateAsync({type:'blob',compression:'DEFLATE'});
}
