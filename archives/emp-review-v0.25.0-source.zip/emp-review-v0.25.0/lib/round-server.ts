import {headers} from 'next/headers';
import {ZodError} from 'zod';
import {bindings,owner,failure} from './server';
import {RoundStore} from './round-store';
export async function roundStore(){return new RoundStore(bindings(),await owner(),(await headers()).get('oai-authenticated-user-email')||'');}
export function roundFailure(e:unknown){if(e instanceof ZodError)return Response.json({error:'Check the required fields.'},{status:400});return failure(e);}
