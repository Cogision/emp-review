import { z } from 'zod';
import {normalizeReviewerEmail,recipientEmailSchema} from './reviewer-invitations';
import { AppError } from './app-error';
import {FigureStore} from './figure-store';
import {newManifest} from './versions';
import { type Analysis, type Source } from './emp';
import { ROUND_MANUAL, blankRoundDraft, parseDraft, assertSubmission, safeRound, type RoundDetail, type RoundDraft, type RoundSource, type RoundSubmission, type Adjudication, type AdjudicationDraft } from './review-rounds';
type RoundRow={id:string;coordinator_id:string;title:string;mode:string;status:string;manual_version:string;source_document_id:string;source_hash:string;stage:string;source_key:string;proposal_key:string|null;had_analysis:number;revision:number;created_at:string;updated_at:string};
type MemberRow={round_id:string;user_id:string;name:string;email:string;status:'pending'|'approved'|'rejected';draft_key:string|null;revision:number;submission_id:string|null;submitted_at:string|null;created_at:string};
const nameSchema=z.string().trim().min(1).max(120), idSchema=z.string().min(1).max(120);
const fail=(message:string,status=400):never=>{throw new AppError(message,status);};
const conflict=()=>fail('This round changed. Reload before continuing.',409);
export const nowISO=()=>new Date().toISOString();
export async function tokenHash(token:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(b=>b.toString(16).padStart(2,'0')).join('');}
export class RoundStore{
 constructor(private env:{DB:D1Database;BUCKET:R2Bucket},private who:string,private email=''){if(!who)fail('Sign in.',401);}
 private q(sql:string,...args:unknown[]){return this.env.DB.prepare(sql).bind(...args);}
 private async object<T>(key:string):Promise<T>{const o=await this.env.BUCKET.get(key);if(!o)fail('Round data temporarily unavailable.',503);return o!.json<T>();}
 private async put(key:string,value:unknown){await this.env.BUCKET.put(key,JSON.stringify(value),{httpMetadata:{contentType:'application/json'}});}
 private async round(id:string){const r=await this.q('SELECT * FROM review_rounds WHERE id=?',id).first<RoundRow>();if(!r)fail('Round not found.',404);return r!;}
 private async member(id:string){return this.q('SELECT * FROM round_members WHERE round_id=? AND user_id=?',id,this.who).first<MemberRow>();}
 private async access(id:string){const r=await this.round(id),m=await this.member(id);if(r.coordinator_id!==this.who&&(!m||m.status==='rejected'))fail('Round not found.',404);return {r,m};}
 private coordinator(r:RoundRow,revision:unknown){if(r.coordinator_id!==this.who)fail('Coordinator only.',403);if(!Number.isInteger(revision)||revision!==r.revision)conflict();}
 private eventFromRound(r:RoundRow,event:string,kind:string,detail:unknown,now:string){return this.q('INSERT INTO round_events (id,round_id,actor,kind,detail,created_at) SELECT ?,id,?,?,?,? FROM review_rounds WHERE id=? AND mutation=?',event,this.who,kind,JSON.stringify(detail),now,r.id,event);}
 private async mutate(r:RoundRow,kind:string,detail:unknown,condition:string,args:unknown[],extra:(event:string,now:string)=>D1PreparedStatement[]=()=>[],newStatus=r.status){
  const event=crypto.randomUUID(),now=nowISO();
  const results=await this.env.DB.batch([this.q(`UPDATE review_rounds SET status=?,revision=revision+1,mutation=?,updated_at=? WHERE id=? AND revision=? AND (${condition})`,newStatus,event,now,r.id,r.revision,...args),...extra(event,now),this.eventFromRound(r,event,kind,detail,now)]);
  if(results[0].meta.changes!==1)conflict();
 }
 async list(){const rows=await this.q("SELECT r.*,m.status AS member_status FROM review_rounds r LEFT JOIN round_members m ON m.round_id=r.id AND m.user_id=? WHERE r.coordinator_id=? OR m.status IN ('pending','approved') ORDER BY r.created_at DESC LIMIT 200",this.who,this.who).all<RoundRow&{member_status:string|null}>();return {rounds:rows.results.map(r=>safeRound(r,this.who,r.member_status))};}
 async create(body:unknown){
  const b=z.object({documentId:idSchema,title:nameSchema,mode:z.enum(['independent','assisted'])}).safeParse(body);if(!b.success)fail('Choose a title, source and mode.');
  const v=b.data!,row=await this.q('SELECT * FROM documents WHERE id=? AND owner=?',v.documentId,this.who).first<{title:string;stage:string;coverage:string;source_hash:string;source_key:string;analysis:string|null}>();
  if(!row)fail('Source not found.',404);if(row!.stage!=='B')fail('Rounds currently require a full-text source (stage B).');
  const source=await this.object<Source>(row!.source_key),proposal:Analysis|null=v.mode==='assisted'&&row!.analysis?JSON.parse(row!.analysis):null;
  if(v.mode==='assisted'&&(!proposal||!proposal.model||proposal.model==='Manual'))fail('Run an AI analysis of this document first.');
  if(proposal)parseDraft(blankRoundDraft(proposal));
  const id=crypto.randomUUID(),now=nowISO(),sourceKey=`rounds/${id}/source.json`,proposalKey=proposal?`rounds/${id}/proposal.json`:null;
  const figuresStore=new FigureStore(this.env,this.who),figures=(await figuresStore.list(v.documentId)).filter(f=>!f.archivedAt);
  for(const figure of figures){const {object}=await figuresStore.content(v.documentId,figure.id);await this.env.BUCKET.put(`rounds/${id}/figures/${figure.id}`,await object.arrayBuffer(),{httpMetadata:{contentType:figure.mime}});}
  // Freeze only original images and metadata. Independent rounds never receive AI figure interpretations.
  const frozen:RoundSource={documentId:v.documentId,source,title:row!.title,coverage:row!.coverage,stage:row!.stage,sourceHash:row!.source_hash,figures,versions:newManifest('full')};
  await this.put(sourceKey,frozen);if(proposalKey)await this.put(proposalKey,proposal);
  try{await this.env.DB.batch([
   this.q('INSERT INTO review_rounds (id,coordinator_id,title,mode,status,manual_version,source_document_id,source_hash,stage,source_key,proposal_key,had_analysis,revision,mutation,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)',id,this.who,v.title,v.mode,'recruiting',ROUND_MANUAL,v.documentId,row!.source_hash,'B',sourceKey,proposalKey,row!.analysis?1:0,id,now,now),
   this.q('INSERT INTO round_events (id,round_id,actor,kind,detail,created_at) VALUES (?,?,?,?,?,?)',id,id,this.who,'created',JSON.stringify({mode:v.mode,manualVersion:ROUND_MANUAL,sourceHash:row!.source_hash,sourceDocumentId:v.documentId,proposalModel:proposal?.model||null}),now),
  ]);}catch(e){/* Keep frozen objects if a database response fails with unknown commit outcome. */throw e;}
  return this.detail(id);
 }
 async figure(id:string,figureId:string){const {r,m}=await this.access(id);if(r.coordinator_id!==this.who&&(m?.status!=='approved'||r.status==='recruiting'))fail('Figure not available in this round.',403);const source=await this.object<RoundSource>(r.source_key),figure=source.figures?.find(f=>f.id===figureId);if(!figure)fail('Figure not found in the frozen source.',404);const object=await this.env.BUCKET.get(`rounds/${id}/figures/${figureId}`);if(!object)fail('The frozen image is temporarily unavailable.',503);return {figure:figure!,object:object!};}
 async join(body:unknown){
  const b=z.object({token:z.string().trim().regex(/^[a-f0-9]{64}$/),name:nameSchema}).safeParse(body);if(!b.success)fail('Invalid invitation code or name.');
  const hash=await tokenHash(b.data!.token),invite=await this.q('SELECT * FROM round_invites WHERE token_hash=?',hash).first<{id:string;round_id:string;claimed_by:string|null;revoked_at:string|null;expires_at:string;recipient_email:string|null}>();
  if(!invite)fail('Invitation is unavailable or expired.',404);
  const authenticatedEmail=normalizeReviewerEmail(this.email);
  if(invite!.recipient_email&&invite!.recipient_email!==authenticatedEmail)fail('Sign in with the email address this invitation was created for. This attempt did not use the code.',403);
  if(invite!.claimed_by===this.who){const m=await this.member(invite!.round_id);if(m&&m.status!=='rejected')return {id:invite!.round_id};}
  const event=crypto.randomUUID(),now=nowISO();
  const result=await this.env.DB.batch([
   this.q("UPDATE round_invites SET claimed_by=?,claim_id=? WHERE id=? AND claimed_by IS NULL AND revoked_at IS NULL AND expires_at>? AND EXISTS(SELECT 1 FROM review_rounds WHERE id=round_id AND status='recruiting') AND (recipient_email IS NULL OR recipient_email=?) AND NOT EXISTS(SELECT 1 FROM round_members WHERE round_id=round_invites.round_id AND user_id=? AND status!='rejected')",this.who,event,invite!.id,now,authenticatedEmail,this.who),
   this.q("INSERT INTO round_members (round_id,user_id,name,email,status,revision,created_at) SELECT round_id,?,?,?,'pending',0,? FROM round_invites WHERE id=? AND claim_id=? ON CONFLICT(round_id,user_id) DO UPDATE SET name=excluded.name,email=excluded.email,status='pending',created_at=excluded.created_at WHERE round_members.status='rejected'",this.who,b.data!.name,this.email,now,invite!.id,event),
   this.q('INSERT INTO round_events (id,round_id,actor,kind,detail,created_at) SELECT ?,round_id,?,?,?,? FROM round_invites WHERE id=? AND claim_id=?',event,this.who,'join_requested','{}',now,invite!.id,event),
   this.q('UPDATE review_rounds SET revision=revision+1,updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM round_invites WHERE id=? AND claim_id=?)',now,invite!.round_id,invite!.id,event),
  ]);if(result[0].meta.changes!==1)fail('Invitation unavailable, expired, or already used.',409);return {id:invite!.round_id};
 }
 async detail(id:string):Promise<RoundDetail>{
  const {r,m}=await this.access(id),coordinator=r.coordinator_id===this.who,released=['revealed','adjudicated'].includes(r.status);
  const out:RoundDetail={round:safeRound(r,this.who,m?.status||null),who:this.who,members:[]};
  if(m?.status==='pending'&&!coordinator){out.members=[{id:m.user_id,name:m.name,status:m.status,submittedAt:null}];return out;}
  const members=(await this.q('SELECT * FROM round_members WHERE round_id=? ORDER BY created_at,user_id',id).all<MemberRow>()).results;
  out.members=members.filter(x=>coordinator||x.status==='approved').map(x=>({id:x.user_id,name:x.name,status:x.status,submittedAt:x.submitted_at,...(coordinator?{email:x.email}:{})}));
  if(coordinator||r.status!=='recruiting')out.source=await this.object<RoundSource>(r.source_key);
  if(r.mode==='assisted'&&r.status!=='recruiting'&&r.proposal_key)out.proposal=await this.object<Analysis>(r.proposal_key);
  if(m?.status==='approved'&&r.status!=='recruiting')out.own={draft:m.draft_key?await this.object<RoundDraft>(m.draft_key):blankRoundDraft(out.proposal,r.manual_version),revision:m.revision,submittedAt:m.submitted_at,submissionId:m.submission_id};
  // No other assessment object is read at all until the round is revealed.
  if(released){out.submissions=[];for(const x of members.filter(x=>x.status==='approved'&&x.submitted_at&&x.draft_key&&x.submission_id))out.submissions.push({id:x.submission_id!,reviewerId:x.user_id,reviewerName:x.name,submittedAt:x.submitted_at!,draft:await this.object<RoundDraft>(x.draft_key!)});
   out.adjudications=[];const adj=(await this.q('SELECT * FROM round_adjudications WHERE round_id=? ORDER BY created_at,id',id).all<{snapshot_key:string}>()).results;for(const a of adj)out.adjudications.push(await this.object<Adjudication>(a.snapshot_key));
  }
  if(coordinator&&released){const state=await this.adjudicationDraftState(id);out.adjudicationDraft={revision:state.revision,value:state.snapshot_key?await this.object<AdjudicationDraft>(state.snapshot_key):null};}
  if(coordinator||released){out.events=(await this.q('SELECT id,actor,kind,detail,created_at AS createdAt FROM round_events WHERE round_id=? ORDER BY created_at,id',id).all<{id:string;actor:string;kind:string;detail:string;createdAt:string}>()).results;}
  if(coordinator)out.invites=(await this.q('SELECT id,expires_at AS expiresAt,claimed_by,revoked_at,recipient_email FROM round_invites WHERE round_id=? ORDER BY created_at DESC',id).all<{id:string;expiresAt:string;claimed_by:string|null;revoked_at:string|null;recipient_email:string|null}>()).results.map(i=>({id:i.id,expiresAt:i.expiresAt,claimed:!!i.claimed_by,revoked:!!i.revoked_at,recipientEmail:i.recipient_email}));
  return out;
 }
 async action(id:string,body:unknown):Promise<RoundDetail|import('./review-rounds').CreatedRoundInvitation>{
  const base=z.object({action:z.string().max(40)}).passthrough().safeParse(body);if(!base.success)fail('Invalid action.');
  const b=base.data!,{r,m}=await this.access(id);
  if(b.action==='save'||b.action==='submit'){await this.saveAssessment(r,m,b);return this.detail(id);}
  this.coordinator(r,b.revision);
  if(b.action==='invite'){
   const recipientEmail=b.recipientEmail===undefined?null:recipientEmailSchema.parse(b.recipientEmail);
   if(recipientEmail){
    const existing=await this.q("SELECT 1 AS found FROM round_invites WHERE round_id=? AND recipient_email=? AND claimed_by IS NULL AND revoked_at IS NULL AND expires_at>? UNION ALL SELECT 1 FROM round_members WHERE round_id=? AND lower(trim(email))=? AND status IN ('pending','approved') LIMIT 1",id,recipientEmail,nowISO(),id,recipientEmail).first();
    if(existing)fail('This reviewer already has an active invitation or membership. Revoke the unused invitation before creating another.',409);
   }
   const token=(crypto.randomUUID()+crypto.randomUUID()).replaceAll('-',''),hash=await tokenHash(token),inviteId=crypto.randomUUID(),expiresAt=new Date(Date.now()+7*86400000).toISOString();
   await this.mutate(r,'invitation_created',{inviteId,expiresAt},"status='recruiting'",[],(event,now)=>[this.q('INSERT INTO round_invites (id,round_id,token_hash,expires_at,created_at,recipient_email) SELECT ?,id,?,?,?,? FROM review_rounds WHERE id=? AND mutation=?',inviteId,hash,expiresAt,now,recipientEmail,id,event)]);return {token,expiresAt,recipientEmail};
  }
  if(b.action==='revokeInvite'){
   const inviteId=idSchema.parse(b.inviteId);await this.mutate(r,'invitation_revoked',{inviteId},"status='recruiting' AND EXISTS(SELECT 1 FROM round_invites WHERE id=? AND round_id=review_rounds.id AND revoked_at IS NULL AND claimed_by IS NULL)",[inviteId],(event,now)=>[this.q('UPDATE round_invites SET revoked_at=? WHERE id=? AND round_id=? AND EXISTS(SELECT 1 FROM review_rounds WHERE id=? AND mutation=?)',now,inviteId,id,id,event)]);
  }else if(b.action==='approve'||b.action==='reject'){
   const memberId=idSchema.parse(b.memberId),status=b.action==='approve'?'approved':'rejected';await this.mutate(r,b.action,{memberId},"status='recruiting' AND EXISTS(SELECT 1 FROM round_members WHERE round_id=review_rounds.id AND user_id=? AND status IN ('pending','approved'))",[memberId],event=>[this.q('UPDATE round_members SET status=? WHERE round_id=? AND user_id=? AND EXISTS(SELECT 1 FROM review_rounds WHERE id=? AND mutation=?)',status,id,memberId,id,event)]);
  }else if(b.action==='joinSelf'){
   const name=nameSchema.parse(b.name);await this.mutate(r,'coordinator_joined',{priorExposureRequired:r.had_analysis===1},"status='recruiting' AND NOT EXISTS(SELECT 1 FROM round_members WHERE round_id=review_rounds.id AND user_id=?)",[this.who],(event,now)=>[this.q("INSERT INTO round_members (round_id,user_id,name,email,status,revision,created_at) SELECT id,?,?,?,'approved',0,? FROM review_rounds WHERE id=? AND mutation=?",this.who,name,this.email,now,id,event)]);
  }else if(b.action==='start'){
   await this.mutate(r,'started',{},"status='recruiting' AND (SELECT COUNT(*) FROM round_members WHERE round_id=review_rounds.id AND status='approved')>=2 AND NOT EXISTS(SELECT 1 FROM round_members WHERE round_id=review_rounds.id AND status='pending')",[],()=>[],'collecting');
  }else if(b.action==='reveal'){
   await this.mutate(r,'revealed',{},"status='collecting' AND (SELECT COUNT(*) FROM round_members WHERE round_id=review_rounds.id AND status='approved')>=2 AND NOT EXISTS(SELECT 1 FROM round_members WHERE round_id=review_rounds.id AND status='approved' AND submitted_at IS NULL)",[],()=>[],'revealed');
  }else if(b.action==='cancel'){
   const reason=z.string().trim().min(5).max(5000).parse(b.reason);await this.mutate(r,'cancelled',{reason},"status IN ('recruiting','collecting')",[],()=>[],'cancelled');
  }else if(b.action==='saveAdjudicationDraft'||b.action==='discardAdjudicationDraft'){
   await this.saveAdjudicationDraft(r,b);
  }else if(b.action==='adjudicate'){
   await this.adjudicate(r,b);
  }else fail('Unknown action.');
  return this.detail(id);
 }
 private async saveAssessment(r:RoundRow,m:MemberRow|null,b:Record<string,unknown>){
  if(!m||m.status!=='approved')fail('Approved reviewers only.',403);
  if(r.status!=='collecting'||m!.submitted_at)fail('The assessment is locked.',409);
  if(!Number.isInteger(b.assessmentRevision)||b.assessmentRevision!==m!.revision)conflict();
  const draft=parseDraft(b.draft,r.manual_version),submit=b.action==='submit',source=await this.object<RoundSource>(r.source_key);
  if(submit){assertSubmission(draft,source.source,r.manual_version);if(r.coordinator_id===this.who&&r.had_analysis&&draft.priorExposure==='no')fail('The source already had an assessment in your workspace. Declare prior exposure or uncertainty.',422);}
  const event=crypto.randomUUID(),now=nowISO(),key=`rounds/${r.id}/assessments/${event}.json`;
  await this.put(key,draft);
  try{const result=await this.env.DB.batch([
   this.q("UPDATE round_members SET draft_key=?,revision=revision+1,submission_id=?,submitted_at=? WHERE round_id=? AND user_id=? AND revision=? AND status='approved' AND submitted_at IS NULL AND EXISTS(SELECT 1 FROM review_rounds WHERE id=? AND status='collecting')",key,submit?event:null,submit?now:null,r.id,this.who,m!.revision,r.id),
   this.q('INSERT INTO round_events (id,round_id,actor,kind,detail,created_at) SELECT ?,round_id,?,?,?,? FROM round_members WHERE round_id=? AND user_id=? AND draft_key=?',event,this.who,submit?'submitted':'draft_saved',JSON.stringify({revision:m!.revision+1,priorExposure:submit?draft.priorExposure:undefined,sharedAI:r.mode==='assisted'}),now,r.id,this.who,key),
  ]);if(result[0].meta.changes!==1){await this.env.BUCKET.delete(key);conflict();}}catch(e){/* Objects are immutable; a failed commit may leave an unreferenced object, never delete a committed snapshot. */throw e;}
 }
 private async adjudicationDraftState(id:string){return await this.q('SELECT snapshot_key,revision FROM round_adjudication_drafts WHERE round_id=?',id).first<{snapshot_key:string|null;revision:number}>()||{snapshot_key:null,revision:0};}
 private async checkAdjudicationDraft(r:RoundRow,b:Record<string,unknown>){const state=await this.adjudicationDraftState(r.id);if((b.draftRevision??0)!==state.revision)conflict();return state;}
 private draftWrite(r:RoundRow,event:string,now:string,key:string|null,revision:number){return this.q('INSERT INTO round_adjudication_drafts (round_id,snapshot_key,revision,updated_at) SELECT id,?,?,? FROM review_rounds WHERE id=? AND mutation=? ON CONFLICT(round_id) DO UPDATE SET snapshot_key=excluded.snapshot_key,revision=excluded.revision,updated_at=excluded.updated_at',key,revision,now,r.id,event);}
 private async saveAdjudicationDraft(r:RoundRow,b:Record<string,unknown>){
  if(!['revealed','adjudicated'].includes(r.status))fail('Reveal the round first.',409);
  const state=await this.checkAdjudicationDraft(r,b),discard=b.action==='discardAdjudicationDraft';let key:string|null=null;
  if(!discard){
   const draft=parseDraft(b.draft,r.manual_version),rationale=z.string().max(10000).parse(b.rationale),links=z.array(z.object({claimId:idSchema,submissionId:idSchema,originalClaimId:idSchema})).max(640).parse(b.links),claimRationales=z.record(z.string().max(5000)).parse(b.claimRationales||{}),detail=await this.detail(r.id);
   for(const l of links)if(!draft.claims.some(c=>c.id===l.claimId)||!detail.submissions!.some(s=>s.id===l.submissionId&&s.draft.claims.some(c=>c.id===l.originalClaimId)))fail('Invalid mapping to original claims.');
   const value:AdjudicationDraft={draft,rationale,links,claimRationales,basedOn:detail.submissions!.map(s=>s.id),actorId:this.who,updatedAt:nowISO()};key=`rounds/${r.id}/adjudication-drafts/${crypto.randomUUID()}.json`;await this.put(key,value);
  }
  await this.mutate(r,discard?'adjudication_draft_discarded':'adjudication_draft_saved',{draftRevision:state.revision+1},"status IN ('revealed','adjudicated') AND COALESCE((SELECT revision FROM round_adjudication_drafts WHERE round_id=review_rounds.id),0)=?",[state.revision],(event,now)=>[this.draftWrite(r,event,now,key,state.revision+1)]);
 }
 private async adjudicate(r:RoundRow,b:Record<string,unknown>){
  if(!['revealed','adjudicated'].includes(r.status))fail('Reveal the round first.',409);
  const draftState=await this.checkAdjudicationDraft(r,b);
  const rationale=z.string().trim().min(10).max(10000).parse(b.rationale),draft=parseDraft(b.draft,r.manual_version),detail=await this.detail(r.id);assertSubmission(draft,detail.source!.source,r.manual_version);
  const links=z.array(z.object({claimId:idSchema,submissionId:idSchema,originalClaimId:idSchema})).max(640).parse(b.links);
  const submissions=detail.submissions!;
  for(const l of links)if(!draft.claims.some(c=>c.id===l.claimId)||!submissions.some(s=>s.id===l.submissionId&&s.draft.claims.some(c=>c.id===l.originalClaimId)))fail('Invalid mapping to original claims.');
  for(const c of draft.claims)if(!links.some(l=>l.claimId===c.id))fail(`${c.id}: link to at least one original claim.`);
  const claimRationales=z.record(z.string().trim().max(5000)).parse(b.claimRationales||{});
  if(r.manual_version==='v0.5')for(const c of draft.claims)if(!claimRationales[c.id]?.trim())fail(`${c.id}: explain the agreed assessment.`,422);
  const actorName=detail.members.find(m=>m.id===this.who)?.name||this.who;
  const id=crypto.randomUUID(),createdAt=nowISO(),key=`rounds/${r.id}/adjudications/${id}.json`,value:Adjudication={id,createdAt,basedOn:submissions.map(s=>s.id),draft,rationale,links,actorId:this.who,actorName,claimRationales,...(draftState.snapshot_key?{finalizedFromDraftRevision:draftState.revision}:{})};await this.put(key,value);
  await this.mutate(r,'adjudicated',{id,basedOn:value.basedOn},"status IN ('revealed','adjudicated') AND COALESCE((SELECT revision FROM round_adjudication_drafts WHERE round_id=review_rounds.id),0)=?",[draftState.revision],(event,now)=>[this.q('INSERT INTO round_adjudications (id,round_id,snapshot_key,created_at) SELECT ?,id,?,? FROM review_rounds WHERE id=? AND mutation=?',id,key,now,r.id,event),this.draftWrite(r,event,now,null,draftState.revision+1)],'adjudicated');
 }
 async export(id:string){const d=await this.detail(id);if(!['revealed','adjudicated'].includes(d.round.status))fail('Export of all assessments becomes available after reveal.',403);return {format:'EMP-collaborative-round-0.9.0',scope:d.round.manualVersion==='v0.5'?'Full EMP v0.5. Immutable individual assessments and separate adjudications.':'Legacy EMP v0.5 core; not upgraded or relabelled.',exportedAt:nowISO(),round:d.round,source:d.source,sharedAIProposal:d.proposal||null,reviewers:d.members.map(({email,...rest})=>rest),submissions:d.submissions,adjudications:d.adjudications,events:d.events};}
}
