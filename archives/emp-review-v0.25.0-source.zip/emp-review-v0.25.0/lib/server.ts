import {tr} from "./i18n";
import { env } from "cloudflare:workers";
import { headers } from "next/headers";
import { type RecordDoc, type Source, type Analysis, type Review } from "./emp";
import {newManifest,legacyManifest,codingScope,type VersionManifest} from './versions';
import { AppError } from "./app-error";
export { AppError } from "./app-error";
type BindingEnv={DB:D1Database;BUCKET:R2Bucket;OPENAI_API_KEY?:string;OPENAI_MODEL?:string};
export function bindings(){return env as unknown as BindingEnv;}
export function db(){const b=bindings().DB;if(!b)throw new Error("Zapis jest chwilowo niedostępny.");return b;}
export async function owner(){const h=await headers();const id=h.get("oai-authenticated-user-id");if(!id)throw new AppError("Zaloguj się, aby otworzyć swój obszar pracy.",401);return id;}
export function sameOrigin(req:Request){const origin=req.headers.get("origin");if(origin&&origin!==new URL(req.url).origin)throw new AppError("Niedozwolone źródło żądania.",403);}
export function failure(e:unknown){if(e instanceof AppError)return Response.json({error:tr(e.message)},{status:e.status});console.error("EMP request failed",e instanceof Error?e.name:"Unknown");return Response.json({error:"Could not complete the operation. Your current input is still on screen. Please try again."},{status:503});}
export async function jsonBody(req:Request,max=250000){const raw=await req.text();if(raw.length>max)throw new AppError("Żądanie jest zbyt duże.",413);try{return JSON.parse(raw);}catch{throw new AppError("Nieprawidłowe dane wejściowe.");}}
export type Row={id:string;owner:string;title:string;stage:string;coverage:string;source_key:string;source_hash:string;version_manifest?:string|null;analysis:string|null;review:string;revision:number;created_at:string;updated_at:string};
export async function rowFor(id:string,who:string){const row=await db().prepare("SELECT * FROM documents WHERE id=? AND owner=?").bind(id,who).first<Row>();if(!row)throw new AppError("Nie znaleziono dokumentu.",404);return row;}
export async function sourceFor(row:Row){const obj=await bindings().BUCKET.get(row.source_key);if(!obj)throw new AppError("Nie udało się odczytać tekstu źródłowego.",503);return obj.json<Source>();}
export async function fullDoc(row:Row):Promise<RecordDoc>{const analysis:Analysis|null=row.analysis?JSON.parse(row.analysis):null,review:Review=JSON.parse(row.review);return {id:row.id,title:row.title,stage:row.stage,coverage:row.coverage,sourceHash:row.source_hash,createdAt:row.created_at,updatedAt:row.updated_at,revision:row.revision,analysis,review,source:await sourceFor(row),versions:row.version_manifest?JSON.parse(row.version_manifest):legacyManifest(analysis,review)};}
export async function updateDoc(row:Row,analysis:Analysis|null,review:Review,kind:string,payload:unknown){
 const event=crypto.randomUUID(),now=new Date().toISOString(),versions:VersionManifest=newManifest(codingScope(analysis,review));
 const snapshotKey=`${row.source_key.replace(/text.json$/,"")}assessments/${event}.json`;
 if(analysis)await bindings().BUCKET.put(snapshotKey,JSON.stringify({version:"EMP-assessment-snapshot-0.10.0",versions,documentId:row.id,revision:row.revision+1,sourceHash:row.source_hash,stage:row.stage,analysis,review,kind,createdAt:now}),{httpMetadata:{contentType:"application/json"}});
 const results=await db().batch([
  db().prepare("UPDATE documents SET analysis=?,review=?,version_manifest=?,revision=revision+1,mutation=?,updated_at=? WHERE id=? AND owner=? AND revision=?").bind(analysis?JSON.stringify(analysis):null,JSON.stringify(review),JSON.stringify(versions),event,now,row.id,row.owner,row.revision),
  db().prepare("INSERT INTO events (id,document_id,owner,revision,kind,payload,created_at) SELECT ?,id,owner,revision,?,?,? FROM documents WHERE id=? AND owner=? AND mutation=?").bind(event,kind,JSON.stringify(payload),now,row.id,row.owner,event),
  ...(analysis?[db().prepare("INSERT INTO assessment_runs (id,document_id,owner,actor_type,actor_id,model,manual_version,source_hash,stage,revision,snapshot_key,created_at) SELECT ?,id,owner,?,?,?,?,source_hash,stage,revision,?,? FROM documents WHERE id=? AND owner=? AND mutation=?").bind(event,["review","reporting"].includes(kind)?"human":"ai",["review","reporting"].includes(kind)?row.owner:analysis.model||"unspecified",analysis.model||null,versions.scope==="full"?"v0.5":"v0.5-core",snapshotKey,now,row.id,row.owner,event)]:[])
 ]);
 if(results[0].meta.changes!==1){if(analysis)await bindings().BUCKET.delete(snapshotKey);throw new AppError("Dokument zmienił się w innej karcie. Otwórz go ponownie przed zapisaniem.",409);}
 return fullDoc(await rowFor(row.id,row.owner));
}
