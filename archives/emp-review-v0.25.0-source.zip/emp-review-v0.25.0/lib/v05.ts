import { z } from "zod";
export const SCOPE_KEYS = ["readout","population","setting","treatment","comparator","outcome","horizon","inferenceUnit","decisionRule"] as const;
export const SCOPE_LABELS:Record<typeof SCOPE_KEYS[number],string>={readout:'Readout extent',population:'Population',setting:'Setting / centres',treatment:'Treatment',comparator:'Comparator',outcome:'Outcome',horizon:'Time horizon',inferenceUnit:'Unit of inference',decisionRule:'Decision rule / care pathway'};
const note=z.string().max(5000);
const match=z.enum(["E","N","X","U","NA"]);
export const v05Schema=z.object({
 location:z.enum(["Title","Abstract results","Abstract conclusion","Full-text results","Discussion","Conclusions","Limitations","Other"]),
 selectionBasis:z.enum(["Explicit primary/take-home conclusion","Formal conclusion/discussion synthesis","Final abstract conclusion","Title proposition","Other foregrounded claim"]),
 commitment:z.enum(["Asserted","Hedged-current","Conditional-future","Mixed"]),polarity:z.enum(["Positive","Negative","Mixed"]),
 declaredUse:z.enum(["U0","U1","U2","U3","U4","U5","U6","U7","U8","U9","UX"]),usePredicate:note,
 methodologicalGeneralisation:z.boolean(),generalisationTarget:note,
 readoutRelation:z.enum(["R0","R1","R2","R3","R4","RNA"]),equivalenceEvidence:note,equivalenceCitation:z.object({blockId:z.string().max(40),quote:z.string().max(2500)}).nullable(),impliedElements:note,
 scopeCodes:z.object({readout:match,population:match,setting:match,treatment:match,comparator:match,outcome:match,horizon:match,inferenceUnit:match,decisionRule:match}),
 evidenceTiming:z.enum(["Prospective","Retrospective","Ambispective","Not stated","Not applicable"]),
 observationMode:z.enum(["Directly observed","Offline-modelled","Simulation","Derived surrogate","Unclear","Not applicable"]),
 evidenceLocation:z.enum(["Report main text","Report supplement","Registered protocol or analysis plan supplied in the bundle","Programme or external report","Multiple report locations; specify","Unclear","Not applicable"]),evidenceLocationDetail:note,
 warrantClaim:note,warrantFamily:z.enum(["Measurement reliability","Operational specificity","Clinical and functional relevance","Response to perturbation","Decision relevance","Unclear","Not applicable"]),
 adequacyRationale:note,condition:z.enum(["NC0","NC1","NC2","NC3","NCU"]),coupling:z.enum(["FC","DC","BG","U","NA"]),conditionMatches:z.enum(["Yes","No","Unclear","Structural NA"]),
 substitutionDetail:note,bridgeFrom:note,bridgeTo:note,hedging:z.enum(["Yes","No","Unclear"]),confidence:z.enum(["High","Medium","Low"]),notes:note,
});
export type V05=z.infer<typeof v05Schema>;
export const v05Example:V05={location:"Other",selectionBasis:"Other foregrounded claim",commitment:"Asserted",polarity:"Positive",declaredUse:"UX",usePredicate:"",methodologicalGeneralisation:false,generalisationTarget:"",readoutRelation:"R4",equivalenceEvidence:"",equivalenceCitation:null,impliedElements:"",scopeCodes:{readout:"U",population:"U",setting:"U",treatment:"U",comparator:"U",outcome:"U",horizon:"U",inferenceUnit:"U",decisionRule:"U"},evidenceTiming:"Not stated",observationMode:"Unclear",evidenceLocation:"Unclear",evidenceLocationDetail:"",warrantClaim:"",warrantFamily:"Unclear",adequacyRationale:"",condition:"NCU",coupling:"U",conditionMatches:"Unclear",substitutionDetail:"",bridgeFrom:"",bridgeTo:"",hedging:"Unclear",confidence:"Low",notes:""};
