import type {Analysis,Review} from './emp';
export const APP_VERSION='0.25.0';
export const MANUAL_VERSION='v0.5';
export const FORM_VERSION='v0.5';
export type VersionManifest={appVersion:string|null;manualVersion:string;formVersion:string|null;scope:'core'|'full';schemaVersion:string|null;recorded:boolean};
export const MANUAL_RELEASES=[{version:MANUAL_VERSION,available:true,description:'EMP v0.5: the current normative manual. Core and full forms use the same manual; their field coverage differs.'}] as const;
export function codingScope(analysis:Analysis|null,review?:Review):'core'|'full'{
 if(!analysis)return 'core';
 const initial=analysis.claims||[],claims=[...initial.map(c=>review?.decisions[c.id]?.claim||c),...Object.values(review?.decisions||{}).filter(d=>!initial.some(c=>c.id===d.claim.id)).map(d=>d.claim)];
 return claims.length?claims.every(c=>!!c.v05)?'full':'core':analysis.automatic?'full':'core';
}
export function newManifest(scope:'core'|'full'):VersionManifest{return {appVersion:APP_VERSION,manualVersion:MANUAL_VERSION,formVersion:scope==='full'?FORM_VERSION:null,scope,schemaVersion:scope==='full'?'EMP-full-v0.5':'EMP-core-v0.5',recorded:true};}
/** Absence of metadata is not evidence that an old result used today's application. */
export function legacyManifest(analysis:Analysis|null,review?:Review):VersionManifest{const scope=codingScope(analysis,review);return {appVersion:null,manualVersion:MANUAL_VERSION,formVersion:scope==='full'?FORM_VERSION:null,scope,schemaVersion:null,recorded:false};}
export function requireManual(version:string){if(!MANUAL_RELEASES.some(r=>r.version===version&&r.available))throw new Error('This manual version is not defined. Existing assessments retain their original version.');return version;}
