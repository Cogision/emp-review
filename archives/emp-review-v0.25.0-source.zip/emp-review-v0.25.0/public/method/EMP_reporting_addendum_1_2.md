# EMP: reporting and focal-workflow addendum 1.1

5 September 2026 | Application 0.19 | Coding manual and full form v0.5

This addendum defines the application's focal selection and descriptive reporting. It does not change the five-family codes, bridge algorithm, or the criterion-referenced primary validation endpoint of manual v0.5. Earlier assessments retain their original selection protocol.

## One publication, one central claim

Select the authorial proposition answering the main objective. Use the explicit take-home passage and the manual's earliest-occurrence tie-breaker. Selection happens before evidence assessment. Do not select for anticipated EI, clinical appeal or gap severity. Preserve separate material predicates.

Normally select one central and zero to two contextual claims. More than three claims require a recorded explanation of the material distinction that would be lost. Additional claims never increase the primary-report denominator. The new selection protocol is focal-v2; existing focal-v1 and earlier/comprehensive selections are separate strata.

## Minimum record and short report

For every selected claim retain its exact quotation and source location, a scope-preserving paraphrase, selection rationale, the evidence actually found, the direct evidence required, the applicable readout and scope, the five-family profile, focal support, the role of substituted evidence, the bridge/class, and an explanation. Source coverage, missing materials, review status and provenance remain visible.

The short report answers four questions: what is claimed; what the study shows; what evidence that claim requires; and the assessment with reasons. Contextual claims answer the same questions when expanded or exported. An absent result in an abstract is not proof of absence from the full study. EI requires identifiable substituted evidence used as a warrant; a gap alone is insufficient.

The current focal workflow reduces the number of selected claims and the default display. Each selected claim still uses the full v0.5 coding fields. It is not a separately validated abbreviated coding instrument. No improvement in validity, agreement or reviewer workload is asserted before prospective evaluation.

## Descriptive percentages

For one displayed group let E be the count of B2 (EI), U the count of BU (unresolved), and R the sum of B0, B1, B2 and B3. Let N = R + U.

- Headline descriptive share: E / N. The label and report state that unresolved assessments are included.
- Resolved-case share: E / R. This uses the denominator form in manual v0.5 section 12.3.
- Full distribution: B0 supported, B1 open, B2 EI, B3 unbridged assertion, BU unresolved. Report counts, not just percentages.
- Extreme unresolved-case bounds: E / N to (E + U) / N. These are sensitivity bounds, not confidence intervals.
- If a denominator is zero, show "Not estimated", never 0%.

Reports awaiting analysis and CB reports awaiting source-checked review are reported separately. They are not silently classified as non-EI. A headline for checked assessments describes that checked subset; it is not the result for all registered eligible reports. The app shows incomplete review coverage.

The headline prominence of a descriptive EI share does not replace the primary validation endpoint. A final manual-v0.5 audit estimate additionally requires an independently specified corpus, complete report dispositions, final Stage-B adjudications and the quality/coverage gates in section 12.3. The app's descriptive dashboard alone does not establish those conditions.

## Separate groups and exclusions

Never pool source stages (abstract, full text, excerpts), selection protocols, field coverage, or source-selection methods. Source selection is recorded as uniform, prespecified subsample, selective follow-up, or unspecified. State the rule and reason. Selectively deepened reports do not replace the other reports' abstract assessments in a single percentage.

Unreviewed AI proposals, unreviewed manual drafts, human-checked assessments and released adjudications form separate groups. "Human checked" means the assessment and source have been checked; it does not mean the authors' claim is supported. Adjudication is not interchangeable with an individual check.

Only CB reports contribute to the clinical-use EI denominator. M, NMC and NC reports remain in the inventory and supplementary analyses. Calibration examples and explicitly excluded reports are counted outside the main denominator, with reasons. The fictional in-app example is always calibration.

All percentages describe the displayed collection. A purposive or convenience collection does not establish population prevalence. Related datasets or programmes are not made independent by assigning report IDs. Do not create a total maturity/readiness score.

## Duplicate imports

The application flags possible same-stage duplicates using recorded publication identifiers, identical source hashes, or normalized titles where identifiers are absent. It never chooses the record with the preferred outcome. Affected percentages are withheld pending reconciliation.

A reviewer may retain the original record and mark another as its duplicate, with a reason. Both records and their history remain stored. The original must be present in the project and at the same stage; broken references withhold percentages. Identity checks cannot guarantee that all duplicates are found, so reconcile the corpus before a final audit.

## Focused full-text checks

The user states an evidence question before adding the next source bundle. The earlier central proposition, scope, source hash, revision and record reference are frozen in the new review. The new source is assessed independently for its own central claim and its evidence; AI addresses the focused question without replacing the main-objective selection rule.

Confirm whether the new central proposition is semantically the same or materially changed, and give a reason. A change in proposition is a claim-selection shift, not evidence reclassification of one claim. A later change to the current claim or scope invalidates the comparison until it is checked again. Source stages retain separate denominators in either case. Linked, unblinded follow-up does not establish a prospectively locked blinded A/B experiment.

## Exports

The same deterministic calculation produces the interface, Word/HTML report and central-claim CSV/JSON files. Exports present all reporting groups separately, independent of the filter for supplementary all-claim synthesis. They include numerator, denominator, unresolved and pending counts, exclusions, duplicate dispositions, source links, scope-selection rules and provenance.

## Prospective pilot before claims of equivalence

Freeze the article set and selection rule before assessment. Use independent full-text reference coding and preserve the reference primary claim. Compare focal selection accuracy, omitted material predicates, focal support and bridge/class accuracy, source/citation errors, completion time and reviewer workload. Record unresolved cases and claim-selection shifts. Report method and source strata separately. Do not call the focal workflow equivalent to full inventory coding on the strength of software tests or repeated model agreement.

The pilot has not been conducted by this software update. Software regression checks validate implementation behavior only.


## Amendment 1.2: preparation, review and evidence uncertainty

The EMP manual and bridge derivation remain v0.5. The following are workflow markers, not additional scientific EMP classes:

- TECH: incomplete or inconsistent coding, unmatched quotations, or a reported technical problem.
- DISPUTED: a correction has been requested; no scientific unresolved judgment is inferred.
- LEGACY: an earlier short-form unresolved decision whose reason category was not recorded. Its text and original coding remain preserved.
- PENDING: a central assessment is not yet available.

A new short-form unresolved decision requires an explicit evidence-uncertainty category and a reason. Merely not having reviewed the report is a draft. Submitted manual coding rounds retain their explicit scientific-uncertainty contract; their source and completeness checks still apply. Technical problems never become BU by changing bridgeClear.

All eligible reports remain visible in the selected source/protocol/basis group. If a group contains technical, disputed, legacy-unspecified or pending records, withhold its headline, resolved-only percentage and uncertainty bounds until those records are classifiable. Show each count and the reason. Resolved is B0+B1+B2+B3. BU is evidence uncertainty. Duplicate safeguards still apply. Human source-check provenance is retained even if validation later fails; failures must not move verified records into an AI group. Unverified human overrides are manual proposals.

AI correction uses the frozen central proposition, supplied source, reviewer feedback and current manual. Feedback does not count as evidence. Only unambiguous citation/enum formatting recovery is automatic; scientific changes remain a proposal. Store exact requests and outputs without credentials. Applying requires an explicit action against the same source hash and document revision, preserves original analysis and earlier decisions, and clears source verification for the changed assessment.

The five-article pilot is a purposeful calibration set, not a prevalence sample or a validated reference set. Stage A is uniform. The P01/P02/P05 full-text subset is specified before judging results. Keep stage and selection strata separate. Prepared notes, software tests, source retrieval and actual human usability observations have distinct completion states. No human-observed pilot is claimed by importing its sources.
