import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/automatic-fixture';
import {roundFixture} from './helpers/round-fixture';
import {readAnalysisExport,sourceContent,reconciliationCompatibility,reconciliationRows,validateReconciliationInputs,applyReconciliation,type Reconciliation,type ReconciliationInput} from '../lib/analysis-reconciliation';
import {ReconciliationStore} from '../lib/reconciliation-store';
function data(){const a=fixture().document,b=structuredClone(a);b.id='another';b.analysis!.claims[0].rationale='Another interpretation of the same source.';return {a,b,inputs:[{label:'A',origin:'current',document:a},{label:'B',origin:'upload',document:b}] as ReconciliationInput[]};}
test('full JSON input retains 80-claim and excerpt exports, rejects summaries and corrupt identities',()=>{
 const {a}=data();a.stage='Excerpt';for(let i=2;i<=80;i++)a.analysis!.claims.push({...structuredClone(a.analysis!.claims[0]),id:`C${i}`,primary:false});
 assert.equal(readAnalysisExport({document:a}).analysis!.claims.length,80);assert.equal(readAnalysisExport(a).stage,'Excerpt');assert.throws(()=>readAnalysisExport({summary:'A summary'}),/Full JSON/);
 a.analysis!.claims[1].id='C01';assert.throws(()=>readAnalysisExport(a),/identifiers/);
});
test('source compatibility verifies content rather than trusting imported hashes or filenames',()=>{
 const {a,b}=data();b.source.fileName='renamed.pdf';b.source.blocks[0].id='renamed';assert.equal(sourceContent(a),sourceContent(b));assert.equal(reconciliationCompatibility(a,b),'');
 b.source.blocks[0].text+=' Different evidence';b.sourceHash=a.sourceHash;assert.match(reconciliationCompatibility(a,b),/source text/);
 const c=structuredClone(a);c.stage='A';assert.match(reconciliationCompatibility(a,c),/Abstracts/);c.stage='B';c.review.reportType='M';assert.match(reconciliationCompatibility(a,c),/Report types/);c.review.reportType=null;delete c.analysis!.claims[0].v05;assert.match(reconciliationCompatibility(a,c),/coverage/);
});
test('claim alignment requires the same proposition, scope and central role; duplicate runs are rejected',()=>{
 const {a,b,inputs}=data();assert.doesNotThrow(()=>validateReconciliationInputs(inputs));assert.equal(reconciliationRows(inputs)[0].versions[1].sameClaim,true);
 b.analysis!.claims[0].id='OtherId';assert.equal(reconciliationRows(inputs)[0].versions[1].sameClaim,true);
 b.analysis!.claims[0].scope.decisionRule='Choose treatment by the biomarker';assert.equal(reconciliationRows(inputs)[0].versions[1].sameClaim,false);
 b.analysis!.claims[0]=structuredClone(a.analysis!.claims[0]);assert.throws(()=>validateReconciliationInputs(inputs),/duplicate/);
 b.analysis!.claims[0].statement='A treatment selection rule improves outcomes';assert.equal(reconciliationRows(inputs)[0].versions[1].sameClaim,false);
});
test('applying one recommendation preserves originals and resets every assessment to an unverified draft',()=>{
 const {a,inputs}=data(),before=structuredClone(a),candidate={...structuredClone(a.analysis!.claims[0]),rationale:'One recommended version after source verification.'};
 a.review.decisions.C01={claim:a.analysis!.claims[0],status:'accepted',comment:'Checked',sourceChecked:true,updatedAt:'now'};a.review.coverageChecked=true;
 const session:Reconciliation={id:crypto.randomUUID(),documentId:a.id,baseRevision:a.revision,sourceHash:a.sourceHash,createdAt:'now',model:'test',revision:1,inputs,candidates:[candidate]};
 const snapshot=structuredClone(a),review=applyReconciliation(a,session);assert.deepEqual(a,snapshot);assert.deepEqual(a.analysis,before.analysis);assert.equal(review.decisions.C01.status,'draft');assert.equal(review.decisions.C01.sourceChecked,false);assert.equal(review.coverageChecked,false);assert.equal(review.decisions.C01.correction?.proposalId,session.id);
 assert.throws(()=>applyReconciliation({...a,revision:2},session),/changed/);assert.throws(()=>applyReconciliation(a,{...session,candidates:[]}),/complete/);
 assert.throws(()=>applyReconciliation(a,{...session,candidates:[{...candidate,statement:'Easier claim'}]}),/selected claim/);
 assert.throws(()=>applyReconciliation(a,{...session,candidates:[{...candidate,scope:{...candidate.scope,outcome:'Another outcome'}}]}),/scope changed/);
 assert.throws(()=>applyReconciliation(a,{...session,candidates:[{...candidate,evidence:[{blockId:'b1',quote:'Invented evidence'}]}]}),/preparation problem/);
});
test('saved reconciliation is owner scoped, resumes immutable inputs and rejects concurrent/stale updates',async()=>{
 const f=roundFixture(),{inputs}=data(),store=new ReconciliationStore(f.env,'owner','doc');
 const session:Reconciliation={id:crypto.randomUUID(),documentId:'doc',baseRevision:0,sourceHash:'hash',createdAt:'now',model:'test',revision:0,inputs,candidates:[],originalUploads:[{raw:'Original file'}]};
 const initial=await store.save(session);assert.deepEqual(await store.get(),JSON.parse(JSON.stringify(initial)));assert.equal(await new ReconciliationStore(f.env,'other','doc').get(),null);
 const updated=await store.save({...initial,candidates:[inputs[0].document.analysis!.claims[0]]},0);assert.equal(updated.revision,1);assert.deepEqual(updated.originalUploads,session.originalUploads);
 await assert.rejects(store.save(initial,0),/changed/);assert.equal((await store.get())!.candidates.length,1);
 f.sql.prepare('UPDATE documents SET revision=1 WHERE id=?').run('doc');await assert.rejects(store.save(updated,1),/changed/);
});
