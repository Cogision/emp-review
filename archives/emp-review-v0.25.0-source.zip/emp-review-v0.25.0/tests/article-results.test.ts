import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/automatic-fixture';
import {articleResultRows,confirmArticleResults,articleResultsHtml} from '../lib/article-results';
import {applyCorrection,type CorrectionProposal} from '../lib/assessment-correction';
import {makeStageLink} from '../lib/reporting';
import {reportingDefaults} from '../lib/reporting-schema';

const input={claimIds:['C01','C02'],sourceChecked:true,selectionChecked:true,comment:''};
function data(){const d=fixture().document;d.analysis!.claims.push({...structuredClone(d.analysis!.claims[0]),id:'C02',primary:false});return d;}
test('summary and final review include active contexts without changing original evidence',()=>{
 const d=data(),before=structuredClone(d),review=confirmArticleResults(d,input);
 assert.deepEqual(d,before);assert.equal(articleResultRows(d).length,2);
 assert.ok(articleResultRows({...d,review}).every(r=>r.checked));
 assert.equal(review.decisions.C02.status,'accepted');assert.deepEqual(review.decisions.C01.claim,d.analysis!.claims[0]);
 const one=confirmArticleResults(d,{...input,claimIds:['C01']});assert.equal(one.decisions.C02,undefined);
 assert.throws(()=>confirmArticleResults(d,{...input,sourceChecked:false}),/source passages/);
 assert.throws(()=>confirmArticleResults(d,{...input,selectionChecked:false}),/claim selection/);
});
test('excluded and structural claims are outside the summary and cannot be confirmed',()=>{
 const d=data();d.review.decisions.C02={claim:d.analysis!.claims[1],status:'excluded',comment:'Outside scope',sourceChecked:true,updatedAt:'now'};
 assert.equal(articleResultRows(d).length,1);assert.throws(()=>confirmArticleResults(d,input),/active claim/);
 d.review.reportType='NC';assert.deepEqual(articleResultRows(d),[]);
});
test('unresolved confirmation preserves a scientific reason instead of correction processing notes',()=>{
 const d=data(),c=d.analysis!.claims[1];c.bridgeClear=false;c.rationale='The treatment interaction is not reported.';
 d.review.decisions.C02={claim:c,status:'draft',comment:'AI correction applied for review.',sourceChecked:false,updatedAt:'now'};
 const review=confirmArticleResults(d,input);assert.equal(review.decisions.C02.status,'unresolved');assert.equal(review.decisions.C02.concern,'evidence-uncertainty');assert.equal(review.decisions.C02.comment,c.rationale);
 assert.equal(articleResultRows({...d,review})[1].bridge,'BU');assert.equal(articleResultRows({...d,review})[1].checked,true);
 const noted=confirmArticleResults(d,{...input,comment:'I checked the results section.'});assert.match(noted.decisions.C02.comment,/interaction is not reported/);assert.match(noted.decisions.C02.comment,/results section/);
});
test('technical assessments and ambiguous central selection block final confirmation',()=>{
 const d=data();d.analysis!.claims[1].citation.quote='Invented quote';
 assert.equal(articleResultRows(d)[1].blocked,true);assert.throws(()=>confirmArticleResults(d,input),/flagged assessments/);
 assert.doesNotThrow(()=>confirmArticleResults(d,{...input,claimIds:['C01']}));
 d.analysis!.claims[1].primary=true;assert.throws(()=>confirmArticleResults(d,{...input,claimIds:['C01']}),/exactly one central/);
});
test('unknown adequacy is not reported as a demonstrated limitation',()=>{
 const d=data(),c=d.analysis!.claims[0];c.adequacy='Not assessed';
 assert.match(articleResultRows(d)[0].label,/adequacy not assessed/);assert.doesNotMatch(articleResultRows(d)[0].label,/limitations remain/);
 c.adequacy='Partial';assert.match(articleResultRows(d)[0].label,/limitations remain/);
});
test('contextual AI correction preserves the primary claim and cannot alter target identity',()=>{
 const d=data(),c=d.analysis!.claims[1],before=structuredClone(d);
 const p:CorrectionProposal={id:'proposal',documentId:d.id,baseRevision:d.revision,sourceHash:d.sourceHash,createdAt:'now',model:'test',feedback:'',before:structuredClone(c),candidate:{...structuredClone(c),evidenceSummary:'Clearer description of the same evidence.'}};
 const review=applyCorrection(d,p);assert.deepEqual(d,before);assert.equal(review.decisions.C01,undefined);assert.equal(review.decisions.C02.status,'draft');assert.equal(review.decisions.C02.sourceChecked,false);
 assert.throws(()=>applyCorrection(d,{...p,candidate:{...p.candidate,primary:true}}),/selected claim/);
 assert.throws(()=>applyCorrection(d,{...p,candidate:{...p.candidate,statement:'Another claim'}}),/selected claim/);
 d.review.decisions.C02={claim:c,status:'excluded',comment:'Out of scope',sourceChecked:true,updatedAt:'now'};assert.throws(()=>applyCorrection(d,p),/changed/);
});
test('print summary retains changed-claim warning, both propositions and escaped source content',()=>{
 const a=data(),b=structuredClone(a);a.stage='A';a.analysis!.claims[0].statement='Earlier decision claim';
 b.analysis!.claims[0].statement='Current prediction claim';b.title='<script>unsafe</script>';
 b.review.reporting={...reportingDefaults(),stageLink:{...makeStageLink(a,'Check the same claim'),relation:'changed',reason:'Different inference',comparedClaimId:'C01',comparedStatement:b.analysis!.claims[0].statement,comparedScope:JSON.stringify(b.analysis!.claims[0].scope)}};
 const html=articleResultsHtml(b);assert.match(html,/cannot be compared directly/);assert.match(html,/Earlier decision claim/);assert.match(html,/Current prediction claim/);assert.doesNotMatch(html,/<script>/);assert.match(html,/&lt;script&gt;/);
});
