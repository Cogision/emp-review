import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/automatic-fixture';
import {articleReview,articleReviewGuidance,type ArticleDecision} from '../lib/article-review';
import {publicationProfile} from '../lib/publication-profile';
import {reviewSchema} from '../lib/emp';

const confirmed:ArticleDecision={status:'accepted',comment:'',sourceChecked:true,selectionChecked:true};
test('article review preserves coding and contextual decisions; both checks are explicit',()=>{
 const d=fixture().document,c=d.analysis!.claims[0];
 d.analysis!.claims.push({...structuredClone(c),id:'C02',primary:false});
 d.review.decisions.C02={claim:d.analysis!.claims[1],status:'draft',comment:'Context untouched',sourceChecked:false,updatedAt:'old'};
 const before=structuredClone(d),review=articleReview(d,confirmed);
 assert.deepEqual(d,before);
 assert.deepEqual(review.decisions.C01.claim,c);
 assert.deepEqual(review.decisions.C02,before.review.decisions.C02);
 assert.equal(publicationProfile({...d,review}).checked,true);
 assert.ok(reviewSchema.safeParse(review).success);
 assert.throws(()=>articleReview(d,{...confirmed,selectionChecked:false}),/selected claim/);
 assert.throws(()=>articleReview(d,{...confirmed,sourceChecked:false}),/source passages/);
});
test('unresolved and inconsistent coding cannot be confirmed by the short form',()=>{
 const d=fixture().document;
 d.analysis!.claims[0].bridgeClear=false;
 assert.equal(articleReviewGuidance(d).state,'unresolved');
 assert.throws(()=>articleReview(d,confirmed),e=>e instanceof Error&&e.message.includes(d.analysis!.claims[0].rationale)&&e.message.includes('Save an unresolved review'));
 d.analysis!.claims[0].bridgeClear=true;
 d.analysis!.claims[0].citation.quote='This quotation is not in the source.';
 assert.equal(articleReviewGuidance(d).state,'technical');
 assert.throws(()=>articleReview(d,confirmed),/claim quotation was not found/);
 assert.throws(()=>articleReview(d,{...confirmed,status:'unresolved',concern:'evidence-uncertainty',comment:'The quotation needs checking.'}),/preparation error/);
 const review=articleReview(d,{...confirmed,status:'draft',concern:'technical',comment:'The quotation needs checking.'});
 assert.equal(publicationProfile({...d,review}).bridge,'TECH');
 assert.equal(review.decisions.C01.status,'draft');
});
test('a genuinely unresolved assessment can be reviewed with its displayed reason and explicit source checks',()=>{
 const d=fixture().document,c=d.analysis!.claims[0];
 c.bridgeClear=false;c.rationale='The abstract does not report the treatment comparison needed to assess selection.';
 c.questions=['Did the full-text analysis test differential treatment benefit?'];
 const before=structuredClone(d),guidance=articleReviewGuidance(d);
 assert.deepEqual(guidance,{state:'unresolved',issues:[],reason:c.rationale,questions:c.questions});
 const input:ArticleDecision={status:'unresolved',concern:'evidence-uncertainty',comment:guidance.reason,sourceChecked:false,selectionChecked:false};
 for(const checks of [{sourceChecked:false,selectionChecked:false},{sourceChecked:true,selectionChecked:false},{sourceChecked:false,selectionChecked:true},{sourceChecked:true,selectionChecked:true}]){
  const review=articleReview(d,{...input,...checks}),profile=publicationProfile({...d,review});
  assert.equal(profile.bridge,'BU');
  assert.equal(profile.checked,checks.sourceChecked&&checks.selectionChecked);
  assert.equal(review.decisions[c.id].comment,c.rationale);
  assert.deepEqual(review.decisions[c.id].claim,c);
 }
 assert.deepEqual(d,before);
 c.citation.quote='Not present in this source.';
 assert.equal(articleReviewGuidance(d).state,'technical');
 assert.throws(()=>articleReview(d,input),/preparation error/);
});
test('unresolved reasons persist without automatically marking unchecked work as reviewed',()=>{
 const d=fixture().document;
 const input:ArticleDecision={status:'unresolved',concern:'evidence-uncertainty',comment:'Full text is needed to settle this question.',sourceChecked:false,selectionChecked:false};
 assert.throws(()=>articleReview(d,{...input,comment:'  '}),/Explain/);
 const review=articleReview(d,input);
 assert.equal(publicationProfile({...d,review}).checked,false);
 assert.equal(review.decisions.C01.comment,input.comment);
 const draft=articleReview(d,{...input,status:'draft',concern:undefined,comment:''});
 assert.equal(draft.decisions.C01.status,'draft');
 assert.equal(draft.coverageChecked,false);
});
test('a previously unresolved decision can be confirmed after checking valid coding',()=>{
 const d=fixture().document;
 d.review=articleReview(d,{...confirmed,status:'unresolved',concern:'evidence-uncertainty',comment:'The available comparator evidence is unclear.'});
 assert.equal(publicationProfile(d).bridge,'BU');
 assert.equal(articleReviewGuidance(d).state,'resolved');
 const review=articleReview(d,confirmed);
 assert.equal(publicationProfile({...d,review}).bridge,'B0');
 assert.equal(publicationProfile({...d,review}).checked,true);
 d.analysis!.claims.push({...d.analysis!.claims[0],id:'C02',primary:true});
 assert.throws(()=>articleReview(d,confirmed),/one central claim/);
});
