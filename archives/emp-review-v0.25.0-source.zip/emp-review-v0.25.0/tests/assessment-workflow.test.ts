import {test} from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {fixture} from './helpers/automatic-fixture';
import {articleReview} from '../lib/article-review';
import {applyCorrection,correctionChanges,correctionRequestSchema,correctionInstruction,GENERAL_ASSESSMENT_CHECK,type CorrectionProposal} from '../lib/assessment-correction';
import {publicationMetrics,publicationHtml} from '../lib/publication-profile';
import {createProjectPackage} from '../lib/project-export';
import {pilotId,pilotManifest} from '../lib/pilot';
import type {ProjectData} from '../lib/projects';
function corpus():ProjectData{
 const documents=Array.from({length:4},(_,i)=>{const d=fixture().document;d.id=`paper-${i}`;d.sourceHash=`source-${i}`;d.title=`Different article ${i}`;d.review=articleReview(d,{status:'accepted',comment:'Checked',sourceChecked:true,selectionChecked:true});return {...d,studyGroup:''};});
 documents[0].review.decisions.C01.claim.evidenceSummary='';
 documents[1].review=articleReview(documents[1],{status:'draft',concern:'disagreement',comment:'The comparison seems wrong.',sourceChecked:true,selectionChecked:true});
 documents[2].review.decisions.C01.status='unresolved'; // Old short-form decision: no inferred reason.
 documents[3].review=articleReview(documents[3],{status:'unresolved',concern:'evidence-uncertainty',comment:'The abstract cannot establish the comparator.',sourceChecked:true,selectionChecked:true});
 return {project:{id:'p',title:'Workflow fixture',question:'',criteria:'',language:'en',revision:0,created_at:'now',updated_at:'now'},documents,generatedAt:'now'};
}
test('an optional correction note defaults to a neutral check and retains targeted requests',()=>{
 for(const feedback of [undefined,'','   \n\t']){
  const input=correctionRequestSchema.parse({action:'propose',revision:1,feedback});
  assert.equal(input.action,'propose');if(input.action!=='propose')throw Error('Wrong action');
  assert.equal(input.feedback,'');assert.equal(correctionInstruction(input.feedback),GENERAL_ASSESSMENT_CHECK);
 }
 assert.match(GENERAL_ASSESSMENT_CHECK,/Do not assume the assessment is wrong/);
 assert.match(GENERAL_ASSESSMENT_CHECK,/retain it unchanged/);
 for(const feedback of ['CRP','?','Please check the treatment interaction.']){
  const input=correctionRequestSchema.parse({action:'propose',revision:1,feedback:`  ${feedback}  `});
  if(input.action!=='propose')throw Error('Wrong action');assert.equal(input.feedback,feedback);assert.equal(correctionInstruction(input.feedback),feedback);
 }
 assert.equal(correctionRequestSchema.safeParse({action:'propose',revision:1,feedback:'x'.repeat(4001)}).success,false);
 assert.equal(correctionRequestSchema.safeParse({action:'propose',feedback:''}).success,false);
 assert.equal(correctionRequestSchema.safeParse({action:'apply',revision:1}).success,false);
});
test('technical, disputed and legacy records stay in their human group without becoming scientific uncertainty',()=>{
 const m=publicationMetrics(corpus(),'reviewed');assert.equal(m.strata.length,1);
 const g=m.strata[0];assert.equal(g.basis,'reviewed');assert.equal(g.included,4);assert.equal(g.counts.BU,1);
 assert.equal(g.counts.TECH,1);assert.equal(g.counts.DISPUTED,1);assert.equal(g.counts.LEGACY,1);assert.equal(g.resolved,0);assert.equal(g.unavailable,3);
 assert.equal(g.percent,null);assert.equal(g.resolvedPercent,null);assert.equal(g.upper,null);
});
test('correction applies only to its source revision, preserves original and other decisions, and clears source verification',()=>{
 const d=fixture().document;d.review=articleReview(d,{status:'accepted',comment:'Earlier human decision',sourceChecked:true,selectionChecked:true});
 const before=structuredClone(d),c=d.review.decisions.C01.claim,candidate={...structuredClone(c),evidenceSummary:'A clearer description of the same evidence.'};
 const proposal:CorrectionProposal={id:'proposal',documentId:d.id,baseRevision:d.revision,sourceHash:d.sourceHash,createdAt:'now',model:'Test',feedback:'Clarify the evidence summary.',before:structuredClone(c),candidate};
 const review=applyCorrection(d,proposal);assert.deepEqual(d,before);assert.equal(review.decisions.C01.status,'draft');assert.equal(review.decisions.C01.sourceChecked,false);assert.equal(review.decisions.C01.concern,undefined);
 assert.deepEqual(correctionChanges(c,candidate).map(c=>c.field),['evidenceSummary']);
 const general=applyCorrection(d,{...proposal,feedback:'',instruction:GENERAL_ASSESSMENT_CHECK});
 assert.match(general.decisions.C01.comment,/General assessment check requested with no additional note/);
 assert.equal(general.decisions.C01.status,'draft');assert.equal(general.decisions.C01.sourceChecked,false);
 assert.deepEqual(d,before);assert.deepEqual(correctionChanges(c,structuredClone(c)),[]);
 assert.throws(()=>applyCorrection({...d,revision:d.revision+1},proposal),/changed/);
 assert.throws(()=>applyCorrection({...d,sourceHash:'new-source'},proposal),/changed/);
 assert.throws(()=>applyCorrection(d,{...proposal,candidate:{...candidate,statement:'A different claim'}}),/selected claim/);
 assert.throws(()=>applyCorrection(d,{...proposal,candidate:{...candidate,evidence:[{blockId:'b2',quote:'Invented evidence'}]}}),/preparation problem/);
});
test('workflow distinctions and withheld percentages agree in HTML, Word, CSV and JSON',async()=>{
 const data=corpus(),blob=await createProjectPackage(data,'all','en'),zip=await JSZip.loadAsync(await blob.arrayBuffer());
 const metric=JSON.parse(await zip.file('central-claim-metrics.json')!.async('string'));assert.equal(metric.strata[0].counts.TECH,1);assert.equal(metric.strata[0].percent,null);assert.equal(metric.rows[0].workflow,'technical');
 assert.match(await zip.file('central-claim-metrics.csv')!.async('string'),/Technical.*Correction_requested/);
 const word=await JSZip.loadAsync(await zip.file('report.docx')!.async('uint8array'));
 for(const text of [await word.file('word/document.xml')!.async('string'),await zip.file('report.html')!.async('string')])assert.match(text,/Percentage withheld until these records are classifiable/);
 assert.match(publicationHtml(data.documents[0]),/Analysis needs repair/);
});
test('pilot imports have distinct stable owner-scoped identities and a non-validation protocol',async()=>{
 const ids=await Promise.all(pilotManifest.records.map(r=>pilotId('owner-a',r.id)));assert.equal(new Set(ids).size,5);
 assert.equal(ids[0],await pilotId('owner-a','P01'));assert.notEqual(ids[0],await pilotId('owner-b','P01'));assert.equal(pilotManifest.status,'prepared_not_run');
 assert.ok(pilotManifest.records.every(r=>r.pmid&&r.doi&&r.plannedStages.includes('A')));
});
