import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/automatic-fixture';
import {claimCategoryMetrics} from '../lib/claim-category-metrics';
import {publicationMetrics} from '../lib/publication-profile';
import {reportingDefaults} from '../lib/reporting-schema';
import type {ProjectData} from '../lib/projects';

function corpus():ProjectData{
 const d={...fixture().document,id:'00000000-0000-4000-8000-000000000001',title:'Claim category test',studyGroup:''};
 const c=d.analysis!.claims[0],inheritance={...structuredClone(c),id:'C02',primary:false},unresolved={...structuredClone(c),id:'C03',primary:false};
 inheritance.focal='I';inheritance.substitution='SE1';inheritance.role='Warrant';
 Object.assign(inheritance.v05!,{warrantFamily:'Clinical and functional relevance',warrantClaim:'Response under A',bridgeFrom:'Response under A',bridgeTo:'Choice of A over B'});
 unresolved.focal='U';d.analysis!.claims.push(inheritance,unresolved);
 return {project:{id:'p',title:'Synthetic count test',question:'',criteria:'Test only',language:'en',revision:0,created_at:'now',updated_at:'now'},documents:[d],generatedAt:'now'};
}
test('all-claim categories include context and unresolved while the primary metric is unchanged',()=>{
 const data=corpus(),before=JSON.stringify(data),primary=publicationMetrics(data,'provisional');
 const all=claimCategoryMetrics(data),g=all.groups[0];assert.equal(all.unit,'claim');assert.equal(g.total,3);assert.equal(g.central,1);assert.equal(g.contextual,2);assert.equal(g.reports,1);
 for(const code of ['B0','B2','BU']){const c=g.categories.find(c=>c.code===code)!;assert.equal(c.count,1);assert.equal(c.denominator,3);assert.equal(c.percent,100/3);}
 assert.equal(g.categories.reduce((n,c)=>n+c.count,0),3);assert.equal(g.blocked,false);
 const central=claimCategoryMetrics(data,'provisional','central').groups[0];assert.equal(central.total,1);assert.equal(central.contextual,0);assert.equal(central.categories.find(c=>c.code==='B0')!.percent,100);
 assert.deepEqual(publicationMetrics(data,'provisional'),primary);assert.equal(primary.strata[0].included,1);assert.equal(JSON.stringify(data),before);
});
test('each contextual claim keeps its own human or AI review status',()=>{
 const data=corpus(),d=data.documents[0],c=d.analysis!.claims[1];d.review.coverageChecked=true;d.review.decisions[c.id]={claim:structuredClone(c),status:'accepted',sourceChecked:true,comment:'Checked this contextual claim',updatedAt:'now'};
 const reviewed=claimCategoryMetrics(data,'reviewed');assert.equal(reviewed.groups.length,1);assert.equal(reviewed.groups[0].total,1);assert.equal(reviewed.groups[0].contextual,1);assert.equal(reviewed.groups[0].counts.B2,1);
 const ai=claimCategoryMetrics(data,'ai');assert.equal(ai.groups[0].total,2);assert.equal(ai.groups[0].counts.B2,0);
 assert.equal(claimCategoryMetrics(data).groups.length,2);assert.equal(claimCategoryMetrics(data,'reviewed','central').groups.length,0);
});
test('stages, selection rules, report types and calibration collections remain separate',()=>{
 const data=corpus(),original=data.documents[0];
 for(const kind of ['abstract','selective','methodological','calibration','adjudicated']){
  const d=structuredClone(original);d.id=kind;d.sourceHash=kind;d.title=`Different source ${kind}`;
  if(kind==='abstract')d.stage='A';
  if(kind==='selective')d.review.reporting={...reportingDefaults(),sourceSelection:'selective',selectionReason:'Targeted check'};
  if(kind==='methodological')d.review.reportType='M';
  if(kind==='calibration')d.review.reporting={...reportingDefaults(),role:'calibration',reason:'External worked example'};
  if(kind==='adjudicated')d.assessmentBasis={kind:'adjudicated',manualVersion:'v0.5'};
  data.documents.push(d);
 }
 const summary=claimCategoryMetrics(data);assert.equal(summary.groups.length,6);assert.ok(summary.groups.every(g=>g.total===3));
 assert.equal(summary.groups.filter(g=>g.population.startsWith('calibration:')).length,1);
});
test('excluded claims and structural reports contribute no observations',()=>{
 const data=corpus(),d=data.documents[0],c=d.analysis!.claims[1];d.review.decisions[c.id]={claim:c,status:'excluded',sourceChecked:false,comment:'Out of scope',updatedAt:'now'};
 assert.equal(claimCategoryMetrics(data).groups[0].total,2);
 d.review.reportType='NMC';assert.deepEqual(claimCategoryMetrics(data).groups,[]);
 assert.deepEqual(claimCategoryMetrics({...data,documents:[]}).groups,[]);
});
test('duplicates and preparation errors withhold percentages without erasing their counts',()=>{
 const data=corpus(),duplicate={...structuredClone(data.documents[0]),id:'duplicate'};data.documents.push(duplicate);
 let g=claimCategoryMetrics(data).groups[0];assert.equal(g.total,6);assert.equal(g.duplicateBlocked,true);assert.ok(g.categories.every(c=>c.percent===null));
 duplicate.review.reporting={...reportingDefaults(),duplicateOf:data.documents[0].id,duplicateReason:'Repeated import'};
 g=claimCategoryMetrics(data).groups[0];assert.equal(g.total,3);assert.equal(g.blocked,false);
 data.documents[0].analysis!.claims[1].evidenceSummary='';g=claimCategoryMetrics(data).groups[0];assert.equal(g.total,3);assert.equal(g.unavailable,1);assert.equal(g.counts.BU,1);assert.ok(g.categories.every(c=>c.percent===null));
});
test('an ambiguous central selection never becomes a zero-percent central result',()=>{
 const data=corpus();data.documents[0].analysis!.claims[1].primary=true;
 const central=claimCategoryMetrics(data,'provisional','central').groups[0];assert.equal(central.missingCentral,1);assert.equal(central.total,0);assert.ok(central.categories.every(c=>c.percent===null));
 assert.equal(claimCategoryMetrics(data).groups[0].total,3);
});
