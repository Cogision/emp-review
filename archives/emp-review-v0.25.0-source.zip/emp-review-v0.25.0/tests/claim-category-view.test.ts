import {test} from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './helpers/automatic-fixture';
import {claimCategoryMetrics} from '../lib/claim-category-metrics';
import {selectClaimCategoryGroup,collectionKey,methodName} from '../lib/claim-category-view';
import {reportingDefaults} from '../lib/reporting-schema';
import type {ProjectData} from '../lib/projects';
function corpus():ProjectData{
 const base=fixture().document;
 const documents=['full','abstract','excerpt','selective','methodological'].map(id=>{
  const d={...structuredClone(base),id,sourceHash:id,title:`Test article ${id}`,studyGroup:''};
  if(id==='abstract')d.stage='A';if(id==='excerpt')d.stage='Excerpt';
  if(id==='selective')d.review.reporting={...reportingDefaults(),sourceSelection:'selective',selectionReason:'Focused follow-up'};
  if(id==='methodological')d.review.reportType='M';
  return d;
 });
 return {project:{id:'p',title:'View test',question:'',criteria:'',language:'en',revision:0,created_at:'now',updated_at:'now'},documents,generatedAt:'now'};
}
test('the default is one existing full-text stratum, never pooled sources or report types',()=>{
 const summary=claimCategoryMetrics(corpus()),before=JSON.stringify(summary),v=selectClaimCategoryGroup(summary,{});
 assert.equal(v.group.stage,'B');assert.equal(v.group.reportType,'CB');assert.equal(v.group.total,1);assert.equal(v.methods.length,2);assert.ok(summary.groups.includes(v.group));assert.deepEqual(v.stages,['B','A','Excerpt']);assert.equal(JSON.stringify(summary),before);
});
test('selection changes cannot retain a table from a different material or collection',()=>{
 const summary=claimCategoryMetrics(corpus()),a=selectClaimCategoryGroup(summary,{});
 const b=selectClaimCategoryGroup(summary,{collection:a.collection,stage:'A',basis:a.basis,method:a.group.key});assert.equal(b.group.stage,'A');assert.notEqual(b.group.key,a.group.key);
 const methodological=summary.groups.find(g=>g.reportType==='M')!;
 const c=selectClaimCategoryGroup(summary,{collection:collectionKey(methodological),stage:'A',method:b.group.key});assert.equal(c.group,methodological);assert.equal(c.stage,'B');
 const empty=selectClaimCategoryGroup({...summary,groups:[]},{method:c.group.key});assert.equal(empty.group,undefined);assert.deepEqual(empty.methods,[]);
});
test('extended and unknown analysis protocols have distinguishable choices',()=>{
 const g=claimCategoryMetrics(corpus()).groups[0];
 const labels=['focal-v1','focal-v1-extended','focal-v2'].map(protocol=>methodName({...g,protocol}));assert.equal(new Set(labels).size,3);assert.match(labels[1],/Extended/);assert.match(labels[2],/focal-v2/);
});
test('a missing central claim stays selectable with no computed percentage',()=>{
 const data=corpus();data.documents=data.documents.slice(0,1);data.documents[0].analysis!.claims[0].primary=false;
 const summary=claimCategoryMetrics(data,'provisional','central'),v=selectClaimCategoryGroup(summary,{});assert.equal(v.group.total,0);assert.equal(v.group.missingCentral,1);assert.equal(v.group.blocked,true);assert.ok(v.group.categories.every(c=>c.percent===null));
});
