import {test} from 'node:test';
import assert from 'node:assert/strict';
import {roundFixture} from './helpers/round-fixture';
import {deleteReport} from '../lib/delete-report';
import {DraftStore} from '../lib/draft-store';
import {DraftController} from '../lib/draft-controller';
import {HttpError} from '../lib/http';
function setup(){const f=roundFixture();f.env.BUCKET.list=async({prefix}:any)=>({objects:[...f.objects.keys()].filter(k=>k.startsWith(prefix)).map(key=>({key})),truncated:false}) as any;f.env.BUCKET.delete=async(key:string|string[])=>{for(const k of Array.isArray(key)?key:[key])f.objects.delete(k);};return f;}
test('deletion removes owned reports, current project links and drafts while preserving frozen rounds',async()=>{
 const f=setup(),round=await f.create(),drafts=new DraftStore(f.env,'owner');
 await drafts.put('article:doc:notes',0,{format:1,base:'hash',data:{comment:'Remove this'}});await drafts.put('resume',0,{format:1,base:'',data:{id:'doc'}});await drafts.put('import',0,{title:'Keep this'});
 f.sql.prepare("INSERT INTO projects (id,owner,title,created_at,updated_at) VALUES ('p','owner','P','now','now')").run();f.sql.prepare("INSERT INTO project_documents (project_id,document_id,added_at) VALUES ('p','doc','now')").run();f.objects.set('documents/owner/doc/reconciliations/raw.json','private');
 await assert.rejects(deleteReport(f.env,'other','doc'),/not found/);assert.ok(f.sql.prepare('SELECT id FROM documents').get());
 await deleteReport(f.env,'owner','doc');assert.equal(f.sql.prepare('SELECT id FROM documents').get(),undefined);assert.equal(f.sql.prepare('SELECT document_id FROM project_documents').get(),undefined);assert.equal(f.sql.prepare('SELECT revision FROM projects').get()!.revision,1);
 assert.equal(f.sql.prepare("SELECT scope FROM workspace_drafts WHERE scope LIKE 'article:%'").get(),undefined);assert.equal((await drafts.get('resume')).value,null);assert.deepEqual((await drafts.get('import')).value,{title:'Keep this'});
 assert.equal(f.objects.has('documents/owner/doc/reconciliations/raw.json'),false);assert.ok(await f.owner.detail(round.round.id));
 await assert.rejects(drafts.put('article:doc:notes',0,{comment:'Resurrect'}),/not found/);
});
test('retiring a deleted article cancels queued writes without affecting other drafts',async()=>{
 let writes=0;const c=new DraftController('article:doc:notes',{note:''},'hash',true,async(_s,r)=>{if(r!==undefined)writes++;return {revision:0,value:null,updatedAt:null};});
 await c.load();c.set({note:'Pending'});await c.retire();await c.flush();await c.retry();c.set({note:'Too late'});assert.equal(writes,0);assert.equal(c.hasPending,false);
});
test('a remote deletion tombstone does not disable future resume bookmarks',async()=>{
 let revision=0,value:any=null;const send=async(_s:string,r?:number,next?:unknown)=>{if(r!==undefined){if(r!==revision)throw new HttpError('Conflict',409);revision++;value=next;}return {revision,value,updatedAt:'now'};};
 const c=new DraftController<{id:string}|null>('resume',null,'',false,send);await c.load();c.set({id:'deleted'});await c.flush();revision++;value=null;
 await c.reloadSaved();assert.equal(c.getSnapshot().value,null);assert.equal(c.blocked,false);assert.equal(c.hasPending,false);
 c.set({id:'another'});await c.flush();assert.equal(value.data.id,'another');
});
test('a draft upload finishing after report deletion cannot recreate its database entry',async()=>{
 const f=setup(),put=f.env.BUCKET.put.bind(f.env.BUCKET);let release!:()=>void,entered!:()=>void;
 const gate=new Promise<void>(r=>{release=r;}),ready=new Promise<void>(r=>{entered=r;});
 f.env.BUCKET.put=(async(k:string,v:any)=>{entered();await gate;return put(k,v);}) as typeof f.env.BUCKET.put;
 const pending=new DraftStore(f.env,'owner').put('article:doc:notes',0,{note:'Late write'});await ready;await deleteReport(f.env,'owner','doc');release();await assert.rejects(pending,/changed/);
 assert.equal(f.sql.prepare("SELECT scope FROM workspace_drafts WHERE scope LIKE 'article:%'").get(),undefined);
});
