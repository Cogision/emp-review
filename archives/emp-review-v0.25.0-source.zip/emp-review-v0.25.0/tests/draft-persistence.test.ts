import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DraftStore} from '../lib/draft-store';
import {DraftController} from '../lib/draft-controller';
import {HttpError} from '../lib/http';
import {roundFixture} from './helpers/round-fixture';
function server(){let revision=0,value:unknown=null;return {get value(){return value;},send:async(_scope:string,expected?:number,next?:unknown)=>{if(expected!==undefined){if(expected!==revision)throw new HttpError('Draft changed in another tab.',409);value=structuredClone(next);revision++;}return {revision,value:structuredClone(value),updatedAt:'now'};}};}
function deferred<T>(){let resolve!:(v:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return {promise,resolve};}
test('drafts survive reload, stay account scoped and never mutate assessment records',async()=>{
 const f=roundFixture(),before=f.sql.prepare('SELECT review,revision FROM documents').get(),a=new DraftStore(f.env,'owner'),b=new DraftStore(f.env,'other');
 await a.put('article:doc:notes',0,{comment:'Keep this note'});
 assert.deepEqual((await a.get('article:doc:notes')).value,{comment:'Keep this note'});
 await assert.rejects(b.get('article:doc:notes'),/not found/);
 await a.put('import',0,{title:'Private import'});assert.equal((await b.get('import')).value,null);
 assert.deepEqual(f.sql.prepare('SELECT review,revision FROM documents').get(),before);
 await assert.rejects(a.put('article:doc:notes',0,{comment:'Stale overwrite'}),/changed/);
 await a.put('article:doc:notes',1,null);assert.equal((await a.get('article:doc:notes')).revision,2);
 await assert.rejects(a.put('article:doc:notes',1,{comment:'Resurrect old draft'}),/changed/);
});
test('simultaneous first writes have one winner and keep its payload',async()=>{
 const f=roundFixture(),store=new DraftStore(f.env,'owner');const results=await Promise.allSettled([store.put('import',0,{title:'A'}),store.put('import',0,{title:'B'})]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal((await store.get('import')).revision,1);
});
test('loading never overwrites saved notes with defaults and reloading restores text',async()=>{
 const s=server();await s.send('x',0,{format:1,base:'source',data:{note:'Saved text'}});
 const waiting=deferred<any>(),c=new DraftController('resume',{note:''},'source',true,()=>waiting.promise);const load=c.load();c.set({note:'Must not overwrite before load'});assert.equal(c.blocked,true);waiting.resolve(await s.send('x'));await load;assert.equal(c.getSnapshot().value.note,'Saved text');
 const restored=new DraftController('resume',{note:''},'source',true,s.send);await restored.load();restored.set({note:'Revised text'});await restored.flush();const next=new DraftController('resume',{note:''},'source',true,s.send);await next.load();assert.equal(next.getSnapshot().value.note,'Revised text');assert.equal(next.getSnapshot().restored,true);
});
test('typing during a save persists the newest text after the first write',async()=>{
 const s=server(),gate=deferred<void>();let delayed=true;const c=new DraftController('resume',{note:''},'source',true,async(...args)=>{if(args[1]!==undefined&&delayed){delayed=false;await gate.promise;}return s.send(...args);});
 await c.load();c.set({note:'First'});const save=c.flush();c.set({note:'Newest'});gate.resolve();await save;assert.equal((s.value as any).data.note,'Newest');assert.equal(c.hasPending,false);
});
test('discard waits for in-flight save and cannot resurrect discarded text',async()=>{
 const s=server(),gate=deferred<void>();const c=new DraftController('resume',{note:''},'source',true,async(...args)=>{if(args[1]!==undefined&&args[2]!==null)await gate.promise;return s.send(...args);});
 await c.load();c.set({note:'Discard this'});const save=c.flush(),clear=c.clear();gate.resolve();await Promise.all([save,clear]);assert.equal(s.value,null);assert.equal(c.getSnapshot().value.note,'');assert.equal(c.hasPending,false);
});
test('revision change during save keeps the conflict visible and preserves recovery text',async()=>{
 const s=server(),gate=deferred<void>();const c=new DraftController('resume',{note:''},'r1',true,async(...args)=>{if(args[1]!==undefined)await gate.promise;return s.send(...args);});
 await c.load();c.set({note:'Keep me'});const save=c.flush();c.setBase('r2',{note:''});gate.resolve();await save;assert.equal(c.blocked,true);assert.equal(c.getSnapshot().status,'conflict');assert.equal(c.getSnapshot().recovery?.note,'Keep me');
});
test('another tab cannot be overwritten by retrying a conflicted local draft',async()=>{
 const s=server(),a=new DraftController('resume',{note:''},'source',true,s.send),b=new DraftController('resume',{note:''},'source',true,s.send);await Promise.all([a.load(),b.load()]);a.set({note:'Tab A'});await a.flush();b.set({note:'Tab B'});await b.flush();await b.retry();assert.equal(b.blocked,true);assert.equal(b.getSnapshot().value.note,'Tab B');assert.equal(b.getSnapshot().recovery?.note,'Tab A');assert.equal((s.value as any).data.note,'Tab A');
});
test('old assessment drafts are available for recovery but never applied to a new revision',async()=>{
 const s=server();await s.send('x',0,{format:1,base:'r1',data:{note:'Old interpretation'}});const c=new DraftController('resume',{note:'Current'},'r2',true,s.send);await c.load();assert.equal(c.getSnapshot().value.note,'Current');assert.equal(c.getSnapshot().recovery?.note,'Old interpretation');assert.equal(c.getSnapshot().status,'conflict');await c.clear();assert.equal(s.value,null);assert.equal(c.blocked,false);
});
