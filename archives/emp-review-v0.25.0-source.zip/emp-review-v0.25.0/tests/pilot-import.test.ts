import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {importPilotRecord,type PilotRecord} from '../lib/pilot-import';
import {deriveBridge} from '../lib/emp';
import {stageComparison} from '../lib/reporting';
import {publicationMetrics,calibrationMetrics,metricReportLines,calibrationNarrative,calibrationCalculationLines,calibrationComparisonNotice} from '../lib/publication-profile';
import {createProjectPackage,reportHtml} from '../lib/project-export';
import {claimCategoryMetrics} from '../lib/claim-category-metrics';
import JSZip from 'jszip';

const records=JSON.parse(readFileSync('lib/pilot-import-data.server.json','utf8')) as PilotRecord[];
const user={id:'site-scoped-user',email:'d.wiener@cogision.com'};
function fixture(){
 const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const f of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sql.exec(readFileSync(`drizzle/${f}`,'utf8'));
 const objects=new Map<string,string|Uint8Array>();let failPut=false,queue=Promise.resolve();
 function prepare(s:string){const bound=(args:unknown[]=[])=>({bind:(...a:unknown[])=>bound(a),first:async()=>sql.prepare(s).get(...args as any[])||null,all:async()=>({results:sql.prepare(s).all(...args as any[])}),run:async()=>({meta:{changes:Number(sql.prepare(s).run(...args as any[]).changes)}})});return bound();}
 const env={DB:{prepare,batch:(statements:any[])=>{const result=queue.then(async()=>{sql.exec('BEGIN');try{const out=[];for(const s of statements)out.push(await s.run());sql.exec('COMMIT');return out;}catch(e){sql.exec('ROLLBACK');throw e;}});queue=result.then(()=>{},()=>{});return result;}},BUCKET:{put:async(k:string,v:string|Uint8Array)=>{if(failPut&&k.includes('/originals/'))throw Error('storage interrupted');objects.set(k,v);},delete:async(k:string)=>{objects.delete(k);}}} as unknown as {DB:D1Database;BUCKET:R2Bucket};
 return {env,sql,objects,fail:()=>{failPut=true;},resume:()=>{failPut=false;}};
}
test('ten saved pilot assessments retain AI provenance, exact sources and calibration exclusions',async()=>{
 const f=fixture();for(const r of records)await importPilotRecord(f.env,user,r);
 const rows=f.sql.prepare('SELECT * FROM documents ORDER BY title,stage').all() as any[];
 assert.equal(rows.length,10);assert.equal(f.sql.prepare('SELECT * FROM project_documents').all().length,10);assert.equal(f.sql.prepare('SELECT * FROM projects').all().length,1);
 let claims=0;for(const row of rows){const a=JSON.parse(row.analysis),review=JSON.parse(row.review);claims+=a.claims.length;assert.equal(a.model,'Codex · imported pilot assessment');assert.equal(a.selection,undefined);assert.equal(a.automatic,undefined);assert.deepEqual(review.decisions,{});assert.equal(review.coverageChecked,false);assert.equal(review.reporting.role,'calibration');assert.equal(review.reporting.sourceSelection,'uniform');assert.equal(a.sourceHash,row.source_hash);assert.ok(f.objects.has(row.source_key));const original=records.find(r=>r.title===row.title&&r.stage===row.stage)!;assert.deepEqual(a.claims.map((c:any)=>deriveBridge(c,a.reportType)),original.analysis.claims.map(c=>deriveBridge(c,original.analysis.reportType)));assert.deepEqual(JSON.parse(String(f.objects.get(row.source_key.replace('text.json','pilot-audit.json')))).rawAssessment,original.rawAssessment);}
 assert.equal(claims,22);assert.equal(f.sql.prepare("SELECT * FROM assessment_runs WHERE actor_type!='ai'").all().length,0);
 const documents=rows.map(row=>({...row,sourceHash:row.source_hash,analysis:JSON.parse(row.analysis),review:JSON.parse(row.review),source:JSON.parse(String(f.objects.get(row.source_key))),studyGroup:''}));
 for(const view of ['reviewed','ai','provisional','adjudicated'] as const){const metric=publicationMetrics({documents} as any,view);assert.equal(metric.calibration,10);assert.equal(metric.strata.length,0);}
 for(const d of documents.filter(d=>d.stage==='B'&&d.analysis.claims.length)){assert.equal(stageComparison(d)?.stale,false);assert.match(stageComparison(d)!.link.reason,/AI comparison/);}
 for(const p of ['P02','P03']){const b=rows.find(r=>r.title===records.find(x=>x.pilotId===p&&x.stage==='B')!.title&&r.stage==='B');assert.equal(JSON.parse(b.review).reporting.stageLink.relation,'changed');}
 const data={project:{id:'pilot',title:'Supplied five-paper pilot',question:'',criteria:'Calibration only',language:'en' as const,revision:0,created_at:'now',updated_at:'now'},documents,generatedAt:'now'};
 const before=JSON.stringify(documents),calibration=calibrationMetrics(data);
 assert.equal(calibration.recordCount,10);assert.equal(calibration.includedInResearchMetric,false);assert.equal(calibration.changedClaims.length,2);
 assert.deepEqual(calibration.groups.map(g=>g.key),['psychiatry','external']);
 const psychiatric=calibration.groups[0];assert.equal(psychiatric.papers,4);assert.equal(psychiatric.recordCount,8);assert.deepEqual(psychiatric.types,{CB:5,M:1,NMC:2,NC:0,pending:0});
 const a=psychiatric.metrics.strata.find(g=>g.stage==='A')!,b=psychiatric.metrics.strata.find(g=>g.stage==='B')!;
 assert.equal(a.included,2);assert.equal(a.counts.B2,1);assert.equal(a.counts.BU,1);assert.equal(a.percent,50);assert.equal(a.resolvedPercent,100);
 assert.equal(b.included,3);assert.equal(b.counts.B2,0);assert.equal(b.counts.B0,3);assert.equal(b.percent,0);assert.equal(b.basis,'ai');
 assert.match(calibrationNarrative(a),/AI proposed evidential inheritance for 1 of 2/);assert.match(calibrationNarrative(a),/1 claim remains unresolved/);
 assert.match(calibrationNarrative(b),/AI did not flag evidential inheritance among 3/);assert.match(calibrationNarrative(b),/All 3 were assessed as supported within their scope/);
 assert.doesNotMatch(calibrationNarrative(a)+calibrationNarrative(b),/%/);
 assert.match(calibrationCalculationLines(a).join(' '),/Resolved assessments only: 1 \/ 1 \(100%\)/);
 assert.match(calibrationCalculationLines(a).join(' '),/not confidence in an assessment/);
 const changes=psychiatric.comparisons.filter(c=>c.status==='changed');assert.equal(changes.length,2);
 assert.equal(calibration.groups[1].comparisons.filter(c=>c.status==='changed').length,0);
 for(const change of changes){const source=documents.find(d=>d.id===change.documentId)!;assert.equal(change.earlierStatement,source.review.reporting.stageLink.statement);assert.equal(change.currentStatement,source.analysis.claims.find((c:any)=>c.primary).statement);}
 assert.equal(calibrationComparisonNotice(psychiatric)?.title,'These stages cannot be compared directly');
 assert.deepEqual(calibration.groups[1].metrics.strata.map(g=>g.included),[1,1]);
 assert.equal(calibrationMetrics(data,'reviewed').groups.flatMap(g=>g.metrics.strata).reduce((n,g)=>n+g.included,0),0);
 assert.equal(JSON.stringify(documents),before);assert.deepEqual(publicationMetrics(data,'provisional').strata,[]);
 const claimCounts=claimCategoryMetrics(data);assert.equal(claimCounts.groups.reduce((n,g)=>n+g.total,0),22);assert.ok(claimCounts.groups.every(g=>!g.blocked&&g.population.startsWith('calibration:')));
 assert.equal(claimCategoryMetrics(data,'provisional','central').groups.reduce((n,g)=>n+g.total,0),8);
 assert.equal(claimCategoryMetrics(data,'reviewed').groups.length,0);assert.equal(JSON.stringify(documents),before);
 const lines=metricReportLines(data).join('\n');assert.match(lines,/1 \/ 2 \(50%\)/);assert.match(lines,/0 \/ 3 \(0%\)/);assert.match(lines,/External calibration/);assert.match(lines,/not reclassifications/);assert.match(reportHtml(data,'accepted','en'),/Pilot and calibration results/);
 assert.ok(lines.indexOf('These stages cannot be compared directly')<lines.indexOf('1 / 2 (50%)'));
 assert.ok(lines.indexOf(calibrationNarrative(a))<lines.indexOf('1 / 2 (50%)'));
 const archive=await JSZip.loadAsync(await (await createProjectPackage(data,'accepted','en')).arrayBuffer());
 const json=JSON.parse(await archive.file('pilot-calibration-metrics.json')!.async('string'));assert.equal(json.groups[0].metrics.strata.find((g:any)=>g.stage==='A').percent,50);
 assert.match(await archive.file('pilot-calibration-metrics.csv')!.async('string'),/Calibration only/);
 const research=JSON.parse(await archive.file('central-claim-metrics.json')!.async('string'));assert.deepEqual(research.strata,[]);
 const word=await JSZip.loadAsync(await archive.file('report.docx')!.async('uint8array'));assert.match(await word.file('word/document.xml')!.async('string'),/1 \/ 2 \(50%\)/);
 const duplicate={...structuredClone(documents.find(d=>d.title===records[1].title&&d.stage==='B')!),id:'duplicate-pilot-record'};
 const dup=calibrationMetrics({...data,documents:[...documents,duplicate]});assert.equal(dup.groups[0].metrics.strata.find(g=>g.stage==='B')!.percent,null);assert.equal(dup.groups[1].metrics.strata.find(g=>g.stage==='B')!.percent,0);
 assert.match(calibrationNarrative(dup.groups[0].metrics.strata.find(g=>g.stage==='B')!),/withheld/);
 const edited=structuredClone(data),changed=edited.documents.find(d=>d.id===changes[0].documentId)!;changed.analysis.claims.find((c:any)=>c.primary).statement='A later central-claim correction';
 const updated=calibrationMetrics(edited).groups[0],comparison=updated.comparisons.find(c=>c.documentId===changed.id)!;
 assert.equal(comparison.status,'pending');assert.equal(comparison.stale,true);assert.equal(comparison.currentStatement,'A later central-claim correction');assert.match(calibrationComparisonNotice(updated)!.text,/1 claim comparison still needs checking/);
});
test('unauthorized accounts cannot read or write the supplied bundle through importer',async()=>{
 const f=fixture();for(const u of [null,{id:'other',email:'someone@example.com'},{id:'',email:user.email}])await assert.rejects(importPilotRecord(f.env,u,records[0]),/owner/);
 assert.equal(f.objects.size,0);assert.equal(f.sql.prepare('SELECT * FROM documents').all().length,0);
});
test('retry and concurrent opening create one record and preserve subsequent user decisions',async()=>{
 const f=fixture();const [a,b]=await Promise.all([importPilotRecord(f.env,user,records[0]),importPilotRecord(f.env,user,records[0])]);assert.equal(a.documentId,b.documentId);assert.equal(f.sql.prepare('SELECT * FROM documents').all().length,1);assert.equal(f.sql.prepare('SELECT * FROM events').all().length,1);assert.equal(f.sql.prepare('SELECT * FROM assessment_runs').all().length,1);assert.equal(f.objects.size,4);
 f.sql.prepare('UPDATE documents SET revision=4,review=? WHERE id=?').run('{"human_note":"preserve"}',a.documentId);const before=[...f.objects.keys()];await importPilotRecord(f.env,user,records[0]);const row=f.sql.prepare('SELECT revision,review FROM documents WHERE id=?').get(a.documentId) as any;assert.equal(row.revision,4);assert.equal(row.review,'{"human_note":"preserve"}');assert.deepEqual([...f.objects.keys()],before);
});
test('interrupted original upload leaves no partial document and can safely resume',async()=>{
 const f=fixture();f.fail();await assert.rejects(importPilotRecord(f.env,user,records[0]),/storage interrupted/);assert.equal(f.objects.size,0);assert.equal(f.sql.prepare('SELECT * FROM documents').all().length,0);f.resume();await importPilotRecord(f.env,user,records[0]);assert.equal(f.sql.prepare('SELECT * FROM documents').all().length,1);
});
