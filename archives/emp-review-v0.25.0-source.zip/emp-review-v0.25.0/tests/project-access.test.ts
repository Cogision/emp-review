import {test} from 'node:test';
import assert from 'node:assert/strict';
import {ProjectAccessStore} from '../lib/project-access';
import {roundFixture} from './helpers/round-fixture';
function fixture(){const f=roundFixture(),id=crypto.randomUUID();f.sql.prepare("INSERT INTO projects(id,owner,title,question,criteria,category,target_count,created_at,updated_at) VALUES(?,'owner','Shared project','PRIVATE_QUESTION','PRIVATE_CRITERIA','PRIVATE_CATEGORY',8,'now','now')").run(id);f.sql.prepare("INSERT INTO project_documents(project_id,document_id,added_at) VALUES(?,'doc','now')").run(id);const access=(who:string,email=`${who}@test.invalid`)=>new ProjectAccessStore(f.env,who,email);return {...f,id,access,po:access('owner')};}
type F=ReturnType<typeof fixture>;
async function invite(f:F,email='alice@test.invalid'){const p=await f.po.people(f.id),r=await f.po.action(f.id,{action:'invite',revision:p.revision,recipientEmail:email});assert.ok(r.invitation);return r.invitation;}
async function approve(f:F){const i=await invite(f);await f.access('alice').join({token:i.token,name:'Alice'});const p=await f.po.people(f.id);await f.po.action(f.id,{action:'approve',revision:p.revision,memberId:'alice'});return i;}
test('strangers cannot manage projects; pending membership exposes no private metadata',async()=>{
 const f=fixture(),a=f.access('alice');assert.deepEqual(await a.list(),[]);await assert.rejects(a.shared(f.id),/not found/);await assert.rejects(a.people(f.id),/not found/);
 const i=await invite(f);await a.join({token:i.token,name:'Alice'});const list=await a.list(),shared=await a.shared(f.id);
 assert.equal(list[0].role,'member');assert.equal(list[0].target_count,null);assert.equal(list[0].document_count,0);assert.deepEqual(shared.articles,[]);assert.deepEqual(shared.rounds,[]);assert.doesNotMatch(JSON.stringify({list,shared}),/PRIVATE_|Paper/);assert.deepEqual(f.reads,[]);
});
test('approved members receive inventory but no source, owner assessment, tokens or management rights',async()=>{
 const f=fixture();f.sql.prepare('UPDATE documents SET analysis=?,review=?').run('{"secret":"OWNER_AI_SECRET"}','{"secret":"OWNER_REVIEW_SECRET"}');await approve(f);const a=f.access('alice'),s=await a.shared(f.id);
 assert.deepEqual(s.articles.map(a=>({...a})),[{id:'doc',title:'Paper',stage:'B'}]);assert.equal(s.project.category,'PRIVATE_CATEGORY');assert.equal(s.project.target_count,8);assert.deepEqual(f.reads,[]);assert.doesNotMatch(JSON.stringify(s),/OWNER_AI_SECRET|OWNER_REVIEW_SECRET|source_key|token_hash|recipient_email/);
 await assert.rejects(a.people(f.id),/not found/);const revision=(await f.po.people(f.id)).revision;for(const body of [{action:'invite',recipientEmail:'bob@test.invalid'},{action:'approve',memberId:'alice'},{action:'remove',memberId:'alice'}])await assert.rejects(a.action(f.id,{...body,revision}),/not found/);
});
test('invitations bind authenticated email, store a hash, and can only be claimed once',async()=>{
 const f=fixture(),i=await invite(f,' ALICE@Test.Invalid ');assert.equal(i.recipientEmail,'alice@test.invalid');assert.doesNotMatch(JSON.stringify(f.sql.prepare('SELECT * FROM project_invites').get()),new RegExp(i.token));
 await assert.rejects(f.access('bob').join({token:i.token,name:'Alice',email:'alice@test.invalid'}),/email address/);await assert.rejects(f.access('alice','').join({token:i.token,name:'Alice'}),/email address/);assert.equal(f.sql.prepare('SELECT claimed_by FROM project_invites').get()!.claimed_by,null);
 const a=f.access('alice',' ALICE@test.invalid ');assert.deepEqual(await a.join({token:i.token,name:'Alice'}),{id:f.id});const rev=(await f.po.people(f.id)).revision;await a.join({token:i.token,name:'Alice'});assert.equal((await f.po.people(f.id)).revision,rev);await assert.rejects(f.access('another','alice@test.invalid').join({token:i.token,name:'Other'}),/unavailable/);
});
test('email changes between invitation read and claim cause an atomic rejection',async()=>{
 const f=fixture(),i=await invite(f),batch=f.env.DB.batch.bind(f.env.DB);f.env.DB.batch=(async(statements:any[])=>{f.sql.prepare("UPDATE project_invites SET recipient_email='bob@test.invalid'").run();return batch(statements);}) as typeof f.env.DB.batch;
 await assert.rejects(f.access('alice').join({token:i.token,name:'Alice'}),/unavailable/);assert.equal(f.sql.prepare('SELECT claimed_by FROM project_invites').get()!.claimed_by,null);assert.equal(f.sql.prepare('SELECT COUNT(*) AS n FROM project_members').get()!.n,0);
});
test('stale revisions cause no invitation or membership mutation',async()=>{
 const f=fixture(),i=await invite(f),before=f.sql.prepare('SELECT COUNT(*) AS n FROM project_access_events').get()!.n;
 await assert.rejects(f.po.action(f.id,{action:'invite',revision:0,recipientEmail:'bob@test.invalid'}),/project changed/);assert.equal(f.sql.prepare('SELECT COUNT(*) AS n FROM project_invites').get()!.n,1);assert.equal(f.sql.prepare('SELECT COUNT(*) AS n FROM project_access_events').get()!.n,before);
 const revision=(await f.po.people(f.id)).revision;await f.access('alice').join({token:i.token,name:'Alice'});await assert.rejects(f.po.action(f.id,{action:'approve',revision,memberId:'alice'}),/project changed/);assert.equal((await f.access('alice').shared(f.id)).membership,'pending');
});
test('revoked or expired tokens fail; removal requires a new invitation and approval',async()=>{
 const f=fixture(),i=await invite(f);let p=await f.po.people(f.id);await f.po.action(f.id,{action:'revoke',revision:p.revision,inviteId:p.invites[0].id});await assert.rejects(f.access('alice').join({token:i.token,name:'Alice'}),/unavailable/);
 const expired=await invite(f);f.sql.prepare("UPDATE project_invites SET expires_at='2000-01-01' WHERE claimed_by IS NULL").run();await assert.rejects(f.access('alice').join({token:expired.token,name:'Alice'}),/unavailable/);
 const used=await approve(f);p=await f.po.people(f.id);await f.po.action(f.id,{action:'remove',revision:p.revision,memberId:'alice'});assert.deepEqual(await f.access('alice').list(),[]);await assert.rejects(f.access('alice').shared(f.id),/not found/);await assert.rejects(f.access('alice').join({token:used.token,name:'Alice'}),/unavailable/);
 const replacement=await invite(f);await f.access('alice').join({token:replacement.token,name:'Alice'});assert.equal((await f.access('alice').shared(f.id)).membership,'pending');
});
test('project membership neither grants round access nor removes a separate round assignment',async()=>{
 const f=fixture();await approve(f);let r=await f.create();assert.deepEqual((await f.access('alice').shared(f.id)).rounds,[]);await assert.rejects(f.as('alice').detail(r.round.id),/not found/);
 r=await f.join(r,'alice');const shared=await f.access('alice').shared(f.id);assert.equal(shared.rounds[0].id,r.round.id);assert.equal(shared.rounds[0].membership,'pending');assert.equal((await f.as('alice').detail(r.round.id)).source,undefined);
 const p=await f.po.people(f.id);await f.po.action(f.id,{action:'remove',revision:p.revision,memberId:'alice'});await assert.rejects(f.access('alice').shared(f.id),/not found/);assert.equal((await f.as('alice').detail(r.round.id)).round.memberStatus,'pending');
});
