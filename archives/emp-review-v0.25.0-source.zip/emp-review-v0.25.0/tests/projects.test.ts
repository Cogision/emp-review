import {test} from "node:test";
import assert from "node:assert/strict";
import JSZip from "jszip";
import {demoAnalysis,demoSource} from "../lib/demo";
import {emptyReview,FAMILIES} from "../lib/emp";
import {synthesise,projectNarrative,type ProjectData,type ProjectDocument} from "../lib/projects";
import {createProjectPackage,csvCell,reportHtml,matrixSvg} from "../lib/project-export";
import {translate} from "../lib/i18n";
export function projectFixture():ProjectData{
 const doc:ProjectDocument={id:"report-a",title:"Synthetic study A",stage:"B",coverage:"Synthetic full text",sourceHash:"hash-a",revision:1,createdAt:"2026-09-05",updatedAt:"2026-09-05",studyGroup:"Cohort A",analysis:structuredClone(demoAnalysis),review:structuredClone(emptyReview),source:structuredClone(demoSource)};
 return {project:{id:"project-test",title:"EMP test collection",question:"What does the evidence support?",criteria:"Synthetic examples only",language:"en",revision:0,created_at:"2026-09-05",updated_at:"2026-09-05"},documents:[doc],generatedAt:"2026-09-05T00:00:00Z"};
}
test("synthesis separates report, study label and claim units and excludes NE from assessed denominator",()=>{
 const d=projectFixture();d.documents.push({...structuredClone(d.documents[0]),id:"report-b"});const s=synthesise(d);
 assert.equal(s.counts.reports,2);assert.equal(s.counts.groups,1);assert.equal(s.counts.claims,4);assert.equal(s.matrix.length,5);
 for(const row of s.matrix){assert.equal(Object.values(row.counts).reduce((a,b)=>a+b),4);assert.equal(row.assessed,4-row.counts.NE);}
 assert.notEqual(s.rows[0].key,s.rows[2].key);assert.equal(s.rows[0].claim.id,s.rows[2].claim.id);
});
test("effective structural types and excluded claims never enter substantive synthesis",()=>{
 const d=projectFixture(),c=d.documents[0].analysis!.claims[0];d.documents[0].review.decisions[c.id]={claim:c,status:"excluded",comment:"Excluded",sourceChecked:false,updatedAt:"now"};
 assert.equal(synthesise(d).counts.claims,1);d.documents[0].review.reportType="NC";assert.equal(synthesise(d).counts.claims,0);assert.equal(synthesise(d).counts.structural,1);
});
test("accepted counts and accepted filter both require source verification and resolved valid fields",()=>{
 const d=projectFixture(),doc=d.documents[0],c=doc.analysis!.claims[0];doc.review.decisions[c.id]={claim:structuredClone(c),status:"accepted",comment:"",sourceChecked:false,updatedAt:"now"};
 assert.equal(synthesise(d).counts.accepted,0);assert.equal(synthesise(d,"accepted").counts.claims,0);doc.review.decisions[c.id].sourceChecked=true;
 assert.equal(synthesise(d).counts.accepted,1);assert.equal(synthesise(d,"accepted").counts.claims,1);
 doc.review.decisions[c.id].claim.citation.quote="fabricated";assert.equal(synthesise(d,"accepted").counts.claims,0);assert.equal(synthesise(d).rows[0].bridge,"TECH");
});
test("review corrections drive synthesis while model proposal remains unchanged",()=>{
 const d=projectFixture(),doc=d.documents[0],c=structuredClone(doc.analysis!.claims[0]);c.statement="Corrected interpretation";
 doc.review.decisions[c.id]={claim:c,status:"draft",comment:"Correction",sourceChecked:false,updatedAt:"now"};
 assert.equal(synthesise(d).rows[0].claim.statement,c.statement);assert.notEqual(doc.analysis!.claims[0].statement,c.statement);
});
test("language switching changes labels without rewriting codes or source content",()=>{
 const d=projectFixture(),before=JSON.stringify(d);assert.equal(translate("Nowy przegląd","en"),"New review");assert.equal(translate("Nowy przegląd","pl"),"Nowy przegląd");
 assert.match(projectNarrative(d,"all","en")[0],/Reports in the project/);assert.match(projectNarrative(d,"all","pl")[0],/Raporty w projekcie/);assert.equal(JSON.stringify(d),before);
 for(const code of ["D","I","N0","U","NE","B0","B1","B2"])assert.equal(translate(code,"pl"),code);
});
test("project export preserves provenance and all raw records, escapes HTML and CSV, includes Word QC",async()=>{
 const d=projectFixture();d.project.title="<script>alert(1)</script>";d.documents[0].analysis!.claims[0].citation.quote="fabricated";
 const html=reportHtml(d,"all","en");assert.doesNotMatch(html,/<script>/);assert.match(html,/&lt;script&gt;/);assert.doesNotMatch(matrixSvg(d,"all","en"),/<script>/);assert.match(csvCell(" =1+1"),/^"'/);
 const blob=await createProjectPackage(d,"accepted","en"),z=await JSZip.loadAsync(await blob.arrayBuffer()),raw=JSON.parse(await z.file("project.json")!.async("string"));
 assert.equal(raw.documents[0].analysis.claims.length,2);assert.equal(raw.derived.rows.length,0);assert.equal(raw.documents[0].sourceHash,"hash-a");
 for(const file of ["claims.csv","profiles.csv","reports.csv","codebook.csv","report.html","report.docx","EMP_matrix.svg"])assert.ok(z.file(file));
 const all=await JSZip.loadAsync(await (await createProjectPackage(d,"all","pl")).arrayBuffer());const word=await JSZip.loadAsync(await all.file("report.docx")!.async("uint8array"));const xml=await word.file("word/document.xml")!.async("string");assert.match(xml,/QC:/);assert.match(xml,/EMP family/);assert.doesNotMatch(xml,/Rodzina EMP/);assert.match(xml,/3638/);
 assert.equal(FAMILIES.length,5);
});
