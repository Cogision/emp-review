import {test} from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {fixture} from './helpers/automatic-fixture';
import {publicationMetrics,metricReportLines,publicationHtml,calibrationNarrative,calibrationCalculationLines} from '../lib/publication-profile';
import {createProjectPackage,reportHtml} from '../lib/project-export';
import {reportingDefaults} from '../lib/reporting-schema';
import {stageComparison,makeStageLink,validateReporting} from '../lib/reporting';
import {confirmFocalSelection} from '../lib/focal-selection';
import {validateInventory} from '../lib/automatic';
import {claimIssues} from '../lib/emp';
import type {ProjectData} from '../lib/projects';

function corpus():ProjectData{
 const documents=Array.from({length:20},(_,i)=>{const f=fixture(),d={...f.document,id:`00000000-0000-4000-8000-${String(i+1).padStart(12,'0')}`,sourceHash:`source-${i}`,title:`Article ${i+1}`,studyGroup:''};
 const c=d.analysis!.claims[0];
 if(i<7){c.focal='I';c.substitution='SE1';c.role='Warrant';Object.assign(c.v05!,{warrantFamily:'Clinical and functional relevance',warrantClaim:'Association under one treatment',bridgeFrom:'Response under A',bridgeTo:'Selection of A over B'});}
 assert.deepEqual(claimIssues(c,d.source),[]);
 d.review.coverageChecked=true;d.review.decisions[c.id]={claim:c,status:i>=17?'unresolved':'accepted',...(i>=17?{concern:'evidence-uncertainty' as const}:{}),sourceChecked:true,comment:i>=17?'Required comparator cannot be determined.':'',updatedAt:'now'};return d;});
 return {project:{id:'p',title:'Synthetic reporting check',question:'One central claim per publication',criteria:'Software fixture only',language:'en',revision:1,created_at:'now',updated_at:'now'},documents,generatedAt:'now'};
}
test('20-report example yields 7/20, 7/17 and 35–50% bounds with unresolved preserved',()=>{
 const d=corpus(),m=publicationMetrics(d),g=m.strata[0];assert.equal(g.percent,35);assert.equal(g.included,20);assert.equal(g.resolved,17);assert.equal(g.resolvedPercent,700/17);assert.equal(g.counts.BU,3);assert.equal(g.lower,35);assert.equal(g.upper,50);
 // One pending review must not silently become a resolved negative.
 d.documents[19].review.decisions.C01.sourceChecked=false;const next=publicationMetrics(d);assert.equal(next.awaitingReview,1);assert.equal(next.strata.reduce((n,g)=>n+g.included,0),19);
});
test('additional claims never increase the denominator; calibration and exclusions are outside it',()=>{
 const d=corpus(),before=publicationMetrics(d).strata[0];for(const r of d.documents)r.analysis!.claims.push({...structuredClone(r.analysis!.claims[0]),id:'C02',primary:false});assert.deepEqual(publicationMetrics(d).strata[0],before);
 d.documents[0].analysis!.demo=true;d.documents[1].review.reporting={...reportingDefaults(),role:'excluded',reason:'Outside prespecified frame'};const m=publicationMetrics(d);assert.equal(m.calibration,1);assert.equal(m.excluded,1);assert.equal(m.strata[0].included,18);assert.equal(m.strata[0].counts.B2,5);
});
test('AI, human checks, adjudications and selective follow-up are never pooled',()=>{
 const d=corpus();d.documents[0].review.decisions.C01.sourceChecked=false;d.documents[1].assessmentBasis={kind:'adjudicated',manualVersion:'v0.5'};d.documents[2].review.reporting={...reportingDefaults(),sourceSelection:'selective',selectionReason:'Suspicious abstract'};
 const m=publicationMetrics(d,'provisional');assert.equal(m.strata.length,4);assert.equal(m.strata.find(g=>g.basis==='ai')?.included,1);assert.equal(m.strata.find(g=>g.basis==='adjudicated')?.included,1);assert.equal(m.strata.find(g=>g.sourceSelection==='selective')?.included,1);
 assert.equal(publicationMetrics(d,'ai').strata.reduce((n,g)=>n+g.included,0),1);
});
test('duplicates withhold percentages until a reviewer reconciles them; records survive',()=>{
 const d=corpus(),duplicate={...structuredClone(d.documents[0]),id:'00000000-0000-4000-8000-000000000021'};d.documents.push(duplicate);
 let m=publicationMetrics(d);assert.equal(m.duplicates.length,1);assert.equal(m.strata[0].percent,null);assert.equal(m.rows.length,21);
 duplicate.review.reporting={...reportingDefaults(),duplicateOf:d.documents[0].id,duplicateReason:'Same publication and source stage'};
 m=publicationMetrics(d);assert.equal(m.duplicates.length,0);assert.equal(m.strata[0].percent,35);assert.equal(m.reconciledDuplicates,1);assert.equal(m.rows.length,21);
 d.documents.shift();assert.ok(publicationMetrics(d).brokenDuplicates.length);assert.equal(publicationMetrics(d).strata[0].percent,null);
});
test('source links freeze the earlier claim and invalidate after current claim or scope changes',()=>{
 const d=corpus(),parent=d.documents[0],child=d.documents[1];parent.stage='A';const link=makeStageLink(parent,'Was A compared with B?');child.review.reporting={...reportingDefaults(),stageLink:{...link,relation:'same',reason:'Same predicate and material scope',comparedClaimId:'C01',comparedStatement:child.analysis!.claims[0].statement,comparedScope:JSON.stringify(child.analysis!.claims[0].scope)}};
 assert.equal(stageComparison(child)?.comparable,true);const frozen=child.review.reporting.stageLink!.statement;parent.review.decisions.C01.claim.statement='Later edit';assert.equal(child.review.reporting.stageLink!.statement,frozen);
 child.review.decisions.C01.claim.scope.population='Different population';assert.equal(stageComparison(child)?.status,'pending');assert.equal(stageComparison(child)?.comparable,false);
});
test('four focal claims require an explicit reason in discovery, confirmation and review',()=>{
 const f=fixture();f.state.selection={policy:'focal-v2'};f.state.claims=[];f.state.complete=false;const claims=Array.from({length:4},(_,i)=>({...f.state.inventory.claims[0],id:`C0${i+1}`,primary:i===0})),rationale='Main-objective selection';
 assert.throws(()=>confirmFocalSelection(f.state,{claims,rationale},f.document.source,'human'),/more than three/);
 const reason='The fourth predicate changes the population and required comparative evidence.';
 const c=confirmFocalSelection(f.state,{claims,rationale,extensionReason:reason},f.document.source,'human');assert.equal(c.inventory.claims.length,4);assert.equal(c.selection?.extensionReason,reason);
 const raw=JSON.stringify({...f.state.inventory,claims,extensionReason:reason});assert.equal(validateInventory(raw,f.document.source,'focal').inventory?.claims.length,4);
});
test('zero denominators are not 0%; reporting scope requires reasons',()=>{
 const d=corpus();d.documents=[];assert.deepEqual(publicationMetrics(d).strata,[]);const one=corpus().documents[0];assert.throws(()=>validateReporting({...reportingDefaults(),role:'calibration'},one),/reason/);
 one.review.decisions.C01.status='unresolved';one.review.decisions.C01.concern='evidence-uncertainty';one.review.decisions.C01.comment='The evidence needed to resolve the claim is missing.';const m=publicationMetrics({...corpus(),documents:[one]});assert.equal(m.strata[0].resolved,0);assert.equal(m.strata[0].resolvedPercent,null);
 assert.equal(calibrationNarrative(m.strata[0]),'The assessed central claim remains unresolved.');assert.doesNotMatch(calibrationNarrative(m.strata[0]),/did not flag|do not record/);
 assert.match(calibrationCalculationLines(m.strata[0]).join(' '),/not estimated because no claims have been resolved/);
});
test('Word, HTML, JSON and CSV use the same central metric independent of narrative filter',async()=>{
 const d=corpus();const lines=metricReportLines(d).join('\n');assert.match(lines,/7 \/ 20 \(35%\)/);assert.match(reportHtml(d,'accepted','en'),/7 \/ 20 \(35%\)/);
 const blob=await createProjectPackage(d,'accepted','en'),z=await JSZip.loadAsync(await blob.arrayBuffer()),word=await JSZip.loadAsync(await z.file('report.docx')!.async('uint8array'));
 assert.match(await word.file('word/document.xml')!.async('string'),/7 \/ 20 \(35%\)/);const metrics=JSON.parse(await z.file('central-claim-metrics.json')!.async('string'));assert.equal(metrics.strata[0].percent,35);assert.equal(metrics.strata[0].counts.BU,3);assert.match(await z.file('central-claim-metrics.csv')!.async('string'),/EI_percent_including_unresolved/);assert.ok(z.file('reporting-dispositions.csv'));
 const context={...structuredClone(d.documents[0].analysis!.claims[0]),id:'C02',primary:false,evidenceRequired:'Distinct comparative design is needed',rationale:'Context-specific rationale'};d.documents[0].analysis!.claims.push(context);const html=publicationHtml(d.documents[0]);assert.match(html,/Distinct comparative design is needed/);assert.match(html,/Context-specific rationale/);
});
