import {test} from 'node:test';
import assert from 'node:assert/strict';
import {claimIssues,syncV05} from '../lib/emp';
import {SCOPE_KEYS} from '../lib/v05';
import {demoSource} from '../lib/demo';
import {submissionIssues,assertSubmission,parseDraft} from '../lib/review-rounds';
import {translate} from '../lib/i18n';
import {fullDraft} from './helpers/full-round-fixture';

test('submission reports one actionable D conflict in English alongside exposure and decision checks',()=>{
 const draft=fullDraft();
 draft.priorExposure='';
 draft.claims[0].kindMatch='No';
 draft.fullFields!.C01.scopeCodes!.population='N';
 draft.fullFields!.C01.readoutRelation='R2';
 draft.fullFields!.C01.evidenceLocation='Programme or external report';
 const context={...structuredClone(draft.claims[0]),id:'C02',primary:false};
 draft.claims.push(context);
 draft.decisions.C02={status:'draft',sourceChecked:false,comment:''};
 const original=structuredClone(draft),issues=submissionIssues(draft,demoSource,'v0.5');
 assert.equal(issues.length,3);
 assert.match(issues[0],/previously seen AI or other assessments/);
 const direct=issues.filter(x=>x.startsWith('C01: D (direct support)'));
 assert.equal(direct.length,1);
 assert.match(direct[0],/Appropriate type of evidence\? = No/);
 assert.match(direct[0],/Population = N/);
 assert.match(direct[0],/Readout relation = R2/);
 assert.match(direct[0],/Evidence location = Programme or external report/);
 assert.match(issues[2],/C02: choose Your decision on this claim/);
 assert.doesNotMatch(issues.join('\n'),/[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]/);
 assert.throws(()=>assertSubmission(draft,demoSource,'v0.5'),e=>e instanceof Error&&e.message===issues.join('\n'));
 assert.deepEqual(draft,original,'Validation must not change the reviewer’s fields or code');
});

test('each incompatible scope dimension independently blocks D with its field and selected value',()=>{
 for(const key of SCOPE_KEYS)for(const code of ['N','X','U'] as const){
  const c=fullDraft().claims[0];
  c.v05!.scopeCodes[key]=code;
  const issues=claimIssues(syncV05(c),demoSource);
  assert.equal(issues.length,1,`${key}=${code}`);
  assert.match(issues[0],/D \(direct support\)/);
  assert.ok(issues[0].includes(`= ${code}`));
 }
});

test('D still requires matching evidence kind, readout and report location',()=>{
 const c=fullDraft().claims[0];
 assert.deepEqual(claimIssues(c,demoSource),[]);
 for(const kindMatch of ['No','Unclear'] as const)
  assert.equal(claimIssues({...c,kindMatch},demoSource).length,1);
 for(const readoutRelation of ['R2','R3','R4','RNA'] as const)
  assert.equal(claimIssues({...c,v05:{...c.v05!,readoutRelation}},demoSource).length,1);
 assert.equal(claimIssues({...c,v05:{...c.v05!,evidenceLocation:'Programme or external report'}},demoSource).length,1);
 const {v05,...core}=c;
 assert.deepEqual(claimIssues(core,demoSource),[]);
 assert.match(claimIssues({...core,scopeMatch:'Unclear'},demoSource)[0],/Does all relevant scope match\? = Unclear/);
 // The same fields are not errors merely because a reviewer selected indirect support.
 const indirect=syncV05({...c,focal:'I',kindMatch:'No',v05:{...c.v05!,readoutRelation:'R2',evidenceLocation:'Programme or external report',scopeCodes:{...c.v05!.scopeCodes,population:'N'}}});
 assert.deepEqual(claimIssues(indirect,demoSource),[]);
});

test('empirical equivalence still needs a valid quotation, and a condition is not reported twice',()=>{
 const c=fullDraft().claims[0];
 c.v05!.readoutRelation='R1';
 assert.match(claimIssues(c,demoSource)[0],/R1 requires/);
 c.v05!.equivalenceEvidence='Empirical equivalence described in the source.';
 c.v05!.equivalenceCitation=structuredClone(c.evidence[0]);
 assert.deepEqual(claimIssues(c,demoSource),[]);
 c.v05!.equivalenceCitation.quote='This quotation is not present in the source.';
 assert.match(claimIssues(c,demoSource)[0],/R1 requires/);
 c.v05!.readoutRelation='R0';
 c.v05!.condition='NC2';
 c.v05!.conditionMatches='Unclear';
 c.conditionCitation=null;
 const issues=claimIssues(syncV05(c),demoSource);
 assert.deepEqual(issues,['NC2 requires an exact source quotation of the specific condition.']);
});

test('empty full assessments and invalid draft payloads use English validation messages',()=>{
 const draft=fullDraft();
 draft.reportType='';draft.typeRationale='';draft.coverageChecked=false;draft.priorExposure='';
 draft.metadata={language:'en',bibliography:'',conflict:'declared',conflictDetails:'',operatorConfirmed:false};
 draft.fullFields!.C01={};draft.unanswered={C01:['kindMatch']};
 draft.decisions.C01={status:'unresolved',sourceChecked:false,comment:''};
 const issues=submissionIssues(draft,demoSource,'v0.5');
 assert.ok(issues.length>8);
 assert.doesNotMatch(issues.join('\n'),/[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ]/);
 assert.throws(()=>parseDraft({}),{message:'Invalid assessment fields.'});
});

test('legacy diagnostics translate with claim IDs, multiple lines and HTTP context intact',()=>{
 const legacy='D wymaga zgodności rodzaju dowodu i całego istotnego zakresu.';
 const english='D requires a match in evidence type and all relevant scope dimensions.';
 assert.equal(translate(`C01: ${legacy}`,'en'),`C01: ${english}`);
 assert.equal(translate(`C01: ${legacy}\nC02: ${legacy}`,'en'),`C01: ${english}\nC02: ${english}`);
 assert.equal(translate(`C01: ${legacy} (HTTP 422)`,'en'),`C01: ${english} (HTTP 422)`);
 const original='C01: Cytat użytkownika / original quotation\nThis is assessment text.';
 assert.equal(translate(original,'en'),original);
});
