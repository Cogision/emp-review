import assert from "node:assert/strict";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import test, { after } from "node:test";
import { fileURLToPath } from "node:url";

import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { createServer } from "vite";

const root = fileURLToPath(new URL("..", import.meta.url));
const vite = await createServer({
  appType: "custom",
  configFile: false,
  root,
  resolve: { alias: { "@": root } },
  server: { middlewareMode: true },
});

after(async () => {
  await vite.close();
});

async function readCssTree(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const contents = await Promise.all(
    entries.map(async (entry) => {
      const entryPath = path.join(directory, entry.name);
      if (entry.isDirectory()) {
        return readCssTree(entryPath);
      }
      return entry.name.endsWith(".css") ? readFile(entryPath, "utf8") : "";
    }),
  );
  return contents.join("\n");
}

test('reconciliation shows scope changes separately from assessment disagreements', async () => {
 const {ReconciliationTable}=await vite.ssrLoadModule('/components/analysis-reconciliation.tsx');
 const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
 const a=fixture().document,b=structuredClone(a);b.analysis.claims[0].scope.decisionRule='Use the biomarker to choose a drug';
 const inputs=[{label:'Open report',origin:'current',document:a},{label:'Analysis 2',origin:'upload',document:b}];
 const html=renderToStaticMarkup(React.createElement(ReconciliationTable,{inputs}));
 assert.match(html,/Different or missing claim \/ scope/);assert.match(html,/Claim in the open report/);assert.match(html,/Central claim/);assert.doesNotMatch(html,/confidence.*%/);
});

test('completed reports have a labeled delete action on the home page', async () => {
 const {default:Home}=await vite.ssrLoadModule('/components/workspace-home.tsx');
 const html=renderToStaticMarkup(React.createElement(Home,{articles:[{id:'done',title:'Completed report',analyzed:1,stage:'B'}],loading:false,disabled:false,onArticle(){},onProject(){},onContinue(){},onAll(){},onDelete(){}}));
 assert.match(html,/Assessment saved/);assert.match(html,/aria-label="Delete report: Completed report"/);assert.match(html,/>Delete<\/button>/);
});

test('claim category percentages are optional and show explicit denominators when expanded', async () => {
  const { default: Percentages, ClaimCategoryTables } = await vite.ssrLoadModule('/components/claim-category-percentages.tsx');
  const { claimCategoryMetrics } = await vite.ssrLoadModule('/lib/claim-category-metrics.ts');
  const { fixture } = await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
  const d=fixture().document;d.analysis.claims.push({...structuredClone(d.analysis.claims[0]),id:'C02',primary:false});
  const data={documents:[d]};
  const closed=renderToStaticMarkup(React.createElement(Percentages,{data,view:'provisional',disabled:false}));
  assert.match(closed,/Show percentages/);assert.match(closed,/role="switch"/);assert.match(closed,/aria-checked="false"/);assert.doesNotMatch(closed,/<table/);
  const open=renderToStaticMarkup(React.createElement(ClaimCategoryTables,{summary:claimCategoryMetrics(data)}));
  assert.match(open,/Share \(%\)/);assert.match(open,/2 claims from 1 article/);assert.match(open,/100%/);assert.match(open,/AI suggestions/);
  const empty=renderToStaticMarkup(React.createElement(ClaimCategoryTables,{summary:claimCategoryMetrics(data,'reviewed')}));
  assert.match(empty,/A percentage cannot be calculated/);assert.doesNotMatch(empty,/0%/);
});

test('AI assessment check is available with an empty or short optional note', async () => {
  const { default: Correction } = await vite.ssrLoadModule('/components/assessment-correction.tsx');
  const { fixture } = await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
  const props={document:fixture().document,apiKey:'',model:'test',disabled:false,reviewDirty:false,onDirty(){},onBusy(){},onApplied(){}};
  const {DraftContext}=await vite.ssrLoadModule('/components/draft-state.tsx');
  const {DraftController}=await vite.ssrLoadModule('/lib/draft-controller.ts');
  const scope=`article:${props.document.id}:correction:central`,controller=new DraftController(scope,null,props.document.sourceHash,true,async()=>({revision:0,value:null,updatedAt:null}));
  const pending=renderToStaticMarkup(React.createElement(Correction,{...props,initialFeedback:''}));assert.match(pending,/Looking for saved work/);
  await controller.load();
  const render=(initialFeedback,disabled=false)=>renderToStaticMarkup(React.createElement(DraftContext.Provider,{value:new Map([[scope,controller]])},React.createElement(Correction,{...props,initialFeedback,disabled})));
  for(const feedback of ['','   ','CRP','Check the comparator.']){
    const html=render(feedback);
    assert.match(html,/Your note \(optional\)/);assert.match(html,/leave the note empty for a general check/);
    assert.match(html,/no changes are needed/);
    const button=html.match(/<button\b[^>]*>Check assessment and suggest corrections<\/button>/)?.[0];
    assert.ok(button);assert.doesNotMatch(button,/\sdisabled(?:=|\s|>)/);
  }
  assert.match(render('',true).match(/<button\b[^>]*>Check assessment and suggest corrections<\/button>/)?.[0]||'',/\sdisabled(?:=|\s|>)/);
});

test('calibration results show changed claims and verification before collapsed percentages', async () => {
  const { default: CalibrationResults } = await vite.ssrLoadModule('/components/calibration-results.tsx');
  const { calibrationMetrics } = await vite.ssrLoadModule('/lib/publication-profile.ts');
  const { fixture } = await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
  const { makeStageLink } = await vite.ssrLoadModule('/lib/reporting.ts');
  const { reportingDefaults } = await vite.ssrLoadModule('/lib/reporting-schema.ts');
  const a=fixture().document,b=structuredClone(a);
  Object.assign(a,{id:'00000000-0000-4000-8000-000000000001',stage:'A',sourceHash:'abstract-hash'});
  Object.assign(b,{id:'00000000-0000-4000-8000-000000000002',stage:'B',sourceHash:'fulltext-hash'});
  a.analysis.demo=false;b.analysis.demo=false;
  a.analysis.claims[0].statement='Synthetic decision benefit claim';
  b.analysis.claims[0].statement='Synthetic response prediction claim';
  for(const d of [a,b])d.review.reporting={...reportingDefaults(),role:'calibration',publicationId:'10.1000/calibration-ui-test',reason:'Synthetic test'};
  const claim=b.analysis.claims[0];
  b.review.reporting.stageLink={...makeStageLink(a,'Does the full text support the same claim?'),relation:'changed',reason:'Decision benefit and response prediction differ.',comparedClaimId:claim.id,comparedStatement:claim.statement,comparedScope:JSON.stringify(claim.scope)};
  const render=view=>renderToStaticMarkup(React.createElement(CalibrationResults,{summary:calibrationMetrics({documents:[a,b]},view),onOpen(){},onShowAll(){},disabled:false}));
  const html=render('provisional'),visible=html.replace(/<details\b[^>]*>[\s\S]*?<\/details>/g,'');
  assert.match(visible,/These stages cannot be compared directly/);
  assert.match(visible,/Synthetic decision benefit claim/);assert.match(visible,/Synthetic response prediction claim/);
  assert.match(visible,/Unreviewed AI proposals/);assert.match(visible,/awaiting human verification/);
  assert.doesNotMatch(visible,/\d+(?:\.\d+)?%/);assert.doesNotMatch(html,/<details[^>]*\bopen/);
  assert.match(html,/Resolved assessments only/);assert.match(html,/not confidence in an assessment/);
  assert.match(render('reviewed'),/Show all saved pilot results/);
});

test("emits the catalog's animation and scrolling utilities", async () => {
  const css = await readCssTree(path.join(root, "dist"));

  assert.match(css, /--tw-enter-opacity/);
  assert.match(css, /scrollbar-width:\s*thin/);
  assert.match(css, /scrollbar-width:\s*none/);
  assert.match(css, /scrollbar-gutter:\s*stable/);
  assert.match(css, /scroll-fade-reveal-b/);
  assert.match(css, /mask-image:/);
  assert.match(css, /tw-shimmer/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test("forwards progress semantics to the primitive", async () => {
  const { Progress } = await vite.ssrLoadModule("/components/ui/progress.tsx");
  const html = renderToStaticMarkup(React.createElement(Progress, { value: 37 }));

  assert.match(html, /aria-valuenow="37"/);
  assert.match(html, /aria-valuetext="37%"/);
  assert.match(html, /data-state="loading"/);
});

test("emits chart themes for the starter's media dark mode", async () => {
  const { ChartStyle } = await vite.ssrLoadModule("/components/ui/chart.tsx");
  const html = renderToStaticMarkup(
    React.createElement(ChartStyle, {
      id: "contract",
      config: {
        latency: { theme: { light: "#ffffff", dark: "#000000" } },
      },
    }),
  );

  assert.match(html, /\[data-chart=contract\]/);
  assert.match(html, /@media \(prefers-color-scheme: dark\)/);
  assert.doesNotMatch(html, /\.dark/);
});

test("renders sidebar skeletons deterministically", async () => {
  const { SidebarMenuSkeleton } = await vite.ssrLoadModule(
    "/components/ui/sidebar.tsx",
  );
  const first = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));
  const second = renderToStaticMarkup(React.createElement(SidebarMenuSkeleton));

  assert.equal(first, second);
  assert.match(first, /--skeleton-width:70%/);
});

test('assessment controls expose separate help buttons and associated selected-code guidance', async () => {
  const { Choice, TextField } = await vite.ssrLoadModule('/components/claim-editor.tsx');
  const html=renderToStaticMarkup(React.createElement(Choice,{label:'Support for this exact claim',value:'N0',options:['D','I','N0','U'],onChange(){}}));
  assert.match(html,/aria-label="Help: Support for this exact claim"/);
  const id=html.match(/<label for="([^"]+)"/)[1];
  assert.ok(html.includes(`id="${id}"`));
  assert.ok(html.includes(`aria-describedby="${id}-hint"`));
  assert.match(html,/permitted source bundle reports no relevant evidence/);
  assert.doesNotMatch(html,/<label[^>]*>[^<]*<button/);
  const text=renderToStaticMarkup(React.createElement(TextField,{label:'Use predicate',helpId:'claim',value:'Example',onChange(){}}));
  const textId=text.match(/<label for="([^"]+)"/)[1];
  assert.ok(text.match(/<textarea[^>]*>/)[0].includes(`id="${textId}"`));
  assert.match(text,/aria-label="Help: Use predicate"/);
});

test('collection overview keeps scope warnings visible and methods collapsed across filters', async () => {
  const { default: Overview } = await vite.ssrLoadModule('/components/collection-overview.tsx');
  const { synthesise } = await vite.ssrLoadModule('/lib/projects.ts');
  const { demoAnalysis, demoSource } = await vite.ssrLoadModule('/lib/demo.ts');
  const { emptyReview } = await vite.ssrLoadModule('/lib/emp.ts');
  const analysis=structuredClone(demoAnalysis);
  analysis.automatic={inventoryComplete:false};
  const data={project:{id:'example'},documents:[{id:'example-report',analysis,source:demoSource,review:emptyReview,studyGroup:''}],generatedAt:'2026-09-05'};
  const render=filter=>renderToStaticMarkup(React.createElement(Overview,{data,summary:synthesise(data,filter),filter,onFilter(){}}));
  const all=render('all'),visible=all.split('<details')[0];
  assert.match(visible,/1 report has a claim list flagged as incomplete by AI/);
  assert.match(visible,/Exploratory scope includes drafts, unresolved decisions and unverified AI proposals/);
  assert.match(visible,/Needs checking in view/);
  assert.doesNotMatch(visible,/0 unavailable|0 structural|Form coverage|No meta-analysis/);
  assert.doesNotMatch(all,/<details[^>]*\bopen(?:=|\s|>)/);
  assert.match(all,/Scope &amp; methodology/);
  assert.match(all,/No meta-analysis/);
  const accepted=render('accepted');
  assert.match(accepted,/No claim assessments meet this filter yet/);
  assert.match(accepted,/Explore all active assessments/);
  assert.match(accepted,/assessments hidden by this filter/);
  assert.match(accepted.split('<details')[0],/1 report has a claim list flagged as incomplete by AI/);
});


test('reviewer access panel labels email, renders real invite states and locks actions',async()=>{
 const {default:Panel}=await vite.ssrLoadModule('/components/round-invitations-panel.tsx');
 const invites=[
  {id:'expired',recipientEmail:'old@example.invalid',expiresAt:'2000-01-01',claimed:false,revoked:false},
  {id:'live',recipientEmail:'new@example.invalid',expiresAt:'2099-01-01',claimed:false,revoked:false},
  {id:'legacy',recipientEmail:null,expiresAt:'2099-01-01',claimed:true,revoked:false},
 ];
 const html=renderToStaticMarkup(React.createElement(Panel,{invites,disabled:true,onCreate:async()=>{},onRevoke:async()=>{}}));
 assert.match(html,/Reviewer email/);assert.match(html,/type="email"/);assert.match(html,/Expired/);assert.match(html,/Awaiting reviewer/);assert.match(html,/Legacy invitation code/);assert.match(html,/Used/);
 assert.equal((html.match(/Revoke invitation/g)||[]).length,1);
 assert.doesNotMatch(html,/Email sent|Access granted/);
 for(const button of html.match(/<button[^>]*>/g)||[])assert.match(button,/disabled/);
});

test('automatic analysis has one claim bar and distinct pause, export and completion states',async()=>{
 const {default:Panel}=await vite.ssrLoadModule('/components/automatic-progress.tsx');
 const current={id:'one',title:'Example publication',phase:'claims',completed:22,total:38};
 const render=(overrides={})=>renderToStaticMarkup(React.createElement(Panel,{items:[current],running:true,stopping:false,exportReady:false,onStop(){},onResume(){},onDownload(){},error:'',...overrides}));
 const single=render();assert.equal((single.match(/role="progressbar"/g)||[]).length,1);assert.match(single,/22 of 38 claims assessed/);assert.doesNotMatch(single,/Completed publications|Publication details|Resume analysis/);
 const batch=render({items:[{id:'done',title:'Earlier report',phase:'complete',completed:10,total:10},current,{id:'next',title:'Next report',phase:'waiting',completed:0,total:0}]});
 assert.equal((batch.match(/role="progressbar"/g)||[]).length,1);assert.match(batch.replace(/<!--[\s\S]*?-->/g,''),/1 of 3 publications complete/);assert.match(batch,/<details[^>]*>/);assert.doesNotMatch(batch,/<details[^>]*\bopen/);
 const paused=render({running:false});assert.match(paused,/Analysis paused/);assert.match(paused,/Resume analysis/);assert.doesNotMatch(paused,/Pause after this step|animate-spin/);
 const exporting=render({exporting:true,exportReady:true});assert.match(exporting,/Preparing Word forms/);assert.doesNotMatch(exporting,/role="progressbar"|Pause after this step|Resume analysis|Download Word forms/);
 const complete=render({items:[{...current,phase:'complete',completed:38}],running:false,exportReady:true});assert.match(complete,/Analysis complete/);assert.match(complete,/Download Word forms/);assert.doesNotMatch(complete,/Resume analysis|role="progressbar"/);
 const empty=render({items:[{...current,total:0,completed:0}]});assert.doesNotMatch(empty,/role="progressbar"|NaN|Infinity/);
 const failed=render({items:[{...current,phase:'error',error:'Connection interrupted.'}],running:false});assert.match(failed,/Analysis needs attention/);assert.match(failed,/Retry unfinished analyses/);assert.match(failed,/role="alert"/);assert.doesNotMatch(failed,/Analysis complete/);
 const reviewable=render({items:[{...current,phase:'complete',completed:38}],running:false,exportReady:true,onReview(){},onDismiss(){}});
 assert.match(reviewable,/Review claims/);assert.match(reviewable,/Dismiss/);assert.doesNotMatch(reviewable,/role="progressbar"/);
 const active=render({onReview(){},onDismiss(){},exportReady:true});assert.doesNotMatch(active,/>Dismiss<|>Review claims</);
});

test('claim inventory retains scientific scope, source checks and structural report routing',async()=>{
 const {default:Inventory}=await vite.ssrLoadModule('/components/claim-inventory.tsx');
 const {demoAnalysis,demoSource}=await vite.ssrLoadModule('/lib/demo.ts');
 const {emptyReview}=await vite.ssrLoadModule('/lib/emp.ts');
 const document={analysis:structuredClone(demoAnalysis),source:demoSource,review:structuredClone(emptyReview)};
 const props={document,disabled:false,onOpen(){},onAdd(){},onContinue(){},onCoverage(){}};
 const html=renderToStaticMarkup(React.createElement(Inventory,props));
 assert.match(html,/Check the claim list/);assert.match(html,/not an independent study/);assert.match(html,/Continue to evidence/);
 assert.doesNotMatch(html,/<details[^>]*\bopen/);assert.match(html,/I have checked the source for missed claims/);
 document.review.reportType='NC';
 const structural=renderToStaticMarkup(React.createElement(Inventory,props));
 assert.match(structural,/Check report summary/);assert.doesNotMatch(structural,/Add a missed claim|Continue to evidence/);
 const locked=renderToStaticMarkup(React.createElement(Inventory,{...props,disabled:true}));
 const mainButton=(locked.match(/<button[^>]*>[\s\S]*?Check report summary[\s\S]*?<\/button>/)||[])[0];
 assert.ok(mainButton);assert.match(mainButton,/disabled/);
});

test('legacy report retains its detailed audit and comparison uses central claims only',async()=>{
 const {default:Profile}=await vite.ssrLoadModule('/components/publication-profile.tsx');
 const {default:Comparison}=await vite.ssrLoadModule('/components/publication-comparison.tsx');
 const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
 const document=fixture().document;
 document.analysis.selection={policy:'focal-v1',confirmedAt:'now',confirmedBy:'reviewer',rationale:'Main objective'};
 document.analysis.claims.push({...structuredClone(document.analysis.claims[0]),id:'C02',primary:false,statement:'Context-only finding'});
 const html=renderToStaticMarkup(React.createElement(Profile,{document,onReview(){},onDetails(){},onDeepen(){}}));
 assert.match(html,/support the central claim/);assert.match(html,/Detailed EMP audit/);assert.match(html,/AI proposal/);assert.match(html,/Download report/);assert.doesNotMatch(html,/<details[^>]*\bopen/);
 assert.ok(html.indexOf('central claim')<html.indexOf('Context-only finding'));
 const data={project:{id:'p'},documents:[{...document,studyGroup:''}],generatedAt:'now'};
 const table=renderToStaticMarkup(React.createElement(Comparison,{data,onOpen(){}}));
 assert.match(table,/Unreviewed AI proposals/);assert.doesNotMatch(table,/Context-only finding/);assert.match(table,/Detailed profiles across articles/);
 document.review.reportType='NC';
 const structural=renderToStaticMarkup(React.createElement(Profile,{document,onReview(){},onDetails(){},onDeepen(){}}));
 assert.doesNotMatch(structural,/Detailed EMP audit|Context-only finding/);
});


test('home starts with article or project and no headline metrics',async()=>{
 const {default:Home}=await vite.ssrLoadModule('/components/workspace-home.tsx');
 const html=renderToStaticMarkup(React.createElement(Home,{articles:[],loading:false,disabled:false,onArticle(){},onProject(){},onContinue(){},onAll(){}}));
 assert.match(html,/Analyse an article/);assert.match(html,/Create a project/);assert.match(html,/Continue your work/);assert.doesNotMatch(html,/\d+%|<table/);
 const {default:Steps}=await vite.ssrLoadModule('/components/article-steps.tsx');
 const steps=renderToStaticMarkup(React.createElement(Steps,{step:3,available:4,onStep(){}}));assert.match(steps,/aria-current="step"/);assert.match(steps,/Evidence &amp; links/);assert.equal((steps.match(/<li>/g)||[]).length,4);
});
test('article summary keeps verification per row and selected context opens its own evidence',async()=>{
 const {default:Results}=await vite.ssrLoadModule('/components/article-results.tsx');const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
 const d=fixture().document;d.analysis.claims.push({...structuredClone(d.analysis.claims[0]),id:'C02',primary:false,statement:'Selected contextual proposition'});
 const props={document:d,mode:'summary',disabled:false,apiKey:'',model:'test',onBusy(){},onApplied(){},onDirty(){},onStep(){},onEdit(){},onDetails(){},onConfirm:async()=>{},onRound(){},onAttach(){},onDeepen(){}};
 const html=renderToStaticMarkup(React.createElement(Results,props));assert.match(html,/Gap or evidence transition/);assert.match(html,/Selected contextual proposition/);assert.match(html,/Confirm the assessments I checked/);assert.match(html,/AI proposal · not reviewed/);assert.doesNotMatch(html,/\d+%/);assert.doesNotMatch(html,/<details[^>]*\bopen/);
 const context=renderToStaticMarkup(React.createElement(Results,{...props,mode:'evidence',selectedClaimId:'C02'}));assert.match(context,/<h3[^>]*>Selected contextual proposition<\/h3>/);
 d.analysis.claims[1].primary=true;const ambiguous=renderToStaticMarkup(React.createElement(Results,props));assert.match(ambiguous,/Choose exactly one central claim/);assert.doesNotMatch(ambiguous,/Central claim ·/);
 d.stage='A';const abstract=renderToStaticMarkup(React.createElement(Results,props));assert.match(abstract,/Add full text to start an independent review round/);
});
test('research collection percentages remain behind explicit optional controls',async()=>{
 const {default:Comparison}=await vite.ssrLoadModule('/components/publication-comparison.tsx');const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');const {confirmArticleResults}=await vite.ssrLoadModule('/lib/article-results.ts');
 const d=fixture().document;d.analysis.demo=false;d.review=confirmArticleResults(d,{claimIds:['C01'],selectionChecked:true,sourceChecked:true,comment:''});
 const html=renderToStaticMarkup(React.createElement(Comparison,{data:{project:{id:'p'},documents:[d],generatedAt:'now'},onOpen(){}}));
 assert.match(html,/Show central-claim percentages/);assert.match(html,/Show percentages/);assert.doesNotMatch(html,/<details[^>]*\bopen/);assert.doesNotMatch(html.replace(/<details\b[^>]*>[\s\S]*?<\/details>/g,'').replace(/<[^>]+>/g,''),/\d+(?:\.\d+)?%/);
});


test('claim percentages show one chosen table and explain a missing denominator without zero division',async()=>{
 const {ClaimCategoryTables}=await vite.ssrLoadModule('/components/claim-category-percentages.tsx');const {claimCategoryMetrics}=await vite.ssrLoadModule('/lib/claim-category-metrics.ts');const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');
 const a=fixture().document,b=structuredClone(a);a.id='a';a.stage='A';b.id='b';b.stage='B';b.sourceHash='different';b.title='Different synthetic report';
 const summary=claimCategoryMetrics({documents:[a,b]}),g=summary.groups.find(g=>g.stage==='B');const html=renderToStaticMarkup(React.createElement(ClaimCategoryTables,{summary,group:g}));
 assert.equal((html.match(/<table/g)||[]).length,1);assert.match(html,/Full text/);assert.match(html,/1 claims from 1 article/);assert.doesNotMatch(html,/Title and abstract/);
 a.analysis.claims[0].primary=false;const missing=claimCategoryMetrics({documents:[a]},'provisional','central');const empty=renderToStaticMarkup(React.createElement(ClaimCategoryTables,{summary:missing}));
 assert.match(empty,/needs a central claim selected/);assert.match(empty,/A denominator is not available/);assert.match(empty,/Not calculated/);assert.doesNotMatch(empty,/0 \/ 0|÷ 0|0%|NaN/);
});
test('article work status distinguishes saved assessments from checks and unsaved notes',async()=>{
 const {default:Status}=await vite.ssrLoadModule('/components/article-work-status.tsx');const {fixture}=await vite.ssrLoadModule('/tests/helpers/automatic-fixture.ts');const {confirmArticleResults}=await vite.ssrLoadModule('/lib/article-results.ts');
 const d=fixture().document,render=unsaved=>renderToStaticMarkup(React.createElement(Status,{document:d,unsaved,busy:false}));
 assert.match(render(false),/Saved · Awaiting your review/);assert.match(render(true),/Working changes · not applied/);assert.match(render(true),/Assessment confirmation remains a separate action/);assert.doesNotMatch(render(false),/Human review complete/);
 d.review=confirmArticleResults(d,{claimIds:['C01'],sourceChecked:true,selectionChecked:true,comment:''});assert.match(render(false),/Human review complete/);
});
